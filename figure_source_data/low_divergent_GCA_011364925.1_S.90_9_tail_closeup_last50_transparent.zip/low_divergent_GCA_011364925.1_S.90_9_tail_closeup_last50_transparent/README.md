# low_divergent_GCA_011364925.1_S.90_9_tail_closeup_last50_transparent

- Manuscript panel: Supp.Fig.6F
- Source figure basename: low_divergent_GCA_011364925.1_S.90_9_tail_closeup_last50_transparent
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 4 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 12 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
