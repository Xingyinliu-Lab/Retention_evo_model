# H_Volactin_like_Homo_ACTB_AF_superposed_transparent

- Manuscript panel: Supp.Fig.4F
- Source figure basename: H_Volactin_like_Homo_ACTB_AF_superposed_transparent
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 8 directly referenced or locally packaged source-data file(s)
