# asgard_gtdb_r226_actin_trait_mrca_events_ladder

- Manuscript panel: Supp.Fig.15A-part2
- Source figure basename: fig_asgard_gtdb_r226_actin_trait_mrca_events_ladder
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 7 directly referenced or locally packaged source-data file(s)
