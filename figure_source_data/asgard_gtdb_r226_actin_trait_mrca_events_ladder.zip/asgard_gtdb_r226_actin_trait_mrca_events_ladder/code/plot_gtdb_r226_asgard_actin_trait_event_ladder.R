#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(ragg)
})

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1L) {
  normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
} else {
  ".."
}
data_dir <- file.path(root, "data")
figure_dir <- file.path(root, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

event_dir <- file.path(
  data_dir, "gtdb_r226_asgard_actin_trait_events_calp_dalp_20260826"
)
events <- read_tsv(
  file.path(event_dir, "gtdb_r226_asgard_actin_trait_mrca_events.tsv"),
  show_col_types = FALSE
)
axis_source <- read_tsv(
  file.path(data_dir, "fig_asgard_gtdb_r226_class_mrca_axis_plot_source.tsv"),
  show_col_types = FALSE
)
remote_audit_file <- file.path(
  event_dir, "gtdb_r226_asgard_actin_trait_events_audit.json"
)

source_traits <- c(
  "trait_canonical_actin",
  "trait_canonical_multicopy",
  "trait_dalp_calp_coexistence",
  "trait_loki_canonical_multicopy",
  "trait_canonical_with_intermediate_or_high_tail",
  "trait_canonical_with_high_tail"
)
excluded_display_traits <- c(
  "trait_canonical_multicopy",
  "trait_loki_canonical_multicopy"
)
allowed_traits <- setdiff(source_traits, excluded_display_traits)
forbidden_traits <- c(
  "trait_any_actin_like",
  "trait_crenactin",
  "trait_actin_multicopy"
)
stopifnot(
  nrow(events) == 6,
  setequal(events$trait, source_traits),
  !any(events$trait %in% forbidden_traits),
  all(events$gtdb_release == "r226"),
  all(events$tree_present_n > 0),
  all(!is.na(events$mrca_asgard_axis_norm)),
  all(events$mrca_asgard_axis_norm >= 0),
  all(events$mrca_asgard_axis_norm <= 1),
  nrow(axis_source) == 12,
  all(axis_source$gtdb_release == "r226"),
  file.exists(remote_audit_file)
)
events <- events %>% filter(trait %in% allowed_traits)

class_window_min_raw <- min(axis_source$x_log_raw)
class_window_max_raw <- max(axis_source$x_log_raw)
display_left <- 0.18
display_right <- 0.78
expand_class_window <- function(x) {
  ifelse(
    x <= class_window_min_raw,
    display_left * x / max(class_window_min_raw, .Machine$double.eps),
    ifelse(
      x <= class_window_max_raw,
      display_left +
        (display_right - display_left) *
          (x - class_window_min_raw) /
          (class_window_max_raw - class_window_min_raw),
      display_right +
        (1 - display_right) *
          (x - class_window_max_raw) /
          max(1 - class_window_max_raw, .Machine$double.eps)
    )
  )
}

lane_levels <- c("cALP", "copy architecture", "tail state")
lane_y <- c(
  "cALP" = 4.25,
  "copy architecture" = 2.45,
  "tail state" = 0.70
)
lane_colors <- c(
  "cALP" = "#3E7CB1",
  "copy architecture" = "#6A994E",
  "tail state" = "#C85A54"
)

plot_source <- events %>%
  mutate(
    lane = recode(lane, "canonical actin" = "cALP"),
    lane = factor(lane, levels = lane_levels),
    label = recode(
      trait,
      "trait_canonical_actin" = "cALP present",
      "trait_canonical_multicopy" = "cALP multicopy >=2",
      "trait_dalp_calp_coexistence" =
        "dALP-cALP coexistence (subset distribution bound)",
      "trait_loki_canonical_multicopy" = "Loki cALP multicopy >=2",
      "trait_canonical_with_intermediate_or_high_tail" =
        "cALP intermediate-or-high tail",
      "trait_canonical_with_high_tail" = "cALP high euk-like tail"
    ),
    x_log_raw = log1p(99 * mrca_asgard_axis_norm) / log(100),
    x_display = expand_class_window(x_log_raw),
    lane_y = unname(lane_y[as.character(lane)]),
    label_offset = case_when(
      trait == "trait_canonical_actin" ~ 0.35,
      trait == "trait_dalp_calp_coexistence" ~ 0,
      trait == "trait_canonical_with_intermediate_or_high_tail" ~ -0.45,
      trait == "trait_canonical_with_high_tail" ~ 0.45,
      TRUE ~ 0
    ),
    label_y = lane_y + label_offset,
    scope_label = sub("^[pc]__", "", mrca_named_scope),
    label_text = paste0(
      label,
      " (MAG=", n_mag,
      "; r226 tips=", n_gtdb_tips,
      "; classes=", observed_class_n,
      "; MRCA=", scope_label,
      ")"
    )
  ) %>%
  arrange(event_order)

write_tsv(
  plot_source,
  file.path(data_dir, "fig_asgard_gtdb_r226_actin_trait_ladder_plot_source.tsv")
)

audit <- tibble(
  metric = c(
    "gtdb_release",
    "phenotype_mag_n",
    "matched_mag_n",
    "trait_n",
    "trait_with_mrca_n",
    "forbidden_trait_n",
    "asgard_root_event_n",
    "within_asgard_event_n",
    "figure_status"
  ),
  value = c(
    "r226",
    "971",
    "971",
    as.character(nrow(plot_source)),
    as.character(sum(!is.na(plot_source$mrca_asgard_axis_norm))),
    as.character(sum(plot_source$trait %in% forbidden_traits)),
    as.character(sum(plot_source$mrca_asgard_axis_norm == 0)),
    as.character(sum(plot_source$mrca_asgard_axis_norm > 0)),
    "strict_complete_display_without_cALP_multicopy_events"
  )
)
write_tsv(
  audit,
  file.path(data_dir, "fig_asgard_gtdb_r226_actin_trait_ladder_audit.tsv")
)

class_colors <- setNames(axis_source$colour, axis_source$c)
class_window_start <- min(axis_source$x_display)
class_window_end <- max(axis_source$x_display)
original_breaks <- c(0, 0.01, 0.025, 0.05, 0.10, 0.20, 0.40, 0.60, 0.80, 1)
display_breaks <- expand_class_window(
  log1p(99 * original_breaks) / log(100)
)

p <- ggplot(plot_source) +
  geom_segment(
    data = tibble(
      lane = factor(lane_levels, levels = lane_levels),
      lane_y = unname(lane_y[lane_levels])
    ),
    aes(x = 0, xend = 1, y = lane_y, yend = lane_y),
    inherit.aes = FALSE,
    linewidth = 0.45,
    colour = "#D8D8D8"
  ) +
  geom_segment(
    aes(
      x = x_display, xend = x_display,
      y = lane_y, yend = label_y,
      colour = lane
    ),
    linewidth = 0.38,
    alpha = 0.75
  ) +
  geom_segment(
    aes(
      x = x_display, xend = x_display,
      y = lane_y - 0.10, yend = lane_y + 0.10,
      colour = lane
    ),
    linewidth = 1.15,
    lineend = "butt"
  ) +
  geom_point(
    aes(x = x_display, y = lane_y, fill = lane),
    shape = 21, size = 2.25, stroke = 0.4, colour = "white"
  ) +
  geom_text(
    aes(
      x = x_display + 0.015,
      y = label_y,
      label = label_text,
      colour = lane
    ),
    family = "Arial",
    size = 2.30,
    hjust = 0,
    lineheight = 0.92
  ) +
  annotate(
    "segment",
    x = 0, xend = 1, y = -0.58, yend = -0.58,
    linewidth = 5.2, colour = "#C8CDD5", lineend = "butt"
  ) +
  geom_segment(
    data = axis_source,
    aes(
      x = interval_start_display,
      xend = interval_end_display,
      y = -0.58, yend = -0.58,
      colour = c
    ),
    inherit.aes = FALSE,
    linewidth = 5.2,
    lineend = "butt",
    alpha = 0.92
  ) +
  annotate(
    "text",
    x = class_window_start / 2, y = -0.83,
    label = "shared Asgard stem",
    family = "Arial", size = 2.55, colour = "#555555"
  ) +
  annotate(
    "text",
    x = (class_window_start + class_window_end) / 2, y = -0.83,
    label = "class MRCA window",
    family = "Arial", size = 2.55, colour = "#465166"
  ) +
  annotate(
    "text",
    x = (class_window_end + 1) / 2, y = -0.83,
    label = "within-class diversification to tips",
    family = "Arial", size = 2.55, colour = "#555555"
  ) +
  annotate(
    "text",
    x = 0, y = -1.05,
    label = "Asgardarchaeota MRCA",
    family = "Arial", size = 2.45, hjust = 0, colour = "#555555"
  ) +
  annotate(
    "text",
    x = 1, y = -1.05,
    label = "GTDB r226 Asgard tips",
    family = "Arial", size = 2.45, hjust = 1, colour = "#555555"
  ) +
  scale_colour_manual(
    values = c(lane_colors, class_colors),
    guide = "none"
  ) +
  scale_fill_manual(values = lane_colors, guide = "none") +
  scale_x_continuous(
    limits = c(-0.025, 1.025),
    breaks = display_breaks,
    labels = c("0", "0.01", "0.025", "0.05", "0.1",
               "0.2", "0.4", "0.6", "0.8", "1"),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    limits = c(-1.18, 5.35),
    breaks = unname(lane_y),
    labels = names(lane_y),
    expand = expansion(mult = 0)
  ) +
  labs(
    title = "Observed MRCA bounds of cALP/dALP distributions on the GTDB r226 Asgard axis",
    subtitle = paste0(
      "Taxon-name projections for 971 Asgard MAGs; ",
      "4 displayed traits passed strict r226 audit; cALP multicopy events are omitted"
    ),
    caption = paste0(
      "Three displayed traits project to the Asgardarchaeota MRCA; dALP-cALP coexistence ",
      "projects within the shared Asgard stem. ",
      "These are earliest-observed distribution bounds, not inferred gains or dates.\n",
      "The coexistence set is the intersection of cALP- and dALP-positive MAGs. Its more tipward MRCA is a subset-distribution bound, ",
      "not evidence that coexistence first evolved there. cALP multicopy, any-actin and all-actin events are omitted."
    ),
    x = paste0(
      "normalized GTDB r226 Asgardarchaeota root-to-MRCA depth ",
      "(log- and piecewise-expanded display)"
    ),
    y = NULL
  ) +
  theme_void(base_family = "Arial", base_size = 8) +
  theme(
    axis.text.y = element_text(
      face = "bold", size = 8, colour = "#333333",
      hjust = 1, margin = margin(r = 8)
    ),
    axis.text.x = element_text(size = 7.1, colour = "#566174"),
    axis.ticks.x = element_line(linewidth = 0.3, colour = "#7C8799"),
    axis.ticks.length = grid::unit(2.5, "pt"),
    axis.title.x = element_text(
      size = 7.7, colour = "#465166", margin = margin(t = 7)
    ),
    plot.title = element_text(face = "bold", size = 11, colour = "#111111"),
    plot.subtitle = element_text(size = 8.2, colour = "#5D6675"),
    plot.caption = element_text(
      size = 6.6, colour = "#667085", hjust = 0, lineheight = 1.1
    ),
    plot.margin = margin(10, 18, 16, 14)
  ) +
  coord_cartesian(clip = "off")

stem <- file.path(
  figure_dir, "fig_asgard_gtdb_r226_actin_trait_mrca_events_ladder"
)
ggsave(
  paste0(stem, ".pdf"),
  p,
  width = 12.6, height = 6.0, units = "in",
  device = cairo_pdf
)
agg_png(
  paste0(stem, ".png"),
  width = 12.6, height = 6.0, units = "in", res = 600
)
print(p)
dev.off()

message("Saved Asgard cALP/dALP-coexistence actin-trait ladder: 4 displayed events")
