suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
})

base_dir <- ".."
src_dir <- file.path(base_dir, "source_data")
fig_dir <- file.path(base_dir, "figures")
detail_file <- file.path(
  src_dir, "static_tail_full156_residue_contacts_20260804",
  "static_tail_full156_residue_model_detail.tsv"
)

detail <- read_tsv(detail_file, show_col_types = FALSE) %>%
  select(organism, state, template, actin_ref_position, contact_5A)

sequence_length <- c("Human ACTB" = 375, "Rabbit ACTA1" = 377)
organism_levels <- c("Human ACTB", "Rabbit ACTA1")
condition_levels <- c("Delta KCF", "Random 3 aa", "Delta tail25", "Random 25 aa")

# Actual mutant losses, one observation per audited template.
totals <- detail %>%
  group_by(organism, template, state) %>%
  summarise(total_contacted_residues = sum(contact_5A, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = state, values_from = total_contacted_residues)

actual <- bind_rows(
  totals %>% transmute(
    organism, template, condition = "Delta KCF", deleted_residues = 3L,
    wt_total_contacts = WT, raw_contact_loss = WT - `Delta KCF`
  ),
  totals %>% transmute(
    organism, template, condition = "Delta tail25", deleted_residues = 25L,
    wt_total_contacts = WT, raw_contact_loss = WT - `Delta tail25`
  )
) %>%
  mutate(
    sequence_length = unname(sequence_length[organism]),
    deleted_sequence_fraction = deleted_residues / sequence_length,
    contact_loss_fraction = raw_contact_loss / wt_total_contacts,
    length_normalized_contact_loss = contact_loss_fraction / deleted_sequence_fraction,
    source_type = "Observed deletion"
  )

# Exhaustive null: every contiguous window of identical length in every WT template.
wt <- detail %>%
  filter(state == "WT") %>%
  arrange(organism, template, actin_ref_position) %>%
  group_by(organism, template) %>%
  summarise(
    contact_vector = list(as.integer(contact_5A[order(actin_ref_position)])),
    wt_total_contacts = sum(contact_5A, na.rm = TRUE),
    .groups = "drop"
  )

window_rows <- vector("list", nrow(wt) * 2L)
k <- 1L
for (i in seq_len(nrow(wt))) {
  v <- wt$contact_vector[[i]]
  for (L in c(3L, 25L)) {
    starts <- seq_len(length(v) - L + 1L)
    burdens <- vapply(starts, function(s) sum(v[s:(s + L - 1L)]), numeric(1))
    org <- wt$organism[[i]]
    seq_len_native <- unname(sequence_length[org])
    window_rows[[k]] <- tibble(
      organism = org,
      template = wt$template[[i]],
      window_length = L,
      window_start_actb_aligned = starts,
      window_end_actb_aligned = starts + L - 1L,
      wt_total_contacts = wt$wt_total_contacts[[i]],
      window_contact_burden = burdens,
      deleted_sequence_fraction = L / seq_len_native,
      length_normalized_direct_burden =
        (burdens / wt$wt_total_contacts[[i]]) / (L / seq_len_native)
    )
    k <- k + 1L
  }
}
window_all <- bind_rows(window_rows)

# For a fair four-box comparison, retain one observation per template: the exact
# expectation over all possible same-length windows, rather than an arbitrary draw.
random_expected <- window_all %>%
  group_by(organism, template, window_length, wt_total_contacts, deleted_sequence_fraction) %>%
  summarise(
    raw_contact_loss = mean(window_contact_burden),
    length_normalized_contact_loss = mean(length_normalized_direct_burden),
    n_exhaustive_windows = n(),
    .groups = "drop"
  ) %>%
  mutate(
    contact_loss_fraction = raw_contact_loss / wt_total_contacts,
    condition = if_else(window_length == 3L, "Random 3 aa", "Random 25 aa"),
    deleted_residues = window_length,
    sequence_length = unname(sequence_length[organism]),
    source_type = "Exhaustive-window expectation"
  ) %>%
  select(names(actual), n_exhaustive_windows)

actual$n_exhaustive_windows <- NA_integer_
plot_data <- bind_rows(actual, random_expected) %>%
  mutate(
    organism = factor(organism, levels = organism_levels),
    condition = factor(condition, levels = condition_levels)
  )

write_tsv(plot_data, file.path(src_dir,
  "fig_static_actual_vs_random_window_length_normalized_boxplots_source.tsv"))
write_tsv(window_all, file.path(src_dir,
  "static_exhaustive_3aa_25aa_window_length_normalized_source.tsv"))

cols <- c(
  "Delta KCF" = "#739EB5",
  "Random 3 aa" = "#C5D3DA",
  "Delta tail25" = "#C39C68",
  "Random 25 aa" = "#DED0BA"
)
labels <- c(
  "Delta KCF" = expression(Delta*KCF),
  "Random 3 aa" = "Random 3 aa",
  "Delta tail25" = expression(Delta*tail25),
  "Random 25 aa" = "Random 25 aa"
)

paired_test_table <- function(dat, value_col, metric_name) {
  wide <- dat %>%
    select(organism, template, condition, value = all_of(value_col)) %>%
    pivot_wider(names_from = condition, values_from = value)
  comparisons <- list(
    c("Delta KCF", "Random 3 aa"),
    c("Delta tail25", "Random 25 aa")
  )
  out <- bind_rows(lapply(organism_levels, function(org) {
    z <- wide %>% filter(organism == org)
    bind_rows(lapply(comparisons, function(cp) {
      keep <- is.finite(z[[cp[[1]]]]) & is.finite(z[[cp[[2]]]])
      test <- suppressWarnings(wilcox.test(
        z[[cp[[1]]]][keep], z[[cp[[2]]]][keep],
        paired = TRUE, alternative = "two.sided", exact = FALSE
      ))
      tibble(
        metric = metric_name,
        organism = org,
        observed_condition = cp[[1]],
        random_condition = cp[[2]],
        n_paired_templates = sum(keep),
        median_paired_difference = median(z[[cp[[1]]]][keep] - z[[cp[[2]]]][keep]),
        p_raw = test$p.value,
        test = "two-sided paired Wilcoxon signed-rank"
      )
    }))
  }))
  out %>%
    mutate(
      p_holm = p.adjust(p_raw, method = "holm"),
      p_label = if_else(
        p_holm < 0.001,
        sprintf("Holm P = %.1e", p_holm),
        sprintf("Holm P = %.3f", p_holm)
      )
    )
}

annotation_table <- function(dat, stats, value_col) {
  bind_rows(lapply(seq_len(nrow(stats)), function(i) {
    s <- stats[i, ]
    vals <- dat %>%
      filter(organism == s$organism,
             condition %in% c(s$observed_condition, s$random_condition)) %>%
      pull(all_of(value_col))
    vals <- vals[is.finite(vals)]
    span <- diff(range(vals))
    y <- max(vals) + if_else(span > 0, 0.08 * span, 0.2)
    x1 <- match(s$observed_condition, condition_levels)
    x2 <- match(s$random_condition, condition_levels)
    tibble(
      organism = factor(s$organism, levels = organism_levels),
      x1 = x1, x2 = x2, y = y,
      cap = if_else(span > 0, 0.025 * span, 0.05),
      label = s$p_label
    )
  }))
}

stats_formal <- paired_test_table(
  plot_data, "length_normalized_contact_loss", "loss_fraction_divided_by_sequence_fraction"
)
ann_formal <- annotation_table(
  plot_data, stats_formal, "length_normalized_contact_loss"
)

p <- ggplot(plot_data, aes(x = condition, y = length_normalized_contact_loss,
                           fill = condition, colour = condition)) +
  geom_hline(yintercept = 1, linewidth = 0.42, linetype = "22", colour = "#6F6F6F") +
  geom_hline(yintercept = 0, linewidth = 0.28, colour = "#B8B8B8") +
  geom_boxplot(width = 0.62, outlier.shape = NA, alpha = 0.58, linewidth = 0.48) +
  geom_point(position = position_jitter(width = 0.11, height = 0),
             size = 0.7, alpha = 0.28, stroke = 0) +
  geom_segment(data = ann_formal,
               aes(x = x1, xend = x2, y = y, yend = y),
               inherit.aes = FALSE, linewidth = 0.38, colour = "#303030") +
  geom_segment(data = ann_formal,
               aes(x = x1, xend = x1, y = y, yend = y - cap),
               inherit.aes = FALSE, linewidth = 0.38, colour = "#303030") +
  geom_segment(data = ann_formal,
               aes(x = x2, xend = x2, y = y, yend = y - cap),
               inherit.aes = FALSE, linewidth = 0.38, colour = "#303030") +
  geom_text(data = ann_formal,
            aes(x = (x1 + x2) / 2, y = y, label = label),
            inherit.aes = FALSE, vjust = -0.45, size = 2.25,
            family = "Arial", colour = "#303030") +
  facet_wrap(~organism, nrow = 1) +
  scale_fill_manual(values = cols, guide = "none") +
  scale_colour_manual(values = cols, guide = "none") +
  scale_x_discrete(labels = labels, drop = FALSE) +
  scale_y_continuous(trans = scales::pseudo_log_trans(sigma = 1)) +
  labs(
    title = "Actual tail perturbations diverge from length-matched window expectations",
    subtitle = "Each box contains 142 audited templates; random controls are exact per-template means over every possible contiguous window",
    x = NULL,
    y = "Length-normalized interface-contact loss",
    caption = paste0(
      "Normalization = (fraction of WT contacting residues lost) / (fraction of sequence deleted). ",
      "The dashed line at 1 denotes sequence-proportional loss.\n",
      "Random controls use all 373 possible 3-aa windows or all 351 possible 25-aa windows per template.\n",
      "They are contact-map statistical nulls,\nnot AlphaFold-predicted, chain-replaced, minimized or MD-simulated deletion mutants."
    )
  ) +
  theme_classic(base_size = 8.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text.x = element_text(size = 6.4, colour = "#222222", margin = margin(t = 4)),
    axis.text.y = element_text(colour = "#222222"),
    strip.text = element_text(size = 8.5, face = "bold", margin = margin(b = 5)),
    strip.background = element_blank(),
    plot.title = element_text(size = 10.5, face = "bold", margin = margin(b = 3)),
    plot.subtitle = element_text(size = 8, colour = "#5A5A5A", margin = margin(b = 8)),
    plot.caption = element_text(size = 6.6, colour = "#666666", hjust = 0, margin = margin(t = 7)),
    plot.margin = margin(9, 11, 9, 9),
    panel.spacing.x = unit(14, "mm"),
    panel.grid.major.y = element_line(linewidth = 0.23, colour = "#E7E7E7"),
    panel.grid.minor = element_blank()
  )

stem <- file.path(fig_dir, "fig_static_actual_vs_random_window_length_normalized_boxplots")
cairo_pdf(paste0(stem, ".pdf"), width = 178 / 25.4, height = 104 / 25.4, family = "Arial")
print(p)
dev.off()

# More directly interpretable length normalization: contact loss per deleted residue.
per_residue_data <- plot_data %>%
  mutate(contact_loss_per_deleted_residue = raw_contact_loss / deleted_residues)
write_tsv(per_residue_data, file.path(src_dir,
  "fig_static_actual_vs_random_window_contact_loss_per_residue_source.tsv"))

stats_per_residue <- paired_test_table(
  per_residue_data, "contact_loss_per_deleted_residue", "contact_loss_per_deleted_residue"
)
ann_per_residue <- annotation_table(
  per_residue_data, stats_per_residue, "contact_loss_per_deleted_residue"
)

p_per_residue <- ggplot(
  per_residue_data,
  aes(x = condition, y = contact_loss_per_deleted_residue,
      fill = condition, colour = condition)
) +
  geom_hline(yintercept = 0, linewidth = 0.35, linetype = "22", colour = "#707070") +
  geom_boxplot(width = 0.62, outlier.shape = NA, alpha = 0.58, linewidth = 0.48) +
  geom_point(position = position_jitter(width = 0.11, height = 0),
             size = 0.7, alpha = 0.28, stroke = 0) +
  geom_segment(data = ann_per_residue,
               aes(x = x1, xend = x2, y = y, yend = y),
               inherit.aes = FALSE, linewidth = 0.38, colour = "#303030") +
  geom_segment(data = ann_per_residue,
               aes(x = x1, xend = x1, y = y, yend = y - cap),
               inherit.aes = FALSE, linewidth = 0.38, colour = "#303030") +
  geom_segment(data = ann_per_residue,
               aes(x = x2, xend = x2, y = y, yend = y - cap),
               inherit.aes = FALSE, linewidth = 0.38, colour = "#303030") +
  geom_text(data = ann_per_residue,
            aes(x = (x1 + x2) / 2, y = y, label = label),
            inherit.aes = FALSE, vjust = -0.45, size = 2.25,
            family = "Arial", colour = "#303030") +
  facet_wrap(~organism, nrow = 1) +
  scale_fill_manual(values = cols, guide = "none") +
  scale_colour_manual(values = cols, guide = "none") +
  scale_x_discrete(labels = labels, drop = FALSE) +
  labs(
    title = "Tail perturbations cause more contact loss per residue than random windows",
    subtitle = "Each box contains 142 audited templates; random controls average every possible contiguous window within each template",
    x = NULL,
    y = "Interface-contact loss per deleted residue",
    caption = paste0(
      "Length normalization = contacting-residue loss / number of deleted residues. Positive values indicate contact loss; negative values indicate net contact gain.\n",
      "Random controls use all 373 possible 3-aa windows or all 351 possible 25-aa windows per template.\n",
      "They are contact-map statistical nulls,\nnot AlphaFold-predicted, chain-replaced, minimized or MD-simulated deletion mutants."
    )
  ) +
  theme_classic(base_size = 8.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text.x = element_text(size = 6.9, colour = "#222222", margin = margin(t = 4)),
    axis.text.y = element_text(colour = "#222222"),
    strip.text = element_text(size = 8.5, face = "bold", margin = margin(b = 5)),
    strip.background = element_blank(),
    plot.title = element_text(size = 10.5, face = "bold", margin = margin(b = 3)),
    plot.subtitle = element_text(size = 8, colour = "#5A5A5A", margin = margin(b = 8)),
    plot.caption = element_text(size = 6.6, colour = "#666666", hjust = 0, margin = margin(t = 7)),
    plot.margin = margin(9, 11, 9, 9),
    panel.spacing.x = unit(14, "mm"),
    panel.grid.major.y = element_line(linewidth = 0.23, colour = "#E7E7E7"),
    panel.grid.minor = element_blank()
  )

stem_per_residue <- file.path(fig_dir,
  "fig_static_actual_vs_random_window_contact_loss_per_deleted_residue_boxplots")
cairo_pdf(paste0(stem_per_residue, ".pdf"), width = 178 / 25.4,
          height = 104 / 25.4, family = "Arial")
print(p_per_residue)
dev.off()
png(paste0(stem_per_residue, ".png"), width = 178 / 25.4,
    height = 104 / 25.4, units = "in", res = 600, type = "cairo")
print(p_per_residue)
dev.off()

per_residue_summary <- per_residue_data %>%
  group_by(organism, condition) %>%
  summarise(
    n_templates = n(),
    median = median(contact_loss_per_deleted_residue),
    q1 = quantile(contact_loss_per_deleted_residue, 0.25),
    q3 = quantile(contact_loss_per_deleted_residue, 0.75),
    .groups = "drop"
  )
write_tsv(per_residue_summary, file.path(src_dir,
  "fig_static_actual_vs_random_window_contact_loss_per_residue_summary.tsv"))
write_tsv(bind_rows(stats_per_residue, stats_formal), file.path(src_dir,
  "fig_static_actual_vs_random_window_paired_wilcoxon_stats.tsv"))
png(paste0(stem, ".png"), width = 178 / 25.4, height = 104 / 25.4,
    units = "in", res = 600, type = "cairo")
print(p)
dev.off()

summary_out <- plot_data %>%
  group_by(organism, condition) %>%
  summarise(
    n_templates = n(),
    median = median(length_normalized_contact_loss),
    q1 = quantile(length_normalized_contact_loss, 0.25),
    q3 = quantile(length_normalized_contact_loss, 0.75),
    .groups = "drop"
  )
write_tsv(summary_out, file.path(src_dir,
  "fig_static_actual_vs_random_window_length_normalized_boxplots_summary.tsv"))

writeLines(c(
  "PASS",
  "backend=R",
  "templates_per_organism_condition=142",
  "conditions=Delta_KCF,Random_3aa,Delta_tail25,Random_25aa",
  "random_3aa_windows_per_template=373",
  "random_25aa_windows_per_template=351",
  "normalization=(contact_loss_fraction)/(deleted_sequence_fraction)",
  "primary_normalization=contact_loss_per_deleted_residue",
  "supplementary_normalization=(contact_loss_fraction)/(deleted_sequence_fraction)",
  "figures=2",
  "test=two-sided_paired_Wilcoxon_signed-rank",
  "multiple_testing=Holm_within_each_normalization_across_4_comparisons",
  "random_control=exact_templatewise_mean_over_all_windows",
  "physical_random_deletion_mutants=no",
  "random_control_scope=contact_map_statistical_null_only",
  "random_control_not_run_through=AlphaFold,chain_replacement,minimization,MD",
  "y_axis=pseudo_log_preserves_sign_and_extremes"
), file.path(fig_dir,
  "fig_static_actual_vs_random_window_length_normalized_boxplots.QA.marker"))

print(summary_out)
