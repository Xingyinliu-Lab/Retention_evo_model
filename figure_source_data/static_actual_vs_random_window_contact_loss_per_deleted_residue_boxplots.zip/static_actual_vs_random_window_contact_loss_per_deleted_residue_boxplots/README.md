# static_actual_vs_random_window_contact_loss_per_deleted_residue_boxplots

- Manuscript panel: Supp.Fig.7B
- Source figure basename: fig_static_actual_vs_random_window_contact_loss_per_deleted_residue_boxplots
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 7 directly referenced or locally packaged source-data file(s)
