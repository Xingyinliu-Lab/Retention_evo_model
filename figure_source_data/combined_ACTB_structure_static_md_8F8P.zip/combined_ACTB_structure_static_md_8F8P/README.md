# combined_ACTB_structure_static_md_8F8P

- Manuscript panel: Fig.3A
- Source figure basename: fig_combined_ACTB_structure_static_md_8F8P_20260819
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 5 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 49 directly referenced or locally packaged source-data file(s)
