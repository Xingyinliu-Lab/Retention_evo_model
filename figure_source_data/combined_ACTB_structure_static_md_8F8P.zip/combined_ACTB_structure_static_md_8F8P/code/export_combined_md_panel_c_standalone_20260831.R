suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

root <- ".."
source_file <- file.path(
  root, "source_data",
  "fig_combined_ACTB_structure_static_md_8F8P_dynamic_template_resolved_source.tsv"
)
output_dir <- ".."
output_stem <- file.path(
  output_dir,
  "fig_md_wt_delta_kcf_tail25_dynamic_interface_persistence_template_resolved_20260819"
)

figure_contract <- list(
  core_conclusion = paste(
    "WT, Delta KCF and Delta tail25 exhibit template-dependent differences in",
    "per-residue actin-partner contact occupancy during MD."
  ),
  evidence_chain = "four actin-complex backgrounds -> three perturbation states -> residue-level contact occupancy",
  archetype = "quantitative heatmap",
  backend = "R",
  export = "183-mm PDF plus 600-dpi PNG preview; no SVG or TIFF"
)

stopifnot(file.exists(source_file))
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

md <- read_tsv(source_file, show_col_types = FALSE)
required <- c("row_label", "y", "actb_position", "value", "denominator")
stopifnot(all(required %in% names(md)))
stopifnot(nrow(md) == 4500L)
stopifnot(all(md$actb_position >= 1L & md$actb_position <= 375L))

heat_cols <- c(low = "#F7F7F7", high = "#557F99", missing = "#FFFFFF")
x_breaks <- c(1, seq(50, 350, 50), 375)

row_key <- md %>%
  distinct(y, row_label) %>%
  arrange(y) %>%
  mutate(
    display_y = c(1, 2, 3, 4.5, 5.5, 6.5, 8, 9, 10, 11.5, 12.5, 13.5),
    display_label = case_when(
      row_label == "ACTB  WT | 7W4Z" ~ "Human ACTB | 7W4Z | WT",
      row_label == "ACTB  Delta KCF | 7W4Z" ~ "Human ACTB | 7W4Z | Delta KCF",
      row_label == "ACTB  Delta tail25 | 7W4Z" ~ "Human ACTB | 7W4Z | Delta tail25",
      row_label == "ACTA1  WT | 7W4Z" ~ "Rabbit ACTA1 | 7W4Z | WT",
      row_label == "ACTA1  Delta KCF | 7W4Z" ~ "Rabbit ACTA1 | 7W4Z | Delta KCF",
      row_label == "ACTA1  Delta tail25 | 7W4Z" ~ "Rabbit ACTA1 | 7W4Z | Delta tail25",
      TRUE ~ row_label
    )
  )

md_plot <- md %>%
  left_join(row_key %>% select(row_label, display_y), by = "row_label")

p_md <- ggplot(md_plot, aes(x = actb_position, y = display_y, fill = value)) +
  geom_tile(width = 0.98, height = 0.72) +
  scale_fill_gradient(
    low = heat_cols["low"], high = heat_cols["high"], limits = c(0, 1),
    breaks = seq(0, 1, 0.25), labels = percent_format(accuracy = 1),
    na.value = heat_cols["missing"], name = "Maximum partner-residue\ncontact occupancy"
  ) +
  scale_x_continuous(
    breaks = x_breaks, limits = c(0.5, 375.5), expand = c(0, 0)
  ) +
  scale_y_continuous(
    breaks = row_key$display_y, labels = row_key$display_label,
    limits = c(min(row_key$display_y) - 0.45, max(row_key$display_y) + 0.45), expand = c(0, 0)
  ) +
  labs(
    title = "Dynamic interface persistence is template dependent",
    subtitle = paste0(
      "7W4Z, 8BJH and 8DD0 ACTB complexes; rabbit ACTA1 is available only for 7W4Z\n",
      "Maximum partner-residue occupancy across 3 x 50-ns replicates"
    ),
    x = "Human ACTB-aligned residue position", y = NULL,
    caption = paste(
      "Occupancy is calculated over the 5-50 ns analysis window.",
      "White gaps denote deleted or unmapped residues."
    )
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.line.y = element_blank(),
    axis.ticks = element_line(linewidth = 0.32, colour = "#222222"),
    axis.ticks.y = element_blank(),
    axis.text = element_text(colour = "#222222"),
    axis.title.x = element_text(size = 7.5),
    plot.title = element_text(size = 9.0, face = "bold", margin = margin(b = 3)),
    plot.subtitle = element_text(size = 7.2, colour = "#555555", margin = margin(b = 5)),
    plot.caption = element_text(size = 6.2, colour = "#666666", hjust = 0),
    legend.position = "bottom",
    legend.justification = "left",
    legend.title = element_text(size = 6.8),
    legend.text = element_text(size = 6.4),
    plot.margin = margin(6, 8, 5, 27),
    panel.grid = element_blank()
  ) +
  guides(fill = guide_colourbar(
    direction = "horizontal", title.position = "top",
    barwidth = grid::unit(48, "mm"), barheight = grid::unit(3, "mm")
  ))

ggsave(
  paste0(output_stem, ".pdf"), p_md,
  device = grDevices::cairo_pdf,
  width = 183, height = 116, units = "mm", family = "Arial", bg = "white"
)
ggsave(
  paste0(output_stem, ".png"), p_md,
  device = ragg::agg_png,
  width = 183, height = 116, units = "mm", dpi = 600, background = "white"
)

stopifnot(file.info(paste0(output_stem, ".pdf"))$size > 10000)
stopifnot(file.info(paste0(output_stem, ".png"))$size > 10000)

writeLines(c(
  "status=PASS",
  "analysis_rerun=FALSE",
  paste0("source=", basename(source_file)),
  paste0("rows=", nrow(md)),
  "actin_positions=1-375",
  "templates=7W4Z,8BJH,8DD0",
  "states=WT,Delta KCF,Delta tail25",
  "replicates=3 x 50 ns per available background-state combination",
  "analysis_window=5-50 ns",
  "output_pdf=TRUE",
  "output_png=TRUE",
  "svg_tiff=FALSE"
), paste0(output_stem, ".QA.marker"))
