#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
  library(ragg)
})

root <- ".."
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")
manuscript_dir <- ".."

dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(manuscript_dir, recursive = TRUE, showWarnings = FALSE)

figure_contract <- list(
  core_conclusion = paste(
    "Tail25 and KCF deletion produce residue- and background-dependent changes",
    "in static contact support and MD interface occupancy relative to matched WT."
  ),
  archetype = "quantitative grid",
  backend = "R",
  static_unit = "template-derived contact support fraction; 142 assessable templates per actin background",
  dynamic_unit = "complex-background mean of replicate-level maximum partner-residue occupancy; 3 x 50-ns replicates",
  interpretation = "structural compatibility evidence, not affinity, in-vivo function or a universal mechanism"
)

variant_cols <- c("Delta tail25" = "#3E6F9E", "Delta KCF" = "#D2765D")
x_breaks <- c(1, 50, 100, 150, 200, 250, 300, 350, 375)

tail_annotation <- tibble::tibble(
  xmin = c(351, 373),
  xmax = c(373, 376),
  region = c("Tail body", "Terminal KCF")
)

theme_relative <- function() {
  theme_classic(base_family = "Arial", base_size = 8.0) +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "#222222"),
      axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
      axis.text = element_text(colour = "#222222", size = 6.8),
      axis.title = element_text(size = 7.6),
      strip.background = element_rect(fill = "#F1F3F5", colour = NA),
      strip.text = element_text(face = "bold", size = 7.5),
      panel.spacing = grid::unit(1.05, "lines"),
      panel.grid.major.y = element_line(linewidth = 0.22, colour = "#E9E9E9"),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(face = "bold", size = 10.0),
      plot.subtitle = element_text(size = 7.8, colour = "#555555"),
      plot.caption = element_text(size = 6.3, colour = "#666666", hjust = 0),
      plot.margin = margin(8, 10, 8, 8)
    )
}

add_tail_background <- function(p) {
  p +
    geom_rect(
      data = tail_annotation %>% filter(region == "Tail body"),
      aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf),
      inherit.aes = FALSE, fill = "#E8EDF1", alpha = 0.62
    ) +
    geom_rect(
      data = tail_annotation %>% filter(region == "Terminal KCF"),
      aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf),
      inherit.aes = FALSE, fill = "#F2DED6", alpha = 0.72
    )
}

save_bundle <- function(p, stem_name, width_mm, height_mm, source_data, qa_lines) {
  stem <- file.path(figure_dir, stem_name)
  source_file <- file.path(source_dir, paste0(stem_name, "_source.tsv"))
  write_tsv(source_data, source_file)

  ggsave(
    paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
    width = width_mm, height = height_mm, units = "mm", family = "Arial", bg = "white"
  )
  ggsave(
    paste0(stem, ".png"), p, device = ragg::agg_png,
    width = width_mm, height = height_mm, units = "mm", dpi = 600, background = "white"
  )

  stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
  writeLines(c("PASS", "backend=R", qa_lines), paste0(stem, ".QA.marker"))

  file.copy(paste0(stem, ".pdf"), manuscript_dir, overwrite = TRUE)
  file.copy(paste0(stem, ".png"), manuscript_dir, overwrite = TRUE)
  file.copy(source_file, manuscript_dir, overwrite = TRUE)
  file.copy(paste0(stem, ".QA.marker"), manuscript_dir, overwrite = TRUE)
}

static_all <- read_tsv(
  file.path(source_dir, "fig_static_full142_tail_variants_delta_vs_wt_footprint_source.tsv"),
  show_col_types = FALSE
) %>%
  mutate(
    state = factor(state, levels = c("Delta tail25", "Delta KCF")),
    organism = factor(organism, levels = c("Human ACTB", "Rabbit ACTA1")),
    panel = factor(
      paste0(organism, " | 142 templates"),
      levels = c("Human ACTB | 142 templates", "Rabbit ACTA1 | 142 templates")
    ),
    delta_contact_pp = 100 * delta_vs_wt
  )

stopifnot(
  nrow(static_all) == 1500L,
  all(static_all$n_templates_total == 142L),
  sum(is.na(static_all$delta_contact_pp[static_all$state == "Delta tail25"])) == 50L,
  sum(is.na(static_all$delta_contact_pp[static_all$state == "Delta KCF"])) == 6L
)

make_static_plot <- function(variant) {
  z <- static_all %>% filter(state == .env$variant)
  col <- unname(variant_cols[variant])
  title <- paste0(variant, ": static contact changes relative to WT")

  p <- ggplot(z, aes(x = actin_ref_position, y = delta_contact_pp))
  p <- p +
    geom_hline(yintercept = 0, linewidth = 0.42, linetype = "22", colour = "#4D4D4D") +
    geom_ribbon(aes(ymin = pmin(delta_contact_pp, 0), ymax = pmax(delta_contact_pp, 0)),
                fill = col, alpha = 0.13, colour = NA) +
    geom_line(linewidth = 0.58, colour = col, na.rm = TRUE) +
    facet_wrap(~panel, ncol = 2) +
    scale_x_continuous(breaks = x_breaks, limits = c(0.5, 375.5),
                       expand = expansion(mult = c(0, 0))) +
    coord_cartesian(ylim = c(-23, 23)) +
    labs(
      title = title,
      subtitle = "Variant contact-support fraction minus matched WT across the full 142-template screen",
      x = "Human ACTB-aligned residue position",
      y = "Change in contact support vs WT (percentage points)",
      caption = paste0(
        "Positive values indicate more templates with a direct contact within 5 A than WT; negative values indicate fewer.\n",
        "Each panel summarizes 142 assessable templates; deleted or unmapped residues are left blank. Descriptive structural coverage only."
      )
    ) +
    theme_relative()
  list(plot = p, data = z)
}

dynamic_all <- read_tsv(
  file.path(source_dir, "fig_combined_ACTB_structure_static_md_8F8P_dynamic_template_resolved_source.tsv"),
  show_col_types = FALSE
) %>%
  mutate(
    state = factor(state, levels = c("WT", "Delta tail25", "Delta KCF")),
    panel = factor(
      paste(organism, template, sep = " | "),
      levels = c(
        "Human ACTB | 7W4Z", "Human ACTB | 8BJH",
        "Human ACTB | 8DD0", "Rabbit ACTA1 | 7W4Z"
      )
    )
  )

dynamic_wt <- dynamic_all %>%
  filter(state == "WT") %>%
  select(organism, template, panel, actb_position, wt_occupancy = value)

dynamic_delta <- dynamic_all %>%
  filter(state != "WT") %>%
  left_join(
    dynamic_wt,
    by = c("organism", "template", "panel", "actb_position")
  ) %>%
  mutate(
    variant = factor(as.character(state), levels = c("Delta tail25", "Delta KCF")),
    delta_occupancy_pp = 100 * (value - wt_occupancy),
    comparison = "variant mean maximum occupancy minus matched WT mean maximum occupancy"
  )

stopifnot(
  nrow(dynamic_delta) == 3000L,
  sum(is.na(dynamic_delta$delta_occupancy_pp[dynamic_delta$variant == "Delta tail25"])) == 100L,
  sum(is.na(dynamic_delta$delta_occupancy_pp[dynamic_delta$variant == "Delta KCF"])) == 12L,
  all(dynamic_delta %>% count(panel, variant) %>% pull(n) == 375L)
)

make_dynamic_plot <- function(variant) {
  z <- dynamic_delta %>% filter(variant == .env$variant)
  col <- unname(variant_cols[variant])
  title <- paste0(variant, ": dynamic interface changes relative to WT")

  p <- ggplot(z, aes(x = actb_position, y = delta_occupancy_pp))
  p <- p +
    geom_hline(yintercept = 0, linewidth = 0.42, linetype = "22", colour = "#4D4D4D") +
    geom_ribbon(aes(ymin = pmin(delta_occupancy_pp, 0), ymax = pmax(delta_occupancy_pp, 0)),
                fill = col, alpha = 0.13, colour = NA) +
    geom_line(linewidth = 0.56, colour = col, na.rm = TRUE) +
    facet_wrap(~panel, ncol = 2) +
    scale_x_continuous(breaks = x_breaks, limits = c(0.5, 375.5),
                       expand = expansion(mult = c(0, 0))) +
    coord_cartesian(ylim = c(-105, 105)) +
    labs(
      title = title,
      subtitle = "Variant mean maximum partner-residue occupancy minus matched WT across three 50-ns replicates",
      x = "Human ACTB-aligned residue position",
      y = "Change in maximum interface occupancy vs WT (percentage points)",
      caption = paste0(
        "Positive values indicate greater dynamic interface persistence than WT; negative values indicate lower persistence.\n",
        "Each panel is one actin-complex background averaged across three 50-ns replicates; deleted residues are left blank.\n",
        "Focused MD feasibility evidence; lines are descriptive differences of replicate means, not confidence intervals."
      )
    ) +
    theme_relative()
  list(plot = p, data = z)
}

static_tail <- make_static_plot("Delta tail25")
static_kcf <- make_static_plot("Delta KCF")
dynamic_tail <- make_dynamic_plot("Delta tail25")
dynamic_kcf <- make_dynamic_plot("Delta KCF")

save_bundle(
  static_tail$plot,
  "fig_static_delta_tail25_contact_support_relative_to_wt",
  183, 92, static_tail$data,
  c(
    "evidence_mode=static_142_template_screen",
    "variant=Delta_tail25", "actin_backgrounds=2", "templates_per_background=142",
    "metric=contact_support_fraction_variant_minus_WT_in_percentage_points",
    "deleted_positions=NA_white_gap", paste0("source_rows=", nrow(static_tail$data)),
    paste0("core_conclusion=", figure_contract$core_conclusion)
  )
)

save_bundle(
  static_kcf$plot,
  "fig_static_delta_kcf_contact_support_relative_to_wt",
  183, 92, static_kcf$data,
  c(
    "evidence_mode=static_142_template_screen",
    "variant=Delta_KCF", "actin_backgrounds=2", "templates_per_background=142",
    "metric=contact_support_fraction_variant_minus_WT_in_percentage_points",
    "deleted_positions=NA_white_gap", paste0("source_rows=", nrow(static_kcf$data)),
    paste0("core_conclusion=", figure_contract$core_conclusion)
  )
)

save_bundle(
  dynamic_tail$plot,
  "fig_md_delta_tail25_interface_occupancy_relative_to_wt",
  183, 132, dynamic_tail$data,
  c(
    "evidence_mode=MD", "variant=Delta_tail25", "complex_backgrounds=4",
    "replicates_per_state_and_background=3", "trajectory_length_ns=50",
    "metric=mean_maximum_partner_residue_occupancy_variant_minus_WT_in_percentage_points",
    "uncertainty=not_displayed", "deleted_positions=NA_white_gap",
    paste0("source_rows=", nrow(dynamic_tail$data)),
    paste0("core_conclusion=", figure_contract$core_conclusion)
  )
)

save_bundle(
  dynamic_kcf$plot,
  "fig_md_delta_kcf_interface_occupancy_relative_to_wt",
  183, 132, dynamic_kcf$data,
  c(
    "evidence_mode=MD", "variant=Delta_KCF", "complex_backgrounds=4",
    "replicates_per_state_and_background=3", "trajectory_length_ns=50",
    "metric=mean_maximum_partner_residue_occupancy_variant_minus_WT_in_percentage_points",
    "uncertainty=not_displayed", "deleted_positions=NA_white_gap",
    paste0("source_rows=", nrow(dynamic_kcf$data)),
    paste0("core_conclusion=", figure_contract$core_conclusion)
  )
)
