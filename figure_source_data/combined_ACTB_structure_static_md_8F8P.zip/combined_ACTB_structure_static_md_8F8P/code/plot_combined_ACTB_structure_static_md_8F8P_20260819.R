suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(ragg)
})

root <- ".."
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")

figure_contract <- list(
  core_conclusion = paste(
    "A common human ACTB residue axis connects structural landmarks with broad static screening,",
    "focused MD validation and experimental PDB contact evidence."
  ),
  evidence_chain = "ACTB annotation -> 142-template static screen -> 7W4Z MD -> 483-PDB experimental corpus",
  archetype = "schematic-led vertical quantitative composite",
  backend = "R",
  export = "183-mm PDF and 600-dpi PNG; source TSV"
)

heat_cols <- c(low = "#F7F7F7", high = "#557F99", missing = "#FFFFFF")
x_breaks <- c(1, seq(50, 350, 50), 375)

theme_common <- function(base_size = 7.3) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "#222222"),
      axis.ticks = element_line(linewidth = 0.32, colour = "#222222"),
      axis.text = element_text(colour = "#222222"),
      axis.title.x = element_text(size = base_size + 0.3),
      plot.title = element_text(size = base_size + 1.8, face = "bold", margin = margin(b = 3)),
      plot.subtitle = element_text(size = base_size, colour = "#555555", margin = margin(b = 5)),
      plot.caption = element_text(size = base_size - 1, colour = "#666666", hjust = 0),
      plot.margin = margin(5, 8, 4, 24),
      panel.grid = element_blank()
    )
}

ss <- read_tsv(file.path(source_dir, "human_ACTB_P60709_dssp_segments.tsv"), show_col_types = FALSE) %>%
  mutate(
    display_class = case_when(
      secondary_structure_class == "alpha_helix" ~ "Alpha helix",
      secondary_structure_class %in% c("3_10_helix", "pi_helix") ~ "3-10 / pi helix",
      secondary_structure_class %in% c("beta_strand", "beta_bridge") ~ "Beta strand",
      TRUE ~ NA_character_
    ),
    display_class = factor(display_class, levels = c("Alpha helix", "Beta strand", "3-10 / pi helix"))
  ) %>% filter(!is.na(display_class))

ann <- read_tsv(file.path(source_dir, "human_ACTB_P60709_structural_functional_regions.tsv"), show_col_types = FALSE)
subdomains <- ann %>% filter(track == "subdomain")
nucleotide <- ann %>% filter(track == "nucleotide_sensor")
interface <- ann %>% filter(track == "interface_allostery")
perturbation <- ann %>% filter(track == "perturbation")

track_y <- c(nucleotide = 4.00, interface = 3.18, perturbation = 2.36, dssp = 1.50, subdomain = 0.62)
subdomain_cols <- c(SD1 = "#B7C9D4", SD2 = "#D8C4B5", SD3 = "#C6D3BE", SD4 = "#C7C0D0")
ss_cols <- c("Alpha helix" = "#A98791", "Beta strand" = "#6F91A7", "3-10 / pi helix" = "#CCB8BE")

p_structure <- ggplot() +
  geom_segment(aes(x = 1, xend = 375, y = track_y["dssp"], yend = track_y["dssp"]),
               linewidth = 0.32, colour = "#D5D8DA") +
  geom_segment(
    data = ss %>% filter(display_class != "Beta strand"),
    aes(x = start, xend = end, y = track_y["dssp"], yend = track_y["dssp"], colour = display_class),
    linewidth = 3.1, lineend = "round"
  ) +
  geom_segment(
    data = ss %>% filter(display_class == "Beta strand"),
    aes(x = start, xend = end, y = track_y["dssp"], yend = track_y["dssp"], colour = display_class),
    linewidth = 2.3, lineend = "butt", arrow = arrow(type = "closed", length = unit(1.1, "mm"))
  ) +
  geom_rect(
    data = subdomains,
    aes(xmin = start, xmax = end, ymin = track_y["subdomain"] - 0.16,
        ymax = track_y["subdomain"] + 0.16, fill = label),
    colour = "white", linewidth = 0.22
  ) +
  geom_text(data = subdomains,
            aes(x = (start + end) / 2, y = track_y["subdomain"], label = label),
            size = 2.05, family = "Arial", colour = "#283036") +
  geom_rect(data = nucleotide,
            aes(xmin = start, xmax = end, ymin = track_y["nucleotide"] - 0.12,
                ymax = track_y["nucleotide"] + 0.12), fill = "#B09AAB", colour = NA) +
  geom_text(data = nucleotide,
            aes(x = (start + end) / 2, y = track_y["nucleotide"] + 0.23, label = label),
            size = 1.95, family = "Arial", colour = "#584A55") +
  geom_rect(data = interface,
            aes(xmin = start, xmax = end, ymin = track_y["interface"] - 0.12,
                ymax = track_y["interface"] + 0.12), fill = "#9EB39B", colour = NA) +
  geom_text(data = interface,
            aes(x = (start + end) / 2, y = track_y["interface"] + 0.23, label = label),
            size = 1.95, family = "Arial", colour = "#435541") +
  geom_rect(data = perturbation %>% filter(label == "Tail25"),
            aes(xmin = start, xmax = end, ymin = track_y["perturbation"] - 0.12,
                ymax = track_y["perturbation"] + 0.12), fill = "#83A9C1", colour = NA) +
  geom_rect(data = perturbation %>% filter(label == "KCF"),
            aes(xmin = start, xmax = end, ymin = track_y["perturbation"] - 0.17,
                ymax = track_y["perturbation"] + 0.17), fill = "#5D7F95", colour = NA) +
  annotate("text", x = 359, y = track_y["perturbation"] + 0.23, label = "Tail25",
           size = 1.95, family = "Arial", colour = "#42657A") +
  annotate("segment", x = 374, xend = 338, y = track_y["perturbation"],
           yend = track_y["perturbation"] - 0.28, linewidth = 0.28, colour = "#5D7F95") +
  annotate("text", x = 335, y = track_y["perturbation"] - 0.28, label = "KCF (373-375)",
           hjust = 1, size = 1.9, family = "Arial", colour = "#42657A") +
  annotate("text", x = 0.8,
           y = unname(track_y[c("nucleotide", "interface", "perturbation", "dssp", "subdomain")]),
           label = c("Nucleotide sensors", "Interface / allostery", "Perturbations", "DSSP", "Subdomains"),
           hjust = 1, size = 2.15, family = "Arial", colour = "#303438") +
  scale_colour_manual(values = ss_cols, name = NULL) +
  scale_fill_manual(values = subdomain_cols, guide = "none") +
  scale_x_continuous(breaks = x_breaks, limits = c(0.5, 375.5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.15, 4.48), expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  labs(
    title = "a  Human ACTB structural landmarks",
    subtitle = "DSSP from the human ACTB WT model; established actin subdomains and functional regions",
    x = "Human ACTB-aligned residue position", y = NULL
  ) + theme_common(7.2) +
  theme(
    axis.line.y = element_blank(), axis.ticks.y = element_blank(), axis.text.y = element_blank(),
    legend.position = "top", legend.justification = "left",
    legend.key.width = unit(8, "mm"), legend.key.height = unit(2.5, "mm"),
    plot.margin = margin(4, 8, 4, 27)
  )

row_key <- tibble::tribble(
  ~state, ~y, ~row_label,
  "WT", 3.0, "WT",
  "Delta tail25", 2.0, "Delta tail25",
  "Delta KCF", 1.0, "Delta KCF"
)

static <- read_tsv(
  file.path(source_dir, "fig_static_full142_tail_variants_contact_footprint_source.tsv"),
  show_col_types = FALSE
) %>%
  group_by(state, actin_ref_position) %>%
  summarise(
    value = if (all(is.na(plotted_support))) NA_real_ else mean(plotted_support, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(row_key, by = "state") %>%
  transmute(evidence_mode = "Static screen", organism = "Pooled ACTB/ACTA1",
            state, row_label, y, actb_position = actin_ref_position, value,
            denominator = "mean fraction across ACTB and ACTA1; 142 assessable templates per background")

mapping <- read_tsv(file.path(source_dir, "ACTA1_native_to_human_ACTB_P60709_mapping.tsv"), show_col_types = FALSE)
old_md <- read_tsv(
  file.path(source_dir, "fig_md_wt_delta_kcf_tail25_contact_occupancy_profile_source.tsv"),
  show_col_types = FALSE
) %>%
  mutate(organism = as.character(organism_label), template = "7W4Z") %>%
  left_join(mapping %>% select(native_position, actb_position),
            by = c("actin_residue" = "native_position")) %>%
  mutate(actb_position = if_else(organism == "Human ACTB", actin_residue, actb_position)) %>%
  filter(!is.na(actb_position)) %>%
  transmute(evidence_mode = "MD", organism, state = as.character(state), template,
            row_label = paste(organism, "| 7W4Z |", state),
            y = case_when(
              organism == "Human ACTB" & state == "WT" ~ 6.5,
              organism == "Human ACTB" & state == "Delta KCF" ~ 5.5,
              organism == "Human ACTB" & state == "Delta tail25" ~ 4.5,
              organism == "Rabbit ACTA1" & state == "WT" ~ 3.0,
              organism == "Rabbit ACTA1" & state == "Delta KCF" ~ 2.0,
              organism == "Rabbit ACTA1" & state == "Delta tail25" ~ 1.0
            ),
            actb_position = as.integer(actb_position),
            value = mean_max_pair_occupancy,
            denominator = "mean maximum partner-residue occupancy; 3 x 50-ns replicates; 5-50 ns")

build_new_md <- function(dir_names, template_label) {
  files <- unlist(lapply(dir_names, function(d) list.files(
    file.path(source_dir, "md_interface_contacts_fixed_20260818", d),
    pattern = "contact_residue_pair_occupancy.tsv$", full.names = TRUE
  )))
  stopifnot(length(files) == 3L)
  one_rep <- function(f) {
    x <- read_tsv(f, show_col_types = FALSE) %>%
      group_by(actin_resid) %>% summarise(value = max(occupancy), .groups = "drop")
    tibble(actb_position = 1:375) %>% left_join(x, by = c("actb_position" = "actin_resid")) %>%
      mutate(value = replace_na(value, 0))
  }
  bind_rows(lapply(files, one_rep), .id = "replicate") %>%
    group_by(actb_position) %>% summarise(value = mean(value), .groups = "drop") %>%
    mutate(
      evidence_mode = "MD", organism = "Human ACTB", state = rep(c("WT", "Delta KCF", "Delta tail25"), each = 375)[1],
      template = template_label
    )
}

new_groups <- list(
  `Human ACTB | 8BJH | WT` = c("ACTB_WT_8BJH_rep1", "ACTB_WT_8BJH_rep2", "ACTB_WT_8BJH_rep3"),
  `Human ACTB | 8BJH | Delta KCF` = c("ACTB_delta_KCF_8BJH_rep1", "ACTB_delta_KCF_8BJH_rep2", "ACTB_delta_KCF_8BJH_rep3"),
  `Human ACTB | 8BJH | Delta tail25` = c("ACTB_delta_tail25_8BJH_rep1", "ACTB_delta_tail25_8BJH_rep2", "ACTB_delta_tail25_8BJH_rep3"),
  `Human ACTB | 8DD0 | WT` = c("ACTB_WT_8DD0_rep1", "ACTB_WT_8DD0_rep2", "ACTB_WT_8DD0_rep3"),
  `Human ACTB | 8DD0 | Delta KCF` = c("ACTB_delta_KCF_8DD0_rep1", "ACTB_delta_KCF_8DD0_rep2", "ACTB_delta_KCF_8DD0_rep3"),
  `Human ACTB | 8DD0 | Delta tail25` = c("md_priority_ACTB_delta_tail25_8DD0_gpu0_3x50ns_20260806_rep1", "md_priority_ACTB_delta_tail25_8DD0_gpu0_3x50ns_20260806_rep2", "md_priority_ACTB_delta_tail25_8DD0_gpu0_3x50ns_20260806_rep3")
)
new_md <- bind_rows(lapply(seq_along(new_groups), function(i) {
  k <- names(new_groups)[i]
  z <- build_new_md(new_groups[[k]], sub(".*\\| ([^ ]+) \\|.*", "\\1", k))
  state_label <- sub("^.*\\| (WT|Delta KCF|Delta tail25)$", "\\1", k)
  z %>% mutate(
    state = .env$state_label,
    value = case_when(
      .env$state_label == "Delta tail25" & actb_position >= 351L ~ NA_real_,
      .env$state_label == "Delta KCF" & actb_position >= 373L ~ NA_real_,
      TRUE ~ value
    ),
    row_label = k, y = 13 - i,
    denominator = "mean maximum partner-residue occupancy; 3 x 50-ns replicates; 5-50 ns"
  )
})) %>% select(evidence_mode, organism, state, template, row_label, y, actb_position, value, denominator)

md_detail <- bind_rows(old_md, new_md)
md_group_audit <- md_detail %>% count(organism, template, state, name = "n_positions")
md_state_audit <- md_detail %>% count(state, name = "n_positions")
stopifnot(
  nrow(md_group_audit) == 12L,
  all(md_group_audit$n_positions == 375L),
  all(md_state_audit$n_positions == 1500L),
  all(is.na(md_detail$value[md_detail$state == "Delta tail25" & md_detail$actb_position >= 351L])),
  all(is.na(md_detail$value[md_detail$state == "Delta KCF" & md_detail$actb_position >= 373L]))
)
md <- md_detail %>%
  group_by(state, actb_position) %>%
  summarise(
    value = if (all(is.na(value))) NA_real_ else mean(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(row_key, by = "state") %>%
  transmute(
    evidence_mode = "MD", organism = "Pooled actin-complex backgrounds", state,
    template = "7W4Z + 8BJH + 8DD0", row_label, y, actb_position, value,
    denominator = paste(
      "mean maximum partner-residue occupancy across four actin-complex backgrounds;",
      "3 x 50-ns replicates per background; 5-50 ns"
    )
  )

exp_wide <- read_tsv(
  file.path(source_dir, "fig_8F8P_full_length_human_ACTB_aligned_contact_footprint_source.tsv"),
  show_col_types = FALSE
)
exp <- exp_wide %>%
  select(
    actb_position = actin_position,
    `Coordinate observed` = coordinate_coverage_fraction,
    `Non-actin protein contact` = nonactin_contact_support_fraction,
    `Actin-chain contact` = actin_chain_contact_support_fraction
  ) %>%
  pivot_longer(-actb_position, names_to = "row_label", values_to = "value") %>%
  mutate(
    evidence_mode = "Experimental PDB corpus", organism = "Eukaryotic actin corpus",
    state = row_label,
    y = recode(row_label, `Coordinate observed` = 3, `Non-actin protein contact` = 2, `Actin-chain contact` = 1),
    denominator = "fraction of 483 curated PDB structures"
  )

combined_source <- bind_rows(
  static %>% select(evidence_mode, organism, state, row_label, y, actb_position, value, denominator),
  md %>% select(evidence_mode, organism, state, row_label, y, actb_position, value, denominator),
  exp %>% select(evidence_mode, organism, state, row_label, y, actb_position, value, denominator)
)
write_tsv(md_detail, file.path(source_dir, "fig_combined_ACTB_structure_static_md_8F8P_dynamic_template_resolved_source.tsv"))
write_tsv(md, file.path(source_dir, "fig_combined_ACTB_structure_static_md_8F8P_dynamic_latest_source.tsv"))
write_tsv(combined_source, file.path(source_dir, "fig_combined_ACTB_structure_static_md_8F8P_20260819_source.tsv"))

heat_scale <- scale_fill_gradient(
  low = heat_cols["low"], high = heat_cols["high"], limits = c(0, 1),
  breaks = seq(0, 1, 0.25), labels = percent_format(accuracy = 1),
  na.value = heat_cols["missing"], name = "Panel-specific fraction\nor occupancy"
)

make_heat_panel <- function(data, title, subtitle, show_x = FALSE, show_legend = FALSE) {
  breaks <- sort(unique(data$y))
  labels <- data %>% distinct(y, row_label) %>% arrange(y) %>% pull(row_label)
  p <- ggplot(data, aes(x = actb_position, y = y, fill = value)) +
    geom_tile(width = 0.98, height = 0.72) +
    heat_scale +
    scale_x_continuous(breaks = x_breaks, limits = c(0.5, 375.5), expand = c(0, 0)) +
    scale_y_continuous(breaks = breaks, labels = labels,
                       limits = c(min(breaks) - 0.45, max(breaks) + 0.45), expand = c(0, 0)) +
    labs(title = title, subtitle = subtitle,
         x = if (show_x) "Human ACTB-aligned residue position" else NULL, y = NULL) +
    theme_common(7.2) +
    theme(
      axis.ticks.y = element_blank(), axis.line.y = element_blank(),
      axis.text.x = if (show_x) element_text() else element_blank(),
      axis.ticks.x = if (show_x) element_line(linewidth = 0.32) else element_blank(),
      axis.line.x = if (show_x) element_line(linewidth = 0.35) else element_blank(),
      legend.position = if (show_legend) "bottom" else "none",
      legend.justification = "left", legend.title = element_text(size = 6.8),
      legend.text = element_text(size = 6.4),
      plot.margin = margin(4, 8, 4, 27)
    )
  if (show_legend) {
    p <- p + guides(fill = guide_colourbar(
      direction = "horizontal", title.position = "top",
      barwidth = unit(48, "mm"), barheight = unit(3, "mm")
    ))
  }
  p
}

p_static <- make_heat_panel(
  static,
  "b  Static interface contact footprint",
  paste0(
    "WT, Delta tail25 and Delta KCF pooled across ACTB/ACTA1\n",
    "Mean direct-contact support within 5 A across 142 assessable templates per background"
  )
)

p_md <- make_heat_panel(
  md,
  "c  Dynamic interface persistence",
  paste0(
    "WT, Delta tail25 and Delta KCF pooled across four actin-complex backgrounds\n",
    "Mean maximum partner-residue occupancy across 3 x 50-ns replicates per background"
  )
)

p_exp <- make_heat_panel(
  exp,
  "d  Experimental actin-complex contact landscape",
  "483 curated PDB structures from the audited 8F8P complex library, globally aligned to human ACTB",
  show_x = TRUE, show_legend = TRUE
)

combined <- p_structure / p_static / p_md / p_exp +
  plot_layout(heights = c(2.05, 1.18, 1.80, 1.10)) +
  plot_annotation(
    caption = paste(
      "All tracks use the human ACTB P60709 residue axis. White gaps denote deleted or unmapped residues.\n",
      "Panels b-c show the engineered ACTB/ACTA1 deletion series; natural non-KCF actins are evaluated separately.\n",
      "Colour scales are numerically 0-1 but have panel-specific denominators and should not be compared as identical measurements."
    ),
    theme = theme(
      plot.caption = element_text(family = "Arial", size = 6.4, colour = "#666666", hjust = 0,
                                  margin = margin(t = 4)),
      plot.margin = margin(6, 6, 5, 6)
    )
  )

stem <- file.path(figure_dir, "fig_combined_ACTB_structure_static_md_8F8P_20260819")
ggsave(paste0(stem, ".pdf"), combined, device = grDevices::cairo_pdf,
       width = 183, height = 305, units = "mm", family = "Arial", bg = "white")
ggsave(paste0(stem, ".png"), combined, device = ragg::agg_png,
       width = 183, height = 305, units = "mm", dpi = 600, background = "white")

stopifnot(
  nrow(static) == 1125L,
  nrow(md) == 1125L,
  nrow(exp) == 1125L,
  all(sort(unique(combined_source$actb_position)) == 1:375),
  all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000)
)

writeLines(c(
  "PASS", "backend=R", "coordinate_system=human_ACTB_P60709_1-375",
  "panel_a=DSSP_and_functional_annotation", "panel_b=three_state_static_mean_across_ACTB_ACTA1",
  "panel_c=three_state_MD_mean_across_four_actin_complex_backgrounds_3x50ns", "panel_d=audited_8F8P_library_483_PDB_structures",
  "natural_non_KCF_controls=separate_figures_not_mixed_into_engineered_series",
  "ACTA1_MD_mapping=375_of_377_native_residues_mapped_identity_0.933333",
  "three_state_order=WT,Delta_tail25,Delta_KCF", "dynamic_source=fig_combined_ACTB_structure_static_md_8F8P_dynamic_latest_source.tsv",
  "MD_state_balance=4_backgrounds_per_state_375_positions_each",
  "MD_state_mapping=audited_with_explicit_environment_binding",
  "upstream_static_and_experimental_inputs=frozen",
  "deleted_or_unmapped_positions=white_gaps", "tail_or_KCF_outline_boxes=none", "exports=PDF,PNG_600dpi", "source_data=written",
  paste0("core_conclusion=", figure_contract$core_conclusion)
), file.path(figure_dir, "fig_combined_ACTB_structure_static_md_8F8P_20260819.QA.marker"))
