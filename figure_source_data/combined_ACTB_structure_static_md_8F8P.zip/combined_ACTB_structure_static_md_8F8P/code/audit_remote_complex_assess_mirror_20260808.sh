#!/usr/bin/env bash
set -euo pipefail
ulimit -n 65535
R=..
echo MIRROR_DIRS
find "$R" -maxdepth 4 -type d \( -name 'complex_assess' -o -name 'source_data' -o -name 'figures' -o -name 'formal*' -o -name '*archive*' \) -printf '%p\n' 2>/dev/null | head -100
echo NAMED
for n in fig_delta_tail25_vs_kcf_static_metric_support.pdf fig_md_wt_delta_kcf_tail25_interface_contacts.pdf fig_combined_ACTB_structure_static_md_8F8P.pdf delta_tail25_fullscreen_156_plot_ready.tsv; do echo -n "$n\t"; find "$R" -type f -name "$n" -printf '%p\t%s\n' 2>/dev/null | head -3; done
