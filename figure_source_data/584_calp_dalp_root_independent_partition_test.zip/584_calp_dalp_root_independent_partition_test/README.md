# 584_calp_dalp_root_independent_partition_test

- Manuscript panel: Fig.5F-G
- Source figure basename: figure_584_calp_dalp_root_independent_partition_test
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 3 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 11 directly referenced or locally packaged source-data file(s)
