# tail_kcf_static_dynamic_contact_correlation

- Manuscript panel: Supp.Fig.7H
- Source figure basename: fig_tail_kcf_static_dynamic_contact_correlation_20260819
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 3 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
