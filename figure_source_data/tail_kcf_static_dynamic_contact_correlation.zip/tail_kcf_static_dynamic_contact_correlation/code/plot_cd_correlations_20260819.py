import pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
root=Path(r'..'); fig=root/'fig'; fig.mkdir(exist_ok=True)
df=pd.read_csv(root/'data/calp_dalp_static_dynamic_correlation_20260819.tsv',sep='	')
def draw(d,path,title,colors):
 figx,ax=plt.subplots(figsize=(5.2,4.6))
 for label,g in d.groupby('label'):
  ax.scatter(g.static,g.dynamic,s=42,alpha=.85,label=label,color=colors.get(label,'#333333'),edgecolor='white',linewidth=.4)
 if len(d)>1:
  x=d.static; y=d.dynamic; ax.plot([x.min(),x.max()],[y.min(),y.max()],color='#777777',lw=1.1,ls='--')
  z=__import__('numpy').polyfit(x,y,1); xx=__import__('numpy').linspace(x.min(),x.max(),100); ax.plot(xx,z[0]*xx+z[1],color='#222222',lw=1)
 ax.axhline(0,color='#cccccc',lw=.6); ax.axvline(0,color='#cccccc',lw=.6); ax.set_xlabel('Static contact effect (variant − reference)'); ax.set_ylabel('Dynamic contact effect (variant − reference)'); ax.set_title(title,fontsize=10); ax.legend(frameon=False,fontsize=8); ax.spines[['top','right']].set_visible(False); figx.tight_layout(); figx.savefig(str(path)+'.pdf'); figx.savefig(str(path)+'.png',dpi=300); plt.close(figx)
cd=df.rename(columns={'static_dalp_minus_calp':'static','dynamic_dalp_minus_calp':'dynamic'}); cd['label']='cALP–dALP'
draw(cd,fig/'fig_calp_dalp_static_dynamic_contact_correlation_20260819','cALP–dALP dynamic validation',{'cALP–dALP':'#0072B2'})
tail=pd.read_csv(root/'data/tail_kcf_static_dynamic_contact_correlation_20260819.tsv',sep='	').rename(columns={'static_contact_loss':'static','dynamic_contact_loss':'dynamic'}); tail['label']=tail.get('variant','tail/KCF')
allx=pd.concat([cd[['static','dynamic','label']],tail[['static','dynamic','label']]],ignore_index=True)
draw(allx,fig/'fig_calp_dalp_tail_kcf_static_dynamic_contact_correlation_20260819','Static–dynamic contact concordance',{'cALP–dALP':'#0072B2','Delta KCF':'#D55E00','Delta tail25':'#CC79A7'})
