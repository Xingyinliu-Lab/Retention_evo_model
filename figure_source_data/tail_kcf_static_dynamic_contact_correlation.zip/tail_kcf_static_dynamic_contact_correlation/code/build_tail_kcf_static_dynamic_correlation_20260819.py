import csv,statistics
from pathlib import Path
out=Path(r'..')
static=list(csv.DictReader(open(r'../data/effective_stage1_combined_13104_20260721.tsv'),delimiter='\t'))
md=list(csv.DictReader(open(r'../data/fig_md_wt_delta_kcf_tail25_interface_contacts_latest_replicate_source.tsv'),delimiter='\t'))
ids={'Human ACTB':'AFSERVER_tail_mutant_EUK_HUMAN_ACTB__','Rabbit ACTA1':'AFSERVER_tail_mutant_EUK_RABBIT_ACTA1_8F8P__'}
def mean_state(org,state,t):
 v=[float(x['value']) for x in md if x['organism_label']==org and x['state']==state and x.get('template')==t]
 return statistics.mean(v) if v else None
rows=[]
for org,prefix in ids.items():
 for t in ('7W4Z','8BJH','8DD0'):
  wt=[x for x in static if x['candidate']==prefix+'WT' and x['template']==t]
  if not wt: continue
  sw=float(wt[0]['contacts_5A'])
  for state,label in [('Delta KCF','Delta KCF'),('Delta tail25','Delta tail25')]:
   sv=[x for x in static if x['candidate']==prefix+state.replace(' ','_').upper() and x['template']==t]
   # actual source uses DELTA_KCF/DELTA_TAIL25
   if not sv: sv=[x for x in static if x['candidate']==prefix+('DELTA_KCF' if 'KCF' in state else 'DELTA_TAIL25') and x['template']==t]
   dm=mean_state(org,'WT',t); dv=mean_state(org,state,t)
   if sv and dm is not None and dv is not None: rows.append([org,t,label,float(wt[0]['contacts_5A'])-float(sv[0]['contacts_5A']),dm-dv])
with open(out/'tail_kcf_static_dynamic_contact_correlation_20260819.tsv','w',newline='') as h:
 w=csv.writer(h,delimiter='\t');w.writerow(['organism','template','condition','static_contact_loss','dynamic_contact_loss']);w.writerows(rows)
print('rows',len(rows))
