from math import acos, degrees, sqrt
import os
from pathlib import Path
from pymol import cmd

root = Path(r"..")
pose_ref = Path(r"..")
transparent_bg = os.environ.get("PYMOL_TRANSPARENT_BG", "0") == "1"
actb_transparency = float(os.environ.get("ACTB_CARTOON_TRANSPARENCY", "0.70"))
output_name = (
    "B_cALPs_Homo_ACTB_AF_superposed_transparent.png"
    if transparent_bg
    else "B_cALPs_Homo_ACTB_AF_superposed.png"
)
out = root / "pymol_profile_family_atlas_fixedpose" / output_name

def centroid(selection):
    atoms = cmd.get_model(selection).atom
    return [sum(a.coord[i] for a in atoms) / len(atoms) for i in range(3)]

cmd.reinitialize()
cmd.set_color("ink", [0.071, 0.094, 0.133])
cmd.set_color("actb_green", [0.20, 0.78, 0.47])
cmd.set_color("tail_orange", [0.96, 0.40, 0.10])
cmd.set_color("terminal_magenta", [0.90, 0.23, 0.53])
for i in range(75):
    t = i / 74
    a, b = [0.298, 0.471, 0.659], [0.420, 0.620, 0.700]
    cmd.set_color(f"grad_{i:02d}", [a[j] * (1-t) + b[j] * t for j in range(3)])
cmd.bg_color("ink")
cmd.set("ray_opaque_background", 0 if transparent_bg else 1)
cmd.set("orthoscopic", 0)
cmd.set("ambient", 0.20)
cmd.set("direct", 0.80)
cmd.set("specular", 0.32)
cmd.set("shininess", 40)
cmd.set("ray_shadows", 1)
cmd.set("ambient_occlusion_mode", 2)
cmd.set("cartoon_fancy_helices", 1)
cmd.set("stick_radius", 0.18)

cmd.load(str(pose_ref), "pose_ref")
cmd.load(str(root / "Homo_actb_AF-P60709-F1-model_v6.cif"), "actb_af")
cmd.load(str(root / "fold_GCA_054384275.1_S.8_46_model_0.cif"), "calp")

# Superpose both models in their original coordinates, then apply the identical
# 8F8P fixed-pose transform to both.  This keeps the ACTB-AF analytical anchor
# and prevents a second alignment from changing the camera/object frame.
cmd.align("actb_af", "pose_ref and chain E")
cmd.align("calp", "actb_af")
core = centroid("pose_ref and chain E and resi 1-340 and not hydro")
tail = centroid("pose_ref and chain E and resi 351-375 and not hydro")
v = [tail[i] - core[i] for i in range(3)]
vnorm = sqrt(sum(x*x for x in v)); v = [x/vnorm for x in v]
target = [-0.36, 0.20, 0.91]; tnorm = sqrt(sum(x*x for x in target)); target = [x/tnorm for x in target]
axis = [v[1]*target[2]-v[2]*target[1], v[2]*target[0]-v[0]*target[2], v[0]*target[1]-v[1]*target[0]]
anorm = sqrt(sum(x*x for x in axis)); axis = [x/anorm for x in axis]
angle = degrees(acos(max(-1, min(1, sum(v[i]*target[i] for i in range(3))))))
for obj in ("actb_af", "calp"):
    cmd.translate([-core[0], -core[1], -core[2]], obj, camera=0)
    cmd.rotate(axis, angle, obj, camera=0)

# The AlphaFold mmCIF does not carry experimental secondary-structure records;
# assign a display-only secondary structure before drawing its cartoon.
cmd.dss("actb_af")

cmd.hide("everything")
cmd.show("cartoon", "actb_af")
cmd.color("actb_green", "actb_af")
cmd.set("cartoon_transparency", actb_transparency, "actb_af")
cmd.color("tail_orange", "actb_af and resi 351-372")
cmd.color("terminal_magenta", "actb_af and resi 373-375")
cmd.show("cartoon", "calp")
for i in range(75):
    lo, hi = 1 + 401*i//75, 1 + 401*(i+1)//75 - 1
    cmd.color(f"grad_{i:02d}", f"calp and resi {lo}-{hi}")
cmd.set("cartoon_transparency", 0.00, "calp")
cmd.zoom("actb_af or calp", 6)
cmd.ray(2400, 1800)
cmd.png(str(out), dpi=300)
cmd.sync()
cmd.quit()
