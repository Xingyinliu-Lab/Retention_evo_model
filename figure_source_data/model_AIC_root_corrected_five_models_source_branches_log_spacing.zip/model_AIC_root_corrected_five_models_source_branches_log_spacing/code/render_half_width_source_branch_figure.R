suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
})

script_arg <- grep("^--file=", commandArgs(), value = TRUE)
script_file <- normalizePath(sub("^--file=", "", script_arg[[1]]), winslash = "/", mustWork = TRUE)
package_root <- normalizePath(file.path(dirname(script_file), ".."), winslash = "/", mustWork = TRUE)

source_file <- file.path(package_root, "data", "five_model_source_branch_lengths_source.tsv")
annotation_file <- file.path(package_root, "data", "five_model_source_branch_lengths_p_annotations.tsv")
output_file <- file.path(
  package_root,
  "figure",
  "model_AIC_root_corrected_five_models_source_branches_log_spacing.pdf"
)

tree_cols <- c(
  "GTDB r226" = "#4D4D4D", "Asgard971 add-core" = "#3B73A3",
  "Asgard971 ASTRAL89" = "#56A6B8", "Archaea1338 add-core" = "#D08A3C",
  "Archaea1338 de novo" = "#C85A63", "Archaea1338 ASTRAL64" = "#8B6DAE"
)
tree_shapes <- c(
  "GTDB r226" = 16, "Asgard971 add-core" = 17, "Asgard971 ASTRAL89" = 15,
  "Archaea1338 add-core" = 18, "Archaea1338 de novo" = 8,
  "Archaea1338 ASTRAL64" = 7
)

x <- read_tsv(source_file, col_types = cols())
fixed_models <- c("ARD unrestricted", "Sequential retention\n(coexist middle)")
remaining_models <- setdiff(unique(x$model_label), fixed_models)
remaining_medians <- tapply(x$delta_AIC, x$model_label, median, na.rm = TRUE)[remaining_models]
model_order <- c(fixed_models, names(sort(remaining_medians)))
x <- x %>% mutate(
  tree_label = factor(tree_label, levels = names(tree_cols)),
  model_label = factor(model_label, levels = model_order)
)
model_levels <- levels(x$model_label)
annotations <- read_tsv(annotation_file, col_types = cols()) %>%
  mutate(model_label = factor(model_label, levels = model_levels))

breaks_raw <- c(0, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000)

p <- ggplot(x, aes(as.numeric(model_label), y_plot, group = model_label)) +
  geom_hline(yintercept = 0, linewidth = 0.30, colour = "#666666", linetype = "22") +
  geom_boxplot(width = 0.48, linewidth = 0.30, outlier.shape = NA, fill = NA, colour = "#8F8F8F") +
  geom_point(
    aes(colour = tree_label, shape = tree_label),
    position = position_jitter(width = 0.075, height = 0, seed = 20260820), size = 1.85
  ) +
  geom_text(
    data = annotations, aes(x = x, y = y, label = p_label), inherit.aes = FALSE,
    family = "Arial", size = 2.25, colour = "#252525", vjust = 0
  ) +
  scale_x_continuous(
    breaks = seq_along(levels(x$model_label)), labels = levels(x$model_label),
    limits = c(0.65, length(levels(x$model_label)) + 0.35)
  ) +
  scale_y_continuous(
    breaks = log10(breaks_raw + 1), labels = breaks_raw,
    minor_breaks = NULL, expand = expansion(mult = c(0.01, 0.13))
  ) +
  scale_colour_manual(values = tree_cols, drop = FALSE) +
  scale_shape_manual(values = tree_shapes, drop = FALSE) +
  labs(
    x = NULL, y = expression(Delta * "AIC"), colour = NULL, shape = NULL,
    title = "Source branch lengths",
    caption = paste(
      "P values: unadjusted two-sided exact paired Wilcoxon signed-rank tests",
      "across six matched species-tree reconstructions; each comparison is versus sequential retention.",
      "Trees are sensitivity reconstructions, not independent biological replicates."
    )
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.30), axis.ticks = element_line(linewidth = 0.28),
    axis.text.x = element_text(size = 6.3, hjust = 0.5),
    plot.title = element_text(size = 8.2, face = "bold"),
    plot.caption = element_text(size = 5.2, colour = "#555555", hjust = 0),
    legend.position = "top", legend.text = element_text(size = 5.5),
    plot.margin = margin(3, 6, 2, 5)
  ) +
  guides(colour = guide_legend(nrow = 1), shape = guide_legend(nrow = 1))

ggsave(output_file, p, width = 91.5, height = 96, units = "mm", device = cairo_pdf)
