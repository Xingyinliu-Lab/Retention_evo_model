# Quality distributions for retained archaeal MAGs by phylum
# Metrics: completeness, contamination, contig N50 and total contig count

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
script_dir <- if (length(script_arg) == 1) {
  dirname(normalizePath(sub("^--file=", "", script_arg)))
} else {
  normalizePath("arch_mag_desc")
}

input_file <- file.path(script_dir, "18261_arch_mag_meta.txt")
output_dir <- file.path(script_dir, "figures")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

mag <- read.delim(
  input_file,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_columns <- c(
  "p", "Completeness", "Contamination", "Contig_N50",
  "Total_Contigs", "pass.GUNC", "quality_checkm2"
)
missing_columns <- setdiff(required_columns, names(mag))
if (length(missing_columns) > 0) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}

gunc_pass <- tolower(trimws(as.character(mag$pass.GUNC))) == "true"
quality <- trimws(as.character(mag$quality_checkm2))
final_mag <- mag[gunc_pass & quality %in% c("HQ", "MQ"), , drop = FALSE]

final_mag$phylum <- trimws(as.character(final_mag$p))
final_mag$Completeness <- as.numeric(final_mag$Completeness)
final_mag$Contamination <- as.numeric(final_mag$Contamination)
final_mag$Contig_N50 <- as.numeric(final_mag$Contig_N50)
final_mag$Total_Contigs <- as.numeric(final_mag$Total_Contigs)
final_mag <- final_mag[nzchar(final_mag$phylum), , drop = FALSE]

if (nrow(final_mag) != 15914) {
  warning("Expected 15,914 retained MAGs; observed ", nrow(final_mag), ".")
}

phylum_n <- sort(table(final_mag$phylum), decreasing = TRUE)
phylum_order <- names(phylum_n)
phylum_labels <- paste0(
  phylum_order,
  " (n=",
  format(
    as.integer(phylum_n),
    big.mark = ",",
    scientific = FALSE,
    trim = TRUE
  ),
  ")"
)
names(phylum_labels) <- phylum_order

final_mag$phylum_factor <- factor(
  final_mag$phylum,
  levels = rev(phylum_order)
)
final_mag$phylum_label <- factor(
  phylum_labels[final_mag$phylum],
  levels = rev(phylum_labels)
)

rare_phyla <- names(phylum_n[phylum_n < 5])
rare_mag <- final_mag[final_mag$phylum %in% rare_phyla, , drop = FALSE]

summarize_metric <- function(data, metric, metric_label) {
  groups <- split(data[[metric]], data$phylum)
  do.call(
    rbind,
    lapply(names(groups), function(phylum_name) {
      x <- groups[[phylum_name]]
      x <- x[is.finite(x)]
      data.frame(
        phylum = phylum_name,
        n = length(x),
        metric = metric_label,
        q1 = unname(quantile(x, 0.25)),
        median = median(x),
        q3 = unname(quantile(x, 0.75)),
        min = min(x),
        max = max(x),
        stringsAsFactors = FALSE
      )
    })
  )
}

quality_summary <- rbind(
  summarize_metric(final_mag, "Completeness", "Completeness (%)"),
  summarize_metric(final_mag, "Contamination", "Contamination (%)"),
  summarize_metric(final_mag, "Contig_N50", "Contig N50 (bp)"),
  summarize_metric(final_mag, "Total_Contigs", "Total contigs")
)
quality_summary <- quality_summary[
  order(
    match(
      quality_summary$metric,
      c(
        "Completeness (%)", "Contamination (%)",
        "Contig N50 (bp)", "Total contigs"
      )
    ),
    match(quality_summary$phylum, phylum_order)
  ),
]

write.csv(
  quality_summary,
  file.path(output_dir, "source_data_phylum_quality_summary.csv"),
  row.names = FALSE
)

theme_quality <- function(show_y = TRUE) {
  theme_classic(base_size = 6.7, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.32, colour = "#293241"),
      axis.line.y = element_blank(),
      axis.ticks = element_line(linewidth = 0.32, colour = "#293241"),
      axis.ticks.y = element_blank(),
      axis.ticks.length = grid::unit(1.1, "mm"),
      axis.title = element_text(size = 6.8, colour = "#293241"),
      axis.text.x = element_text(size = 5.9, colour = "#293241"),
      axis.text.y = if (show_y) {
        element_text(size = 5.55, colour = "#293241", margin = margin(r = 1.5))
      } else {
        element_blank()
      },
      plot.title = element_text(size = 7.4, face = "bold", colour = "#172033"),
      plot.subtitle = element_text(size = 5.8, colour = "#687386", margin = margin(b = 1.5)),
      plot.tag = element_text(size = 8.5, face = "bold", colour = "#172033"),
      plot.margin = margin(3.5, 5, 3.5, if (show_y) 3 else 1),
      panel.grid.major.y = element_line(linewidth = 0.22, colour = "#E7EBF0"),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank()
    )
}

base_boxplot <- function(
    data,
    metric,
    title,
    subtitle,
    x_label,
    fill,
    line_colour,
    show_y = TRUE) {
  y_column <- if (show_y) "phylum_label" else "phylum_factor"
  ggplot(data, aes(x = .data[[metric]], y = .data[[y_column]])) +
    geom_boxplot(
      width = 0.50,
      linewidth = 0.38,
      colour = line_colour,
      fill = fill,
      alpha = 0.92,
      outlier.shape = NA
    ) +
    stat_summary(
      fun = median,
      geom = "point",
      shape = 21,
      size = 1.05,
      stroke = 0.35,
      colour = line_colour,
      fill = "white"
    ) +
    geom_point(
      data = rare_mag,
      aes(x = .data[[metric]], y = .data[[y_column]]),
      inherit.aes = FALSE,
      size = 1.35,
      shape = 21,
      fill = "white",
      colour = line_colour,
      stroke = 0.45
    ) +
    labs(
      x = x_label,
      y = NULL,
      title = title,
      subtitle = subtitle
    ) +
    theme_quality(show_y = show_y)
}

p_completeness <- base_boxplot(
  final_mag,
  "Completeness",
  "CheckM2 completeness",
  "Retention threshold: 90%",
  "Completeness (%)",
  "#B7C8D8",
  "#496B8A",
  show_y = TRUE
) +
  geom_vline(
    xintercept = 90,
    linewidth = 0.35,
    linetype = "22",
    colour = "#C64E45"
  ) +
  scale_x_continuous(
    limits = c(45, 101),
    breaks = c(50, 60, 70, 80, 90, 100)
  )

p_contamination <- base_boxplot(
  final_mag,
  "Contamination",
  "CheckM2 contamination",
  "Retention thresholds: 5% and 10%",
  "Contamination (%) (square-root axis)",
  "#E6C0B8",
  "#9A594E",
  show_y = FALSE
) +
  geom_vline(
    xintercept = c(5, 10),
    linewidth = 0.35,
    linetype = "22",
    colour = c("#C58B2B", "#C64E45")
  ) +
  scale_x_sqrt(
    limits = c(0, 10.2),
    breaks = c(0, 1, 2, 5, 10)
  )

p_n50 <- base_boxplot(
  final_mag,
  "Contig_N50",
  "Assembly continuity",
  "Higher values indicate greater continuity",
  "Contig N50 (bp, log10 axis)",
  "#B7D3CD",
  "#477F74",
  show_y = TRUE
) +
  scale_x_log10(
    breaks = c(1000, 10000, 100000, 1000000),
    labels = c("1k", "10k", "100k", "1M")
  )

p_contigs <- base_boxplot(
  final_mag,
  "Total_Contigs",
  "Assembly fragmentation",
  "Lower values indicate greater continuity",
  "Total contigs (log10 axis)",
  "#D1C2D4",
  "#755E7A",
  show_y = FALSE
) +
  scale_x_log10(
    breaks = c(1, 10, 100, 1000),
    labels = c("1", "10", "100", "1k")
  )

figure <- (p_completeness | p_contamination) /
  (p_n50 | p_contigs) +
  plot_layout(widths = c(1.10, 0.90)) +
  plot_annotation(
    tag_levels = "a",
    caption = paste0(
      "Boxes show the interquartile range; white points denote medians; whiskers extend to 1.5 x IQR.\n",
      "Outliers are omitted for clarity. Phyla are ordered by retained MAG count.\n",
      "Open points denote phyla with n < 5."
    )
  ) &
  theme(
    plot.tag = element_text(size = 8.5, face = "bold", family = "Arial"),
    plot.caption = element_text(
      size = 5.5,
      colour = "#687386",
      hjust = 0,
      family = "Arial",
      margin = margin(t = 3)
    )
  )

width_mm <- 122
height_mm <- 178
width_in <- width_mm / 25.4
height_in <- height_mm / 25.4
output_suffix <- Sys.getenv("ACTIN_MAG_QUALITY_OUTPUT_SUFFIX", unset = "")
output_stem <- file.path(
  output_dir,
  paste0("arch_mag_phylum_quality_boxplots", output_suffix)
)

grDevices::cairo_pdf(
  paste0(output_stem, ".pdf"),
  width = width_in,
  height = height_in,
  family = "Arial"
)
print(figure)
grDevices::dev.off()

grDevices::png(
  paste0(output_stem, "_preview.png"),
  width = width_in,
  height = height_in,
  units = "in",
  res = 300,
  type = "cairo",
  bg = "white"
)
print(figure)
grDevices::dev.off()

message(
  "Created quality boxplots for ",
  length(phylum_order),
  " phyla and ",
  format(nrow(final_mag), big.mark = ",", scientific = FALSE),
  " retained MAGs."
)
