# arch_mag_phylum_quality_boxplots

- Manuscript panel: Supp.Fig.1B
- Source figure basename: arch_mag_phylum_quality_boxplots
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 9 directly referenced or locally packaged source-data file(s)
