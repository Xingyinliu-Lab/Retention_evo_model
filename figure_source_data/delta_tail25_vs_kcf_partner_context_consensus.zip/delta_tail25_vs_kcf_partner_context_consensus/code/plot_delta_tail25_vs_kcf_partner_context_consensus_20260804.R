suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(ragg)
})

root <- ".."
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")

figure_contract <- list(
  core_conclusion = paste(
    "Full-tail deletion causes broader context-level interface weakening than KCF deletion,",
    "with marked partner-context and actin-specific heterogeneity."
  ),
  archetype = "single quantitative comparison",
  backend = "R",
  denominator = "the same 156 templates per actin and perturbation across 18 refined contexts",
  statistics = "descriptive structural coverage only"
)

tail <- read_tsv(
  file.path(source_dir, "fig_delta_tail25_partner_context_source.tsv"),
  show_col_types = FALSE
) %>% mutate(perturbation = "Delta tail25")
kcf <- read_tsv(
  file.path(source_dir, "fig_delta_kcf_partner_context_source.tsv"),
  show_col_types = FALSE
) %>% mutate(perturbation = "Delta KCF")

raw <- bind_rows(tail, kcf)
order_table <- raw %>%
  group_by(context_final, perturbation) %>%
  summarise(mean_fraction = mean(fraction_consensus), .groups = "drop") %>%
  pivot_wider(names_from = perturbation, values_from = mean_fraction) %>%
  mutate(tail_minus_kcf = `Delta tail25` - `Delta KCF`) %>%
  arrange(tail_minus_kcf, context_final) %>%
  mutate(y_base = row_number())

d <- raw %>%
  left_join(order_table %>% select(context_final, tail_minus_kcf, y_base), by = "context_final") %>%
  mutate(
    perturbation = factor(perturbation, levels = c("Delta tail25", "Delta KCF")),
    organism_label = factor(organism_label, levels = c("Human ACTB", "Rabbit ACTA1")),
    y_offset = case_when(
      perturbation == "Delta tail25" & organism_label == "Human ACTB" ~ 0.27,
      perturbation == "Delta tail25" & organism_label == "Rabbit ACTA1" ~ 0.09,
      perturbation == "Delta KCF" & organism_label == "Human ACTB" ~ -0.09,
      TRUE ~ -0.27
    ),
    y = y_base + y_offset,
    label_x = fraction_consensus + if_else(fraction_consensus > 0.92, -0.018, 0.018),
    label_hjust = if_else(fraction_consensus > 0.92, 1, 0)
  )

stopifnot(
  nrow(d) == 72L,
  n_distinct(d$context_final) == 18L,
  n_distinct(d$perturbation) == 2L,
  n_distinct(d$organism_label) == 2L,
  all(d$n_templates >= 1L)
)

write_tsv(d, file.path(source_dir, "fig_delta_tail25_vs_kcf_partner_context_consensus_source.tsv"))
write_tsv(order_table, file.path(source_dir, "fig_delta_tail25_vs_kcf_partner_context_order_source.tsv"))

context_labels <- order_table %>%
  arrange(y_base) %>%
  transmute(y_base, label = gsub("_", " ", context_final))
palette <- c("Delta tail25" = "#3976A8", "Delta KCF" = "#D0833D")
shapes <- c("Human ACTB" = 21, "Rabbit ACTA1" = 24)

p <- ggplot(d, aes(x = fraction_consensus, y = y)) +
  geom_hline(yintercept = order_table$y_base, linewidth = 0.22, colour = "#E8E8E8") +
  geom_point(
    aes(fill = perturbation, shape = organism_label),
    size = 2.85, stroke = 0.42, colour = "#222222"
  ) +
  geom_text(
    aes(x = label_x, label = label, colour = perturbation, hjust = label_hjust),
    size = 1.95, fontface = "bold", show.legend = FALSE
  ) +
  scale_fill_manual(values = palette, name = "Perturbation") +
  scale_colour_manual(values = palette) +
  scale_shape_manual(values = shapes, name = "Actin") +
  guides(
    fill = guide_legend(order = 1, override.aes = list(
      shape = c(21, 21), fill = unname(palette), colour = c("#222222", "#222222")
    )),
    shape = guide_legend(order = 2, override.aes = list(fill = "white"))
  ) +
  scale_x_continuous(
    labels = scales::label_percent(accuracy = 1), breaks = seq(0, 1, 0.2),
    limits = c(-0.06, 1.06), expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    breaks = context_labels$y_base, labels = context_labels$label,
    limits = c(0.55, 18.45), expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Context-specific responses to full-tail and KCF deletion",
    subtitle = "Eighteen refined contexts ordered by the mean\nDelta tail25 minus Delta KCF effect",
    x = "Templates with at least 3 of 5 static metrics supporting interface loss", y = NULL,
    caption = paste(
      "Labels show n/N; colour denotes perturbation and shape denotes actin.\n",
      "Singleton contexts are retained; descriptive structural coverage only."
    )
  ) +
  theme_classic(base_size = 8.0, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#222222"),
    axis.text.y = element_text(size = 6.7),
    legend.position = "top", legend.justification = "left", legend.box = "vertical",
    legend.box.margin = margin(0, 0, 2, 0),
    legend.title = element_text(size = 7.1, face = "bold"),
    legend.text = element_text(size = 7.1),
    plot.title = element_text(size = 9.5, face = "bold"),
    plot.subtitle = element_text(size = 8.0, colour = "#4D4D4D"),
    plot.caption = element_text(size = 6.8, colour = "#666666", hjust = 0),
    panel.grid = element_blank(),
    plot.margin = margin(8, 12, 8, 8)
  )

stem <- file.path(figure_dir, "fig_delta_tail25_vs_kcf_partner_context_consensus")
ggsave(paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
       width = 150, height = 205, units = "mm", family = "Arial")
ggsave(paste0(stem, ".png"), p, device = ragg::agg_png,
       width = 150, height = 205, units = "mm", dpi = 600, background = "white")

stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
writeLines(
  c(
    "PASS", "backend=R", "rows=72", "contexts=18", "perturbations=2", "actins=2",
    "singleton_contexts_retained=yes", "independent_biological_replicates=no",
    paste0("core_conclusion=", figure_contract$core_conclusion)
  ),
  paste0(stem, ".QA.marker")
)
