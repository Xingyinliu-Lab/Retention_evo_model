# delta_tail25_vs_kcf_partner_context_consensus

- Manuscript panel: Fig.3C
- Source figure basename: fig_delta_tail25_vs_kcf_partner_context_consensus
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
