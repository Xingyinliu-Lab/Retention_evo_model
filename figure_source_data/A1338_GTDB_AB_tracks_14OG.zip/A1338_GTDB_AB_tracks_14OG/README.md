# A1338_GTDB_AB_tracks_14OG

- Manuscript panel: Supp.Fig.13A-part4
- Source figure basename: fig_A1338_GTDB_AB_tracks_14OG
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 28 directly referenced or locally packaged source-data file(s)
