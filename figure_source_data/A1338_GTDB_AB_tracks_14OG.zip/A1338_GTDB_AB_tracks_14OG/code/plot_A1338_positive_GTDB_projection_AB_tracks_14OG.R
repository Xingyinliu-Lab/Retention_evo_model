suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(tidyr)
})

package_root <- ".."
data_dir <- file.path(package_root, "data")
figure_dir <- file.path(package_root, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

projection_file <- file.path(data_dir, "A1338_GTDB_projection_mapping.tsv")
tip_order_file <- file.path(data_dir, "A1338_GTDB_projection_tip_order.tsv")
state_file <- file.path(data_dir, "formal_14_host_states.tsv")
state_audit_file <- file.path(data_dir, "formal_14_host_state_audit.tsv")
order_file <- file.path(data_dir, "fig_14_shared_OG_order.tsv")
function_file <- file.path(data_dir, "fig_14_function_labels_clean.tsv")
stopifnot(all(file.exists(c(projection_file, tip_order_file, state_file,
                            state_audit_file, order_file, function_file))))

state_palette <- c(
  "A-only" = "#4C78A8",
  "A+B coexist" = "#D89C2B",
  "B-only" = "#4F9C8E",
  "taxon collision" = "#7A6F8F",
  "no state" = "#F0F0F0"
)

projection <- read_tsv(projection_file, show_col_types = FALSE, progress = FALSE) %>%
  select(mag_id, anchor_tip)
tip_order <- read_tsv(tip_order_file, show_col_types = FALSE, progress = FALSE) %>%
  select(gtdb_tip, tip_order)
states <- read_tsv(state_file, show_col_types = FALSE, progress = FALSE)
state_audit <- read_tsv(state_audit_file, show_col_types = FALSE, progress = FALSE)
case_order <- read_tsv(order_file, show_col_types = FALSE, progress = FALSE) %>%
  transmute(og_id, case_order = x_position)
functions <- read_tsv(function_file, show_col_types = FALSE, progress = FALSE) %>%
  select(og_id, functional_label)

stopifnot(
  n_distinct(states$og_id) == 14L,
  nrow(state_audit) == 14L,
  all(state_audit$status == "PASS"),
  !anyDuplicated(states[c("og_id", "host_id")]),
  nrow(case_order) == 14L,
  setequal(case_order$og_id, unique(states$og_id)),
  !anyDuplicated(tip_order$gtdb_tip),
  !anyDuplicated(tip_order$tip_order)
)

case_meta <- case_order %>%
  left_join(functions, by = "og_id") %>%
  mutate(
    functional_label = if_else(is.na(functional_label) | functional_label == "",
                               "uncharacterized", functional_label),
    case_label = paste0(og_id, "  |  ", functional_label)
  ) %>%
  arrange(case_order)
stopifnot(!anyNA(case_meta$case_label))

case_states <- states %>%
  transmute(og_id, mag_id = host_id, display_state = state) %>%
  left_join(projection, by = "mag_id")
stopifnot(all(case_states$display_state %in% c("A-only", "A+B coexist", "B-only")))

tip_case_states <- case_states %>%
  filter(!is.na(anchor_tip)) %>%
  group_by(og_id, gtdb_tip = anchor_tip) %>%
  summarise(
    n_MAGs = n_distinct(mag_id),
    observed_states = paste(sort(unique(display_state)), collapse = ";"),
    display_state = case_when(
      "A+B coexist" %in% display_state ~ "A+B coexist",
      n_distinct(display_state) == 1L ~ first(display_state),
      TRUE ~ "taxon collision"
    ),
    .groups = "drop"
  )

track_data <- crossing(
  case_meta %>% select(og_id, case_label, case_order),
  tip_order
) %>%
  left_join(tip_case_states, by = c("og_id", "gtdb_tip")) %>%
  mutate(
    display_state = replace_na(display_state, "no state"),
    case_label = factor(case_label, levels = rev(case_meta$case_label))
  )

reference_axis <- tip_order %>% arrange(tip_order) %>% pull(gtdb_tip)
axis_match_audit <- track_data %>%
  arrange(case_order, tip_order) %>%
  group_by(og_id) %>%
  summarise(
    axis_tips = n(),
    min_tip_order = min(tip_order),
    max_tip_order = max(tip_order),
    exact_GTDB_axis_match = identical(gtdb_tip, reference_axis),
    .groups = "drop"
  )
stopifnot(nrow(axis_match_audit) == 14L,
          all(axis_match_audit$exact_GTDB_axis_match))

projection_audit <- case_states %>%
  group_by(og_id) %>%
  summarise(
    formal_MAGs = n(),
    mapped_MAGs = sum(!is.na(anchor_tip)),
    unmapped_MAGs = sum(is.na(anchor_tip)),
    mapping_fraction = mapped_MAGs / formal_MAGs,
    .groups = "drop"
  )

p <- ggplot(track_data, aes(tip_order, case_label, fill = display_state)) +
  geom_tile(width = 1, height = 0.64, colour = NA) +
  scale_fill_manual(
    values = state_palette,
    breaks = c("A-only", "A+B coexist", "B-only", "taxon collision"),
    labels = c("A-only", "A+B coexist", "B-only",
               "multiple MAG states at one GTDB tip"),
    name = NULL,
    drop = FALSE
  ) +
  scale_x_continuous(expand = c(0, 0)) +
  labs(x = NULL, y = NULL) +
  theme_void(base_family = "Arial", base_size = 6.5) +
  theme(
    axis.text.y = element_text(size = 5.6, colour = "#202020", hjust = 1,
                               margin = margin(r = 3.5)),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 5.7, colour = "#303030"),
    legend.key.width = grid::unit(4.4, "mm"),
    legend.key.height = grid::unit(2.1, "mm"),
    legend.margin = margin(0, 0, 1.5, 0),
    plot.margin = margin(1, 1.5, 1, 1.5)
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE,
                             override.aes = list(colour = NA)))

stem <- "fig_A1338_GTDB_AB_tracks_14OG"
ggsave(file.path(figure_dir, paste0(stem, ".pdf")), p,
       width = 183, height = 62, units = "mm", device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, paste0(stem, ".png")), p,
       width = 183, height = 62, units = "mm", dpi = 420, bg = "white")

write_tsv(case_meta, file.path(data_dir, "A1338_positive_14OG_case_metadata.tsv"))
write_tsv(track_data,
          file.path(data_dir, "A1338_positive_GTDB_projection_AB_tracks_14OG_source.tsv"))
write_tsv(axis_match_audit,
          file.path(data_dir, "A1338_positive_GTDB_projection_AB_tracks_14OG_axis_match_audit.tsv"))
write_tsv(projection_audit,
          file.path(data_dir, "A1338_positive_14OG_projection_audit.tsv"))

marker <- c(
  "status=complete",
  "cases=14",
  "case_set=2_strong_plus_12_supported",
  paste0("formal_state_rows=", nrow(case_states)),
  paste0("mapped_state_rows=", sum(!is.na(case_states$anchor_tip))),
  paste0("unmapped_state_rows=", sum(is.na(case_states$anchor_tip))),
  paste0("taxon_collision_cells=", sum(tip_case_states$display_state == "taxon collision")),
  "axis=existing_A1338_taxon_name_pruned_GTDB_r226_tip_order",
  paste0("GTDB_axis_tips=", nrow(tip_order)),
  "GTDB_axis_exact_match_14_of_14=true",
  "GTDB_axis_reordered=false",
  "GTDB_axis_case_specific_pruning=false",
  "A_B_direction=undefined",
  paste0("output_pdf=", file.path(figure_dir, paste0(stem, ".pdf"))),
  paste0("output_png=", file.path(figure_dir, paste0(stem, ".png")))
)
writeLines(marker, file.path(package_root, "PACKAGE_COMPLETE.marker"))
cat(paste(marker, collapse = "\n"), "\n")
