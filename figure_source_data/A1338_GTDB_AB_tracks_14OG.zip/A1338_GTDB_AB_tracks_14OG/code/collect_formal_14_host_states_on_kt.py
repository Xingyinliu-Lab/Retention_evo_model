#!/usr/bin/env python3
"""Collect current formal A/B MAG states for the frozen 14-case display set.

Run on kt, where the canonical AU case inputs and matched ALE mappings reside.
The A/B orientation follows each case's frozen reciprocal constraint and is
biologically undirected.
"""

from __future__ import annotations

import csv
import hashlib
import argparse
from collections import Counter, defaultdict
from pathlib import Path

from Bio import Phylo


DEFAULT_AU_ROOT = Path("..")
OGS = [
    "OG0000244", "OG0001088", "OG0000688", "OG0001243",
    "OG0001580", "OG0002358", "OG0001833", "OG0000345",
    "OG0001050", "OG0001565", "OG0000566", "OG0001791",
    "OG0002388", "OG0001568",
]


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict], columns: list[str]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def host_from_gene_id(gene_id: str):
    if "_S." not in gene_id:
        raise RuntimeError(f"Cannot derive exact MAG prefix from gene ID: {gene_id}")
    return gene_id.rsplit("_S.", 1)[0]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--au-root", type=Path, default=DEFAULT_AU_ROOT)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    au_root = args.au_root
    out = args.out or au_root / "GTDB_projection_AB_tracks_14_strong_supported_20260827"
    states_out, audits = [], []
    for og in OGS:
        case = au_root / "cases" / og
        constraint = case / "input" / "reciprocal_AB.constraint.treefile"
        mapping_path = case / "results" / "ordinary_ALE_GTDB_r226" / "gene_to_species.tsv"
        if not constraint.is_file():
            raise RuntimeError(f"Missing reciprocal constraint: {constraint}")
        tree = Phylo.read(str(constraint), "newick")
        if len(tree.root.clades) != 2:
            raise RuntimeError(f"{og}: reciprocal constraint root is not bifurcating")
        a_genes = {tip.name for tip in tree.root.clades[0].get_terminals()}
        b_genes = {tip.name for tip in tree.root.clades[1].get_terminals()}
        if not a_genes or not b_genes or a_genes & b_genes:
            raise RuntimeError(f"{og}: invalid A/B terminal sets")

        if mapping_path.is_file():
            mapping = {row["gene_id"]: row["host_id"] for row in read_tsv(mapping_path)}
            mapping_source = "matched_ALE_gene_to_species"
            if set(mapping) != a_genes | b_genes:
                raise RuntimeError(f"{og}: mapping and reciprocal A/B gene sets differ")
        else:
            mapping = {gene: host_from_gene_id(gene) for gene in a_genes | b_genes}
            mapping_source = "exact_gene_header_MAG_prefix"

        host_counts = defaultdict(lambda: [0, 0])
        for gene in a_genes:
            host_counts[mapping[gene]][0] += 1
        for gene in b_genes:
            host_counts[mapping[gene]][1] += 1
        counts = Counter()
        for host in sorted(host_counts):
            na, nb = host_counts[host]
            state = "A+B coexist" if na and nb else ("A-only" if na else "B-only")
            counts[state] += 1
            states_out.append({"og_id": og, "host_id": host, "state": state, "n_A": na, "n_B": nb})
        audits.append({
            "og_id": og,
            "n_genes": len(mapping),
            "n_hosts": len(host_counts),
            "n_A_only": counts["A-only"],
            "n_coexist": counts["A+B coexist"],
            "n_B_only": counts["B-only"],
            "mapping_source": mapping_source,
            "constraint_sha256": sha256(constraint),
            "mapping_sha256": sha256(mapping_path) if mapping_path.is_file() else "NA",
            "status": "PASS",
        })

    write_tsv(out / "formal_14_host_states.tsv", states_out,
              ["og_id", "host_id", "state", "n_A", "n_B"])
    write_tsv(out / "formal_14_host_state_audit.tsv", audits,
              ["og_id", "n_genes", "n_hosts", "n_A_only", "n_coexist", "n_B_only",
               "mapping_source", "constraint_sha256", "mapping_sha256", "status"])
    (out / "COLLECT_COMPLETE.marker").write_text(
        f"status=complete\ncases={len(OGS)}\nstate_rows={len(states_out)}\n"
        "AB_definition=copy_associated_AB_v2_orderCV\nA_B_direction=undefined\n",
        encoding="utf-8",
    )
    print(f"status=complete cases={len(OGS)} state_rows={len(states_out)}")


if __name__ == "__main__":
    main()
