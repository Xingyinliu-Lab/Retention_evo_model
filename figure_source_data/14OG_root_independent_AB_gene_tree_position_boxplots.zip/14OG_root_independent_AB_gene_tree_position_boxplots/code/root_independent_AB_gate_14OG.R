suppressPackageStartupMessages({library(ape); library(dplyr); library(ggplot2)})

base <- ".."
out <- file.path(base, "A_B_root_position_boxplots_14OG_20260827")
full31_mode <- identical(Sys.getenv("AB_GATE_MODE"), "full31")
prefix <- if (full31_mode) "fig_31OG" else "fig_14OG"
tree_dir <- file.path(base, "full31_support_and_AU_figures_20260827/data/raw/formal")
assign_file <- file.path(base, "full31_support_and_AU_figures_20260827/data/formal31_rescreen/copy_associated_AB_sequence_assignments.tsv")
order_file <- file.path(base, "data/AB_MAG_state_stacked_14_strong_supported/fig_14_shared_OG_x_order.tsv")
label_file <- file.path(base, "GTDB_projection_AB_tracks_14_strong_supported_20260827/data/fig_14_function_labels_clean.tsv")
a0 <- read.delim(assign_file, stringsAsFactors=FALSE)
if (full31_mode) {
  tab1 <- read.delim(file.path(base,"tables","Supplementary_Table_1_31_AU_gate_evidence.tsv"),stringsAsFactors=FALSE)
  ord <- data.frame(x_position=seq_len(nrow(tab1)),og_id=tab1$og_id)
} else {
  ord <- read.delim(order_file, stringsAsFactors=FALSE) |> arrange(x_position)
}
label_tab <- read.delim(label_file, stringsAsFactors=FALSE) |>
  mutate(functional_label=if_else(is.na(functional_label) | functional_label=="", "unannotated", functional_label),
         function_short=if_else(nchar(functional_label)>32,paste0(substr(functional_label,1,29),"..."),functional_label),
         axis_label=paste0(og_id,"\n",function_short))
axis_labels <- setNames(label_tab$axis_label,label_tab$og_id)

permanova_f <- function(d2, g) {
  n <- length(g); lev <- unique(g); k <- length(lev)
  ss_total <- sum(d2)/(2*n)
  ss_within <- sum(vapply(lev, function(z) {i <- which(g==z); sum(d2[i,i,drop=FALSE])/(2*length(i))}, numeric(1)))
  ss_between <- ss_total-ss_within
  c(F=(ss_between/(k-1))/(ss_within/(n-k)), R2=ss_between/ss_total)
}

one_og <- function(og, nperm=999L) {
  tr <- read.tree(file.path(tree_dir, paste0(og,".treefile")))
  a <- a0 |> filter(og_id==og)
  stopifnot(setequal(tr$tip.label,a$sequence_id))
  a <- a[match(tr$tip.label,a$sequence_id),]
  d <- cophenetic.phylo(tr); diam <- max(d); d2 <- d^2
  g <- a$copy_associated_state
  obs <- permanova_f(d2,g)
  set.seed(20260827+as.integer(sub("OG","",og)))
  pf <- replicate(nperm, permanova_f(d2,sample(g))["F"])
  pperm <- (1+sum(pf>=obs["F"]-1e-12))/(nperm+1)

  score <- numeric(nrow(a))
  for(i in seq_len(nrow(a))) {
    same <- which(g==g[i] & seq_along(g)!=i); other <- which(g!=g[i])
    da <- if(length(same)) median(d[i,same]) else NA_real_
    db <- median(d[i,other])
    score[i] <- if(g[i]=="A") (da-db)/diam else (db-da)/diam
  }
  seqtab <- data.frame(og_id=og,sequence_id=a$sequence_id,host_id=a$host_id,state=g,
                       tree_position_score=score,stringsAsFactors=FALSE)

  coexist <- a |> distinct(host_id,copy_associated_state) |> count(host_id) |> filter(n==2) |> pull(host_id)
  nearest <- apply(d+diag(Inf,nrow(d)),1,min)
  mags <- lapply(coexist,function(h){
    ix <- which(a$host_id==h); ia <- ix[g[ix]=="A"]; ib <- ix[g[ix]=="B"]
    obsab <- median(d[ia,ib,drop=FALSE])/diam
    nullnn <- median(nearest[ix])/diam
    data.frame(og_id=og,host_id=h,observed_AB=obsab,terminal_NN_null=nullnn,difference=obsab-nullnn)
  }) |> bind_rows()
  pterm <- suppressWarnings(wilcox.test(mags$observed_AB,mags$terminal_NN_null,paired=TRUE,
                                        alternative="greater",exact=FALSE)$p.value)
  summary <- data.frame(og_id=og,n_tips=nrow(a),n_coexist_MAGs=nrow(mags),
                        permanova_F=obs["F"],permanova_R2=obs["R2"],permanova_p=pperm,
                        median_AB_distance=median(mags$observed_AB),
                        median_terminal_NN=median(mags$terminal_NN_null),terminal_null_p=pterm)
  list(summary=summary,seq=seqtab,mags=mags)
}

res <- lapply(ord$og_id,one_og)
sumtab <- bind_rows(lapply(res,`[[`,"summary")) |>
  mutate(pass_AB_tree_position=permanova_p<0.05,
         pass_within_MAG_nonterminal=terminal_null_p<0.05,
         pass_root_independent_gate=pass_AB_tree_position & pass_within_MAG_nonterminal)
seqtab <- bind_rows(lapply(res,`[[`,"seq")) |>
  mutate(og_id=factor(og_id,levels=ord$og_id),state=factor(state,levels=c("A","B")))
magt <- bind_rows(lapply(res,`[[`,"mags"))
write.table(sumtab,file.path(out,"data",paste0(prefix,"_root_independent_AB_gate_summary.tsv")),sep="\t",quote=FALSE,row.names=FALSE)
write.table(seqtab,file.path(out,"data",paste0(prefix,"_root_independent_tree_position_scores.tsv")),sep="\t",quote=FALSE,row.names=FALSE)
write.table(magt,file.path(out,"data",paste0(prefix,"_within_MAG_terminal_null_comparison.tsv")),sep="\t",quote=FALSE,row.names=FALSE)

p <- ggplot(seqtab,aes(og_id,tree_position_score,fill=state,colour=state))+
  geom_hline(yintercept=0,linetype="dashed",linewidth=.32,colour="#7B8491")+
  geom_boxplot(position=position_dodge(.70),width=.54,outlier.shape=NA,linewidth=.46,alpha=.88)+
  scale_fill_manual(values=c(A="#79A9CF",B="#D88B72"),name="Copy-associated partition")+
  scale_colour_manual(values=c(A="#2F638E",B="#A74E3E"),guide="none")+
  scale_x_discrete(labels=axis_labels,drop=FALSE)+
  labs(x=NULL,y="Root-independent gene-tree position score")+
  theme_classic(base_family="Arial",base_size=8)+
  theme(axis.line=element_line(linewidth=.38,colour="#202733"),
        axis.ticks=element_line(linewidth=.35,colour="#202733"),
        axis.text.x=element_text(angle=52,hjust=1,vjust=1,size=6.7,colour="#28364A",lineheight=.90),
        axis.text.y=element_text(size=7.2,colour="#28364A"),
        axis.title.y=element_text(size=8.7,face="bold",colour="#1C293C",margin=margin(r=7)),
        legend.position="top",legend.justification="left",
        legend.title=element_text(size=7.4,face="bold"),legend.text=element_text(size=7),
        legend.key.width=grid::unit(4.4,"mm"),legend.key.height=grid::unit(3.0,"mm"),
        plot.margin=margin(5,7,20,7))
fig_width <- if(full31_mode) 260 else 235
fig_height <- if(full31_mode) 112 else 105
ggsave(file.path(out,"figures",paste0(prefix,"_root_independent_AB_gene_tree_position_boxplots.pdf")),p,width=fig_width,height=fig_height,units="mm",device=cairo_pdf,bg="white")
ggsave(file.path(out,"figures",paste0(prefix,"_root_independent_AB_gene_tree_position_boxplots.png")),p,width=fig_width,height=fig_height,units="mm",dpi=600,device=ragg::agg_png,bg="white")
writeLines(c("status=complete",paste0("n_pass=",sum(sumtab$pass_root_independent_gate)),"permutations=999",
             "multiple_testing_correction=none","root_required=false"),file.path(out,"ROOT_INDEPENDENT_AB_GATE_COMPLETE.marker"))
