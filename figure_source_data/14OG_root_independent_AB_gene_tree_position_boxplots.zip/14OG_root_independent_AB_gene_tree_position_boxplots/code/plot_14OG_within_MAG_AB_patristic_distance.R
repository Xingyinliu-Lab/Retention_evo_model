suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(ggplot2)
})

base_dir <- ".."
out_dir <- file.path(base_dir, "A_B_root_position_boxplots_14OG_20260827")
tree_dir <- file.path(base_dir, "full31_support_and_AU_figures_20260827/data/raw/formal")
assignment_file <- file.path(base_dir, "full31_support_and_AU_figures_20260827/data/formal31_rescreen/copy_associated_AB_sequence_assignments.tsv")
order_file <- file.path(base_dir, "data/AB_MAG_state_stacked_14_strong_supported/fig_14_shared_OG_x_order.tsv")

dir.create(file.path(out_dir, "data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_dir, "figures"), recursive = TRUE, showWarnings = FALSE)

assignments <- read.delim(assignment_file, check.names = FALSE, stringsAsFactors = FALSE)
og_order <- read.delim(order_file, check.names = FALSE, stringsAsFactors = FALSE) |>
  arrange(x_position)
stopifnot(nrow(og_order) == 14L, !anyDuplicated(og_order$og_id))

extract_og_pairs <- function(og) {
  tr <- read.tree(file.path(tree_dir, paste0(og, ".treefile")))
  a <- assignments |> filter(og_id == og)
  if (!setequal(tr$tip.label, a$sequence_id)) stop("Tree/assignment tip mismatch: ", og)
  if (is.null(tr$edge.length)) stop("Missing branch lengths: ", og)

  d <- cophenetic.phylo(tr)
  tree_diameter <- max(d)
  if (!is.finite(tree_diameter) || tree_diameter <= 0) stop("Invalid tree diameter: ", og)

  coexist_hosts <- a |>
    distinct(host_id, copy_associated_state) |>
    count(host_id, name = "n_states") |>
    filter(n_states == 2L) |>
    pull(host_id)

  rows <- lapply(coexist_hosts, function(host) {
    h <- a |> filter(host_id == host)
    ids_a <- h$sequence_id[h$copy_associated_state == "A"]
    ids_b <- h$sequence_id[h$copy_associated_state == "B"]
    grid <- expand.grid(sequence_A = ids_a, sequence_B = ids_b, stringsAsFactors = FALSE)
    ia <- match(grid$sequence_A, rownames(d))
    ib <- match(grid$sequence_B, colnames(d))
    grid$og_id <- og
    grid$host_id <- host
    grid$patristic_distance <- d[cbind(ia, ib)]
    grid$tree_diameter <- tree_diameter
    grid$normalized_patristic_distance <- grid$patristic_distance / tree_diameter
    grid$n_A_copies_in_MAG <- length(ids_a)
    grid$n_B_copies_in_MAG <- length(ids_b)
    grid
  })
  bind_rows(rows)
}

pair_data <- bind_rows(lapply(og_order$og_id, extract_og_pairs))
stopifnot(n_distinct(pair_data$og_id) == 14L, !anyNA(pair_data$normalized_patristic_distance))

# One observation per coexist MAG prevents high-copy MAGs from dominating.
mag_data <- pair_data |>
  group_by(og_id, host_id) |>
  summarise(
    n_AB_pairs = n(),
    n_A_copies = first(n_A_copies_in_MAG),
    n_B_copies = first(n_B_copies_in_MAG),
    median_AB_patristic_distance = median(patristic_distance),
    median_normalized_AB_patristic_distance = median(normalized_patristic_distance),
    minimum_normalized_AB_patristic_distance = min(normalized_patristic_distance),
    maximum_normalized_AB_patristic_distance = max(normalized_patristic_distance),
    .groups = "drop"
  ) |>
  mutate(og_id = factor(og_id, levels = og_order$og_id))

write.table(pair_data,
            file.path(out_dir, "data", "fig_14OG_within_coexist_MAG_all_AB_patristic_pairs.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(mag_data,
            file.path(out_dir, "data", "fig_14OG_within_coexist_MAG_median_AB_patristic_distance.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

p <- ggplot(mag_data, aes(x = og_id, y = median_normalized_AB_patristic_distance)) +
  geom_boxplot(
    width = 0.56, linewidth = 0.48, outlier.shape = NA,
    fill = "#78A6C8", colour = "#2F6088", alpha = 0.88
  ) +
  scale_y_continuous(
    limits = c(0, 1), breaks = seq(0, 1, 0.2),
    expand = expansion(mult = c(0.01, 0.035))
  ) +
  labs(
    x = NULL,
    y = "Within-MAG A-B patristic distance\n(normalized by gene-tree diameter)"
  ) +
  theme_classic(base_family = "Arial", base_size = 8) +
  theme(
    axis.line = element_line(linewidth = 0.38, colour = "black"),
    axis.ticks = element_line(linewidth = 0.35, colour = "black"),
    axis.text.x = element_text(angle = 48, hjust = 1, vjust = 1, size = 6.8),
    axis.text.y = element_text(size = 7),
    axis.title.y = element_text(size = 8.2, margin = margin(r = 6), lineheight = 0.95),
    plot.margin = margin(4, 5, 3, 5)
  )

pdf_file <- file.path(out_dir, "figures", "fig_14OG_within_coexist_MAG_AB_patristic_distance_boxplots.pdf")
png_file <- file.path(out_dir, "figures", "fig_14OG_within_coexist_MAG_AB_patristic_distance_boxplots.png")
ggsave(pdf_file, p, width = 183, height = 88, units = "mm", device = cairo_pdf)
ggsave(png_file, p, width = 183, height = 88, units = "mm", dpi = 600, device = ragg::agg_png)

writeLines(c(
  "status=complete",
  paste0("n_ogs=", n_distinct(mag_data$og_id)),
  paste0("n_coexist_MAGs=", nrow(mag_data)),
  paste0("n_AB_sequence_pairs=", nrow(pair_data)),
  "observation_unit=median_AB_patristic_distance_per_coexist_MAG",
  "normalization=patristic_distance_divided_by_gene_tree_diameter"
), file.path(out_dir, "PATRISTIC_FIGURE_COMPLETE.marker"))

