suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(ggplot2)
})

base_dir <- ".."
out_dir <- file.path(base_dir, "A_B_root_position_boxplots_14OG_20260827")
dir.create(file.path(out_dir, "data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_dir, "figures"), recursive = TRUE, showWarnings = FALSE)

tree_dir <- file.path(base_dir, "full31_support_and_AU_figures_20260827/data/raw/formal")
assignment_file <- file.path(base_dir, "full31_support_and_AU_figures_20260827/data/formal31_rescreen/copy_associated_AB_sequence_assignments.tsv")
order_file <- file.path(base_dir, "data/AB_MAG_state_stacked_14_strong_supported/fig_14_shared_OG_x_order.tsv")
label_file <- file.path(base_dir, "GTDB_projection_AB_tracks_14_strong_supported_20260827/data/fig_14_function_labels_clean.tsv")

assignments <- read.delim(assignment_file, check.names = FALSE, stringsAsFactors = FALSE)
og_order <- read.delim(order_file, check.names = FALSE, stringsAsFactors = FALSE) |>
  arrange(x_position)
labels <- read.delim(label_file, check.names = FALSE, stringsAsFactors = FALSE)

stopifnot(nrow(og_order) == 14L, !anyDuplicated(og_order$og_id))
stopifnot(all(og_order$og_id %in% assignments$og_id))

extract_one <- function(og) {
  tree_file <- file.path(tree_dir, paste0(og, ".treefile"))
  if (!file.exists(tree_file)) stop("Missing formal tree: ", tree_file)
  tr <- read.tree(tree_file)
  if (is.null(tr$edge.length)) stop("Tree has no branch lengths: ", og)
  a <- assignments |> filter(og_id == og)
  if (anyDuplicated(tr$tip.label)) stop("Duplicated tree tips: ", og)
  if (anyDuplicated(a$sequence_id)) stop("Duplicated assignment IDs: ", og)
  if (!setequal(tr$tip.label, a$sequence_id)) {
    stop("Tip/assignment closure failed: ", og,
         "; tree_only=", length(setdiff(tr$tip.label, a$sequence_id)),
         "; assignment_only=", length(setdiff(a$sequence_id, tr$tip.label)))
  }
  depth <- node.depth.edgelength(tr)[seq_len(Ntip(tr))]
  span <- max(depth) - min(depth)
  normalized <- if (span > 0) (depth - min(depth)) / span else rep(0, length(depth))
  tibble(
    og_id = og,
    sequence_id = tr$tip.label,
    host_id = a$host_id[match(tr$tip.label, a$sequence_id)],
    original_state = a$copy_associated_state[match(tr$tip.label, a$sequence_id)],
    root_to_tip = depth,
    normalized_root_to_tip = normalized,
    n_tree_tips = Ntip(tr)
  )
}

positions <- bind_rows(lapply(og_order$og_id, extract_one))
stopifnot(!anyNA(positions$original_state), all(positions$original_state %in% c("A", "B")))
positions_all <- positions

# Figure scope: only copies from multicopy/coexist MAGs that contain at least
# one formally assigned A copy and at least one formally assigned B copy.
coexist_hosts <- positions |>
  distinct(og_id, host_id, original_state) |>
  count(og_id, host_id, name = "n_states") |>
  filter(n_states == 2L) |>
  select(og_id, host_id)

positions <- positions |>
  inner_join(coexist_hosts, by = c("og_id", "host_id"))

if (n_distinct(positions$og_id) != 14L) {
  stop("At least one of the 14 OGs lacks a formally defined A+B coexist MAG")
}

orientation <- positions |>
  group_by(og_id, original_state) |>
  summarise(n = n(), median_depth = median(normalized_root_to_tip), .groups = "drop") |>
  tidyr::pivot_wider(names_from = original_state, values_from = c(n, median_depth)) |>
  mutate(
    swap_for_plot = median_depth_A > median_depth_B,
    plotted_A_median = if_else(swap_for_plot, median_depth_B, median_depth_A),
    plotted_B_median = if_else(swap_for_plot, median_depth_A, median_depth_B),
    orientation_rule = "Plot-only swap when original median(A) > median(B)"
  )

prepare_plot_data <- function(x) {
  x |>
    left_join(orientation |> select(og_id, swap_for_plot), by = "og_id") |>
    mutate(
      plot_state = case_when(
        !swap_for_plot ~ original_state,
        original_state == "A" ~ "B",
        TRUE ~ "A"
      )
    ) |>
    left_join(labels, by = "og_id") |>
    mutate(
      functional_label = if_else(is.na(functional_label) | functional_label == "", "unannotated", functional_label),
      x_label = factor(og_id, levels = og_order$og_id),
      plot_state = factor(plot_state, levels = c("A", "B"))
    )
}

positions <- prepare_plot_data(positions)
positions_all <- prepare_plot_data(positions_all)

write.table(positions, file.path(out_dir, "data", "fig_14OG_coexist_MAG_AB_normalized_gene_tree_positions.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(positions_all, file.path(out_dir, "data", "fig_14OG_all_sequences_AB_normalized_gene_tree_positions.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(orientation, file.path(out_dir, "data", "fig_14OG_AB_plot_orientation_audit.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

build_plot <- function(plot_data) {
  ggplot(plot_data, aes(x = x_label, y = normalized_root_to_tip, fill = plot_state, colour = plot_state)) +
    geom_boxplot(
      position = position_dodge(width = 0.68), width = 0.52,
      linewidth = 0.45, outlier.shape = NA, alpha = 0.82
    ) +
    scale_fill_manual(values = c(A = "#6F9FC5", B = "#D98B73"), name = "Copy-associated partition") +
    scale_colour_manual(values = c(A = "#315F88", B = "#A94F3D"), guide = "none") +
    scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2), expand = expansion(mult = c(0.01, 0.03))) +
    labs(x = NULL, y = "Normalized position in the gene tree") +
    theme_classic(base_family = "Arial", base_size = 8) +
    theme(
      axis.line = element_line(linewidth = 0.38, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.text.x = element_text(angle = 48, hjust = 1, vjust = 1, size = 6.8),
      axis.text.y = element_text(size = 7),
      axis.title.y = element_text(size = 8.2, margin = margin(r = 6)),
      legend.position = c(0.985, 0.985),
      legend.justification = c(1, 1),
      legend.background = element_rect(fill = scales::alpha("white", 0.88), colour = NA),
      legend.title = element_text(size = 7.2),
      legend.text = element_text(size = 7),
      legend.key.width = grid::unit(4.2, "mm"),
      legend.key.height = grid::unit(3.2, "mm"),
      plot.margin = margin(4, 5, 3, 5)
    )
}

p_coexist <- build_plot(positions)
p_all <- build_plot(positions_all)

pdf_file <- file.path(out_dir, "figures", "fig_14OG_coexist_MAG_AB_gene_tree_positions_28_boxplots.pdf")
png_file <- file.path(out_dir, "figures", "fig_14OG_coexist_MAG_AB_gene_tree_positions_28_boxplots.png")
ggsave(pdf_file, p_coexist, width = 183, height = 92, units = "mm", device = cairo_pdf)
ggsave(png_file, p_coexist, width = 183, height = 92, units = "mm", dpi = 600, device = ragg::agg_png)

pdf_all <- file.path(out_dir, "figures", "fig_14OG_all_sequences_AB_gene_tree_positions_28_boxplots.pdf")
png_all <- file.path(out_dir, "figures", "fig_14OG_all_sequences_AB_gene_tree_positions_28_boxplots.png")
ggsave(pdf_all, p_all, width = 183, height = 92, units = "mm", device = cairo_pdf)
ggsave(png_all, p_all, width = 183, height = 92, units = "mm", dpi = 600, device = ragg::agg_png)

writeLines(c(
  "status=complete",
  paste0("n_ogs=", n_distinct(positions$og_id)),
  paste0("n_boxplots=", n_distinct(interaction(positions$og_id, positions$plot_state))),
  paste0("n_coexist_MAGs=", n_distinct(interaction(positions$og_id, positions$host_id))),
  paste0("n_sequences=", nrow(positions)),
  paste0("n_all_sequences=", nrow(positions_all)),
  paste0("n_plot_swaps=", sum(orientation$swap_for_plot)),
  "tree_root_interpretation=display_root_only",
  "figure_scope=A_and_B_copies_from_formal_coexist_MAGs_only",
  "frozen_assignments_modified=false"
), file.path(out_dir, "FIGURE_COMPLETE.marker"))
