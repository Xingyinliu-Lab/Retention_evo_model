args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("usage: Rscript audit_bilateral_AB_self_affinity.R <scores.tsv> <output.tsv>")

d <- read.delim(args[1], check.names = FALSE)
required <- c("og_id", "state", "tree_position_score")
stopifnot(all(required %in% names(d)))

rows <- lapply(split(d, d$og_id), function(x) {
  a <- x$tree_position_score[x$state == "A"]
  b <- x$tree_position_score[x$state == "B"]
  data.frame(
    og_id = x$og_id[1],
    n_A = length(a),
    n_B = length(b),
    median_A = median(a, na.rm = TRUE),
    median_B = median(b, na.rm = TRUE),
    prop_A_negative = mean(a < 0, na.rm = TRUE),
    prop_B_positive = mean(b > 0, na.rm = TRUE)
  )
})
z <- do.call(rbind, rows)
z$bilateral_median_pass <- z$median_A < 0 & z$median_B > 0
z <- z[order(z$og_id), ]
write.table(z, args[2], sep = "\t", quote = FALSE, row.names = FALSE)

cat(sprintf("TOTAL=%d PASS=%d FAIL=%d\n", nrow(z), sum(z$bilateral_median_pass), sum(!z$bilateral_median_pass)))
cat("FAILURES\n")
print(z[!z$bilateral_median_pass, ], row.names = FALSE)
cat("OG0000345\n")
print(z[z$og_id == "OG0000345", ], row.names = FALSE)
