suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
})

root <- ".."
order_file <- "../data/fig_14_shared_OG_x_order.tsv"
coexist_file <- file.path(root, "data", "fig_14OG_coexist_MAG_AB_normalized_gene_tree_positions.tsv")
all_file <- file.path(root, "data", "fig_14OG_all_sequences_AB_normalized_gene_tree_positions.tsv")

og_order <- read.delim(order_file, stringsAsFactors = FALSE) |> arrange(x_position)
coexist <- read.delim(coexist_file, stringsAsFactors = FALSE)
all_seq <- read.delim(all_file, stringsAsFactors = FALSE)

safe_t <- function(x, y, paired = FALSE) {
  tryCatch(t.test(x, y, paired = paired)$p.value, error = function(e) NA_real_)
}

safe_wilcox <- function(x, y, paired = FALSE) {
  tryCatch(
    suppressWarnings(wilcox.test(x, y, paired = paired, exact = FALSE, alternative = "two.sided")$p.value),
    error = function(e) NA_real_
  )
}

# Coexist scope: one paired observation per MAG after separately aggregating
# all A and all B copies within that MAG by their median position.
coexist_mag <- coexist |>
  group_by(og_id, host_id, plot_state) |>
  summarise(position = median(normalized_root_to_tip), n_copies = n(), .groups = "drop") |>
  pivot_wider(names_from = plot_state, values_from = c(position, n_copies)) |>
  filter(!is.na(position_A), !is.na(position_B))

paired_results <- bind_rows(lapply(og_order$og_id, function(og) {
  d <- coexist_mag |> filter(og_id == og)
  tibble(
    og_id = og,
    n_paired_coexist_MAGs = nrow(d),
    median_A = median(d$position_A),
    median_B = median(d$position_B),
    median_paired_difference_B_minus_A = median(d$position_B - d$position_A),
    mean_paired_difference_B_minus_A = mean(d$position_B - d$position_A),
    paired_wilcoxon_p = safe_wilcox(d$position_A, d$position_B, paired = TRUE),
    paired_t_p = safe_t(d$position_A, d$position_B, paired = TRUE)
  )
})) |>
  mutate(
    paired_wilcoxon_BH = p.adjust(paired_wilcoxon_p, method = "BH"),
    paired_t_BH = p.adjust(paired_t_p, method = "BH")
  )

# All-sequence scope: A and B tips are not naturally paired.
all_results <- bind_rows(lapply(og_order$og_id, function(og) {
  d <- all_seq |> filter(og_id == og)
  a <- d$normalized_root_to_tip[d$plot_state == "A"]
  b <- d$normalized_root_to_tip[d$plot_state == "B"]
  tibble(
    og_id = og,
    n_A_sequences = length(a),
    n_B_sequences = length(b),
    median_A_all = median(a),
    median_B_all = median(b),
    median_difference_B_minus_A_all = median(b) - median(a),
    wilcoxon_rank_sum_p = safe_wilcox(a, b, paired = FALSE),
    welch_t_p = safe_t(a, b, paired = FALSE)
  )
})) |>
  mutate(
    wilcoxon_rank_sum_BH = p.adjust(wilcoxon_rank_sum_p, method = "BH"),
    welch_t_BH = p.adjust(welch_t_p, method = "BH")
  )

combined <- og_order |>
  select(x_position, og_id) |>
  left_join(paired_results, by = "og_id") |>
  left_join(all_results, by = "og_id")

write.table(coexist_mag, file.path(root, "data", "fig_14OG_coexist_MAG_paired_AB_position_input.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(combined, file.path(root, "data", "fig_14OG_AB_gene_tree_position_statistical_tests.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

writeLines(c(
  "status=complete",
  "coexist_primary_test=paired_Wilcoxon_on_per_MAG_A_and_B_median_positions",
  "coexist_sensitivity_test=paired_t_test",
  "all_sequence_primary_test=unpaired_Wilcoxon_rank_sum",
  "all_sequence_sensitivity_test=Welch_t_test",
  "multiple_testing=BH_within_each_14_OG_test_family",
  "interpretation=descriptive_support_only_due_to_tree_based_AB_selection"
), file.path(root, "AB_POSITION_TESTS_COMPLETE.marker"))

