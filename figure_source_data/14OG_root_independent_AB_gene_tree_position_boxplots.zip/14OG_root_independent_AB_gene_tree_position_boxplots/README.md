# 14OG_root_independent_AB_gene_tree_position_boxplots

- Manuscript panel: Fig.6F
- Source figure basename: fig_14OG_root_independent_AB_gene_tree_position_boxplots
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 5 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 15 directly referenced or locally packaged source-data file(s)
