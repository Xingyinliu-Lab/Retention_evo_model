# tail_body_vs_terminal_KCF_contact_prevalence

- Manuscript panel: Fig.3B
- Source figure basename: fig01_tail_body_vs_terminal_KCF_contact_prevalence
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 9 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 55 directly referenced or locally packaged source-data file(s)
