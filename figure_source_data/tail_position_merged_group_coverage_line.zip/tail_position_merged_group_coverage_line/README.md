# 3A_tail_position_merged_group_coverage_line

- Manuscript panel: Fig.2G-left
- Source figure basename: figure_3A_tail_position_merged_group_coverage_line
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
