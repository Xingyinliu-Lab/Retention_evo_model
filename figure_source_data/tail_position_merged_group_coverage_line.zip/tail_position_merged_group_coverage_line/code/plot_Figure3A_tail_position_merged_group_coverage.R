# ============================================================
# Figure 3A (merged groups): tail position x non-gap coverage
#
# Calculation inputs (read only):
# 1. tail_hmm386_410_position_frequency_by_compare_group_with_Thermoproteota.tsv
#    Per original compare_group and HMM position: n_total, n_non_gap.
# 2. Figure2C_tail_euk_pssm_distribution_merged_groups/group_mapping.tsv
#    Original compare_group -> merged comparison group mapping.
#
# Coverage is recalculated as sum(n_non_gap) / sum(n_total) after mapping.
# Output: PDF + PNG preview + audit TSVs only (no SVG/TIFF).
# ============================================================

suppressPackageStartupMessages({ library(ggplot2); library(dplyr); library(scales) })

PROJECT_DIR <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
POSITION_INPUT <- file.path(PROJECT_DIR, "tail_hmm386_410_position_frequency_by_compare_group_with_Thermoproteota.tsv")
MAPPING_INPUT <- file.path(PROJECT_DIR, "Figure2C_tail_euk_pssm_distribution_merged_groups", "group_mapping.tsv")
OUTPUT_ROOT <- file.path(PROJECT_DIR, "Figure3A_tail_position_merged_group_coverage")
HMM_START <- 386L; HMM_END <- 410L

GROUP_ORDER <- c("Eukaryota_actin", "Asgard_high_euk_like", "Asgard_intermediate", "Asgard_low_divergent", "Asgard_short_or_missing", "Thermoproteota_canonical")
GROUP_LABELS <- c(
  "Eukaryota_actin" = "Eukaryota actin",
  "Asgard_high_euk_like" = "Asgard high euk-like",
  "Asgard_intermediate" = "Asgard intermediate",
  "Asgard_low_divergent" = "Asgard low divergent",
  "Asgard_short_or_missing" = "Asgard short/missing",
  "Thermoproteota_canonical" = "Thermoproteota canonical"
)
GROUP_COLORS <- c(
  "Eukaryota_actin" = "#C73E32", "Asgard_high_euk_like" = "#009E73",
  "Asgard_intermediate" = "#E69F00", "Asgard_low_divergent" = "#0072B2",
  "Asgard_short_or_missing" = "#6D6D6D", "Thermoproteota_canonical" = "#7B61A8"
)

write_tsv <- function(x, file) utils::write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
theme_nature <- function(base_size = 7) theme_classic(base_size = base_size, base_family = "sans") + theme(
  axis.line = element_line(linewidth = 0.35, colour = "black"), axis.ticks = element_line(linewidth = 0.35, colour = "black"),
  axis.ticks.length = grid::unit(1.4, "mm"), axis.title = element_text(size = base_size), axis.text = element_text(size = base_size - 0.3),
  legend.title = element_text(size = base_size - 0.2), legend.text = element_text(size = base_size - 0.5), panel.grid = element_blank(),
  plot.margin = margin(4, 5, 4, 5)
)

if (!file.exists(POSITION_INPUT) || !file.exists(MAPPING_INPUT)) stop("Required read-only input is missing.")
dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)

position_df <- read.delim(POSITION_INPUT, sep = "\t", quote = "", comment.char = "", stringsAsFactors = FALSE)
mapping_df <- read.delim(MAPPING_INPUT, sep = "\t", quote = "", comment.char = "", stringsAsFactors = FALSE)
req_position <- c("group", "hmm_pos", "n_total", "n_non_gap")
req_mapping <- c("compare_group_original", "compare_group_merged")
if (length(setdiff(req_position, names(position_df))) > 0 || length(setdiff(req_mapping, names(mapping_df))) > 0) stop("Expected count or mapping columns are absent.")

merged_counts <- position_df %>%
  transmute(
    compare_group_original = as.character(group), hmm_pos = suppressWarnings(as.integer(hmm_pos)),
    n_total = suppressWarnings(as.integer(n_total)), n_non_gap = suppressWarnings(as.integer(n_non_gap))
  ) %>%
  inner_join(mapping_df, by = "compare_group_original") %>%
  filter(compare_group_merged %in% GROUP_ORDER, between(hmm_pos, HMM_START, HMM_END), !is.na(n_total), !is.na(n_non_gap)) %>%
  group_by(compare_group_merged, hmm_pos) %>%
  summarise(n_total = sum(n_total), n_non_gap = sum(n_non_gap), .groups = "drop") %>%
  mutate(non_gap_coverage = n_non_gap / n_total)

expected_n <- length(GROUP_ORDER) * (HMM_END - HMM_START + 1L)
if (nrow(merged_counts) != expected_n) stop("Merged count matrix is incomplete: expected ", expected_n, "; obtained ", nrow(merged_counts), ".")

group_n <- merged_counts %>% group_by(compare_group_merged) %>% summarise(n_seq = first(n_total), .groups = "drop") %>%
  mutate(compare_group_merged = factor(compare_group_merged, levels = GROUP_ORDER), group_label = paste0(GROUP_LABELS[as.character(compare_group_merged)], " (n=", n_seq, ")")) %>% arrange(compare_group_merged)

df_plot <- merged_counts %>%
  mutate(compare_group_merged = factor(compare_group_merged, levels = GROUP_ORDER)) %>%
  left_join(group_n, by = "compare_group_merged") %>%
  mutate(group_label = factor(group_label, levels = group_n$group_label)) %>%
  arrange(compare_group_merged, hmm_pos)

group_summary <- df_plot %>% group_by(compare_group_merged, group_label, n_seq) %>% summarise(
  mean_coverage = mean(non_gap_coverage), min_coverage = min(non_gap_coverage), max_coverage = max(non_gap_coverage),
  coverage_386 = non_gap_coverage[hmm_pos == 386L], coverage_407 = non_gap_coverage[hmm_pos == 407L],
  coverage_408 = non_gap_coverage[hmm_pos == 408L], coverage_409 = non_gap_coverage[hmm_pos == 409L], coverage_410 = non_gap_coverage[hmm_pos == 410L], .groups = "drop")

label_colours <- setNames(GROUP_COLORS[as.character(group_n$compare_group_merged)], group_n$group_label)
p <- ggplot(df_plot, aes(hmm_pos, non_gap_coverage, colour = group_label, group = group_label)) +
  geom_line(linewidth = 0.8, alpha = 0.95) + geom_point(size = 1.3, alpha = 0.95) +
  geom_hline(yintercept = c(0.5, 0.8), linetype = c("dashed", "dotted"), linewidth = c(0.3, 0.3), colour = c("#7A7A7A", "#9A9A9A")) +
  scale_colour_manual(values = label_colours, drop = FALSE) +
  scale_x_continuous(breaks = seq(HMM_START, HMM_END, 2), minor_breaks = seq(HMM_START, HMM_END), expand = expansion(mult = c(0.01, 0.01))) +
  scale_y_continuous(limits = c(0, 1.02), breaks = seq(0, 1, 0.2), labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.02))) +
  labs(x = "PF00022 HMM position (386–410)", y = "Non-gap coverage", colour = "Merged comparison group",
       title = "Tail-position coverage across merged comparison groups",
       subtitle = "Coverage recalculated after pooling original comparison groups by their prespecified mapping",
       caption = "Dashed line, 50% coverage; dotted line, 80% coverage.") +
  theme_nature() + theme(legend.position = "right", legend.key.height = grid::unit(3.2, "mm"))

fig_name <- "figure_3A_tail_position_merged_group_coverage_line"; fig_dir <- file.path(OUTPUT_ROOT, fig_name); dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
stem <- file.path(fig_dir, fig_name); width_in <- 180 / 25.4; height_in <- 95 / 25.4
if (capabilities("cairo")) grDevices::cairo_pdf(paste0(stem, ".pdf"), width = width_in, height = height_in, family = "sans") else grDevices::pdf(paste0(stem, ".pdf"), width = width_in, height = height_in, family = "sans")
print(p); grDevices::dev.off()
grDevices::png(paste0(stem, "_preview.png"), width = width_in, height = height_in, units = "in", res = 300, type = "cairo", bg = "white"); print(p); grDevices::dev.off()

config <- data.frame(parameter = c("project_dir", "position_count_input", "mapping_input", "coverage_formula", "hmm_range", "n_groups", "n_rows", "output_formats"),
  value = c(PROJECT_DIR, POSITION_INPUT, MAPPING_INPUT, "sum(n_non_gap)/sum(n_total) after original-to-merged mapping", "386-410", length(GROUP_ORDER), nrow(df_plot), "PDF; PNG preview"), stringsAsFactors = FALSE)
write_tsv(df_plot, file.path(fig_dir, "source_data_recalculated_from_counts.tsv")); write_tsv(group_summary, file.path(fig_dir, "group_coverage_summary.tsv")); write_tsv(config, file.path(fig_dir, "plot_config.tsv")); write_tsv(mapping_df, file.path(fig_dir, "original_to_merged_group_mapping.tsv"))
write_tsv(config, file.path(OUTPUT_ROOT, "run_summary.tsv")); write_tsv(data.frame(figure = fig_name, folder = fig_dir, pdf = paste0(stem, ".pdf"), png_preview = paste0(stem, "_preview.png")), file.path(OUTPUT_ROOT, "figure_output_index.tsv"))
message("Done: ", fig_dir)
