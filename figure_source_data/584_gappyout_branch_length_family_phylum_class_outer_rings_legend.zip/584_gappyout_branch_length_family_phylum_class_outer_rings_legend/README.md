# 1a_584_gappyout_branch_length_family_phylum_class_outer_rings_legend

- Manuscript panel: Fig.5E
- Source figure basename: figure_1a_584_gappyout_branch_length_family_phylum_class_outer_rings_legend_v2
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 3 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 11 directly referenced or locally packaged source-data file(s)
