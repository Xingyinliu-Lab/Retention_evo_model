# 31_r1_vs_free_DT

- Manuscript panel: Supp.Fig.14F
- Source figure basename: fig_31_r1_vs_free_DT
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 4 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
