#!/usr/bin/env python3
"""Collect ordinary-ALE summary values for the frozen current31 case index."""
from __future__ import annotations

import csv
import json
from pathlib import Path


INDEX = Path("..")
OUT = Path("../data/current31_ordinary_ALE_summary.tsv")


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def parse_uml(path: Path):
    logl = None
    totals = None
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.startswith(">logl:"):
            logl = float(line.split(":", 1)[1].strip())
        elif line.startswith("Total"):
            fields = line.split()
            if len(fields) >= 4:
                totals = tuple(map(float, fields[1:4]))
                break
    if logl is None or totals is None:
        raise ValueError(f"missing ALE summary fields: {path}")
    return logl, totals


def main():
    out = []
    for row in read_tsv(INDEX):
        result_dir = Path(row["source_dir"])
        marker = result_dir / "ORDINARY_ALE_COMPLETE.marker"
        freeze = json.loads((result_dir / "ALE_INPUT_FREEZE.json").read_text(encoding="utf-8"))
        uml = [p for p in result_dir.glob("*.uml_rec") if p.stat().st_size > 0]
        if not marker.is_file() or len(uml) != 1:
            raise RuntimeError(f"incomplete ordinary ALE case: {row['case_id']}")
        logl, (dup, transfer, loss) = parse_uml(uml[0])
        out.append({
            "case_id": row["case_id"], "og_id": row["og_id"],
            "evidence_class": row["evidence_class"],
            "ale_logL": logl, "ale_D": dup, "ale_T": transfer,
            "ale_L": loss, "ale_D_plus_T": dup + transfer,
            "ale_total_DTL": dup + transfer + loss,
            "ale_gene_tips": freeze["gene_tips"],
            "ale_species_tips": freeze["species_tips"],
            "ale_species_tree_sha256": freeze["sha256"]["species_tree_sanitized"],
            "ale_ufboot_trees": freeze["ufboot_trees"],
            "uml_rec_bytes": uml[0].stat().st_size,
        })
    assert len(out) == 31, len(out)
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(out[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(out)
    print(f"cases={len(out)} output={OUT}")


if __name__ == "__main__":
    main()
