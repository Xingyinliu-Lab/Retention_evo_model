#!/usr/bin/env python3
"""Audit exact input closure between current31 coexist-gl and ordinary ALE."""
from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(r"..")
OUT = ROOT / "figures" / "fig_31_r1_comparisons_20260828" / "source_data" / "current31_input_consistency_audit.tsv"


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main():
    base = OUT.parent
    ale = {r["case_id"]: r for r in read_tsv(base / "current31_ordinary_ALE_summary.tsv")}
    coexist = {r["case_id"]: r for r in read_tsv(ROOT / "summary" / "COEXIST_GL_31_AU_CASE_RESULTS.tsv")}
    assert set(ale) == set(coexist) and len(ale) == 31
    rows = []
    for case_id in sorted(ale):
        audit = json.loads((ROOT / "cases" / case_id / "results" / "input_audit.json").read_text(encoding="utf-8"))
        a = ale[case_id]
        c = coexist[case_id]
        rows.append({
            "case_id": case_id,
            "gene_tips_equal": str(int(a["ale_gene_tips"]) == int(audit["gene_tips"])).upper(),
            "host_tips_equal": str(int(a["ale_species_tips"]) == int(audit["species_tips"]) == int(c["n_hosts"])).upper(),
            "species_tree_sha256_equal": str(a["ale_species_tree_sha256"] == audit["species_tree_sha256"]).upper(),
            "ale_ufboot_trees": a["ale_ufboot_trees"],
            "all_input_checks_pass": str(
                int(a["ale_gene_tips"]) == int(audit["gene_tips"])
                and int(a["ale_species_tips"]) == int(audit["species_tips"]) == int(c["n_hosts"])
                and a["ale_species_tree_sha256"] == audit["species_tree_sha256"]
                and int(a["ale_ufboot_trees"]) == 1000
            ).upper(),
        })
    assert all(r["all_input_checks_pass"] == "TRUE" for r in rows)
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
    print(f"cases={len(rows)} all_pass=true output={OUT}")


if __name__ == "__main__":
    main()
