#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3) stop("Usage: Rscript plot_31_r1_vs_free_and_ALE.R coexist_summary.tsv ale_summary.tsv output_dir")
coexist_file <- args[[1]]
ale_file <- args[[2]]
out <- args[[3]]
dir.create(out, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out, "source_data"), recursive = TRUE, showWarnings = FALSE)

coexist <- read_tsv(coexist_file, show_col_types = FALSE) %>%
  mutate(
    persistence_status = if_else(
      p_persistence_one_sided < 0.05,
      "Reject r=1 (n=29)", "Cannot reject r=1 (n=2)"
    ),
    persistence_status = factor(
      persistence_status,
      levels = c("Reject r=1 (n=29)", "Cannot reject r=1 (n=2)")
    ),
    short_id = sub("^archaea1338__", "", case_id)
  )
ale <- read_tsv(ale_file, show_col_types = FALSE)
dat <- inner_join(coexist, ale, by = c("case_id", "og_id"), suffix = c("", "_ALE"))
stopifnot(
  nrow(dat) == 31,
  sum(dat$persistence_status == "Reject r=1 (n=29)") == 29,
  sum(dat$persistence_status == "Cannot reject r=1 (n=2)") == 2
)

free_rows <- bind_rows(
  dat %>% transmute(case_id, og_id, short_id, persistence_status, metric = "logL", r1 = logL_r1, free = logL_free_r),
  dat %>% transmute(case_id, og_id, short_id, persistence_status, metric = "D+T",
                    r1 = r1_expected_S_to_C_gain, free = free_r_expected_S_to_C_gain),
  dat %>% transmute(case_id, og_id, short_id, persistence_status, metric = "L",
                    r1 = r1_expected_C_to_S_resolution, free = free_r_expected_C_to_S_resolution)
)
write_tsv(free_rows, file.path(out, "source_data", "fig_31_r1_vs_free_source_data.tsv"))

free_stats <- free_rows %>% group_by(metric) %>% summarise(
  n = n(), median_r1 = median(r1), median_free = median(free),
  median_delta_free_minus_r1 = median(free - r1),
  wilcoxon_p = wilcox.test(free, r1, paired = TRUE, exact = FALSE)$p.value,
  .groups = "drop"
)
write_tsv(free_stats, file.path(out, "source_data", "fig_31_r1_vs_free_statistics.tsv"))

ale_rows <- bind_rows(
  dat %>% transmute(case_id, og_id, short_id, persistence_status, metric = "logL", r1_value = logL_r1, ale_value = ale_logL),
  dat %>% transmute(case_id, og_id, short_id, persistence_status, metric = "D+T", r1_value = r1_expected_S_to_C_gain, ale_value = ale_D_plus_T),
  dat %>% transmute(case_id, og_id, short_id, persistence_status, metric = "L", r1_value = r1_expected_C_to_S_resolution, ale_value = ale_L)
)
write_tsv(ale_rows, file.path(out, "source_data", "fig_31_r1_vs_ALE_source_data.tsv"))

ale_stats <- ale_rows %>% group_by(metric) %>% summarise(
  n = n(), pearson_r = cor(r1_value, ale_value, method = "pearson"),
  pearson_p = cor.test(r1_value, ale_value, method = "pearson")$p.value,
  spearman_rho = cor(r1_value, ale_value, method = "spearman"),
  spearman_p = cor.test(r1_value, ale_value, method = "spearman", exact = FALSE)$p.value,
  .groups = "drop"
)
write_tsv(ale_stats, file.path(out, "source_data", "fig_31_r1_vs_ALE_statistics.tsv"))

ale_per_host_rows <- bind_rows(
  dat %>% transmute(case_id, og_id, short_id, persistence_status, n_hosts,
                    metric = "D+T", r1_value = r1_expected_S_to_C_gain / n_hosts,
                    ale_value = ale_D_plus_T / n_hosts),
  dat %>% transmute(case_id, og_id, short_id, persistence_status, n_hosts,
                    metric = "L", r1_value = r1_expected_C_to_S_resolution / n_hosts,
                    ale_value = ale_L / n_hosts)
)
write_tsv(ale_per_host_rows,
          file.path(out, "source_data", "fig_31_r1_vs_ALE_per_host_source_data.tsv"))

ale_per_host_stats <- ale_per_host_rows %>% group_by(metric) %>% summarise(
  n = n(), pearson_r = cor(r1_value, ale_value, method = "pearson"),
  pearson_p = cor.test(r1_value, ale_value, method = "pearson")$p.value,
  spearman_rho = cor(r1_value, ale_value, method = "spearman"),
  spearman_p = cor.test(r1_value, ale_value, method = "spearman", exact = FALSE)$p.value,
  .groups = "drop"
)
write_tsv(ale_per_host_stats,
          file.path(out, "source_data", "fig_31_r1_vs_ALE_per_host_statistics.tsv"))

state_pal <- c("r=1" = "#C9D7E8", "free r" = "#E6B89C")
persistence_cols <- c(
  "Reject r=1 (n=29)" = "#4F8791",
  "Cannot reject r=1 (n=2)" = "#D58A55"
)

theme_pub <- theme_classic(base_size = 8, base_family = "Arial") + theme(
  axis.line = element_line(linewidth = 0.35, colour = "black"),
  axis.ticks = element_line(linewidth = 0.35, colour = "black"),
  axis.text = element_text(colour = "black", size = 7),
  axis.title = element_text(colour = "black", size = 8),
  legend.position = "top", legend.title = element_blank(), legend.text = element_text(size = 6.5),
  legend.key.width = grid::unit(4.2, "mm"),
  plot.title = element_text(size = 9, face = "bold", hjust = 0),
  plot.subtitle = element_text(size = 7, colour = "#333333", hjust = 0),
  plot.margin = margin(5.5, 8, 5.5, 5.5)
)

make_free_plot <- function(metric_name, ylab, filename) {
  dd <- free_rows %>% filter(metric == metric_name)
  long <- bind_rows(
    dd %>% transmute(case_id, short_id, persistence_status, state = "r=1", value = r1),
    dd %>% transmute(case_id, short_id, persistence_status, state = "free r", value = free)
  ) %>% mutate(state = factor(state, levels = c("r=1", "free r")))
  st <- filter(free_stats, metric == metric_name)
  p <- ggplot(long, aes(state, value)) +
    geom_line(aes(group = case_id, colour = persistence_status), linewidth = 0.32, alpha = 0.62) +
    geom_boxplot(aes(fill = state), width = 0.46, linewidth = 0.45, colour = "#222222",
                 outlier.shape = NA, alpha = 0.92) +
    geom_point(aes(fill = persistence_status), shape = 21,
               position = position_jitter(width = 0.065, height = 0, seed = 20260903), size = 1.2,
               colour = "#222222", stroke = 0.25, alpha = 0.92) +
    scale_fill_manual(values = c(state_pal, persistence_cols), breaks = names(persistence_cols)) +
    scale_colour_manual(values = persistence_cols) +
    labs(x = NULL, y = ylab, title = paste0(metric_name, ": r=1 versus free-r model"),
         subtitle = sprintf("31 matched OGs; paired Wilcoxon P = %.3g", st$wilcoxon_p)) +
    guides(fill = guide_legend(override.aes = list(shape = 21, colour = "#222222")),
           colour = "none") + theme_pub
  ggsave(file.path(out, paste0(filename, ".pdf")), p, device = cairo_pdf,
         width = 89/25.4, height = 82/25.4, units = "in")
  ggsave(file.path(out, paste0(filename, ".png")), p, dpi = 500,
         width = 89/25.4, height = 82/25.4, units = "in", bg = "white")
}

make_ale_plot <- function(metric_name, xlab, ylab, filename) {
  dd <- ale_rows %>% filter(metric == metric_name)
  st <- ale_stats %>% filter(metric == metric_name)
  subtitle <- sprintf("n = %d; Pearson r = %.3f (P = %.3g)\nSpearman rho = %.3f (P = %.3g)",
                      st$n, st$pearson_r, st$pearson_p, st$spearman_rho, st$spearman_p)
  p <- ggplot(dd, aes(ale_value, r1_value)) +
    geom_smooth(method = "lm", se = TRUE, colour = "#303030", fill = "#BDBDBD",
                alpha = 0.22, linewidth = 0.55) +
    geom_point(aes(fill = persistence_status), shape = 21, size = 1.35,
               colour = "#222222", stroke = 0.28, alpha = 0.92) +
    scale_fill_manual(values = persistence_cols) +
    labs(x = xlab, y = ylab, title = paste0("r=1 state model versus ordinary ALE: ", metric_name),
         subtitle = subtitle) + theme_pub
  ggsave(file.path(out, paste0(filename, ".pdf")), p, device = cairo_pdf,
         width = 89/25.4, height = 82/25.4, units = "in")
  ggsave(file.path(out, paste0(filename, ".png")), p, dpi = 500,
         width = 89/25.4, height = 82/25.4, units = "in", bg = "white")
}

make_ale_per_host_plot <- function(metric_name, xlab, ylab, filename) {
  dd <- ale_per_host_rows %>% filter(metric == metric_name)
  st <- ale_per_host_stats %>% filter(metric == metric_name)
  subtitle <- sprintf("n = %d; Pearson r = %.3f (P = %.3g)\nSpearman rho = %.3f (P = %.3g)",
                      st$n, st$pearson_r, st$pearson_p, st$spearman_rho, st$spearman_p)
  p <- ggplot(dd, aes(ale_value, r1_value)) +
    geom_smooth(method = "lm", se = TRUE, colour = "#303030", fill = "#BDBDBD",
                alpha = 0.22, linewidth = 0.55) +
    geom_point(aes(fill = persistence_status), shape = 21, size = 1.35,
               colour = "#222222", stroke = 0.28, alpha = 0.92) +
    scale_fill_manual(values = persistence_cols) +
    labs(x = xlab, y = ylab,
         title = paste0("Host-normalized r=1 model versus ordinary ALE: ", metric_name),
         subtitle = subtitle) + theme_pub
  ggsave(file.path(out, paste0(filename, ".pdf")), p, device = cairo_pdf,
         width = 89/25.4, height = 82/25.4, units = "in")
  ggsave(file.path(out, paste0(filename, ".png")), p, dpi = 500,
         width = 89/25.4, height = 82/25.4, units = "in", bg = "white")
}

make_free_plot("logL", "Raw log likelihood", "fig_31_r1_vs_free_logL")
make_free_plot("D+T", "Expected D+T event burden", "fig_31_r1_vs_free_DT")
make_free_plot("L", "Expected L event burden", "fig_31_r1_vs_free_L")
make_ale_plot("logL", "Ordinary ALE log likelihood", "r=1 model log likelihood", "fig_31_r1_vs_ale_logL")
make_ale_plot("D+T", "Ordinary ALE D+T expectation", "r=1 S-to-C gain expectation", "fig_31_r1_vs_ale_DT")
make_ale_plot("L", "Ordinary ALE L expectation", "r=1 C-to-S resolution expectation", "fig_31_r1_vs_ale_L")
make_ale_per_host_plot("D+T", "Ordinary ALE (D+T) per host", "r=1 S-to-C gain per host",
                       "fig_31_r1_vs_ALE_DT_per_host")
make_ale_per_host_plot("L", "Ordinary ALE L per host", "r=1 C-to-S resolution per host",
                       "fig_31_r1_vs_ALE_L_per_host")

writeLines(c("status=complete", "backend=R", "n_cases=31", "n_reject_r1=29",
             "n_cannot_reject_r1=2", "n_pdf=8", "n_png=8"),
           file.path(out, "FIGURES_COMPLETE.marker"))
