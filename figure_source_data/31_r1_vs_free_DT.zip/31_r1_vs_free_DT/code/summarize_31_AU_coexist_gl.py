#!/usr/bin/env python3
"""Create publication-ready machine-readable summaries for 31 coexist-gl cases."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
from pathlib import Path


ROOT = Path(r"..")
CASES = ROOT / "cases"
AU_TABLES = ROOT.parent / "supplementary_tables_31_AU_20260827" / "tables"
OUT = ROOT / "summary"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sum_posteriors(path: Path) -> dict[str, float]:
    totals = {"S_to_S": 0.0, "S_to_C": 0.0, "C_to_S": 0.0, "C_to_C": 0.0}
    for row in read_tsv(path):
        for key in totals:
            totals[key] += float(row[f"posterior_{key}"])
    return totals


def percentile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return ordered[lo]
    return ordered[lo] * (hi - pos) + ordered[hi] * (pos - lo)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def number_or_na(value: object) -> object:
    return "NA" if value is None else float(value)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    suite = read_tsv(CASES / "EXAMPLE_SUITE_RESULTS.tsv")
    evidence = {row["og_id"]: row for row in read_tsv(AU_TABLES / "Supplementary_Table_1_31_AU_gate_evidence.tsv")}
    details = {row["og_id"]: row for row in read_tsv(AU_TABLES / "Supplementary_Table_2_31_OG_sequence_MAG_lineage_details.tsv")}
    if len(suite) != 31 or {row["case_id"].split("__", 1)[1] for row in suite} != set(evidence) or set(evidence) != set(details):
        raise RuntimeError("31-case coexist-gl and AU supplementary-table OG sets do not close")

    rows: list[dict[str, object]] = []
    for base in suite:
        case_id = base["case_id"]
        og = case_id.split("__", 1)[1]
        result_dir = CASES / case_id / "results"
        summary = json.loads((result_dir / "summary.json").read_text(encoding="utf-8"))
        fit = summary["fit"]
        null_events = sum_posteriors(result_dir / "branch_state_posteriors_r1.tsv")
        free_events = sum_posteriors(result_dir / "branch_state_posteriors.tsv")
        null_changed = null_events["S_to_C"] + null_events["C_to_S"]
        free_changed = free_events["S_to_C"] + free_events["C_to_S"]
        reduction = 100.0 * (null_changed - free_changed) / null_changed if null_changed else 0.0
        p_cluster = float(base["p_cluster"])
        p_persist = float(base["p_persistence_one_sided"])
        r_hat = float(base["r_hat"])
        rows.append({
            "case_id": case_id,
            "og_id": og,
            "AU_evidence_class": evidence[og]["evidence_class"],
            "functional_label": details[og]["functional_label"],
            "functional_description": details[og]["functional_description"],
            "n_hosts": int(base["n_hosts"]),
            "n_single": int(base["n_single"]),
            "n_coexist": int(base["n_coexist"]),
            "coexist_fraction": float(base["coexist_fraction"]),
            "p_cluster": p_cluster,
            "phylogenetic_clustering_supported_pLT0.05": str(p_cluster < 0.05).upper(),
            "r_hat": r_hat,
            "r_profile_low": number_or_na(fit["r_profile_low"]),
            "r_profile_high": number_or_na(fit["r_profile_high"]),
            "A_hat_free": float(base["A_hat"]),
            "logL_r1": float(base["logL_null"]),
            "logL_free_r": float(base["logL_free"]),
            "delta_logL": float(base["delta_logL"]),
            "p_persistence_one_sided": p_persist,
            "persistence_supported_pLT0.05": str(p_persist < 0.05 and r_hat > 1.0).upper(),
            "both_clustering_and_persistence_supported": str(p_cluster < 0.05 and p_persist < 0.05 and r_hat > 1.0).upper(),
            "r1_expected_S_to_C_gain": null_events["S_to_C"],
            "free_r_expected_S_to_C_gain": free_events["S_to_C"],
            "r1_expected_C_to_S_resolution": null_events["C_to_S"],
            "free_r_expected_C_to_S_resolution": free_events["C_to_S"],
            "r1_expected_C_to_C_persistence": null_events["C_to_C"],
            "free_r_expected_C_to_C_persistence": free_events["C_to_C"],
            "r1_expected_changed_edges": null_changed,
            "free_r_expected_changed_edges": free_changed,
            "changed_edge_reduction_percent": reduction,
        })

    fields = list(rows[0])
    result_path = OUT / "COEXIST_GL_31_AU_CASE_RESULTS.tsv"
    write_tsv(result_path, rows, fields)

    r_values = [float(row["r_hat"]) for row in rows]
    delta_values = [float(row["delta_logL"]) for row in rows]
    reduction_values = [float(row["changed_edge_reduction_percent"]) for row in rows]
    overview = {
        "schema": "coexist_gl_31_current_AU_summary_v1",
        "cases": len(rows),
        "complete_cases": sum(row["persistence_supported_pLT0.05"] in {"TRUE", "FALSE"} for row in rows),
        "clustering_supported_pLT0.05": sum(row["phylogenetic_clustering_supported_pLT0.05"] == "TRUE" for row in rows),
        "persistence_supported_pLT0.05": sum(row["persistence_supported_pLT0.05"] == "TRUE" for row in rows),
        "both_supported": sum(row["both_clustering_and_persistence_supported"] == "TRUE" for row in rows),
        "r_hat": {
            "min": min(r_values), "q25": percentile(r_values, 0.25), "median": statistics.median(r_values),
            "q75": percentile(r_values, 0.75), "max": max(r_values),
        },
        "delta_logL": {
            "min": min(delta_values), "q25": percentile(delta_values, 0.25), "median": statistics.median(delta_values),
            "q75": percentile(delta_values, 0.75), "max": max(delta_values),
        },
        "changed_edge_reduction_percent": {
            "min": min(reduction_values), "q25": percentile(reduction_values, 0.25),
            "median": statistics.median(reduction_values), "q75": percentile(reduction_values, 0.75),
            "max": max(reduction_values),
        },
        "all_r_ge_1": all(value >= 1.0 for value in r_values),
        "absolute_ALE_likelihood_compared": False,
        "legacy_AB_included": False,
    }
    overview_path = OUT / "COEXIST_GL_31_AU_OVERVIEW.json"
    overview_path.write_text(json.dumps(overview, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    class_rows = []
    for evidence_class in ("strong", "supported", "compatible"):
        selected = [row for row in rows if row["AU_evidence_class"] == evidence_class]
        class_rows.append({
            "AU_evidence_class": evidence_class,
            "n_cases": len(selected),
            "clustering_supported": sum(row["phylogenetic_clustering_supported_pLT0.05"] == "TRUE" for row in selected),
            "persistence_supported": sum(row["persistence_supported_pLT0.05"] == "TRUE" for row in selected),
            "both_supported": sum(row["both_clustering_and_persistence_supported"] == "TRUE" for row in selected),
            "median_r_hat": statistics.median(float(row["r_hat"]) for row in selected),
            "median_delta_logL": statistics.median(float(row["delta_logL"]) for row in selected),
            "median_changed_edge_reduction_percent": statistics.median(float(row["changed_edge_reduction_percent"]) for row in selected),
        })
    class_path = OUT / "COEXIST_GL_31_AU_CLASS_SUMMARY.tsv"
    write_tsv(class_path, class_rows, list(class_rows[0]))

    freeze_rows = []
    for path in sorted([result_path, overview_path, class_path, CASES / "EXAMPLE_SUITE_RESULTS.tsv"]):
        freeze_rows.append({"file": str(path.relative_to(ROOT)), "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_tsv(OUT / "SUMMARY_FILE_FREEZE.tsv", freeze_rows, ["file", "bytes", "sha256"])
    print(json.dumps(overview, ensure_ascii=False))


if __name__ == "__main__":
    main()
