#!/usr/bin/env python3
"""Prepare ALE-matched coexist-gl v2 inputs for the 31 current AU-positive OGs.

Run on kt. This script does not run ALE and does not use A/B labels as model input.
"""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from Bio import Phylo


AU_ROOT = Path("..")
FORMAL_ROOT = Path("..")
OUT = AU_ROOT / "coexist_gl_31_AU_inputs_20260827"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def current_au_positive() -> list[str]:
    observed: set[str] = set()
    for table in ("LIVE_CANONICAL_AU_SUMMARY.tsv", "LIVE_PMSF_AU_CLOSURE_SUMMARY.tsv"):
        for row in read_tsv(AU_ROOT / table):
            if row["terminal_AU_pass"].lower() == "true":
                observed.add(row["og_id"])
    if len(observed) != 31:
        raise RuntimeError(f"Expected 31 current AU-positive OGs, observed {len(observed)}")
    return sorted(observed)


def evidence_class(og: str) -> str:
    freeze = AU_ROOT / "cases" / og / "input" / "INPUT_FREEZE.json"
    if freeze.is_file():
        payload = json.loads(freeze.read_text(encoding="utf-8"))
        if payload.get("dual_scale_gate_class"):
            return str(payload["dual_scale_gate_class"])
    gate = FORMAL_ROOT / "cases" / og / "downstream_gate_v2" / "final_results" / "FORMAL_V2_DUAL_SCALE_GATE.tsv"
    rows = read_tsv(gate)
    if rows and rows[0].get("final_gate_class"):
        return rows[0]["final_gate_class"]
    raise RuntimeError(f"{og}: evidence class missing")


def write_text(path: Path, text: str) -> None:
    path.write_text(text.rstrip() + "\n", encoding="utf-8", newline="\n")


def main() -> None:
    if OUT.exists():
        raise RuntimeError(f"Refusing to overwrite existing output: {OUT}")
    cases_root = OUT / "cases"
    cases_root.mkdir(parents=True)
    index: list[dict[str, object]] = []

    for og in current_au_positive():
        case_id = f"archaea1338__{og}"
        source = AU_ROOT / "cases" / og / "results" / "ordinary_ALE_GTDB_r226"
        required = {
            "species_tree": source / "species_tree.GTDB_r226.induced.sanitized.nwk",
            "gene_trees": source / "gene_trees.relabeled.ufboot",
            "ale_audit": source / "ALE_INPUT_AUDIT.tsv",
            "ale_marker": source / "ORDINARY_ALE_COMPLETE.marker",
        }
        missing = [name for name, path in required.items() if not path.is_file()]
        if missing:
            raise RuntimeError(f"{og}: missing matched ordinary-ALE assets: {missing}")

        input_dir = cases_root / case_id / "input"
        input_dir.mkdir(parents=True)
        species_path = input_dir / "species_tree.nwk"
        gene_path = input_dir / "gene_tree.nwk"
        genes_path = input_dir / "genes.tsv"
        config_path = input_dir / "family.yaml"
        audit_path = input_dir / "ALE_INPUT_AUDIT.tsv"

        write_text(species_path, required["species_tree"].read_text(encoding="utf-8"))
        with required["gene_trees"].open(encoding="utf-8") as handle:
            write_text(gene_path, handle.readline())
        write_text(audit_path, required["ale_audit"].read_text(encoding="utf-8"))

        gene_tree = Phylo.read(str(gene_path), "newick")
        species_tree = Phylo.read(str(species_path), "newick")
        gene_host: list[tuple[str, str]] = []
        for tip in gene_tree.get_terminals():
            gene = str(tip.name)
            if "|" not in gene:
                raise RuntimeError(f"{og}: ALE-relabeled gene lacks host separator: {gene}")
            gene_host.append((gene, gene.split("|", 1)[0]))
        species_tips = {str(tip.name) for tip in species_tree.get_terminals()}
        mapped_hosts = {host for _, host in gene_host}
        if species_tips != mapped_hosts:
            raise RuntimeError(
                f"{og}: host closure failed: species_only={len(species_tips-mapped_hosts)} "
                f"mapping_only={len(mapped_hosts-species_tips)}"
            )
        with genes_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
            writer.writerow(["gene_id", "host_id", "include"])
            writer.writerows((gene, host, 1) for gene, host in sorted(gene_host))

        counts: dict[str, int] = {}
        for _, host in gene_host:
            counts[host] = counts.get(host, 0) + 1
        n_single = sum(value == 1 for value in counts.values())
        n_coexist = sum(value >= 2 for value in counts.values())
        if n_single == 0 or n_coexist == 0:
            raise RuntimeError(f"{og}: coexist-gl inapplicable single={n_single} coexist={n_coexist}")

        write_text(
            config_path,
            f"""schema_version: coexist_gl_family_v2
family_id: {case_id}__AU31_ALE_matched
species_tree:
  path: species_tree.nwk
  rooted: true
  edge_policy: unit
gene_tree:
  path: gene_tree.nwk
  rootedness: unrooted
gene_metadata:
  path: genes.tsv
  include_column: include
copy_state:
  single: 1
  coexist_min: 2
clustering_test:
  permutations: 9999
  seed: 20260827
fit:
  r_lower_bound: 1.0
  starts: 6
  seed: 20260827
surface:
  r_values: [1, 1.25, 1.5, 2, 4, 8, 16, 32, 64, 128]
  A_values: auto_around_mle""",
        )

        primary = [species_path, gene_path, genes_path, config_path, audit_path]
        record = {
            "case_id": case_id,
            "og_id": og,
            "evidence_class": evidence_class(og),
            "n_genes": len(gene_host),
            "n_hosts": len(counts),
            "n_single": n_single,
            "n_coexist": n_coexist,
            "species_tree_tips": len(species_tips),
            "host_closure": "PASS",
            "ordinary_ALE_marker": str(required["ale_marker"]),
            "source_dir": str(source),
            "readiness": "READY",
        }
        index.append(record)
        freeze_payload = {
            **record,
            "schema": "coexist_gl_31_current_AU_v1",
            "legacy_AB_included": False,
            "ALE_used_as_model_input": False,
            "files": {path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in primary},
        }
        (input_dir / "INPUT_FREEZE.json").write_text(
            json.dumps(freeze_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )

    fields = list(index[0])
    write_tsv(OUT / "CASE_INDEX.tsv", index, fields)
    write_text(
        OUT / "README.md",
        """# Current 31 AU-positive Archaea1338 OG coexist-gl suite

This suite uses the current `copy_associated_AB_v2_orderCV` AU-positive case set only.
Each coexist-gl case is input-matched to the retained gene tips, gene-to-host mapping,
and rooted binary GTDB r226 induced species tree used by that case's completed ordinary
ALE run. ALE outputs are provenance/benchmark assets and are not model inputs.

The coexist-gl model receives no A/B label or AU p-value. It observes host copy state
only: S=1 and C=2+, with r constrained to r>=1.
""",
    )
    (OUT / "INPUT_PREPARATION_COMPLETE.marker").write_text(
        "status=complete\ncases=31\nhost_closure=31/31\nlegacy_AB_included=false\n",
        encoding="utf-8",
    )
    print(json.dumps({"status": "complete", "cases": len(index), "output": str(OUT)}))


if __name__ == "__main__":
    main()
