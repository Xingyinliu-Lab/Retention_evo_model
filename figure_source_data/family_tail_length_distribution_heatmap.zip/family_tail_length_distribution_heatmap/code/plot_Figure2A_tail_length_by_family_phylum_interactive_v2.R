# ============================================================
# Figure 2A v2: Improved HMM386-410 tail length visualization
# Interactive R / RStudio version
#
# Why v2:
#   tail_nogap_len is a zero-inflated discrete integer variable from 0 to 25.
#   Violin/boxplot/raincloud often looks ugly and misleading.
#
# Better plots:
#   2A1: family x tail_nogap_len distribution heatmap
#   2A2: family tail completeness summary dot plot
#   2A3: phylum x tail_nogap_len distribution heatmap
#   2A4: phylum frac_tail_ge20 ranked dot plot
#   2A5: phylum mean_tail_len vs frac_tail_ge20 bubble plot
#
# How to use:
#   setwd("parent_folder_of_full_hmm_analysis")
#   source("plot_Figure2A_tail_length_by_family_phylum_interactive_v2.R")
#
# Expected input:
#   full_hmm_analysis/seq_meta_with_tail_hmm386_410.tsv
#   full_hmm_analysis/tail_hmm386_410_length_by_phylum.tsv
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
})

# ============================================================
# 0. User settings
# ============================================================

PROJECT_DIR <- getwd()

SEQ_FILE <- file.path(
  PROJECT_DIR,
  "full_hmm_analysis",
  "seq_meta_with_tail_hmm386_410.tsv"
)

PHYLUM_SUMMARY_FILE <- file.path(
  PROJECT_DIR,
  "full_hmm_analysis",
  "tail_hmm386_410_length_by_phylum.tsv"
)

# The frozen exported tables are now retained directly under PROJECT_DIR.
# Keep the original subdirectory paths when present, otherwise use that
# provenance-preserving location without changing either input table.
if (!file.exists(SEQ_FILE)) {
  SEQ_FILE <- file.path(PROJECT_DIR, "seq_meta_with_tail_hmm386_410.tsv")
}
if (!file.exists(PHYLUM_SUMMARY_FILE)) {
  PHYLUM_SUMMARY_FILE <- file.path(PROJECT_DIR, "tail_hmm386_410_length_by_phylum.tsv")
}

OUTPUT_ROOT <- file.path(
  PROJECT_DIR,
  "Figure2A_tail_length_by_family_phylum_plot_v2"
)

TAIL_START <- 386L
TAIL_END <- 410L
TAIL_FULL_LEN <- TAIL_END - TAIL_START + 1L

# Keep all quality levels by default, because your phylum summary file appears to be all-sequence.
# Set to "HQ" if you want sequence-level plots restricted to HQ only.
QUALITY_FILTER <- "all"   # "all" or "HQ"

# Phylum plot display control
MIN_SEQ_PER_PHYLUM_HEATMAP <- 10L
MAX_PHYLUM_ROWS_HEATMAP <- 18L

dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 1. Helpers
# ============================================================

safe_file_stem <- function(x) {
  x <- gsub("[^A-Za-z0-9_\\-]+", "_", x)
  x <- gsub("_+", "_", x)
  x <- gsub("^_|_$", "", x)
  x
}

make_fig_dir <- function(fig_name) {
  out <- file.path(OUTPUT_ROOT, safe_file_stem(fig_name))
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out
}

write_tsv <- function(x, file) {
  utils::write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

fmt_int <- function(x) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", format(round(x), big.mark = ",", scientific = FALSE, trim = TRUE))
}

fmt_num <- function(x, digits = 1) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", format(round(x, digits), nsmall = digits, scientific = FALSE, trim = TRUE))
}

fmt_pct <- function(x, digits = 1) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", paste0(format(round(100 * x, digits), nsmall = digits, trim = TRUE), "%"))
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size, colour = "black"),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = "black"),
      plot.title = element_text(size = base_size + 0.8, face = "bold", colour = "black"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.caption = element_text(size = base_size - 1.0, colour = "#4D4D4D", hjust = 0),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure_in_own_folder <- function(plot, fig_name, source_data, width_mm, height_mm, dpi = 300, config_df = NULL, extra_files = list()) {
  fig_dir <- make_fig_dir(fig_name)
  stem <- file.path(fig_dir, safe_file_stem(fig_name))
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  pdf_file <- paste0(stem, ".pdf")
  png_file <- paste0(stem, "_preview.png")

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(pdf_file, width = width_in, height = height_in, family = "sans")
  } else {
    grDevices::pdf(pdf_file, width = width_in, height = height_in, family = "sans")
  }
  print(plot)
  grDevices::dev.off()

  if (capabilities("cairo")) {
    grDevices::png(png_file, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo", bg = "white")
  } else {
    grDevices::png(png_file, width = width_in, height = height_in, units = "in", res = dpi, bg = "white")
  }
  print(plot)
  grDevices::dev.off()

  write_tsv(source_data, file.path(fig_dir, "source_data.tsv"))

  if (!is.null(config_df)) {
    write_tsv(config_df, file.path(fig_dir, "plot_config.tsv"))
  }

  if (length(extra_files) > 0) {
    for (nm in names(extra_files)) {
      write_tsv(extra_files[[nm]], file.path(fig_dir, nm))
    }
  }

  invisible(data.frame(
    figure = fig_name,
    folder = fig_dir,
    pdf = pdf_file,
    png_preview = png_file,
    stringsAsFactors = FALSE
  ))
}

# ============================================================
# 2. Read and validate input
# ============================================================

if (!file.exists(SEQ_FILE)) {
  stop(
    "Input file not foun..", SEQ_FILE,
    "\n\nPlease set working directory to the parent folder of full_hmm_analysis/,",
    "\nand ensure seq_meta_with_tail_hmm386_410.tsv exists there."
  )
}

if (!file.exists(PHYLUM_SUMMARY_FILE)) {
  stop(
    "Input file not foun..", PHYLUM_SUMMARY_FILE,
    "\n\nPlease ensure tail_hmm386_410_length_by_phylum.tsv exists under full_hmm_analysis/."
  )
}

seq_df_raw <- read.delim(
  SEQ_FILE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_seq_cols <- c("seq", "actin_family_class", "p", "tail_aligned", "tail_aligned_len", "tail_nogap_len", "quality_checkm2")
missing_seq_cols <- setdiff(required_seq_cols, names(seq_df_raw))
if (length(missing_seq_cols) > 0) {
  stop("Missing required columns in seq_meta_with_tail_hmm386_410.tsv: ", paste(missing_seq_cols, collapse = ", "))
}

seq_df <- seq_df_raw %>%
  mutate(
    seq = as.character(seq),
    actin_family_class = as.character(actin_family_class),
    p = as.character(p),
    quality_checkm2 = as.character(quality_checkm2),
    tail_aligned = as.character(tail_aligned),
    tail_aligned_len = suppressWarnings(as.numeric(tail_aligned_len)),
    tail_nogap_len = suppressWarnings(as.numeric(tail_nogap_len)),
    n_gap = if ("n_gap" %in% names(.)) suppressWarnings(as.numeric(n_gap)) else tail_aligned_len - tail_nogap_len
  ) %>%
  filter(!is.na(actin_family_class), actin_family_class != "", !is.na(p), p != "")

if (QUALITY_FILTER != "all") {
  seq_df <- seq_df %>% filter(quality_checkm2 == QUALITY_FILTER)
}

seq_df <- seq_df %>%
  mutate(
    tail_nogap_len_int = as.integer(round(tail_nogap_len)),
    tail_nogap_len_int = pmax(0L, pmin(TAIL_FULL_LEN, tail_nogap_len_int)),
    tail_ge20 = !is.na(tail_nogap_len) & tail_nogap_len >= 20,
    tail_ge15 = !is.na(tail_nogap_len) & tail_nogap_len >= 15,
    tail_full_25 = !is.na(tail_nogap_len) & tail_nogap_len == TAIL_FULL_LEN,
    tail_zero = !is.na(tail_nogap_len) & tail_nogap_len == 0
  )

phylum_sum_raw <- read.delim(
  PHYLUM_SUMMARY_FILE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_phylum_cols <- c("p", "n_seq", "mean_tail_len", "median_tail_len", "max_tail_len", "n_tail_ge20", "frac_tail_ge20")
missing_phylum_cols <- setdiff(required_phylum_cols, names(phylum_sum_raw))
if (length(missing_phylum_cols) > 0) {
  stop("Missing required columns in tail_hmm386_410_length_by_phylum.tsv: ", paste(missing_phylum_cols, collapse = ", "))
}

phylum_sum <- phylum_sum_raw %>%
  mutate(
    p = as.character(p),
    n_seq = suppressWarnings(as.numeric(n_seq)),
    mean_tail_len = suppressWarnings(as.numeric(mean_tail_len)),
    median_tail_len = suppressWarnings(as.numeric(median_tail_len)),
    max_tail_len = suppressWarnings(as.numeric(max_tail_len)),
    n_tail_ge20 = suppressWarnings(as.numeric(n_tail_ge20)),
    frac_tail_ge20 = suppressWarnings(as.numeric(frac_tail_ge20)),
    frac_tail_ge15 = if ("frac_tail_ge15" %in% names(.)) suppressWarnings(as.numeric(frac_tail_ge15)) else NA_real_,
    frac_tail_25 = if ("frac_tail_25" %in% names(.)) suppressWarnings(as.numeric(frac_tail_25)) else NA_real_
  )

base_config <- data.frame(
  parameter = c(
    "project_dir",
    "seq_file",
    "phylum_summary_file",
    "output_root",
    "tail_start",
    "tail_end",
    "tail_full_len",
    "quality_filter",
    "min_seq_per_phylum_heatmap",
    "max_phylum_rows_heatmap",
    "n_seq_rows",
    "n_phyla",
    "n_family_classes"
  ),
  value = c(
    PROJECT_DIR,
    SEQ_FILE,
    PHYLUM_SUMMARY_FILE,
    OUTPUT_ROOT,
    TAIL_START,
    TAIL_END,
    TAIL_FULL_LEN,
    QUALITY_FILTER,
    MIN_SEQ_PER_PHYLUM_HEATMAP,
    MAX_PHYLUM_ROWS_HEATMAP,
    nrow(seq_df),
    dplyr::n_distinct(seq_df$p),
    dplyr::n_distinct(seq_df$actin_family_class)
  ),
  stringsAsFactors = FALSE
)

# ============================================================
# 3. Family summary and ordering
# ============================================================

family_sum <- seq_df %>%
  group_by(actin_family_class) %>%
  summarise(
    n_seq = n(),
    mean_tail_nogap_len = mean(tail_nogap_len, na.rm = TRUE),
    median_tail_nogap_len = median(tail_nogap_len, na.rm = TRUE),
    mean_tail_aligned_len = mean(tail_aligned_len, na.rm = TRUE),
    mean_n_gap = mean(n_gap, na.rm = TRUE),
    frac_tail_zero = mean(tail_zero, na.rm = TRUE),
    frac_tail_ge15 = mean(tail_ge15, na.rm = TRUE),
    frac_tail_ge20 = mean(tail_ge20, na.rm = TRUE),
    frac_tail_25 = mean(tail_full_25, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(frac_tail_ge20), desc(mean_tail_nogap_len), desc(n_seq), actin_family_class) %>%
  mutate(
    family_display = dplyr::recode(
      actin_family_class,
      "canonical Actin-like" = "canonical actin-like proteins (cALPs)",
      "Crenactin-like / archaeal actin" = "divergent actin-like proteins (dALPs)",
      "MreB/Mbl-like" = "MreB/Mbl-profile proteins",
      "MreB-like_C/ALP_N-related" = "MreB_C/ALP_N domain-profile proteins",
      "FtsA/PilM-like" = "FtsA/PilM-profile proteins",
      "Salactin" = "Salactin-like proteins",
      "Volactin" = "Volactin-like proteins",
      .default = actin_family_class
    ),
    family_label = paste0(family_display, " (n=", fmt_int(n_seq), ")")
  )

family_order <- family_sum$actin_family_class
family_label_order <- family_sum$family_label

seq_df <- seq_df %>%
  mutate(actin_family_class = factor(actin_family_class, levels = family_order)) %>%
  left_join(family_sum %>% select(actin_family_class, family_label), by = "actin_family_class") %>%
  mutate(family_label = factor(family_label, levels = rev(family_label_order)))

# ============================================================
# 4. Figure 2A1 v2: family x tail-length distribution heatmap
# ============================================================

fig2A1_data <- seq_df %>%
  group_by(actin_family_class, family_label, tail_nogap_len_int) %>%
  summarise(n_seq_len = n(), .groups = "drop") %>%
  group_by(actin_family_class, family_label) %>%
  mutate(
    n_seq_family = sum(n_seq_len, na.rm = TRUE),
    fraction_in_family = n_seq_len / n_seq_family
  ) %>%
  ungroup() %>%
  complete(
    family_label = factor(rev(family_label_order), levels = rev(family_label_order)),
    tail_nogap_len_int = 0:TAIL_FULL_LEN,
    fill = list(n_seq_len = 0, n_seq_family = 0, fraction_in_family = 0)
  ) %>%
  mutate(
    tail_nogap_len_int = as.integer(tail_nogap_len_int)
  )

fig2A1_zero_labels <- family_sum %>%
  transmute(
    family_label = factor(family_label, levels = rev(family_label_order)),
    zero_label = paste0("0 aa  ", fmt_pct(frac_tail_zero, 1))
  )

p2A1 <- ggplot(fig2A1_data, aes(x = tail_nogap_len_int, y = family_label, fill = fraction_in_family)) +
  geom_tile(width = 0.90, height = 0.76, colour = "white", linewidth = 0.16) +
  geom_text(
    data = fig2A1_zero_labels,
    aes(x = -3.0, y = family_label, label = zero_label),
    inherit.aes = FALSE, size = 2.2, colour = "#333333", hjust = 0
  ) +
  geom_vline(xintercept = -0.55, linewidth = 0.25, colour = "#BDBDBD") +
  geom_vline(xintercept = 19.5, linetype = 2, linewidth = 0.35, colour = "#D95F02") +
  scale_x_continuous(
    breaks = 0:TAIL_FULL_LEN,
    limits = c(-3.25, TAIL_FULL_LEN + 0.5),
    expand = expansion(mult = c(0, 0.02))
  ) +
  scale_fill_gradient(
    low = "#FFFFFF",
    high = "#2166AC",
    trans = "sqrt",
    labels = percent_format(accuracy = 1),
    name = "Fraction within family\n(square-root colour scale)"
  ) +
  labs(
    x = "Non-gap residues across HMM386-410 tail (0-25)",
    y = NULL,
    title = "HMM386-410 tail-length distribution by actin-superfamily category",
    subtitle = "Left labels give the fraction with tail_nogap_len = 0; dashed line marks tail_nogap_len >= 20"
  ) +
  theme_nature() +
  theme(
    axis.text.x = element_text(size = 5.8),
    legend.position = "right"
  )

out2A1 <- save_figure_in_own_folder(
  p2A1,
  "figure_2A1_family_tail_length_distribution_heatmap",
  fig2A1_data,
  width_mm = 220,
  height_mm = max(90, 48 + 8.5 * length(family_label_order)),
  config_df = base_config,
  extra_files = list("family_summary.tsv" = family_sum)
)

# ============================================================
# 5. Figure 2A2 v2: family tail completeness summary dot plot
# ============================================================

fig2A2_data <- family_sum %>%
  select(
    actin_family_class, family_label, n_seq,
    mean_tail_nogap_len, median_tail_nogap_len,
    frac_tail_ge20, frac_tail_zero, mean_n_gap
  ) %>%
  mutate(family_label = factor(family_label, levels = rev(family_label_order))) %>%
  pivot_longer(
    cols = c(mean_tail_nogap_len, median_tail_nogap_len, frac_tail_ge20, frac_tail_zero, mean_n_gap),
    names_to = "metric",
    values_to = "value"
  ) %>%
  mutate(
    metric = recode(
      metric,
      "mean_tail_nogap_len" = "Mean non-gap length",
      "median_tail_nogap_len" = "Median non-gap length",
      "frac_tail_ge20" = "Fraction length >=20",
      "frac_tail_zero" = "Fraction length =0",
      "mean_n_gap" = "Mean gap count"
    ),
    metric = factor(metric, levels = c(
      "Mean non-gap length",
      "Median non-gap length",
      "Mean gap count",
      "Fraction length >=20",
      "Fraction length =0"
    )),
    label = if_else(
      grepl("Fraction", metric),
      fmt_pct(value, 1),
      fmt_num(value, 1)
    )
  )

p2A2 <- ggplot(fig2A2_data, aes(x = value, y = family_label)) +
  geom_segment(aes(x = 0, xend = value, yend = family_label), linewidth = 0.25, colour = "grey65") +
  geom_point(size = 1.8, shape = 21, fill = "#4C78A8", colour = "black", linewidth = 0.22) +
  geom_text(aes(label = label), hjust = -0.15, size = 1.8) +
  facet_wrap(~ metric, scales = "free_x", ncol = 3) +
  labs(
    x = NULL,
    y = NULL,
    title = "Family-level HMM386-410 tail completeness summary",
    subtitle = "Dot plots summarize length, gap burden, and long-tail prevalence"
  ) +
  theme_nature() +
  theme(
    strip.text = element_text(size = 6.6),
    panel.spacing.x = grid::unit(5, "mm"),
    axis.text.x = element_text(size = 5.8)
  )

out2A2 <- save_figure_in_own_folder(
  p2A2,
  "figure_2A2_family_tail_completeness_summary_dotplot",
  fig2A2_data,
  width_mm = 225,
  height_mm = max(95, 45 + 8.5 * length(family_label_order)),
  config_df = base_config,
  extra_files = list("family_summary_wide.tsv" = family_sum)
)

# ============================================================
# 6. Phylum selection/order for heatmap
# ============================================================

# Use phylum summary for ordering when possible.
phylum_keep <- phylum_sum %>%
  filter(!is.na(n_seq), n_seq >= MIN_SEQ_PER_PHYLUM_HEATMAP) %>%
  arrange(desc(frac_tail_ge20), desc(mean_tail_len), desc(n_seq), p)

# Always keep Asgard if present.
asgard_row <- phylum_sum %>%
  filter(grepl("Asgard", p, ignore.case = TRUE))

phylum_keep <- bind_rows(phylum_keep, asgard_row) %>%
  distinct(p, .keep_all = TRUE) %>%
  arrange(desc(frac_tail_ge20), desc(mean_tail_len), desc(n_seq), p)

if (nrow(phylum_keep) > MAX_PHYLUM_ROWS_HEATMAP) {
  # Keep top rows plus Asgard if not already in top.
  top_keep <- phylum_keep %>% slice(seq_len(MAX_PHYLUM_ROWS_HEATMAP))
  if (nrow(asgard_row) > 0 && !asgard_row$p[1] %in% top_keep$p) {
    top_keep <- bind_rows(top_keep %>% slice(seq_len(MAX_PHYLUM_ROWS_HEATMAP - 1L)), asgard_row)
  }
  phylum_keep <- top_keep %>% distinct(p, .keep_all = TRUE)
}

phylum_order <- phylum_keep$p
phylum_label_df <- phylum_keep %>%
  mutate(
    phylum_label = paste0(p, " (n=", fmt_int(n_seq), ")"),
    p = factor(p, levels = phylum_order)
  )

# ============================================================
# 7. Figure 2A3 v2: phylum x tail length heatmap
# ============================================================

fig2A3_data <- seq_df %>%
  filter(p %in% phylum_order) %>%
  group_by(p, tail_nogap_len_int) %>%
  summarise(n_seq_len = n(), .groups = "drop") %>%
  group_by(p) %>%
  mutate(
    n_seq_phylum = sum(n_seq_len, na.rm = TRUE),
    fraction_in_phylum = n_seq_len / n_seq_phylum
  ) %>%
  ungroup() %>%
  complete(
    p = phylum_order,
    tail_nogap_len_int = 0:TAIL_FULL_LEN,
    fill = list(n_seq_len = 0, fraction_in_phylum = 0)
  ) %>%
  left_join(phylum_label_df %>% select(p, phylum_label, n_seq, mean_tail_len, frac_tail_ge20), by = "p") %>%
  mutate(
    phylum_label = factor(phylum_label, levels = rev(phylum_label_df$phylum_label)),
    tail_nogap_len_int = as.integer(tail_nogap_len_int)
  )

fig2A3_zero_labels <- seq_df %>%
  filter(p %in% phylum_order) %>%
  group_by(p) %>%
  summarise(frac_tail_zero = mean(tail_nogap_len_int == 0, na.rm = TRUE), .groups = "drop") %>%
  left_join(phylum_label_df %>% select(p, phylum_label), by = "p") %>%
  transmute(
    phylum_label = factor(phylum_label, levels = rev(phylum_label_df$phylum_label)),
    zero_label = paste0("0 aa  ", fmt_pct(frac_tail_zero, 1))
  )

p2A3 <- ggplot(fig2A3_data, aes(x = tail_nogap_len_int, y = phylum_label, fill = fraction_in_phylum)) +
  geom_tile(width = 0.92, height = 0.78, colour = "white", linewidth = 0.12) +
  geom_text(
    data = fig2A3_zero_labels,
    aes(x = -3.0, y = phylum_label, label = zero_label),
    inherit.aes = FALSE, size = 2.1, colour = "#333333", hjust = 0
  ) +
  geom_vline(xintercept = -0.55, linewidth = 0.25, colour = "#BDBDBD") +
  geom_vline(xintercept = 19.5, linetype = 2, linewidth = 0.35, colour = "#D95F02") +
  scale_x_continuous(
    breaks = 0:TAIL_FULL_LEN,
    limits = c(-3.25, TAIL_FULL_LEN + 0.5),
    expand = expansion(mult = c(0, 0.02))
  ) +
  scale_fill_gradient(
    low = "#FFFFFF",
    high = "#2166AC",
    trans = "sqrt",
    labels = percent_format(accuracy = 1),
    name = "Fraction within phylum\n(square-root colour scale)"
  ) +
  labs(
    x = "Non-gap residues across HMM386-410 tail (0-25)",
    y = NULL,
    title = "HMM386-410 tail length distribution by phylum",
    subtitle = "Left labels give the fraction with tail_nogap_len = 0; rows are ordered by long-tail prevalence; dashed line marks tail_nogap_len >= 20"
  ) +
  theme_nature() +
  theme(axis.text.x = element_text(size = 5.8), legend.position = "right")

out2A3 <- save_figure_in_own_folder(
  p2A3,
  "figure_2A3_phylum_tail_length_distribution_heatmap",
  fig2A3_data,
  width_mm = 200,
  height_mm = max(95, 45 + 6.5 * length(phylum_order)),
  config_df = base_config,
  extra_files = list("phylum_selection_for_heatmap.tsv" = phylum_keep)
)

# ============================================================
# 8. Figure 2A4 v2: phylum frac_tail_ge20 ranked dot plot
# ============================================================

fig2A4_data <- phylum_sum %>%
  arrange(frac_tail_ge20, mean_tail_len, n_seq, p) %>%
  mutate(
    phylum_label = paste0(p, " (n=", fmt_int(n_seq), ")"),
    phylum_label = factor(phylum_label, levels = phylum_label),
    label = paste0(fmt_pct(frac_tail_ge20, 1), ", mean=", fmt_num(mean_tail_len, 1))
  )

p2A4 <- ggplot(fig2A4_data, aes(x = frac_tail_ge20, y = phylum_label)) +
  geom_segment(aes(x = 0, xend = frac_tail_ge20, yend = phylum_label), linewidth = 0.25, colour = "grey70") +
  geom_point(aes(size = n_seq, fill = mean_tail_len), shape = 21, colour = "black", linewidth = 0.22, alpha = 0.90) +
  geom_text(aes(label = label), hjust = -0.04, size = 1.75) +
  scale_x_continuous(labels = percent_format(accuracy = 1), limits = c(0, max(0.05, max(fig2A4_data$frac_tail_ge20, na.rm = TRUE) * 1.22))) +
  scale_size_continuous(range = c(1.8, 7.8), breaks = pretty(fig2A4_data$n_seq, n = 4)) +
  scale_fill_gradient(low = "#F7F7F7", high = "#2166AC", name = "Mean\nlength") +
  labs(
    x = "Fraction with tail_nogap_len >= 20",
    y = NULL,
    size = "n_seq",
    title = "Phylum-level long-tail prevalence",
    subtitle = "Long tail is defined as tail_nogap_len >= 20"
  ) +
  theme_nature() +
  theme(legend.position = "right")

out2A4 <- save_figure_in_own_folder(
  p2A4,
  "figure_2A4_phylum_frac_tail_ge20_ranked_dotplot",
  fig2A4_data,
  width_mm = 200,
  height_mm = max(90, 40 + 5.4 * nrow(fig2A4_data)),
  config_df = base_config
)

# ============================================================
# 9. Figure 2A5 v2: phylum mean length vs frac_tail_ge20 bubble
# ============================================================

fig2A5_data <- phylum_sum %>%
  mutate(
    highlight = if_else(grepl("Asgard", p, ignore.case = TRUE), "Asgardarchaeota", "Other phyla"),
    label_show = if_else(
      grepl("Asgard", p, ignore.case = TRUE) |
        frac_tail_ge20 >= quantile(frac_tail_ge20, 0.85, na.rm = TRUE) |
        n_seq >= quantile(n_seq, 0.90, na.rm = TRUE),
      p,
      ""
    )
  )

p2A5 <- ggplot(fig2A5_data, aes(x = mean_tail_len, y = frac_tail_ge20, size = n_seq)) +
  geom_point(aes(fill = highlight), shape = 21, colour = "black", linewidth = 0.24, alpha = 0.88) +
  geom_text(aes(label = label_show), size = 2.0, nudge_y = 0.014, check_overlap = TRUE) +
  scale_fill_manual(values = c("Asgardarchaeota" = "#D95F02", "Other phyla" = "#BDBDBD"), drop = FALSE) +
  scale_size_continuous(range = c(2.0, 9.0), breaks = pretty(fig2A5_data$n_seq, n = 4)) +
  scale_y_continuous(labels = percent_format(accuracy = 1), limits = c(0, min(1, max(fig2A5_data$frac_tail_ge20, na.rm = TRUE) * 1.10 + 0.02))) +
  scale_x_continuous(limits = c(0, max(fig2A5_data$mean_tail_len, na.rm = TRUE) * 1.10 + 0.2)) +
  labs(
    x = "Mean tail_nogap_len",
    y = "Fraction with tail_nogap_len >= 20",
    size = "n_seq",
    fill = NULL,
    title = "Phylum-level HMM386-410 tail completeness landscape",
    subtitle = "Bubble size indicates sequence count; Asgardarchaeota is highlighted"
  ) +
  theme_nature() +
  theme(legend.position = "right")

out2A5 <- save_figure_in_own_folder(
  p2A5,
  "figure_2A5_phylum_tail_length_landscape_bubble",
  fig2A5_data,
  width_mm = 170,
  height_mm = 110,
  config_df = base_config
)

# ============================================================
# 10. Global output
# ============================================================

all_outputs <- bind_rows(out2A1, out2A2, out2A3, out2A4, out2A5)

write_tsv(base_config, file.path(OUTPUT_ROOT, "run_summary.tsv"))
write_tsv(all_outputs, file.path(OUTPUT_ROOT, "figure_output_index.tsv"))
write_tsv(family_sum, file.path(OUTPUT_ROOT, "family_tail_length_summary.tsv"))
write_tsv(phylum_sum, file.path(OUTPUT_ROOT, "phylum_tail_length_summary.tsv"))

message("Done.")
message("Working directory: ", PROJECT_DIR)
message("Output root: ", OUTPUT_ROOT)
message("This v2 script replaces ugly violin plots with discrete length heatmaps and summary dot plots.")
