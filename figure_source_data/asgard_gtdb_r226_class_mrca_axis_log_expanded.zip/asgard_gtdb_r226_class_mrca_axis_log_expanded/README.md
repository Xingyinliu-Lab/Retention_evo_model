# asgard_gtdb_r226_class_mrca_axis_log_expanded

- Manuscript panel: Supp.Fig.15A-part3
- Source figure basename: fig_asgard_gtdb_r226_class_mrca_axis_log_expanded
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 5 directly referenced or locally packaged source-data file(s)
