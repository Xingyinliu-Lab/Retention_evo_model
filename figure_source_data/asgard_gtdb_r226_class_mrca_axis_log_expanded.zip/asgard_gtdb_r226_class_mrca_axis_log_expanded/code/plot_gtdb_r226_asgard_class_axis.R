#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(ragg)
})

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1L) {
  normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
} else {
  ".."
}
data_dir <- file.path(root, "data")
figure_dir <- file.path(root, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

class_file <- file.path(data_dir, "gtdb_r226_asgard_class_mrca_axis.tsv")
tip_file <- file.path(data_dir, "gtdb_r226_asgard_tip_taxonomy.tsv")
remote_audit_file <- file.path(
  data_dir, "gtdb_r226_asgard_class_axis_audit.json"
)

classes <- read_tsv(class_file, show_col_types = FALSE)
tips <- read_tsv(tip_file, show_col_types = FALSE)

stopifnot(
  nrow(classes) > 0,
  nrow(tips) > 0,
  all(classes$gtdb_release == "r226"),
  all(tips$gtdb_release == "r226"),
  all(classes$p == "Asgardarchaeota"),
  all(tips$p == "Asgardarchaeota"),
  all(!is.na(classes$class_mrca_axis_norm)),
  sum(classes$n_gtdb_reference_tips) == nrow(tips),
  file.exists(remote_audit_file)
)

class_palette <- c(
  "#4E79A7", "#F28E2B", "#59A14F", "#E15759", "#76B7B2",
  "#B07AA1", "#EDC948", "#9C755F", "#FF9DA7", "#79706E",
  "#86BCB6", "#D37295", "#8CD17D", "#B6992D", "#499894",
  "#D4A6C8", "#A0CBE8", "#FFBE7D", "#A7D8A9", "#BAB0AC"
)
if (nrow(classes) > length(class_palette)) {
  stop("Class count exceeds the fixed colorblind-aware palette")
}

classes <- classes %>%
  arrange(class_mrca_axis_norm, desc(n_gtdb_reference_tips), c) %>%
  mutate(
    class_order = row_number(),
    colour = class_palette[class_order],
    x_log_raw = log1p(99 * pmax(0, pmin(1, class_mrca_axis_norm))) /
      log(100)
  )

midpoints <- if (nrow(classes) > 1L) {
  (head(classes$x_log_raw, -1L) + tail(classes$x_log_raw, -1L)) / 2
} else {
  numeric(0)
}
classes <- classes %>%
  mutate(
    interval_start_raw = c(0, midpoints),
    interval_end_raw = c(midpoints, 1)
  )

window_start_raw <- min(classes$interval_start_raw)
window_end_raw <- max(classes$interval_end_raw)
class_window_min_raw <- min(classes$x_log_raw)
class_window_max_raw <- max(classes$x_log_raw)
display_left <- 0.18
display_right <- 0.78

expand_class_window <- function(x) {
  if (class_window_max_raw <= class_window_min_raw) {
    return(x)
  }
  ifelse(
    x <= class_window_min_raw,
    display_left * x / max(class_window_min_raw, .Machine$double.eps),
    ifelse(
      x <= class_window_max_raw,
      display_left +
        (display_right - display_left) *
          (x - class_window_min_raw) /
          (class_window_max_raw - class_window_min_raw),
      display_right +
        (1 - display_right) *
          (x - class_window_max_raw) /
          max(1 - class_window_max_raw, .Machine$double.eps)
    )
  )
}

label_y_values <- c(0.58, 0.99, 1.40, 1.81)
classes <- classes %>%
  mutate(
    x_display = expand_class_window(x_log_raw),
    interval_start_display = expand_class_window(interval_start_raw),
    interval_end_display = expand_class_window(interval_end_raw),
    label_row = (class_order - 1L) %% length(label_y_values),
    label_y = label_y_values[label_row + 1L],
    label_x = if (n() == 1L) 0.5 else
      seq(0.07, 0.93, length.out = n()),
    label_text = paste0(c, "\nref=", n_gtdb_reference_tips)
  )

class_colors <- setNames(classes$colour, classes$c)
class_window_start <- min(classes$x_display)
class_window_end <- max(classes$x_display)
original_breaks <- c(0, 0.01, 0.025, 0.05, 0.10, 0.20, 0.40, 0.60, 0.80, 1)
display_breaks <- expand_class_window(log1p(99 * original_breaks) / log(100))

plot_source <- classes %>%
  select(
    gtdb_release, p, c, normalized_taxon, n_gtdb_reference_tips,
    class_mrca_depth, class_mrca_depth_from_asgard_root,
    class_mrca_axis_norm, class_mrca_global_root_depth_norm,
    mrca_all_tree_tip_span, mrca_asgard_tip_span,
    mrca_same_class_tip_n, mrca_other_class_tip_n,
    mrca_non_asgard_tip_n, class_monophyly_exact,
    tip_depth_min, tip_depth_median, tip_depth_max,
    asgard_root_depth, asgard_tip_depth_max, asgard_axis_span,
    class_order, colour, x_log_raw, x_display,
    interval_start_raw, interval_end_raw,
    interval_start_display, interval_end_display,
    label_row, label_x, label_y, label_text
  ) %>%
  mutate(label_text = gsub("\n", " | ", label_text, fixed = TRUE))

write_tsv(
  plot_source,
  file.path(data_dir, "fig_asgard_gtdb_r226_class_mrca_axis_plot_source.tsv")
)

audit <- tibble(
  metric = c(
    "gtdb_release",
    "source_phylum",
    "asgard_tip_n",
    "asgard_class_n",
    "class_tip_sum",
    "unclassified_tip_n",
    "exact_monophyletic_class_n",
    "class_mrca_axis_missing_n",
    "class_mrca_axis_out_of_bounds_n",
    "source_tip_duplicate_n",
    "figure_status"
  ),
  value = c(
    "r226",
    "p__Asgardarchaeota",
    as.character(nrow(tips)),
    as.character(nrow(classes)),
    as.character(sum(classes$n_gtdb_reference_tips)),
    as.character(sum(tips$class_name == "Unclassified_Asgardarchaeota")),
    as.character(sum(classes$class_monophyly_exact)),
    as.character(sum(is.na(classes$class_mrca_axis_norm))),
    as.character(sum(
      classes$class_mrca_axis_norm < 0 |
        classes$class_mrca_axis_norm > 1
    )),
    as.character(sum(duplicated(tips$accession))),
    "strict_complete_gtdb_r226_asgard_class_axis"
  )
)
write_tsv(
  audit,
  file.path(data_dir, "fig_asgard_gtdb_r226_class_mrca_axis_audit.tsv")
)

p <- ggplot(classes) +
  annotate(
    "segment",
    x = 0, xend = 1, y = 0, yend = 0,
    linewidth = 6.2, colour = "#C8CDD5", lineend = "butt"
  ) +
  geom_segment(
    aes(
      x = interval_start_display,
      xend = interval_end_display,
      y = 0, yend = 0, colour = c
    ),
    linewidth = 6.2, lineend = "butt", alpha = 0.92
  ) +
  geom_point(
    aes(x = x_display, y = 0, fill = c),
    shape = 21, size = 2.2, stroke = 0.35, colour = "white"
  ) +
  annotate(
    "segment",
    x = 0, xend = class_window_start,
    y = -0.14, yend = -0.14,
    linewidth = 0.55, colour = "#7C8799"
  ) +
  annotate(
    "segment",
    x = class_window_start, xend = class_window_end,
    y = -0.14, yend = -0.14,
    linewidth = 0.55, colour = "#465166"
  ) +
  annotate(
    "segment",
    x = class_window_end, xend = 1,
    y = -0.14, yend = -0.14,
    linewidth = 0.55, colour = "#7C8799"
  ) +
  annotate(
    "text",
    x = class_window_start / 2, y = -0.24,
    label = "shared Asgard stem",
    family = "Arial", size = 2.45, colour = "#667085"
  ) +
  annotate(
    "text",
    x = (class_window_start + class_window_end) / 2, y = -0.24,
    label = "class MRCA window",
    family = "Arial", size = 2.45, colour = "#465166"
  ) +
  annotate(
    "text",
    x = (class_window_end + 1) / 2, y = -0.24,
    label = "within-class diversification to tips",
    family = "Arial", size = 2.45, colour = "#667085"
  ) +
  geom_segment(
    aes(
      x = x_display, xend = label_x,
      y = 0.08, yend = label_y - 0.07,
      colour = c
    ),
    linewidth = 0.48, alpha = 0.82
  ) +
  geom_text(
    aes(
      x = label_x, y = label_y,
      label = label_text, colour = c
    ),
    family = "Arial", size = 2.05, lineheight = 0.92,
    hjust = 0.5, fontface = "plain"
  ) +
  annotate(
    "text",
    x = 0, y = -0.43, label = "Asgardarchaeota MRCA",
    family = "Arial", size = 2.65, hjust = 0, colour = "#555555"
  ) +
  annotate(
    "text",
    x = 1, y = -0.43, label = "GTDB r226 Asgard tips",
    family = "Arial", size = 2.65, hjust = 1, colour = "#555555"
  ) +
  scale_colour_manual(values = class_colors, guide = "none") +
  scale_fill_manual(values = class_colors, guide = "none") +
  scale_x_continuous(
    limits = c(-0.015, 1.015),
    breaks = display_breaks,
    labels = c("0", "0.01", "0.025", "0.05", "0.1",
               "0.2", "0.4", "0.6", "0.8", "1"),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(limits = c(-0.62, 2.25), expand = expansion(mult = 0)) +
  labs(
    title = "GTDB r226 Asgardarchaeota evolution axis by class MRCA",
    subtitle = paste0(
      nrow(tips), " GTDB reference tips; ",
      nrow(classes), " classes; log-expanded normalized depth"
    ),
    caption = paste0(
      "Tick labels show normalized branch-length depth from the ",
      "Asgardarchaeota MRCA (0) to the deepest Asgard tip (1). ",
      "The class-MRCA window is expanded for readability. ",
      "MRCA positions are relative phylogenetic coordinates, not dates."
    ),
    x = paste0(
      "normalized GTDB r226 Asgardarchaeota root-to-MRCA depth ",
      "(log-expanded display)"
    ),
    y = NULL
  ) +
  theme_minimal(base_family = "Arial", base_size = 8.2) +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E5E7EB"),
    axis.line = element_blank(),
    axis.ticks.x = element_line(linewidth = 0.3, colour = "#7C8799"),
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 7.4, colour = "#566174"),
    axis.title.x = element_text(
      size = 8.0, colour = "#465166", margin = margin(t = 10)
    ),
    plot.title = element_text(
      face = "plain", size = 11.2, colour = "#111111", hjust = 0.5
    ),
    plot.subtitle = element_text(
      size = 8.0, colour = "#667085", hjust = 0.5
    ),
    plot.caption = element_text(
      size = 6.6, colour = "#667085", hjust = 0.5
    ),
    legend.position = "none",
    plot.margin = margin(10, 16, 12, 12)
  ) +
  coord_cartesian(clip = "off")

stem <- file.path(
  figure_dir, "fig_asgard_gtdb_r226_class_mrca_axis_log_expanded"
)
ggsave(
  paste0(stem, ".pdf"),
  p,
  width = 12.6, height = 4.7, units = "in",
  device = cairo_pdf
)
agg_png(
  paste0(stem, ".png"),
  width = 12.6, height = 4.7, units = "in", res = 600
)
print(p)
dev.off()

message(
  "Saved GTDB r226 Asgard class axis: ",
  nrow(tips), " tips; ", nrow(classes), " classes"
)
