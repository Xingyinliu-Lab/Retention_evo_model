# 1_multicopy_top8_family_combinations_pie

- Manuscript panel: Fig.4D
- Source figure basename: figure_1_multicopy_top8_family_combinations_pie
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)
