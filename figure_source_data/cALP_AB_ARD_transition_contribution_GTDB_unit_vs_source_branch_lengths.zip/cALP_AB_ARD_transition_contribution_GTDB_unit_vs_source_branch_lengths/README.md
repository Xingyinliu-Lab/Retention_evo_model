# cALP_AB_ARD_transition_contribution_GTDB_unit_vs_source_branch_lengths

- Source figure: `fig_cALP_AB_ARD_transition_contribution_GTDB_unit_vs_source_branch_lengths`
- Analysis basis: ARD transition-contribution decomposition for gappyout584-derived cALP A/B states.
- Contents: final PDF/PNG, R plotting code and the plotted unit/source branch-treatment contribution table.
- Status: included; the former automated1-derived version is superseded.
- Packaging rule: files were copied; the analysis outputs were not moved.
