#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(ragg)
  library(stringr)
})

root <- ".."
data_dir <- file.path(root, "data")
figure_dir <- file.path(root, "figures")
formal_dir <- paste0(
  "..",
  "relationship_rebuild_20260719/data/formal_integrated_relationship_20260723"
)
annotation_file <- paste0(
  "..",
  "four_new_strategy_functional_reclassification_v2_20260718/",
  "four_group_og_functional_classification_v2.tsv"
)

positive <- read_tsv(
  file.path(formal_dir, "asgard_positive_formal_integrated_ranked.tsv"),
  show_col_types = FALSE
)
network <- read_tsv(
  file.path(data_dir, "asgard_positive_network_module_formal_selection.tsv"),
  show_col_types = FALSE
)
annotation <- read_tsv(annotation_file, show_col_types = FALSE) %>%
  filter(dataset == "asgard971_denovo") %>%
  select(
    OG, eggnog_top_preferred_names, eggnog_top_descriptions,
    eggnog_top_cog_categories, eggnog_top_kegg_ko,
    eggnog_top_kegg_pathway, hmmscan_pfam_top_domains,
    hmmscan_pfam_top_domain_desc, hmmscan_pfam_best_domain,
    hmmscan_pfam_best_domain_desc, annotation_text_shared
  )

stopifnot(
  nrow(positive) == 693,
  n_distinct(positive$OG) == 693,
  nrow(network) == 86,
  n_distinct(network$OG) == 86,
  length(intersect(positive$OG, network$OG)) == 86,
  all(!positive$direct_actin_superfamily),
  nrow(annotation) == 1293,
  n_distinct(annotation$OG) == 1293
)

nonnetwork <- positive %>%
  filter(!OG %in% network$OG) %>%
  arrange(formal_integrated_rank, OG) %>%
  mutate(nonnetwork_rank = row_number()) %>%
  left_join(annotation, by = "OG", relationship = "many-to-one")

stopifnot(
  nrow(nonnetwork) == 607,
  n_distinct(nonnetwork$OG) == 607,
  !anyNA(nonnetwork$nonnetwork_rank),
  !anyNA(nonnetwork$functional_group_v2)
)

evidence_columns <- c(
  "functional_description_summary", "eggnog_top_preferred_names",
  "eggnog_top_descriptions", "eggnog_top_cog_categories",
  "eggnog_top_kegg_ko", "eggnog_top_kegg_pathway",
  "hmmscan_pfam_top_domains", "hmmscan_pfam_top_domain_desc",
  "hmmscan_pfam_best_domain", "hmmscan_pfam_best_domain_desc",
  "annotation_text_shared"
)

refined <- nonnetwork %>%
  rowwise() %>%
  mutate(
    secondary_annotation_evidence = str_to_lower(paste(
      coalesce(c_across(all_of(evidence_columns)), ""), collapse = " | "
    )),
    refinement_rule = case_when(
      functional_group_v2 != "unresolved_function" ~ "original_v2_assignment",
      str_detect(secondary_annotation_evidence, "roadblock/?lc7|roadblock lc7") ~
        "Roadblock/LC7 domain",
      str_detect(
        secondary_annotation_evidence,
        paste0(
          "ribonuclease iii|thump domain|d hh family|dhh family|recj|",
          "nura domain|rho termination factor|ribbon-helix-helix|",
          "double zinc ribbon|zinc-ribbon domain|non-smc mitotic condensation|",
          "ribosome biogenesis protein"
        )
      ) ~ "information-processing domain",
      str_detect(
        secondary_annotation_evidence,
        "yip1 domain|oligosaccharyltransferase subunit 5|emc3/tmco1"
      ) ~ "membrane-system domain",
      str_detect(
        secondary_annotation_evidence,
        "pyridoxamine 5'-phosphate oxidase"
      ) ~ "metabolic enzyme domain",
      str_detect(
        secondary_annotation_evidence,
        "flavin reductase"
      ) ~ "energy/redox enzyme domain",
      str_detect(
        secondary_annotation_evidence,
        "chat domain"
      ) ~ "CHAT protease domain",
      str_detect(
        secondary_annotation_evidence,
        "duf998|bon domain"
      ) ~ "membrane-associated DUF998/BON domain",
      annotation_status == "unknown_or_no_hit" ~ "no eggNOG or clean-Pfam hit",
      TRUE ~ "annotation present but function remains nonspecific"
    ),
    refined_functional_group = case_when(
      functional_group_v2 != "unresolved_function" ~ functional_group_v2,
      refinement_rule == "Roadblock/LC7 domain" ~ "structural_scaffold",
      refinement_rule == "information-processing domain" ~ "information_processing",
      refinement_rule == "membrane-system domain" ~ "transport_membrane",
      refinement_rule == "metabolic enzyme domain" ~ "metabolism",
      refinement_rule == "energy/redox enzyme domain" ~ "energy_redox",
      refinement_rule == "CHAT protease domain" ~ "protein_homeostasis",
      refinement_rule == "membrane-associated DUF998/BON domain" ~
        "cell_surface_envelope_secretion",
      refinement_rule == "no eggNOG or clean-Pfam hit" ~ "no_detectable_annotation",
      TRUE ~ "conserved_uncharacterized"
    ),
    refinement_confidence = case_when(
      functional_group_v2 != "unresolved_function" ~ "frozen_v2",
      refinement_rule %in% c(
        "information-processing domain", "membrane-system domain",
        "metabolic enzyme domain", "energy/redox enzyme domain",
        "CHAT protease domain", "membrane-associated DUF998/BON domain"
      ) ~ "moderate_high",
      refinement_rule == "Roadblock/LC7 domain" ~ "moderate",
      TRUE ~ "not_functionally_assigned"
    )
  ) %>%
  ungroup()

fine_labels <- c(
  "information_processing" = "Information processing",
  "no_detectable_annotation" = "No annotation detected",
  "conserved_uncharacterized" = "Conserved, function uncharacterized",
  "metabolism" = "Metabolism",
  "energy_redox" = "Energy and redox",
  "transport_membrane" = "Transport and membrane",
  "membrane_trafficking_remodeling_division" =
    "Membrane trafficking, remodeling and division",
  "cytoskeleton_cell_shape_motility" =
    "Cytoskeleton, cell shape and motility",
  "cell_surface_envelope_secretion" =
    "Cell surface, envelope and secretion",
  "protein_homeostasis" = "Protein homeostasis",
  "defense_mobile_genetic_elements" =
    "Defense and mobile genetic elements",
  "structural_scaffold" = "Structural scaffold",
  "signaling_regulation" = "Signaling and regulation"
)

refined <- refined %>%
  mutate(refined_fine_function = unname(fine_labels[refined_functional_group]))
stopifnot(!anyNA(refined$refined_fine_function))

top100 <- refined %>% filter(nonnetwork_rank <= 100)
stopifnot(nrow(top100) == 100, n_distinct(top100$OG) == 100)

unresolved_audit <- refined %>%
  filter(functional_group_v2 == "unresolved_function") %>%
  select(
    OG, nonnetwork_rank, formal_integrated_rank, annotation_status,
    functional_subgroup_v2, functional_description_summary,
    eggnog_top_preferred_names, eggnog_top_descriptions,
    hmmscan_pfam_best_domain, hmmscan_pfam_best_domain_desc,
    refinement_rule, refined_functional_group, refinement_confidence
  )

top_counts <- top100 %>%
  mutate(
    plot_function_group = if_else(
      refined_functional_group %in% c(
        "no_detectable_annotation", "conserved_uncharacterized"
      ),
      "Unresolved / uncharacterized",
      refined_fine_function
    )
  ) %>%
  count(plot_function_group, name = "og_n") %>%
  mutate(total_og_n = 100L, fraction = og_n / total_og_n) %>%
  arrange(
    plot_function_group == "Unresolved / uncharacterized",
    desc(og_n), plot_function_group
  )

write_tsv(
  refined,
  file.path(data_dir, "asgard_nonnetwork_positive_607_function_classification_refined_20260826.tsv")
)
write_tsv(
  top100,
  file.path(data_dir, "asgard_nonnetwork_positive_top100_function_classification_refined_20260826.tsv")
)
write_tsv(
  unresolved_audit,
  file.path(data_dir, "asgard_nonnetwork_unresolved_secondary_reclassification_audit_20260826.tsv")
)
write_tsv(
  top_counts,
  file.path(data_dir, "fig_asgard_nonnetwork_pos_top100_function_counts_refined_source.tsv")
)

display_order <- top_counts$plot_function_group
plot_data <- top_counts %>%
  mutate(plot_function_group = factor(
    plot_function_group, levels = rev(display_order)
  ))

figure <- ggplot(plot_data, aes(og_n, plot_function_group)) +
  geom_col(width = 0.68, fill = "#5E87A6") +
  geom_text(
    aes(label = sprintf("%d (%.1f%%)", og_n, 100 * fraction)),
    hjust = -0.08, size = 2.7, family = "Arial", colour = "#333333"
  ) +
  scale_x_continuous(
    expand = expansion(mult = c(0, 0.22)),
    breaks = scales::pretty_breaks(n = 5)
  ) +
  labs(
    x = "Number of positive OGs", y = NULL,
    title = "Refined functional composition of the top 100 Asgard non-network positive OGs",
    subtitle = paste0(
      "Frozen 86-OG annotation-supported actin-network set excluded; ",
      "secondary annotation audit applied"
    )
  ) +
  theme_classic(base_size = 9, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#333333"),
    plot.title = element_text(size = 10.5, face = "bold"),
    plot.subtitle = element_text(size = 8.5, colour = "#555555"),
    plot.margin = margin(7, 9, 7, 7)
  )

stem <- file.path(
  figure_dir,
  "fig_asgard_nonnetwork_pos_top100_function_class_counts_refined"
)
ggsave(
  paste0(stem, ".pdf"), figure,
  width = 178, height = 116, units = "mm", device = cairo_pdf
)
ggsave(
  paste0(stem, ".png"), figure,
  width = 178, height = 116, units = "mm", dpi = 600, device = agg_png
)

audit <- tibble(
  metric = c(
    "frozen_positive_og_n", "excluded_network_og_n",
    "nonnetwork_positive_og_n", "top100_og_n",
    "top100_max_original_rank", "top100_unresolved_or_uncharacterized_n",
    "functional_class_n", "figure_status"
  ),
  value = c(
    693L, 86L, nrow(refined), nrow(top100),
    max(top100$formal_integrated_rank),
    sum(top100$refined_functional_group %in% c(
      "no_detectable_annotation", "conserved_uncharacterized"
    )),
    nrow(top_counts), "strict_complete"
  )
)
write_tsv(
  audit,
  file.path(data_dir, "fig_asgard_nonnetwork_pos_top100_function_counts_refined_audit.tsv")
)

message(
  "Saved Asgard non-network Top100 function counts: positive=693; ",
  "network_excluded=86; nonnetwork=607; top100=100"
)
