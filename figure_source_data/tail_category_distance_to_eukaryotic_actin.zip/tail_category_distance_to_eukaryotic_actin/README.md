# 5_tail_category_distance_to_eukaryotic_actin

- Manuscript panel: Supp.Fig.5D
- Source figure basename: figure_5_tail_category_distance_to_eukaryotic_actin
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 21 directly referenced or locally packaged source-data file(s)
