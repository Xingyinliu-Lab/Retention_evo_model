suppressPackageStartupMessages({library(ape);library(dplyr);library(ggplot2);library(readr)})
pkg <- ".."; fig <- file.path(pkg,"figures"); dat <- file.path(pkg,"data")
meta_file <- "../data/frozen6769_sequence_MAG_species_manifest.tsv"
map_a1338 <- ".."
map_asgard <- ".."
tree_a1338 <- ".."
tree_asgard <- ".."
meta <- read_tsv(meta_file,show_col_types=FALSE) %>% mutate(profile=case_when(actin_family_class=="canonical Actin-like"~"cALP",actin_family_class=="Crenactin-like / archaeal actin"~"dALP",TRUE~NA_character_))
state_pal <- c("dALP-only"="#4F9C8E","cALP+dALP coexist"="#D89C2B","cALP-only"="#4C78A8","no cALP/dALP"="#EEEEEE")
make_axis <- function(tree_file, map_file, dataset, taxon_col, taxon_title, stem) {
  tr <- read.tree(tree_file); tips <- tibble(mag_id=tr$tip.label); tree_meta <- read_tsv(map_file,show_col_types=FALSE) %>% select(mag_id,p,c); stopifnot(length(tr$tip.label)==nrow(tips),setequal(tips$mag_id,tree_meta$mag_id))
  g <- ggtree::ggtree(tr,layout="circular"); ord <- g$data %>% filter(isTip) %>% transmute(mag_id=label,y) %>% arrange(y) %>% mutate(tip_order=row_number()) %>% left_join(tree_meta,by="mag_id")
  st <- meta %>% filter(mag_id %in% ord$mag_id,!is.na(profile)) %>% distinct(mag_id,profile) %>% count(mag_id,name="n_profile") %>% left_join(meta %>% filter(!is.na(profile)) %>% distinct(mag_id,profile) %>% group_by(mag_id) %>% summarise(profiles=paste(sort(profile),collapse="+"),.groups="drop"),by="mag_id") %>% mutate(state=case_when(profiles=="dALP"~"dALP-only",profiles=="cALP+dALP"~"cALP+dALP coexist",profiles=="cALP"~"cALP-only"))
  d <- ord %>% left_join(st %>% select(mag_id,state),by="mag_id") %>% mutate(state=ifelse(is.na(state),"no cALP/dALP",state),taxon=.data[[taxon_col]])
  tax <- unique(d$taxon); taxpal <- setNames(grDevices::hcl.colors(length(tax),"Dark 3"),tax)
  p <- ggplot(d,aes(tip_order,1)) + geom_tile(aes(fill=taxon),height=.34) + geom_tile(aes(y=.56,fill=state),height=.34) + scale_fill_manual(values=c(taxpal,state_pal),breaks=c(tax,state_pal),guide="none") + annotate("text",x=-.003*nrow(d),y=1,label=taxon_title,hjust=1,family="Arial",size=2.6,fontface="bold") + annotate("text",x=-.003*nrow(d),y=.56,label="cALP/dALP state",hjust=1,family="Arial",size=2.6,fontface="bold") + scale_x_continuous(expand=c(0,0)) + coord_cartesian(clip="off") + theme_void(base_family="Arial") + theme(plot.margin=margin(5,5,5,55))
  ggsave(file.path(fig,paste0(stem,".pdf")),p,width=183,height=22,units="mm",device=cairo_pdf,bg="white");ggsave(file.path(fig,paste0(stem,".png")),p,width=183,height=22,units="mm",dpi=420,bg="white")
  write_tsv(d,file.path(dat,paste0(stem,"_source.tsv"))); cat(dataset," tips=",nrow(d)," cALP=",sum(d$state=="cALP-only")," coexist=",sum(d$state=="cALP+dALP coexist")," dALP=",sum(d$state=="dALP-only"),"\n",sep="")
}
make_axis(tree_a1338,map_a1338,"Archaea1338","p","Phylum","fig_A1338_ASTRAL64_cALP_dALP_linear_axis")
make_axis(tree_asgard,map_asgard,"Asgard971","c","Asgard class","fig_Asgard971_ASTRAL89_cALP_dALP_linear_axis")

make_gtdb_axis <- function(tip_file, projection_file, taxon_col, taxon_title, stem) {
  ord <- read_tsv(tip_file,show_col_types=FALSE)
  ord <- ord %>% rename(mag_or_tip = 1) %>% mutate(tip_order=as.integer(tip_order))
  pr <- read_tsv(projection_file,show_col_types=FALSE) %>% select(mag_id,anchor_tip)
  mag_state <- meta %>% filter(!is.na(profile)) %>% distinct(mag_id,profile) %>% group_by(mag_id) %>% summarise(profiles=paste(sort(profile),collapse="+"),.groups="drop") %>% mutate(state=case_when(profiles=="dALP"~"dALP-only",profiles=="cALP+dALP"~"cALP+dALP coexist",profiles=="cALP"~"cALP-only"))
  state <- pr %>% left_join(mag_state,by="mag_id") %>% filter(!is.na(anchor_tip),!is.na(state)) %>% group_by(anchor_tip) %>% summarise(state=case_when("cALP+dALP coexist"%in%state~"cALP+dALP coexist",n_distinct(state)==1~first(state),TRUE~"taxon collision"),.groups="drop")
  d <- ord %>% left_join(state,by=c("mag_or_tip"="anchor_tip")) %>% mutate(state=ifelse(is.na(state),"no cALP/dALP",state),taxon=.data[[taxon_col]])
  tax <- unique(d$taxon); taxpal <- setNames(grDevices::hcl.colors(length(tax),"Dark 3"),tax); pal <- c(taxpal,state_pal,"taxon collision"="#7A6F8F")
  p <- ggplot(d,aes(tip_order,1))+geom_tile(aes(fill=taxon),height=.34)+geom_tile(aes(y=.56,fill=state),height=.34)+scale_fill_manual(values=pal,guide="none")+annotate("text",x=-.003*nrow(d),y=1,label=taxon_title,hjust=1,family="Arial",size=2.6,fontface="bold")+annotate("text",x=-.003*nrow(d),y=.56,label="cALP/dALP state",hjust=1,family="Arial",size=2.6,fontface="bold")+scale_x_continuous(expand=c(0,0))+coord_cartesian(clip="off")+theme_void(base_family="Arial")+theme(plot.margin=margin(5,5,5,55))
  ggsave(file.path(fig,paste0(stem,".pdf")),p,width=183,height=22,units="mm",device=cairo_pdf,bg="white");ggsave(file.path(fig,paste0(stem,".png")),p,width=183,height=22,units="mm",dpi=420,bg="white");write_tsv(d,file.path(dat,paste0(stem,"_source.tsv")))
}
make_gtdb_axis("../data/A1338_GTDB_projection_tip_order.tsv","../data/A1338_GTDB_projection_mapping.tsv","p","Phylum","fig_A1338_GTDB_cALP_dALP_linear_axis")
make_gtdb_axis("../data/Asgard971_GTDB_projection_tip_order.tsv","../data/Asgard971_GTDB_projection_mapping.tsv","c","Asgard class","fig_Asgard971_GTDB_cALP_dALP_linear_axis")

make_state_track <- function(source_file, stem) {
  d <- read_tsv(source_file, show_col_types=FALSE)
  p <- ggplot(d,aes(tip_order,1,fill=state)) + geom_raster(interpolate=FALSE) +
    scale_fill_manual(values=c(state_pal,"taxon collision"="#7A6F8F"),
      breaks=c("dALP-only","cALP+dALP coexist","cALP-only","taxon collision"),
      labels=c("dALP-only","cALP+dALP coexist","cALP-only","multiple MAG states at one reference tip"),name=NULL,drop=FALSE) +
    scale_x_continuous(expand=c(0,0)) + coord_cartesian(clip="off") +
    theme_void(base_family="Arial",base_size=7) +
    theme(legend.position="top",legend.justification="left",legend.text=element_text(size=5.7,colour="#303030"),legend.key.width=grid::unit(4.4,"mm"),legend.key.height=grid::unit(2.1,"mm"),legend.margin=margin(0,0,1.5,0),plot.margin=margin(1,1.5,1,1.5)) +
    guides(fill=guide_legend(nrow=1,byrow=TRUE,override.aes=list(colour=NA)))
  ggsave(file.path(fig,paste0(stem,".pdf")),p,width=183,height=12,units="mm",device=cairo_pdf,bg="white")
  ggsave(file.path(fig,paste0(stem,".png")),p,width=183,height=12,units="mm",dpi=420,bg="white")
}
make_state_track(file.path(dat,"fig_A1338_GTDB_cALP_dALP_linear_axis_source.tsv"),"fig_A1338_GTDB_cALP_dALP_state_track")
make_state_track(file.path(dat,"fig_Asgard971_GTDB_cALP_dALP_linear_axis_source.tsv"),"fig_Asgard971_GTDB_cALP_dALP_state_track")
make_state_track(file.path(dat,"fig_A1338_ASTRAL64_cALP_dALP_linear_axis_source.tsv"),"fig_A1338_ASTRAL64_cALP_dALP_state_track")
make_state_track(file.path(dat,"fig_Asgard971_ASTRAL89_cALP_dALP_linear_axis_source.tsv"),"fig_Asgard971_ASTRAL89_cALP_dALP_state_track")

m_state <- meta %>% filter(actin_family_class %in% c("MreB/Mbl-like","MreB-like_C/ALP_N-related","canonical Actin-like","Crenactin-like / archaeal actin")) %>% mutate(layer=if_else(actin_family_class %in% c("MreB/Mbl-like","MreB-like_C/ALP_N-related"),"MreB-like","ALP")) %>% distinct(mag_id,layer) %>% group_by(mag_id) %>% summarise(state=case_when(all(c("MreB-like","ALP")%in%layer)~"MreB-like+ALP coexist",layer[[1]]=="MreB-like"~"MreB-like only",TRUE~"ALP only"),.groups="drop")
f_state <- meta %>% mutate(final_family=recode(actin_family_class,"canonical Actin-like"="cALP","Crenactin-like / archaeal actin"="dALP","MreB/Mbl-like"="MreB/Mbl-like","MreB-like_C/ALP_N-related"="MreB-like_C/ALP_N-related","FtsA/PilM-like"="FtsA/PilM-like","Volactin"="Volactin","Salactin"="Salactin")) %>% distinct(mag_id,final_family) %>% group_by(mag_id) %>% summarise(state=if_else(n()==1,first(final_family),"multi-family MAG"),.groups="drop")
draw_track <- function(d, stem, pal) { p<-ggplot(d,aes(tip_order,1,fill=state))+geom_raster(interpolate=FALSE)+scale_fill_manual(values=pal,name=NULL,drop=FALSE)+scale_x_continuous(expand=c(0,0))+theme_void(base_family="Arial",base_size=7)+theme(legend.position="top",legend.justification="left",legend.text=element_text(size=5.7),legend.key.width=grid::unit(4.4,"mm"),legend.key.height=grid::unit(2.1,"mm"),plot.margin=margin(1,1.5,1,1.5))+guides(fill=guide_legend(nrow=1,byrow=TRUE,override.aes=list(colour=NA)));ggsave(file.path(fig,paste0(stem,".pdf")),p,width=183,height=12,units="mm",device=cairo_pdf,bg="white");ggsave(file.path(fig,paste0(stem,".png")),p,width=183,height=12,units="mm",dpi=420,bg="white") }
direct_tracks <- list(A1338_ASTRAL64=file.path(dat,"fig_A1338_ASTRAL64_cALP_dALP_linear_axis_source.tsv"),Asgard971_ASTRAL89=file.path(dat,"fig_Asgard971_ASTRAL89_cALP_dALP_linear_axis_source.tsv"))
family_pal<-c("MreB/Mbl-like"="#6D8FB3","MreB-like_C/ALP_N-related"="#8A75B5","cALP"="#4C78A8","dALP"="#4F9C8E","Volactin"="#C75C64","Salactin"="#D6A64A","FtsA/PilM-like"="#9C6B4E","multi-family MAG"="#D89C2B","no actin"="#EEEEEE")
for(nm in names(direct_tracks)){x<-read_tsv(direct_tracks[[nm]],show_col_types=FALSE)%>%select(mag_id,tip_order);draw_track(left_join(x,m_state,by="mag_id")%>%mutate(state=ifelse(is.na(state),"no MreB/ALP",state)),paste0("fig_",nm,"_MreB_ALP_state_track"),c("MreB-like only"="#6D8FB3","MreB-like+ALP coexist"="#D89C2B","ALP only"="#4F9C8E","no MreB/ALP"="#EEEEEE"));draw_track(left_join(x,f_state,by="mag_id")%>%mutate(state=ifelse(is.na(state),"no actin",state)),paste0("fig_",nm,"_full_actin_family_track"),family_pal)}

make_gtdb_profile_tracks <- function(tip_file, map_file, prefix) {
  ord <- read_tsv(tip_file,show_col_types=FALSE) %>% rename(anchor_tip=1) %>% select(anchor_tip,tip_order)
  mp <- read_tsv(map_file,show_col_types=FALSE) %>% select(mag_id,anchor_tip)
  aggregate_state <- function(ms, none) { mp %>% left_join(ms,by="mag_id") %>% filter(!is.na(state)) %>% group_by(anchor_tip) %>% summarise(state=if_else(n_distinct(state)==1,first(state),"multi-family MAG"),.groups="drop") %>% right_join(ord,by="anchor_tip") %>% mutate(state=ifelse(is.na(state),none,state)) }
  mm <- aggregate_state(m_state,"no MreB/ALP") %>% mutate(state=ifelse(state=="multi-family MAG","MreB-like+ALP coexist",state))
  ff <- aggregate_state(f_state,"no actin")
  draw_track(mm,paste0("fig_",prefix,"_MreB_ALP_state_track"),c("MreB-like only"="#6D8FB3","MreB-like+ALP coexist"="#D89C2B","ALP only"="#4F9C8E","no MreB/ALP"="#EEEEEE"))
  draw_track(ff,paste0("fig_",prefix,"_full_actin_family_track"),family_pal)
}
make_gtdb_profile_tracks("../data/A1338_GTDB_projection_tip_order.tsv","../data/A1338_GTDB_projection_mapping.tsv","A1338_GTDB")
make_gtdb_profile_tracks("../data/Asgard971_GTDB_projection_tip_order.tsv","../data/Asgard971_GTDB_projection_mapping.tsv","Asgard971_GTDB")
