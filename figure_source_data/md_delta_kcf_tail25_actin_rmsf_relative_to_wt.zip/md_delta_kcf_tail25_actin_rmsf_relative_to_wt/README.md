# md_delta_kcf_tail25_actin_rmsf_relative_to_wt

- Manuscript panel: Fig.3E
- Source figure basename: fig_md_delta_kcf_tail25_actin_rmsf_relative_to_wt
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 3 directly referenced or locally packaged source-data file(s)
