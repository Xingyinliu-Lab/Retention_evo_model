#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ragg)
})

root <- ".."
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")
manuscript_dir <- ".."

input_file <- file.path(
  source_dir,
  "fig_md_wt_delta_kcf_tail25_actin_rmsf_latest_replicate_source.tsv"
)

figure_contract <- list(
  core_conclusion = paste(
    "Tail perturbations produce residue-specific flexibility changes relative to WT,",
    "with magnitude and position depending on the complex and actin background."
  ),
  archetype = "quantitative grid",
  backend = "R",
  statistical_unit = "MD replicate; n=3 per state and complex background",
  interpretation = "descriptive dynamic feasibility, not binding affinity or function"
)

d <- read_tsv(input_file, show_col_types = FALSE) %>%
  mutate(
    template = factor(template, levels = c("7W4Z", "8BJH", "8DD0")),
    state = factor(state, levels = c("WT", "Delta KCF", "Delta tail25")),
    panel = factor(
      panel,
      levels = c(
        "Human ACTB | 7W4Z", "Human ACTB | 8BJH",
        "Human ACTB | 8DD0", "Rabbit ACTA1 | 7W4Z"
      )
    )
  )

stopifnot(
  n_distinct(d$template) == 3L,
  n_distinct(d$panel) == 4L,
  n_distinct(d$state) == 3L,
  all(d %>% distinct(panel, state, replicate) %>% count(panel, state) %>% pull(n) == 3L)
)

state_summary <- d %>%
  group_by(template, organism_label, panel, state, actin_residue) %>%
  summarise(
    mean_rmsf_A = mean(rmsf_A),
    sd_rmsf_A = sd(rmsf_A),
    n_replicates = n(),
    .groups = "drop"
  )

wt <- state_summary %>%
  filter(state == "WT") %>%
  select(
    template, organism_label, panel, actin_residue,
    wt_mean_rmsf_A = mean_rmsf_A,
    wt_sd_rmsf_A = sd_rmsf_A,
    wt_n_replicates = n_replicates
  )

delta <- state_summary %>%
  filter(state != "WT") %>%
  left_join(
    wt,
    by = c("template", "organism_label", "panel", "actin_residue")
  ) %>%
  filter(is.finite(wt_mean_rmsf_A)) %>%
  mutate(
    variant = factor(as.character(state), levels = c("Delta KCF", "Delta tail25")),
    delta_rmsf_A = mean_rmsf_A - wt_mean_rmsf_A,
    propagated_sd_A = sqrt(sd_rmsf_A^2 + wt_sd_rmsf_A^2),
    lower = delta_rmsf_A - propagated_sd_A,
    upper = delta_rmsf_A + propagated_sd_A,
    comparison = "variant mean minus WT mean"
  ) %>%
  select(
    template, organism_label, panel, variant, actin_residue,
    mean_rmsf_A, sd_rmsf_A, n_replicates,
    wt_mean_rmsf_A, wt_sd_rmsf_A, wt_n_replicates,
    delta_rmsf_A, propagated_sd_A, lower, upper, comparison
  )

stopifnot(
  n_distinct(delta$panel) == 4L,
  n_distinct(delta$variant) == 2L,
  all(delta$n_replicates == 3L),
  all(delta$wt_n_replicates == 3L),
  all(is.finite(delta$delta_rmsf_A))
)

source_out <- file.path(
  source_dir,
  "fig_md_delta_kcf_tail25_actin_rmsf_relative_to_wt_source.tsv"
)
write_tsv(delta, source_out)

tail_annotation <- tibble::tribble(
  ~panel, ~tail_start, ~kcf_start, ~sequence_end,
  "Human ACTB | 7W4Z", 351, 373, 375,
  "Human ACTB | 8BJH", 351, 373, 375,
  "Human ACTB | 8DD0", 351, 373, 375,
  "Rabbit ACTA1 | 7W4Z", 353, 375, 377
) %>%
  mutate(panel = factor(panel, levels = levels(d$panel)))

cols <- c("Delta KCF" = "#D2765D", "Delta tail25" = "#3E6F9E")

p <- ggplot(delta, aes(x = actin_residue, y = delta_rmsf_A, colour = variant)) +
  geom_rect(
    data = tail_annotation,
    aes(xmin = tail_start, xmax = kcf_start, ymin = -Inf, ymax = Inf),
    inherit.aes = FALSE, fill = "#E8EDF1", alpha = 0.62
  ) +
  geom_rect(
    data = tail_annotation,
    aes(xmin = kcf_start, xmax = sequence_end + 1, ymin = -Inf, ymax = Inf),
    inherit.aes = FALSE, fill = "#F2DED6", alpha = 0.72
  ) +
  geom_hline(yintercept = 0, linewidth = 0.42, linetype = "22", colour = "#4D4D4D") +
  geom_ribbon(
    aes(ymin = lower, ymax = upper, fill = variant),
    alpha = 0.13, colour = NA
  ) +
  geom_line(linewidth = 0.62) +
  facet_wrap(~panel, ncol = 2, axes = "all", axis.labels = "all") +
  scale_colour_manual(
    values = cols, name = NULL,
    labels = c("Delta KCF" = expression(Delta*KCF),
               "Delta tail25" = expression(Delta*tail25))
  ) +
  scale_fill_manual(values = cols, guide = "none") +
  scale_x_continuous(
    breaks = c(1, 50, 100, 150, 200, 250, 300, 350, 375),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  coord_cartesian(ylim = c(-3.2, 4.2)) +
  labs(
    title = "Residue-level flexibility changes relative to WT",
    subtitle = "Variant mean RMSF minus WT mean RMSF across three 50-ns replicates",
    x = "Actin residue",
    y = expression(Delta*"RMSF relative to WT ("*ring(A)*")"),
    caption = paste0(
      "Positive values indicate increased flexibility relative to WT; negative values indicate reduced flexibility.\n",
      "Lines show differences between replicate means; ribbons show propagated replicate SD, not confidence intervals.\n",
      "Pale blue-grey and pale coral backgrounds mark the tail-body and terminal-KCF coordinates, respectively."
    )
  ) +
  theme_classic(base_family = "Arial", base_size = 8.0) +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#222222", size = 6.8),
    axis.title = element_text(size = 7.6),
    strip.background = element_rect(fill = "#F1F3F5", colour = NA),
    strip.text = element_text(face = "bold", size = 7.5),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 7.1),
    legend.key.width = grid::unit(7, "mm"),
    panel.spacing = grid::unit(1.05, "lines"),
    panel.grid.major.y = element_line(linewidth = 0.22, colour = "#E9E9E9"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 10.0),
    plot.subtitle = element_text(size = 7.8, colour = "#555555"),
    plot.caption = element_text(size = 6.3, colour = "#666666", hjust = 0),
    plot.margin = margin(8, 10, 8, 8)
  )

stem <- file.path(figure_dir, "fig_md_delta_kcf_tail25_actin_rmsf_relative_to_wt")
ggsave(
  paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
  width = 183, height = 132, units = "mm", family = "Arial"
)
ggsave(
  paste0(stem, ".png"), p, device = ragg::agg_png,
  width = 183, height = 132, units = "mm", dpi = 600, background = "white"
)

stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))

file.copy(paste0(stem, ".pdf"), manuscript_dir, overwrite = TRUE)
file.copy(paste0(stem, ".png"), manuscript_dir, overwrite = TRUE)
file.copy(source_out, manuscript_dir, overwrite = TRUE)

writeLines(
  c(
    "PASS",
    "backend=R",
    "templates=7W4Z,8BJH,8DD0",
    "complex_backgrounds=4",
    "replicates_per_state=3",
    "comparison=variant_mean_minus_WT_mean",
    "uncertainty=propagated_replicate_SD_not_CI",
    "percentage_change=no",
    paste0("source_rows=", nrow(delta)),
    paste0("core_conclusion=", figure_contract$core_conclusion)
  ),
  paste0(stem, ".QA.marker")
)
