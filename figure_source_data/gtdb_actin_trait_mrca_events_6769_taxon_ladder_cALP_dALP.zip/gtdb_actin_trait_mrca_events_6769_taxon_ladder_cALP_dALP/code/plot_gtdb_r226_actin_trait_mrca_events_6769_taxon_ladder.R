#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(ragg)
})

root <- ".."
current_dir <- file.path(root, "current_canonical_tail")
data_dir <- file.path(current_dir, "data")
figure_dir <- file.path(current_dir, "figures")
source_dir <- file.path(
  current_dir, "data",
  "gtdb_r226_actin_trait_mrca_6769_calp_dalp_coexistence_20260826"
)

events <- read_tsv(
  file.path(source_dir, "gtdb_r226_actin_trait_mrca_events_from_6769_taxon.tsv"),
  show_col_types = FALSE
)

events <- events %>%
  mutate(
    label = recode(
      label,
      "canonical Actin-like" = "cALP",
      "Crenactin-like" = "dALP",
      "canonical multicopy >=2" = "cALP multicopy >=2",
      "canonical tail length >=10" = "cALP tail length >=10",
      "canonical tail length >=20" = "cALP tail length >=20",
      "canonical tail score >= -3" = "cALP tail score >= -3",
      "canonical tail -3.8 to -3" = "cALP tail -3.8 to -3",
      "canonical tail < -3.8" = "cALP tail < -3.8",
      "dALP-cALP coexistence" =
        "dALP-cALP coexistence (subset distribution bound)"
    )
  )

axis_source <- read_tsv(
  file.path(
    root, "archive_pre0719_root_20260724", "visualization_rebuild_20260718",
    "current_canonical_tail", "data",
    "kt_gtdb_r226_key_phylum_mrca_map_20260718",
    "gtdb_r226_key_phylum_mrca_map_summary.tsv"
  ),
  show_col_types = FALSE
) %>%
  arrange(x_log_plot, desc(n_gtdb_reference_tips), p) %>%
  mutate(
    interval_start_raw = c(
      max(0, x_log_plot[1] - (x_log_plot[2] - x_log_plot[1]) / 2),
      head((x_log_plot + lead(x_log_plot)) / 2, -1)
    ),
    interval_end_raw = c(
      head((x_log_plot + lead(x_log_plot)) / 2, -1),
      min(
        1,
        x_log_plot[n()] + (x_log_plot[n()] - x_log_plot[n() - 1]) / 2
      )
    )
  )

stopifnot(
  nrow(events) == 16,
  all(events$gtdb_release == "r226"),
  all(events$tree_present_n > 0),
  all(!is.na(events$mrca_depth_norm)),
  all(c("interval_start_raw", "interval_end_raw") %in% names(axis_source))
)
events <- events %>% filter(trait != "canonical_multicopy_ge2")

window_start_raw <- min(axis_source$interval_start_raw)
window_end_raw <- max(axis_source$interval_end_raw)
display_left <- 0.22
display_right <- 0.78

expand_middle_window <- function(x) {
  ifelse(
    x <= window_start_raw,
    display_left * x / window_start_raw,
    ifelse(
      x <= window_end_raw,
      display_left +
        (display_right - display_left) *
          (x - window_start_raw) / (window_end_raw - window_start_raw),
      display_right +
        (1 - display_right) *
          (x - window_end_raw) / (1 - window_end_raw)
    )
  )
}

axis_source <- axis_source %>%
  mutate(
    interval_start_display = expand_middle_window(interval_start_raw),
    interval_end_display = expand_middle_window(interval_end_raw)
  )

lane_levels <- c("actin family", "copy architecture", "tail")
lane_y <- c(
  "actin family" = 4.65,
  "copy architecture" = 2.70,
  "tail" = 0.85
)
lane_colors <- c(
  "actin family" = "#3E7CB1",
  "copy architecture" = "#6A994E",
  "tail" = "#C85A54"
)
phylum_colors <- c(
  "Methanobacteriota" = "#3E7CB1",
  "Hadarchaeota" = "#9C755F",
  "Methanobacteriota_B" = "#76B7B2",
  "Thermoplasmatota" = "#E15759",
  "Halobacteriota" = "#F28E2B",
  "Altiarchaeota" = "#B07AA1",
  "Asgardarchaeota" = "#59A14F",
  "Thermoproteota" = "#EDC948",
  "Nanobdellota" = "#4E79A7",
  "Iainarchaeota" = "#FF9DA7",
  "Aenigmatarchaeota" = "#8CD17D",
  "Micrarchaeota" = "#BAB0AC"
)
lane_offsets <- list(
  "actin family" = c(-1.05, -0.70, -0.35, 0, 0.35, 0.70, 1.05, 1.40),
  "copy architecture" = c(-0.42, 0, 0.42),
  "tail" = c(-1.05, -0.70, -0.35, 0, 0.35, 0.70)
)

plot_source <- events %>%
  filter(lane %in% lane_levels) %>%
  mutate(lane = factor(lane, levels = lane_levels)) %>%
  arrange(lane, x_log_plot, desc(n_seq)) %>%
  group_by(lane) %>%
  mutate(
    x_log_plot_raw = x_log_plot,
    x_log_plot = expand_middle_window(x_log_plot),
    lane_y = unname(lane_y[as.character(first(lane))]),
    label_offset = rep(
      lane_offsets[[as.character(first(lane))]],
      length.out = n()
    ),
    label_y = lane_y + label_offset,
    label_text = paste0(
      label,
      " (seq=", n_seq,
      "; GTDB r226=", n_gtdb_tips,
      ")"
    )
  ) %>%
  ungroup()

write_tsv(
  plot_source,
  file.path(data_dir, "fig_gtdb_r226_actin_trait_mrca_events_6769_cALP_dALP_plot_source.tsv")
)
write_tsv(
  tibble(
    metric = c(
      "gtdb_release",
      "sequence_n",
      "trait_n",
      "trait_with_mrca_n",
      "lane_n",
      "broad_traits_used_for_og_ranking",
      "figure_status"
    ),
    value = c(
      "r226",
      "6769",
      as.character(nrow(plot_source)),
      as.character(sum(!is.na(plot_source$mrca_depth_norm))),
      as.character(n_distinct(plot_source$lane)),
      "no",
      "strict_complete_frozen_context_figure"
    )
  ),
  file.path(data_dir, "fig_gtdb_r226_actin_trait_mrca_events_6769_cALP_dALP_audit.tsv")
)

base <- ggplot(plot_source) +
  annotate(
    "segment",
    x = 0,
    xend = 1,
    y = -0.62,
    yend = -0.62,
    linewidth = 5.2,
    colour = "#C8CDD5"
  ) +
  geom_segment(
    data = tibble(
      lane = factor(lane_levels, levels = lane_levels),
      lane_y = unname(lane_y[lane_levels])
    ),
    aes(x = 0, xend = 1, y = lane_y, yend = lane_y),
    inherit.aes = FALSE,
    linewidth = 0.45,
    colour = "#D8D8D8"
  ) +
  geom_segment(
    aes(
      x = x_log_plot,
      xend = x_log_plot,
      y = lane_y,
      yend = label_y,
      colour = lane
    ),
    linewidth = 0.35,
    alpha = 0.70
  ) +
  geom_segment(
    aes(
      x = x_log_plot,
      xend = x_log_plot,
      y = lane_y - 0.09,
      yend = lane_y + 0.09,
      colour = lane
    ),
    linewidth = 1.0,
    lineend = "butt"
  ) +
  geom_segment(
    data = axis_source,
    aes(
      x = interval_start_display,
      xend = interval_end_display,
      y = -0.62,
      yend = -0.62,
      colour = p
    ),
    inherit.aes = FALSE,
    linewidth = 5.2,
    lineend = "butt",
    alpha = 0.92
  ) +
  geom_text(
    aes(
      x = x_log_plot + 0.012,
      y = label_y,
      label = label_text,
      colour = lane
    ),
    family = "Arial",
    size = 2.25,
    hjust = 0,
    lineheight = 0.92
  ) +
  geom_segment(
    aes(
      x = x_log_plot,
      xend = x_log_plot,
      y = lane_y,
      yend = label_y,
      colour = lane
    ),
    linewidth = 0.35,
    alpha = 0.70
  ) +
  annotate(
    "text",
    x = display_left / 2,
    y = -0.88,
    label = "shared archaeal stem",
    family = "Arial",
    size = 2.55,
    hjust = 0.5,
    colour = "#555555"
  ) +
  annotate(
    "text",
    x = (display_left + display_right) / 2,
    y = -0.88,
    label = "phylum MRCA window",
    family = "Arial",
    size = 2.55,
    hjust = 0.5,
    colour = "#465166"
  ) +
  annotate(
    "text",
    x = (display_right + 1) / 2,
    y = -0.88,
    label = "within-phylum diversification to tips",
    family = "Arial",
    size = 2.55,
    hjust = 0.5,
    colour = "#555555"
  ) +
  annotate(
    "text",
    x = 0,
    y = -1.10,
    label = "GTDB r226 root",
    family = "Arial",
    size = 2.45,
    hjust = 0,
    colour = "#555555"
  ) +
  annotate(
    "text",
    x = 1,
    y = -1.10,
    label = "GTDB r226 tips",
    family = "Arial",
    size = 2.45,
    hjust = 1,
    colour = "#555555"
  ) +
  scale_fill_manual(values = lane_colors, guide = "none") +
  scale_colour_manual(
    values = c(lane_colors, phylum_colors),
    guide = "none"
  ) +
  scale_x_continuous(
    limits = c(-0.02, 1.02),
    breaks = expand_middle_window(
      log1p(99 * c(0, 0.01, 0.025, 0.05, 0.10, 0.15, 0.20, 0.30, 0.50, 1)) /
        log(100)
    ),
    labels = c("0", "0.01", "0.025", "0.05", "0.1", "0.15", "0.2", "0.3", "0.5", "1"),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    limits = c(-1.22, 6.10),
    breaks = unname(lane_y),
    labels = names(lane_y),
    expand = expansion(mult = 0)
  ) +
  labs(
    title = "Observed MRCA bounds of actin-trait distributions on the GTDB r226 axis",
    subtitle = paste0(
      "Taxon-name projections for 6,769 actin-like sequences; ",
      "15 displayed traits passed complete r226 MRCA audit"
    ),
    caption = paste0(
      "Tick labels show original normalized depth; the phylum window is expanded piecewise. ",
      "Positions are distribution/MRCA projections, not absolute dates.\n",
      "Broad any-actin and MreB/FtsA axes provide context only; ",
      "they do not define canonical/tail OG ranking. cALP multicopy is omitted. ",
      "The dALP-cALP coexistence set is an intersection subset; its more tipward MRCA must not be interpreted as the first evolution of coexistence."
    ),
    x = "normalized GTDB r226 root-to-MRCA depth (piecewise-expanded display)",
    y = NULL
  ) +
  theme_void(base_family = "Arial", base_size = 8) +
  theme(
    axis.text.y = element_text(
      face = "bold",
      size = 8,
      colour = "#333333",
      hjust = 1,
      margin = margin(r = 8)
    ),
    axis.text.x = element_text(size = 7.1, colour = "#566174"),
    axis.ticks.x = element_line(linewidth = 0.3, colour = "#7C8799"),
    axis.ticks.length = grid::unit(2.5, "pt"),
    axis.title.x = element_text(size = 7.7, colour = "#465166", margin = margin(t = 7)),
    plot.title = element_text(face = "bold", size = 11, colour = "#111111"),
    plot.subtitle = element_text(size = 8.2, colour = "#5D6675"),
    plot.caption = element_text(size = 6.6, colour = "#667085", hjust = 0, lineheight = 1.1),
    plot.margin = margin(10, 18, 16, 14)
  ) +
  coord_cartesian(clip = "off")

stem <- file.path(
  figure_dir,
  "fig_gtdb_actin_trait_mrca_events_6769_taxon_ladder_cALP_dALP"
)
ggsave(
  paste0(stem, ".pdf"),
  base,
  width = 12.6,
  height = 6.4,
  units = "in",
  device = cairo_pdf
)
agg_png(
  paste0(stem, ".png"),
  width = 12.6,
  height = 6.4,
  units = "in",
  res = 600
)
print(base)
dev.off()

message("Saved GTDB r226 actin-trait MRCA ladder with 15 displayed traits")
