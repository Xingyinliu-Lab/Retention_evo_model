# gtdb_actin_trait_mrca_events_6769_taxon_ladder_cALP_dALP

- Manuscript panel: Fig.8A-part2
- Source figure basename: fig_gtdb_actin_trait_mrca_events_6769_taxon_ladder_cALP_dALP
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 5 directly referenced or locally packaged source-data file(s)
