# pymol_8VKH_native_rabbit_ACTA1_full_tail_gelsolin_G1G3_interface_facing_oblique_exact7W50view_splitpatches

- Manuscript panel: Fig.3H
- Source figure basename: fig_pymol_8VKH_native_rabbit_ACTA1_full_tail_gelsolin_G1G3_interface_facing_oblique_exact7W50view_splitpatches
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
