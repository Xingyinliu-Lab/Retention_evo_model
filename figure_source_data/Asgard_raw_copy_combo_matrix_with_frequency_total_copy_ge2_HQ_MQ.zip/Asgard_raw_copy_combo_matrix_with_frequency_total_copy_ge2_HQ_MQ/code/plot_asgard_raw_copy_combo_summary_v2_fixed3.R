#!/usr/bin/env Rscript

# ============================================================
# Plot Asgard raw copy-combo summary, v2
# Input: asgard_raw_copy_combo_summary.tsv
#
# Main changes from v1:
#   1. copy_combo strings are parsed into raw-family membership.
#   2. Combinations are annotated by architecture complexity and
#      evolutionary/functional architecture class.
#   3. Long copy_combo labels are complemented by a combination matrix.
#   4. Cumulative contribution plot is retained to show long-tail/core structure.
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
  library(patchwork)
})

# -----------------------------
# 0. Arguments and paths
# -----------------------------

args <- commandArgs(trailingOnly = TRUE)

input_file <- if (length(args) >= 1) {
  normalizePath(args[1], winslash = "/", mustWork = TRUE)
} else {
  default_file <- "asgard_raw_copy_combo_summary.tsv"
  if (!file.exists(default_file)) {
    stop("Usage: Rscript plot_asgard_raw_copy_combo_summary_v2.R asgard_raw_copy_combo_summary.tsv [output_dir]")
  }
  normalizePath(default_file, winslash = "/", mustWork = TRUE)
}

output_root <- if (length(args) >= 2) {
  normalizePath(args[2], winslash = "/", mustWork = FALSE)
} else {
  dirname(input_file)
}

figure_dir <- file.path(output_root, "figures")
data_dir <- file.path(output_root, "plot_source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

# -----------------------------
# 1. Parameters
# -----------------------------

TOP_N_COMBOS_BAR <- 20L
TOP_N_COMBOS_MATRIX <- 18L
TOP_N_COMBOS_STACKED <- 10L

raw_family_order <- c(
  "canonical_Actin_like",
  "Crenactin_like_archaeal_actin",
  "MreB_Mbl_like",
  "MreB_like_C_ALP_N_related",
  "FtsA_PilM_like",
  "Salactin",
  "Volactin",
  "Other"
)

raw_family_labels <- c(
  "canonical_Actin_like" = "cALP",
  "Crenactin_like_archaeal_actin" = "dALP",
  "MreB_Mbl_like" = "MreB/Mbl-like",
  "MreB_like_C_ALP_N_related" = "MreB-like C/ALP-N-related",
  "FtsA_PilM_like" = "FtsA/PilM-like",
  "Salactin" = "Salactin",
  "Volactin" = "Volactin",
  "Other" = "Other"
)

architecture_colors <- c(
  "cALP-containing" = "#D55E00",
  "dALP-containing (no cALP)" = "#5B6FB2",
  "MreB/Mbl-like only" = "#7B61A8",
  "MreB-like C/ALP-N-related only" = "#B565A7",
  "Other raw-family combination" = "#7F7F7F"
)

combo_palette <- c(
  "Top combos" = "#4B6FA8",
  "Other combos" = "#BDBDBD"
)

# -----------------------------
# 2. Helper functions
# -----------------------------

fmt_int <- function(x) {
  format(x, big.mark = ",", scientific = FALSE, trim = TRUE)
}

fmt_pct <- function(x, digits = 1) {
  paste0(round(100 * x, digits), "%")
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size, colour = "black"),
      axis.text = element_text(size = base_size - 0.4, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = "black"),
      plot.title = element_text(size = base_size + 0.8, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.tag = element_text(size = 8, face = "bold"),
      plot.caption = element_text(size = base_size - 1.0, colour = "#4D4D4D", hjust = 0),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 300) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      paste0(stem, ".pdf"),
      width = width_in,
      height = height_in,
      family = "sans"
    )
  } else {
    grDevices::pdf(
      paste0(stem, ".pdf"),
      width = width_in,
      height = height_in,
      family = "sans"
    )
  }
  print(plot)
  grDevices::dev.off()

  if (capabilities("cairo")) {
    grDevices::png(
      paste0(stem, "_preview.png"),
      width = width_in,
      height = height_in,
      units = "in",
      res = dpi,
      type = "cairo",
      bg = "white"
    )
  } else {
    grDevices::png(
      paste0(stem, "_preview.png"),
      width = width_in,
      height = height_in,
      units = "in",
      res = dpi,
      bg = "white"
    )
  }
  print(plot)
  grDevices::dev.off()
}

write_tsv_base <- function(x, file) {
  write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

shorten_combo <- function(x) {
  x <- gsub("canonical_Actin_like", "cALP", x, fixed = TRUE)
  x <- gsub("Crenactin_like_archaeal_actin", "dALP", x, fixed = TRUE)
  x <- gsub("MreB_Mbl_like", "MreB/Mbl-like", x, fixed = TRUE)
  x <- gsub("MreB_like_C_ALP_N_related", "MreB-like C/ALP-N", x, fixed = TRUE)
  x <- gsub("FtsA_PilM_like", "FtsA/PilM-like", x, fixed = TRUE)
  x
}

has_family <- function(combo, family_name) {
  grepl(family_name, combo, fixed = TRUE)
}

parse_combo_membership <- function(df_in, family_names) {
  out <- df_in
  for (fam in family_names) {
    out[[paste0("has_", fam)]] <- has_family(out$copy_combo, fam)
  }
  out
}

make_combo_architecture <- function(df_in) {
  family_present_cols <- paste0("has_", raw_family_order)
  family_present_cols <- family_present_cols[family_present_cols %in% names(df_in)]

  out <- df_in %>%
    mutate(
      n_raw_families = rowSums(across(all_of(family_present_cols), as.integer)),
      architecture_complexity = case_when(
        n_raw_families <= 1 ~ "Single-family architecture",
        n_raw_families == 2 ~ "Two-family architecture",
        n_raw_families >= 3 ~ "Multi-family architecture",
        TRUE ~ "Unknown architecture"
      ),
      has_canonical = has_canonical_Actin_like,
      has_crenactin = has_Crenactin_like_archaeal_actin,
      evolutionary_architecture = case_when(
        has_canonical ~ "cALP-containing",
        has_crenactin ~ "dALP-containing (no cALP)",
        has_MreB_Mbl_like ~ "MreB/Mbl-like only",
        has_MreB_like_C_ALP_N_related ~ "MreB-like C/ALP-N-related only",
        TRUE ~ "Other raw-family combination"
      ),
      architecture_complexity = factor(
        architecture_complexity,
        levels = c("Single-family architecture", "Two-family architecture", "Multi-family architecture", "Unknown architecture")
      ),
      evolutionary_architecture = factor(
        evolutionary_architecture,
        levels = names(architecture_colors)
      )
    )

  out
}

# -----------------------------
# 3. Load and check data
# -----------------------------

combo_df <- read.delim(
  input_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_cols <- c("copy_combo", "n_mags", "fraction")
missing_cols <- setdiff(required_cols, names(combo_df))
if (length(missing_cols) > 0) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}

combo_df <- combo_df %>%
  mutate(
    copy_combo = trimws(as.character(copy_combo)),
    copy_combo = if_else(is.na(copy_combo) | copy_combo == "", "Unknown combo", copy_combo),
    n_mags = as.integer(n_mags),
    fraction = as.numeric(fraction)
  ) %>%
  arrange(desc(n_mags), desc(fraction), copy_combo)

if (any(is.na(combo_df$n_mags) | combo_df$n_mags < 0)) {
  stop("n_mags contains missing values or negative values.")
}
if (any(is.na(combo_df$fraction) | combo_df$fraction < 0)) {
  stop("fraction contains missing values or negative values.")
}

total_mags <- sum(combo_df$n_mags)

if (total_mags <= 0) {
  stop("Total MAG count is zero; cannot calculate fractions.")
}

combo_df <- combo_df %>%
  mutate(
    fraction_from_counts = n_mags / total_mags,
    fraction_diff = fraction - fraction_from_counts,
    combo_label = shorten_combo(copy_combo),
    rank = row_number(),
    cumulative_fraction = cumsum(fraction_from_counts)
  )

combo_df <- parse_combo_membership(combo_df, raw_family_order)
combo_df <- make_combo_architecture(combo_df)

# Drop raw families that never occur in any combo. This usually removes Other.
used_family_order <- raw_family_order[
  vapply(raw_family_order, function(fam) any(combo_df[[paste0("has_", fam)]]), logical(1))
]
used_family_labels <- raw_family_labels[used_family_order]

write_tsv_base(
  combo_df,
  file.path(data_dir, "asgard_raw_copy_combo_summary_input_checked_annotated.tsv")
)

architecture_summary <- combo_df %>%
  group_by(evolutionary_architecture) %>%
  summarise(
    n_combos = n(),
    n_mags = sum(n_mags),
    fraction = sum(fraction_from_counts),
    .groups = "drop"
  ) %>%
  arrange(desc(fraction))
write_tsv_base(
  architecture_summary,
  file.path(data_dir, "asgard_raw_copy_combo_evolutionary_architecture_summary.tsv")
)

complexity_summary <- combo_df %>%
  group_by(architecture_complexity) %>%
  summarise(
    n_combos = n(),
    n_mags = sum(n_mags),
    fraction = sum(fraction_from_counts),
    .groups = "drop"
  ) %>%
  arrange(architecture_complexity)
write_tsv_base(
  complexity_summary,
  file.path(data_dir, "asgard_raw_copy_combo_architecture_complexity_summary.tsv")
)

# -----------------------------
# 4. Figure 1: Genetic architecture top bar, faceted by complexity
# -----------------------------

top_combo_n <- min(as.integer(TOP_N_COMBOS_BAR), nrow(combo_df))
top_combo <- combo_df %>%
  head(top_combo_n) %>%
  mutate(
    combo_label_n = paste0("C", sprintf("%02d", rank), " | ", combo_label, " (n=", fmt_int(n_mags), ")"),
    combo_label_n = factor(combo_label_n, levels = rev(combo_label_n))
  )

p_architecture_bar <- ggplot(
  top_combo,
  aes(x = fraction_from_counts, y = combo_label_n, fill = evolutionary_architecture)
) +
  geom_col(width = 0.72) +
  geom_text(
    aes(label = fmt_pct(fraction_from_counts, digits = 1)),
    hjust = -0.08,
    size = 2.0
  ) +
  facet_grid(architecture_complexity ~ ., scales = "free_y", space = "free_y") +
  scale_fill_manual(values = architecture_colors, drop = FALSE) +
  scale_x_continuous(
    labels = percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0.16))
  ) +
  labs(
    x = "Fraction of Asgard actin-positive MAGs",
    y = NULL,
    fill = "Architecture class",
    title = "Asgard raw copy-combo genetic architectures",
    subtitle = paste0("Top ", top_combo_n, " raw-family presence/absence combinations, grouped by number of families"),
    caption = "copy_combo encodes raw-family presence/absence; family count is architectural complexity, not exact copy number."
  ) +
  theme_nature() +
  theme(
    legend.position = "right",
    axis.text.y = element_text(size = 5.3),
    strip.text.y = element_text(angle = 0, hjust = 0)
  )

fig1_height <- max(100, 32 + 5.5 * top_combo_n)
save_figure(
  p_architecture_bar,
  file.path(figure_dir, "figure_1_Asgard_raw_copy_combo_architecture_faceted_bar"),
  width_mm = 180,
  height_mm = fig1_height
)
write_tsv_base(
  top_combo,
  file.path(data_dir, "figure_1_Asgard_raw_copy_combo_architecture_faceted_bar_source_data.tsv")
)

# -----------------------------
# 5. Figure 2: Combination matrix with frequency bar
# -----------------------------

matrix_n <- min(as.integer(TOP_N_COMBOS_MATRIX), nrow(combo_df))
matrix_combo <- combo_df %>%
  head(matrix_n) %>%
  mutate(
    combo_id = paste0("C", sprintf("%02d", seq_len(n()))),
    x_index = seq_len(n())
  )

matrix_membership <- matrix_combo %>%
  select(combo_id, x_index, copy_combo, n_mags, fraction_from_counts, evolutionary_architecture, all_of(paste0("has_", used_family_order))) %>%
  pivot_longer(
    cols = all_of(paste0("has_", used_family_order)),
    names_to = "family_col",
    values_to = "present"
  ) %>%
  mutate(
    raw_family = sub("^has_", "", family_col),
    present = as.logical(present)
  )

# Use a numeric y-axis for the membership matrix. This avoids a patchwork/
# ggplot2 edge case where the continuous y-scale from the frequency bar can be
# accidentally applied to a discrete y-axis in the dot matrix.
family_axis <- data.frame(
  raw_family = used_family_order,
  raw_family_label = used_family_labels,
  y_index = rev(seq_along(used_family_order)),
  stringsAsFactors = FALSE
)

matrix_membership <- matrix_membership %>%
  left_join(family_axis, by = "raw_family")

connector_data <- matrix_membership %>%
  filter(present) %>%
  group_by(combo_id, x_index) %>%
  summarise(
    y_min = min(y_index, na.rm = TRUE),
    y_max = max(y_index, na.rm = TRUE),
    n_present = n(),
    .groups = "drop"
  ) %>%
  filter(n_present >= 2)

p_matrix_bar <- ggplot(matrix_combo, aes(x = x_index, y = n_mags, fill = evolutionary_architecture)) +
  geom_col(width = 0.72) +
  geom_text(aes(label = fmt_int(n_mags)), vjust = -0.25, size = 2.0) +
  scale_fill_manual(values = architecture_colors, drop = TRUE) +
  scale_x_continuous(limits = c(0.5, matrix_n + 0.5), breaks = matrix_combo$x_index, labels = NULL, expand = c(0, 0)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(
    x = NULL,
    y = "MAGs",
    fill = "Architecture class",
    title = "Asgard raw-family co-occurrence patterns",
    subtitle = "Bars show MAG counts; matrix dots show binary raw-profile membership"
  ) +
  theme_nature() +
  theme(
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    legend.position = "right",
    plot.margin = margin(4, 5, 0, 5)
  )

p_matrix_dot <- ggplot(matrix_membership, aes(x = x_index, y = y_index)) +
  geom_segment(
    data = connector_data,
    aes(x = x_index, xend = x_index, y = y_min, yend = y_max),
    inherit.aes = FALSE,
    linewidth = 0.35,
    colour = "#4D4D4D"
  ) +
  geom_point(aes(alpha = present), size = 2.1, colour = "black") +
  scale_alpha_manual(values = c("FALSE" = 0.08, "TRUE" = 1.0), guide = "none") +
  scale_x_continuous(
    limits = c(0.5, matrix_n + 0.5),
    breaks = matrix_combo$x_index,
    labels = matrix_combo$combo_id,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    breaks = family_axis$y_index,
    labels = family_axis$raw_family_label,
    limits = c(0.5, length(used_family_order) + 0.5),
    expand = c(0, 0)
  ) +
  labs(
    x = "Pattern ID",
    y = NULL,
    caption = "Patterns are ranked by MAG count. This is raw-profile presence/absence, not exact gene copy number; C01-C17 are decoded in the source data."
  ) +
  theme_nature() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    panel.grid = element_blank(),
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 5.5),
    axis.text.y = element_text(size = 5.8),
    plot.margin = margin(0, 5, 4, 5)
  )

p_combo_matrix <- (p_matrix_bar / p_matrix_dot) +
  plot_layout(heights = c(1.0, 1.15), guides = "collect") &
  theme(legend.position = "right")

save_figure(
  p_combo_matrix,
  file.path(figure_dir, "figure_2_Asgard_raw_copy_combo_matrix_with_frequency"),
  width_mm = 180,
  height_mm = 125
)
write_tsv_base(
  matrix_combo,
  file.path(data_dir, "figure_2_Asgard_raw_copy_combo_matrix_combo_source_data.tsv")
)
write_tsv_base(
  matrix_membership,
  file.path(data_dir, "figure_2_Asgard_raw_copy_combo_matrix_membership_source_data.tsv")
)

# -----------------------------
# 6. Figure 3: Cumulative contribution plot
# -----------------------------

thresholds <- c(0.50, 0.80, 0.90)
threshold_df <- data.frame(threshold = thresholds) %>%
  rowwise() %>%
  mutate(
    rank_reached = {
      idx <- which(combo_df$cumulative_fraction >= threshold)
      if (length(idx) == 0) NA_integer_ else min(idx)
    },
    cumulative_fraction = threshold
  ) %>%
  ungroup()
write_tsv_base(
  threshold_df,
  file.path(data_dir, "figure_3_Asgard_raw_copy_combo_cumulative_thresholds.tsv")
)

p_cumulative <- ggplot(combo_df, aes(x = rank, y = cumulative_fraction)) +
  geom_step(linewidth = 0.55, colour = "#4B6FA8") +
  geom_point(size = 1.15, colour = "#4B6FA8") +
  geom_hline(yintercept = thresholds, linetype = "dashed", linewidth = 0.25, colour = "#777777") +
  geom_vline(
    data = threshold_df %>% filter(!is.na(rank_reached)),
    aes(xintercept = rank_reached),
    linetype = "dotted",
    linewidth = 0.25,
    colour = "#777777"
  ) +
  geom_text(
    data = threshold_df %>% filter(!is.na(rank_reached)),
    aes(x = rank_reached, y = cumulative_fraction, label = paste0(fmt_pct(threshold, 0), " at rank ", rank_reached)),
    inherit.aes = FALSE,
    hjust = -0.05,
    vjust = -0.35,
    size = 2.0,
    colour = "#4D4D4D"
  ) +
  scale_y_continuous(labels = percent_format(accuracy = 1), limits = c(0, 1.04)) +
  scale_x_continuous(expand = expansion(mult = c(0.01, 0.08))) +
  labs(
    x = "copy_combo rank by MAG count",
    y = "Cumulative fraction of Asgard MAGs",
    title = "Cumulative contribution of Asgard raw copy-combo architectures",
    subtitle = "Steeper curves indicate a small core set of dominant architectures"
  ) +
  theme_nature()

save_figure(
  p_cumulative,
  file.path(figure_dir, "figure_3_Asgard_raw_copy_combo_cumulative_fraction"),
  width_mm = 120,
  height_mm = 85
)
write_tsv_base(
  combo_df,
  file.path(data_dir, "figure_3_Asgard_raw_copy_combo_cumulative_fraction_source_data.tsv")
)

# -----------------------------
# 7. Figure 4: Evolutionary architecture composition
# -----------------------------

architecture_summary <- architecture_summary %>%
  mutate(
    evolutionary_architecture = factor(evolutionary_architecture, levels = rev(names(architecture_colors)))
  )

p_architecture_summary <- ggplot(
  architecture_summary,
  aes(x = fraction, y = evolutionary_architecture, fill = evolutionary_architecture)
) +
  geom_col(width = 0.7) +
  geom_text(
    aes(label = paste0(fmt_pct(fraction, 1), " (n=", fmt_int(n_mags), ")")),
    hjust = -0.06,
    size = 2.1
  ) +
  scale_fill_manual(values = architecture_colors, drop = FALSE) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.18))) +
  labs(
    x = "Fraction of Asgard actin-positive MAGs",
    y = NULL,
    fill = "Architecture class",
    title = "Evolutionary classes of Asgard raw copy-combo architectures",
    subtitle = "Combinations are grouped by canonical Actin, Crenactin/archaeal actin and MreB-family membership"
  ) +
  theme_nature() +
  theme(legend.position = "none", axis.text.y = element_text(size = 6.0))

save_figure(
  p_architecture_summary,
  file.path(figure_dir, "figure_4_Asgard_raw_copy_combo_evolutionary_architecture_summary"),
  width_mm = 145,
  height_mm = 80
)
write_tsv_base(
  architecture_summary,
  file.path(data_dir, "figure_4_Asgard_raw_copy_combo_evolutionary_architecture_summary_source_data.tsv")
)

# -----------------------------
# 8. Figure 5: Top combos + Other 100% stacked bar
# -----------------------------

top_overview_n <- min(as.integer(TOP_N_COMBOS_STACKED), nrow(combo_df))
top_names <- combo_df %>% head(top_overview_n) %>% pull(copy_combo)

combo_lumped <- combo_df %>%
  mutate(
    combo_plot = if_else(copy_combo %in% top_names, combo_label, "Other combos"),
    combo_group = if_else(copy_combo %in% top_names, "Top combos", "Other combos")
  ) %>%
  group_by(combo_plot, combo_group) %>%
  summarise(
    n_mags = sum(n_mags),
    fraction = sum(fraction_from_counts),
    .groups = "drop"
  ) %>%
  arrange(desc(combo_group == "Top combos"), desc(fraction))

combo_lumped <- combo_lumped %>%
  mutate(combo_plot = factor(combo_plot, levels = c(combo_plot[combo_plot != "Other combos"], "Other combos")))

p_100pct <- ggplot(combo_lumped, aes(x = "Asgard", y = fraction, fill = combo_plot)) +
  geom_col(width = 0.45, colour = "white", linewidth = 0.18) +
  scale_y_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.01))) +
  labs(
    x = NULL,
    y = "Fraction of Asgard actin-positive MAGs",
    fill = "copy_combo",
    title = "Overall Asgard raw copy-combo composition",
    subtitle = paste0("Top ", top_overview_n, " combos are shown separately; the remaining combos are grouped"),
    caption = paste0("Total Asgard actin-positive MAGs represented: n=", fmt_int(total_mags), ".")
  ) +
  theme_nature() +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 5.4),
    axis.text.x = element_text(size = 6.5)
  )

save_figure(
  p_100pct,
  file.path(figure_dir, "figure_5_Asgard_raw_copy_combo_100pct_stacked_bar"),
  width_mm = 140,
  height_mm = 95
)
write_tsv_base(
  combo_lumped,
  file.path(data_dir, "figure_5_Asgard_raw_copy_combo_100pct_stacked_bar_source_data.tsv")
)

# -----------------------------
# 9. Figure 6: Long-tail combo count distribution
# -----------------------------

count_distribution <- combo_df %>%
  count(n_mags, name = "n_combos") %>%
  arrange(n_mags) %>%
  mutate(
    combo_count_group = case_when(
      n_mags == 1 ~ "1 MAG",
      n_mags == 2 ~ "2 MAGs",
      n_mags == 3 ~ "3 MAGs",
      n_mags >= 4 & n_mags <= 5 ~ "4-5 MAGs",
      n_mags >= 6 & n_mags <= 10 ~ "6-10 MAGs",
      n_mags > 10 ~ ">10 MAGs",
      TRUE ~ "Unknown"
    )
  ) %>%
  group_by(combo_count_group) %>%
  summarise(n_combos = sum(n_combos), .groups = "drop") %>%
  mutate(
    combo_count_group = factor(combo_count_group, levels = c("1 MAG", "2 MAGs", "3 MAGs", "4-5 MAGs", "6-10 MAGs", ">10 MAGs", "Unknown"))
  ) %>%
  filter(!is.na(combo_count_group))

p_long_tail <- ggplot(count_distribution, aes(x = combo_count_group, y = n_combos)) +
  geom_col(width = 0.72, fill = "#6A6A6A") +
  geom_text(aes(label = fmt_int(n_combos)), vjust = -0.28, size = 2.1) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.16))) +
  labs(
    x = "Number of MAGs per copy_combo",
    y = "Number of copy_combo patterns",
    title = "Long-tail distribution of Asgard raw copy-combo patterns",
    subtitle = "Rare combinations may be useful for supplementary inspection rather than main figures"
  ) +
  theme_nature() +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))

save_figure(
  p_long_tail,
  file.path(figure_dir, "figure_6_Asgard_raw_copy_combo_long_tail_distribution"),
  width_mm = 105,
  height_mm = 75
)
write_tsv_base(
  count_distribution,
  file.path(data_dir, "figure_6_Asgard_raw_copy_combo_long_tail_distribution_source_data.tsv")
)

# -----------------------------
# 10. Figure 7: overview panel
# -----------------------------

# NOTE:
# Do not nest the combination-matrix patchwork object in the overview.
# Some patchwork/ggplot2 versions can accidentally propagate a continuous y-scale
# from the frequency bar to the discrete family-membership matrix, causing:
#   Error in scale_y_continuous(): Discrete values supplied to continuous scale.
# The full combination matrix is already saved as Figure 2.
# Here we use the architecture bar + cumulative curve + architecture summary
# for a stable compact overview.

p_architecture_bar_compact <- p_architecture_bar +
  labs(title = NULL, subtitle = NULL, caption = NULL) +
  theme(
    legend.position = "none",
    axis.text.y = element_text(size = 4.8),
    strip.text.y = element_text(size = 5.5, angle = 0, hjust = 0),
    plot.margin = margin(2, 5, 2, 5)
  )

p_cumulative_compact <- p_cumulative +
  theme(
    plot.title = element_text(size = 7.5),
    plot.subtitle = element_blank(),
    plot.margin = margin(2, 5, 2, 5)
  )

p_architecture_summary_compact <- p_architecture_summary +
  theme(
    plot.title = element_text(size = 7.5),
    plot.subtitle = element_blank(),
    axis.text.y = element_text(size = 5.2),
    plot.margin = margin(2, 5, 2, 5)
  )

overview <- (p_architecture_bar_compact | (p_cumulative_compact / p_architecture_summary_compact)) +
  plot_layout(widths = c(1.35, 1.00)) +
  plot_annotation(
    tag_levels = "a",
    title = "Asgard raw copy-combo genetic architecture summary",
    caption = "Only Asgardarchaeota actin-positive MAGs are included. copy_combo is based on raw-family presence/absence, not exact copy counts. The full combination matrix is provided as Figure 2."
  )

save_figure(
  overview,
  file.path(figure_dir, "figure_7_Asgard_raw_copy_combo_architecture_overview"),
  width_mm = 190,
  height_mm = 145
)

# -----------------------------
# Done
# -----------------------------

message("Completed Asgard raw copy-combo architecture plotting.")
message("Input: ", normalizePath(input_file, winslash = "/"))
message("Figures: ", normalizePath(figure_dir, winslash = "/"))
message("Source data: ", normalizePath(data_dir, winslash = "/"))
