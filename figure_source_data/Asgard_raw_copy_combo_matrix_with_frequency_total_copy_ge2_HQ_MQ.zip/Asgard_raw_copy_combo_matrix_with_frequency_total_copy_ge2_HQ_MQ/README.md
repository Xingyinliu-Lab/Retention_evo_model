# 2_Asgard_raw_copy_combo_matrix_with_frequency_total_copy_ge2_HQ_MQ

- Manuscript panel: Supp.Fig.10D
- Source figure basename: figure_2_Asgard_raw_copy_combo_matrix_with_frequency_total_copy_ge2_HQ_MQ
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
