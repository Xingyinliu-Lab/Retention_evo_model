#!/usr/bin/env Rscript

# Adds two tip-aligned annotation rings to the frozen Figure 1 GTDB MAG tree.
# It does not alter the species-tree topology, tip order, family-state rules,
# or copy-number binning used by analyze_actin_origin_species_tree.R.

suppressPackageStartupMessages({
  library(ape)
  library(ggplot2)
  library(ggtree)
  library(ggnewscale)
  library(dplyr)
  library(readr)
})

out_dir <- "actin_origin_species_tree"
data_dir <- file.path(out_dir, "plot_source_data")
fig_dir <- file.path(out_dir, "figures")
tree_file <- file.path(data_dir, "gtdb_ar53_user_mag_species_tree.treefile")
meta_file <- file.path(data_dir, "gtdb_ar53_user_mag_species_tree_tip_metadata.tsv")
stem <- "figure_1_gtdb_species_tree_actin_family_state_with_phylum_copy_number_outer_rings"

family_palette <- c(
  "No actin-like" = "#D4D4D4",
  "canonical Actin-like" = "#4C78A8",
  "Crenactin-like" = "#4F9B8F",
  "MreB-like / FtsA-like" = "#C77DA8",
  "Volactin" = "#E18D4F",
  "Salactin" = "#D6A64A",
  "Mixed actin-family" = "#222222"
)
family_legend_labels <- c(
  "No actin-like" = "No actin-like",
  "canonical Actin-like" = "canonical actin-like proteins (cALPs)",
  "Crenactin-like" = "divergent actin-like proteins (dALPs)",
  "MreB-like / FtsA-like" = "MreB-like / FtsA-like",
  "Volactin" = "Volactin",
  "Salactin" = "Salactin",
  "Mixed actin-family" = "Mixed actin-family"
)
copy_palette <- c("0" = "#D4D4D4", "1" = "#9ECAE1", "2" = "#6BAED6", "3-5" = "#3182BD", ">5" = "#08519C")
phylum_palette_base <- c(
  "#4C78A8", "#4F9B8F", "#E28E2C", "#7B61A8", "#C75C64",
  "#8C8C3E", "#5A7D9A", "#D6A64A", "#9C6B4E", "#8E6A9E",
  "#5C8F45", "#6B6B6B", "#C77DA8", "#4CB7C5", "#B8A72A",
  "#476A8A", "#D95852", "#9E4A4A", "#4E94C4", "#9B776E"
)

dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
mag_tree <- read.tree(tree_file)
tree_meta <- read_tsv(meta_file, show_col_types = FALSE, progress = FALSE)
stopifnot(setequal(mag_tree$tip.label, tree_meta$user_genome))

phylum_order <- tree_meta %>%
  count(p, sort = TRUE) %>%
  filter(!is.na(p), p != "") %>%
  pull(p)
phylum_palette <- setNames(rep(phylum_palette_base, length.out = length(phylum_order)), phylum_order)

display_tree <- mag_tree
display_tree$edge.length <- sqrt(pmax(display_tree$edge.length, 0))
p <- ggtree(display_tree, layout = "circular")
for (i in seq_along(p$layers)) {
  p$layers[[i]]$aes_params$linewidth <- 0.06
  p$layers[[i]]$aes_params$colour <- "#A0A0A0"
}

tip_data <- p$data %>%
  filter(isTip) %>%
  transmute(label, x, y) %>%
  left_join(
    tree_meta %>% select(user_genome, p, copy_state, dominant_actin_family_state),
    by = c("label" = "user_genome")
  )
stopifnot(nrow(tip_data) == length(mag_tree$tip.label), !anyNA(tip_data$p), !anyNA(tip_data$copy_state))

tree_radius <- max(tip_data$x)
ring_gap <- tree_radius * 0.012
ring_width <- tree_radius * 0.026
tip_data <- tip_data %>%
  mutate(
    phylum_ring_x = tree_radius + ring_gap + ring_width / 2,
    copy_ring_x = tree_radius + 2 * ring_gap + 3 * ring_width / 2
  )

p <- p +
  geom_point2(
    aes(subset = isTip, colour = label),
    data = p$data %>%
      filter(isTip) %>%
      mutate(label = tree_meta$dominant_actin_family_state[match(label, tree_meta$user_genome)]),
    shape = 16, size = 0.32, alpha = 0.82
  ) +
  scale_colour_manual(
    values = family_palette,
    breaks = names(family_palette),
    labels = family_legend_labels[names(family_palette)],
    drop = FALSE,
    name = "Actin family state"
  ) +
  guides(colour = guide_legend(override.aes = list(size = 2.4, alpha = 1))) +
  geom_tile(
    data = tip_data,
    aes(x = phylum_ring_x, y = y, fill = p),
    inherit.aes = FALSE,
    width = ring_width,
    height = 1.02,
    linewidth = 0
  ) +
  scale_fill_manual(
    values = phylum_palette,
    breaks = phylum_order,
    drop = FALSE,
    name = "Phylum (outer ring 1)"
  ) +
  guides(fill = guide_legend(ncol = 2, byrow = TRUE, override.aes = list(colour = NA))) +
  ggnewscale::new_scale_fill() +
  geom_tile(
    data = tip_data,
    aes(x = copy_ring_x, y = y, fill = copy_state),
    inherit.aes = FALSE,
    width = ring_width,
    height = 1.02,
    linewidth = 0
  ) +
  scale_fill_manual(
    values = copy_palette,
    breaks = names(copy_palette),
    drop = FALSE,
    name = "Total actin copy number (outer ring 2)"
  ) +
  guides(fill = guide_legend(override.aes = list(colour = NA))) +
  labs(
    title = "Archaeal MAG species tree annotated with actin state, phylum and copy number",
    subtitle = "Each tip is one GTDB-classified archaeal MAG. Inner points show dominant actin-family state; outer rings show phylum then total detected actin-like copy-number bin.",
    caption = paste(
      "GTDB-Tk species tree expanded by attaching ANI-screen MAGs to their closest GTDB reference; branch lengths are square-root transformed for display.",
      "The two outer rings are tip-aligned annotations, not additional phylogenetic distances.",
      sep = "\n"
    )
  ) +
  theme_void(base_size = 7, base_family = "Arial") +
  theme(
    plot.title = element_text(size = 8, face = "bold"),
    plot.subtitle = element_text(size = 6.3, colour = "#4A4A4A"),
    plot.caption = element_text(size = 5.5, colour = "#555555", hjust = 0),
    legend.position = "right",
    legend.box = "vertical",
    legend.title = element_text(size = 6.1, face = "bold"),
    legend.text = element_text(size = 5.2),
    legend.key.height = grid::unit(2.6, "mm"),
    legend.spacing.y = grid::unit(0.5, "mm"),
    plot.margin = margin(4, 8, 4, 4)
  )

ggsave(file.path(fig_dir, paste0(stem, ".pdf")), p, width = 183, height = 145, units = "mm", device = cairo_pdf)
ggsave(file.path(fig_dir, paste0(stem, "_preview.png")), p, width = 183, height = 145, units = "mm", dpi = 450, bg = "white")

write_tsv(
  tip_data %>% select(label, p, copy_state, dominant_actin_family_state),
  file.path(data_dir, paste0(stem, "_tip_ring_metadata.tsv"))
)
writeLines(
  c(
    "status=complete",
    paste0("tree_tips=", length(mag_tree$tip.label)),
    paste0("phylum_levels=", length(phylum_order)),
    paste0("copy_number_bins=", paste(names(copy_palette), collapse = ",")),
    "outer_ring_1=phylum",
    "outer_ring_2=total_actin_copy_number"
  ),
  file.path(fig_dir, paste0(stem, ".marker"))
)
