# 1_gtdb_species_tree_actin_family_state_with_phylum_copy_number_outer_rings

- Manuscript panel: Fig.4B
- Source figure basename: figure_1_gtdb_species_tree_actin_family_state_with_phylum_copy_number_outer_rings
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 21 directly referenced or locally packaged source-data file(s)
