#!/usr/bin/env Rscript

# ============================================================
# HQ-only MAG-level raw-family copy-number visualization
# Input: mag_copy_number_by_unmerged_raw_family.tsv
# One row = one HQ actin-positive MAG
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(stringr)
  library(scales)
  library(patchwork)
})

# -----------------------------
# 0. Arguments and parameters
# -----------------------------
args <- commandArgs(trailingOnly = TRUE)

if (length(args) >= 1 && !is.na(args[1]) && nzchar(args[1])) {
  input_file <- normalizePath(args[1], winslash = "/", mustWork = TRUE)
} else if (file.exists("mag_copy_number_by_unmerged_raw_family.tsv")) {
  input_file <- normalizePath("mag_copy_number_by_unmerged_raw_family.tsv", winslash = "/", mustWork = TRUE)
} else {
  stop("Input file is required. Usage: Rscript plot_mag_copy_number_by_unmerged_raw_family_HQ_only.R mag_copy_number_by_unmerged_raw_family.tsv [output_dir]")
}

output_dir <- ifelse(length(args) >= 2 && nzchar(args[2]), args[2], "mag_copy_number_HQ_only_plot")
figure_dir <- file.path(output_dir, "figures")
source_dir <- file.path(output_dir, "plot_source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

TOP_N_PHYLA <- 18L
TOP_N_HIGHCOPY_MAG <- 90L
TOP_N_GROUP_COMBO <- 25L
TOP_N_COMBO_HEATMAP <- 30L
MIN_RARE_GROUP_COMBO_FRACTION <- 0.01

selected_five_order <- c(
  "Asgardarchaeota",
  "Thermoproteota",
  "Halobacteriota",
  "Methanobacteriota",
  "Thermoplasmatota"
)

raw_family_cols_all <- c(
  "canonical_Actin_like",
  "Crenactin_like_archaeal_actin",
  "MreB_Mbl_like",
  "MreB_like_C_ALP_N_related",
  "FtsA_PilM_like",
  "Salactin",
  "Volactin",
  "Other"
)

raw_family_labels <- c(
  canonical_Actin_like = "cALP",
  Crenactin_like_archaeal_actin = "dALP",
  MreB_Mbl_like = "MreB/Mbl-like",
  MreB_like_C_ALP_N_related = "MreB-like C/ALP-N-related",
  FtsA_PilM_like = "FtsA/PilM-like",
  Salactin = "Salactin",
  Volactin = "Volactin",
  Other = "Other"
)

raw_family_colors <- c(
  canonical_Actin_like = "#E64B35",
  Crenactin_like_archaeal_actin = "#4DBBD5",
  MreB_Mbl_like = "#00A087",
  MreB_like_C_ALP_N_related = "#3C5488",
  FtsA_PilM_like = "#F39B7F",
  Salactin = "#8491B4",
  Volactin = "#91D1C2",
  Other = "#B09C85"
)

copy_group_colors <- c(
  "1 copy" = "#D9D9D9",
  "2 copies" = "#A6CEE3",
  "3 copies" = "#1F78B4",
  "4 copies" = "#B2DF8A",
  ">=5 copies" = "#33A02C"
)

# -----------------------------
# 1. Helper functions
# -----------------------------
`%||%` <- function(x, y) if (is.null(x)) y else x

fmt_pct <- function(x, accuracy = 0.1) {
  scales::percent(x, accuracy = accuracy)
}

shorten_combo <- function(x) {
  x %>%
    str_replace_all("canonical_Actin_like", "Can") %>%
    str_replace_all("Crenactin_like_archaeal_actin", "Cre") %>%
    str_replace_all("MreB_Mbl_like", "MreB") %>%
    str_replace_all("MreB_like_C_ALP_N_related", "MreB-C") %>%
    str_replace_all("FtsA_PilM_like", "FtsA") %>%
    str_replace_all("Salactin", "Sal") %>%
    str_replace_all("Volactin", "Vol") %>%
    str_replace_all("Other", "Other") %>%
    str_replace_all(" \\+ ", "+")
}

copy_group <- function(x) {
  dplyr::case_when(
    x <= 1 ~ "1 copy",
    x == 2 ~ "2 copies",
    x == 3 ~ "3 copies",
    x == 4 ~ "4 copies",
    TRUE ~ ">=5 copies"
  )
}

prepare_family_vector <- function(row_vec, family_cols) {
  # c_across() can return an unnamed vector in some dplyr/R versions.
  # This helper restores names and fills absent raw-family columns with zero,
  # so downstream classification functions are safe even when an all-zero family
  # such as Other or canonical_Actin_like has been dropped from used_family_cols.
  row_vec <- as.numeric(row_vec)
  if (length(row_vec) == length(family_cols)) {
    names(row_vec) <- family_cols
  }
  full_vec <- rep(0, length(raw_family_cols_all))
  names(full_vec) <- raw_family_cols_all
  common <- intersect(names(row_vec), raw_family_cols_all)
  if (length(common) > 0) {
    full_vec[common] <- row_vec[common]
  }
  full_vec[is.na(full_vec)] <- 0
  full_vec
}

architecture_complexity_from_row <- function(row_vec, family_cols = used_family_cols) {
  row_vec <- prepare_family_vector(row_vec, family_cols)
  n_family <- sum(row_vec > 0, na.rm = TRUE)
  if (n_family <= 1) return("Single-family architecture")
  if (n_family == 2) return("Two-family architecture")
  return("Multi-family architecture")
}

classify_evolutionary_architecture <- function(row_vec, family_cols = used_family_cols) {
  row_vec <- prepare_family_vector(row_vec, family_cols)
  has <- function(col) {
    col %in% names(row_vec) && !is.na(row_vec[[col]]) && row_vec[[col]] > 0
  }

  has_can <- has("canonical_Actin_like")
  has_cre <- has("Crenactin_like_archaeal_actin")
  has_mreb <- has("MreB_Mbl_like") || has("MreB_like_C_ALP_N_related")
  has_accessory <- has("FtsA_PilM_like") || has("Salactin") || has("Volactin") || has("Other")

  if (has_can && has_mreb) return("Canonical Actin + MreB mixed")
  if (has_can) return("Canonical Actin-containing")
  if (has_cre && has_mreb) return("Crenactin/archaeal actin + MreB mixed")
  if (has_cre && !has_mreb && !has_accessory) return("Crenactin/archaeal actin-only")
  if (has_mreb && !has_cre && !has_accessory) return("MreB-only")
  return("Accessory/other architecture")
}

make_mag_label <- function(mag_id, p, total_copy, max_chars = 48) {
  x <- paste0(mag_id, " | ", p, " | copy=", total_copy)
  ifelse(nchar(x) > max_chars, paste0(substr(x, 1, max_chars - 3), "..."), x)
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size) %+replace%
    theme(
      axis.line = element_line(linewidth = 0.25, colour = "black"),
      axis.ticks = element_line(linewidth = 0.25, colour = "black"),
      axis.ticks.length = unit(1.5, "mm"),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      strip.background = element_blank(),
      strip.text = element_text(face = "bold", size = base_size),
      legend.key.size = unit(3.0, "mm"),
      legend.title = element_text(size = base_size),
      legend.text = element_text(size = base_size - 0.5),
      plot.title = element_text(face = "bold", size = base_size + 1, hjust = 0),
      plot.subtitle = element_text(size = base_size, hjust = 0),
      plot.caption = element_text(size = base_size - 1, hjust = 0),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure <- function(plot, filename_no_ext, width_mm, height_mm) {
  ggsave(
    paste0(filename_no_ext, ".pdf"),
    plot = plot,
    width = width_mm,
    height = height_mm,
    units = "mm",
    device = cairo_pdf,
    bg = "white"
  )
  ggsave(
    paste0(filename_no_ext, "_preview.png"),
    plot = plot,
    width = width_mm,
    height = height_mm,
    units = "mm",
    dpi = 300,
    bg = "white"
  )
}

# -----------------------------
# 2. Read and validate data
# -----------------------------
mag_df <- readr::read_tsv(input_file, show_col_types = FALSE)

required_columns <- c("mag_id", "p", "quality_checkm2", "total_copy", "group_combo")
missing_columns <- setdiff(required_columns, names(mag_df))
if (length(missing_columns) > 0) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}

raw_family_cols <- intersect(raw_family_cols_all, names(mag_df))
if (length(raw_family_cols) == 0) {
  stop("No expected raw family copy columns were found.")
}

for (col in raw_family_cols) {
  mag_df[[col]] <- suppressWarnings(as.integer(mag_df[[col]]))
  mag_df[[col]][is.na(mag_df[[col]])] <- 0L
}

mag_df <- mag_df %>%
  mutate(
    mag_id = as.character(.data[["mag_id"]]),
    p = if_else(is.na(.data[["p"]]) | .data[["p"]] == "", "Unclassified phylum", as.character(.data[["p"]])),
    quality_checkm2 = as.character(.data[["quality_checkm2"]]),
    total_copy = as.integer(.data[["total_copy"]]),
    group_combo = if_else(is.na(.data[["group_combo"]]) | .data[["group_combo"]] == "", "None", as.character(.data[["group_combo"]]))
  )

# HQ-only sanity check. Keep all rows but warn if non-HQ exists.
non_hq_n <- sum(toupper(trimws(mag_df$quality_checkm2)) != "HQ", na.rm = TRUE)
if (non_hq_n > 0) {
  warning("Input contains ", non_hq_n, " non-HQ rows. This script is designed for HQ-only outputs; figures will still use all rows in the input file.")
}

# Recompute total_copy to verify consistency with raw-family columns.
mag_df <- mag_df %>%
  mutate(
    total_copy_from_raw_family = rowSums(across(all_of(raw_family_cols))),
    total_copy_diff = total_copy - total_copy_from_raw_family
  )

consistency_check <- mag_df %>%
  select(mag_id, total_copy, total_copy_from_raw_family, total_copy_diff)
readr::write_tsv(consistency_check, file.path(source_dir, "input_total_copy_recalculation_check.tsv"))

if (any(consistency_check$total_copy_diff != 0, na.rm = TRUE)) {
  warning("Some rows have total_copy != sum(raw family columns). See plot_source_data/input_total_copy_recalculation_check.tsv")
}

# Drop all-zero Other or any all-zero family columns.
used_family_cols <- raw_family_cols[colSums(mag_df[, raw_family_cols, drop = FALSE]) > 0]
if (length(used_family_cols) == 0) {
  stop("All raw family columns are zero.")
}
used_family_cols <- raw_family_cols_all[raw_family_cols_all %in% used_family_cols]
used_family_labels <- raw_family_labels[used_family_cols]
used_family_colors <- raw_family_colors[used_family_cols]

mag_df <- mag_df %>%
  rowwise() %>%
  mutate(
    copy_number_group = copy_group(total_copy),
    architecture_complexity = architecture_complexity_from_row(c_across(all_of(used_family_cols)), used_family_cols),
    evolutionary_architecture = classify_evolutionary_architecture(c_across(all_of(used_family_cols)), used_family_cols),
    mag_label = make_mag_label(mag_id, p, total_copy)
  ) %>%
  ungroup() %>%
  mutate(
    copy_number_group = factor(copy_number_group, levels = c("1 copy", "2 copies", "3 copies", "4 copies", ">=5 copies")),
    architecture_complexity = factor(architecture_complexity, levels = c("Single-family architecture", "Two-family architecture", "Multi-family architecture")),
    evolutionary_architecture = factor(evolutionary_architecture, levels = c(
      "Canonical Actin + MreB mixed",
      "Canonical Actin-containing",
      "Crenactin/archaeal actin + MreB mixed",
      "Crenactin/archaeal actin-only",
      "MreB-only",
      "Accessory/other architecture"
    ))
  )

readr::write_tsv(mag_df, file.path(source_dir, "mag_copy_number_by_unmerged_raw_family_HQ_input_checked.tsv"))

# Phylum order: selected five first if present, then remaining by MAG count.
phylum_counts <- mag_df %>%
  count(p, name = "n_mags") %>%
  arrange(desc(n_mags), p)

remaining_order <- setdiff(phylum_counts$p, selected_five_order)
phylum_order <- c(selected_five_order[selected_five_order %in% phylum_counts$p], remaining_order)

# Top phyla for dense plots.
top_phyla <- phylum_counts$p[seq_len(min(TOP_N_PHYLA, nrow(phylum_counts)))]
top_phyla <- unique(c(selected_five_order[selected_five_order %in% phylum_counts$p], top_phyla))

top_phylum_data <- mag_df %>%
  mutate(p_plot = if_else(p %in% top_phyla, p, "Other phyla"))

p_plot_order <- c(phylum_order[phylum_order %in% top_phyla], "Other phyla")
p_plot_order <- unique(p_plot_order[p_plot_order %in% top_phylum_data$p_plot])

# -----------------------------
# 3. Figure 1: overall total copy distribution
# -----------------------------
fig1_data <- mag_df %>%
  count(copy_number_group, name = "n_mags") %>%
  mutate(
    fraction = n_mags / sum(n_mags),
    label = paste0(n_mags, "\n", fmt_pct(fraction, 0.1))
  )
readr::write_tsv(fig1_data, file.path(source_dir, "figure_1_HQ_overall_total_copy_distribution_source_data.tsv"))

p_fig1 <- ggplot(fig1_data, aes(x = copy_number_group, y = n_mags, fill = copy_number_group)) +
  geom_col(width = 0.72, colour = "black", linewidth = 0.2) +
  geom_text(aes(label = label), vjust = -0.25, size = 2.2) +
  scale_fill_manual(values = copy_group_colors, drop = FALSE, guide = "none") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(
    x = "Total copy number per HQ MAG",
    y = "Number of HQ actin-positive MAGs",
    title = "HQ-only total copy-number distribution",
    subtitle = "One row represents one HQ actin-positive MAG"
  ) +
  theme_nature()

save_figure(p_fig1, file.path(figure_dir, "figure_1_HQ_overall_total_copy_distribution"), 95, 72)

# -----------------------------
# 4. Figure 2: phylum-level total copy distribution
# -----------------------------
fig2_data <- top_phylum_data %>%
  count(p_plot, copy_number_group, name = "n_mags") %>%
  group_by(p_plot) %>%
  mutate(
    fraction = n_mags / sum(n_mags),
    n_total = sum(n_mags),
    p_label = paste0(p_plot, " (n=", n_total, ")")
  ) %>%
  ungroup()

fig2_data$p_label <- factor(
  fig2_data$p_label,
  levels = rev(unique(fig2_data$p_label[match(p_plot_order, fig2_data$p_plot)]))
)
readr::write_tsv(fig2_data, file.path(source_dir, "figure_2_HQ_phylum_total_copy_distribution_source_data.tsv"))

p_fig2 <- ggplot(fig2_data, aes(x = fraction, y = p_label, fill = copy_number_group)) +
  geom_col(width = 0.78, colour = "white", linewidth = 0.15) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = c(0, 0)) +
  scale_fill_manual(values = copy_group_colors, drop = FALSE, name = "Copy group") +
  labs(
    x = "HQ actin-positive MAGs (%)",
    y = NULL,
    title = "HQ-only copy-number distribution by phylum",
    subtitle = "Top phyla are shown; low-count phyla are grouped as Other phyla"
  ) +
  theme_nature() +
  theme(legend.position = "right")

save_figure(p_fig2, file.path(figure_dir, "figure_2_HQ_phylum_total_copy_distribution"), 155, max(78, 5.8 * length(unique(fig2_data$p_label)) + 28))

# -----------------------------
# 5. Figure 3: raw-family copy fraction by phylum
# -----------------------------
long_copy <- mag_df %>%
  select(mag_id, p, total_copy, all_of(used_family_cols)) %>%
  pivot_longer(cols = all_of(used_family_cols), names_to = "raw_family", values_to = "n_copy") %>%
  filter(n_copy > 0) %>%
  mutate(raw_family = factor(raw_family, levels = used_family_cols))

fig3_data <- long_copy %>%
  mutate(p_plot = if_else(p %in% top_phyla, p, "Other phyla")) %>%
  group_by(p_plot, raw_family) %>%
  summarise(total_raw_copy = sum(n_copy), .groups = "drop") %>%
  group_by(p_plot) %>%
  mutate(
    total_copy_in_phylum = sum(total_raw_copy),
    copy_fraction = total_raw_copy / total_copy_in_phylum
  ) %>%
  ungroup()

fig3_totals <- top_phylum_data %>%
  group_by(p_plot) %>%
  summarise(n_mags = n_distinct(mag_id), n_seq = sum(total_copy), .groups = "drop")
fig3_data <- fig3_data %>%
  left_join(fig3_totals, by = "p_plot") %>%
  mutate(p_label = paste0(p_plot, " (MAG=", n_mags, "; copy=", n_seq, ")"))
fig3_data$p_label <- factor(fig3_data$p_label, levels = rev(unique(fig3_data$p_label[match(p_plot_order, fig3_data$p_plot)])))
readr::write_tsv(fig3_data, file.path(source_dir, "figure_3_HQ_raw_family_copy_fraction_by_phylum_source_data.tsv"))

p_fig3 <- ggplot(fig3_data, aes(x = copy_fraction, y = p_label, fill = raw_family)) +
  geom_col(width = 0.78, colour = "white", linewidth = 0.15) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = c(0, 0)) +
  scale_fill_manual(values = used_family_colors, labels = used_family_labels, name = "Raw family") +
  labs(
    x = "Raw-family copy fraction",
    y = NULL,
    title = "HQ-only raw-family copy composition by phylum",
    subtitle = "Fractions are calculated from raw-family copy counts, not MAG presence"
  ) +
  theme_nature() +
  theme(legend.position = "right")

save_figure(p_fig3, file.path(figure_dir, "figure_3_HQ_raw_family_copy_fraction_by_phylum"), 165, max(82, 6.2 * length(unique(fig3_data$p_label)) + 28))

# -----------------------------
# 6. Figure 4: raw-family MAG presence vs copy contribution
# -----------------------------
fig4_presence <- mag_df %>%
  summarise(across(all_of(used_family_cols), ~ sum(.x > 0), .names = "{.col}")) %>%
  pivot_longer(cols = everything(), names_to = "raw_family", values_to = "n_mags_present")
fig4_copy <- mag_df %>%
  summarise(across(all_of(used_family_cols), ~ sum(.x), .names = "{.col}")) %>%
  pivot_longer(cols = everything(), names_to = "raw_family", values_to = "n_raw_copy")
fig4_data <- fig4_presence %>%
  left_join(fig4_copy, by = "raw_family") %>%
  mutate(
    mag_presence_fraction = n_mags_present / n_distinct(mag_df$mag_id),
    copy_fraction = n_raw_copy / sum(n_raw_copy),
    raw_family = factor(raw_family, levels = used_family_cols),
    raw_family_label = used_family_labels[as.character(raw_family)]
  )
readr::write_tsv(fig4_data, file.path(source_dir, "figure_4_HQ_raw_family_presence_vs_copy_contribution_source_data.tsv"))

fig4_long <- fig4_data %>%
  select(raw_family, raw_family_label, mag_presence_fraction, copy_fraction) %>%
  pivot_longer(cols = c(mag_presence_fraction, copy_fraction), names_to = "metric", values_to = "fraction") %>%
  mutate(metric = recode(metric, mag_presence_fraction = "MAG presence fraction", copy_fraction = "Copy fraction"))

p_fig4 <- ggplot(fig4_long, aes(x = fraction, y = raw_family, fill = metric)) +
  geom_col(position = position_dodge(width = 0.72), width = 0.62, colour = "black", linewidth = 0.15) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.08))) +
  scale_y_discrete(labels = used_family_labels) +
  scale_fill_manual(values = c("MAG presence fraction" = "#7F7F7F", "Copy fraction" = "#3182BD"), name = NULL) +
  labs(
    x = "Fraction",
    y = NULL,
    title = "HQ-only raw-family presence and copy contribution",
    subtitle = "Presence counts MAGs with at least one copy; copy fraction counts all raw-family copies"
  ) +
  theme_nature() +
  theme(legend.position = "top")

save_figure(p_fig4, file.path(figure_dir, "figure_4_HQ_raw_family_presence_vs_copy_contribution"), 135, 78)

# -----------------------------
# 7. Figure 5: high-copy MAG-level stacked bar
# -----------------------------
highcopy_df <- mag_df %>%
  filter(total_copy >= 2) %>%
  arrange(desc(total_copy), p, mag_id)

if (nrow(highcopy_df) > 0) {
  highcopy_df <- highcopy_df[seq_len(min(TOP_N_HIGHCOPY_MAG, nrow(highcopy_df))), , drop = FALSE]
  highcopy_df <- highcopy_df %>%
    mutate(mag_label = make_mag_label(mag_id, p, total_copy, max_chars = 58))

  fig5_data <- highcopy_df %>%
    select(mag_id, mag_label, p, total_copy, group_combo, all_of(used_family_cols)) %>%
    pivot_longer(cols = all_of(used_family_cols), names_to = "raw_family", values_to = "n_copy") %>%
    filter(n_copy > 0) %>%
    mutate(
      raw_family = factor(raw_family, levels = used_family_cols),
      mag_label = factor(mag_label, levels = rev(unique(highcopy_df$mag_label)))
    )
  readr::write_tsv(fig5_data, file.path(source_dir, "figure_5_HQ_highcopy_MAG_raw_family_stacked_bar_source_data.tsv"))

  p_fig5 <- ggplot(fig5_data, aes(x = n_copy, y = mag_label, fill = raw_family)) +
    geom_col(width = 0.76, colour = "white", linewidth = 0.12) +
    scale_fill_manual(values = used_family_colors, labels = used_family_labels, name = "Raw family") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +
    labs(
      x = "Copy count",
      y = NULL,
      title = "HQ-only high-copy MAG raw-family composition",
      subtitle = paste0("Top ", nrow(highcopy_df), " MAGs with total_copy >= 2 are shown")
    ) +
    theme_nature() +
    theme(axis.text.y = element_text(size = 4.8), legend.position = "right")

  save_figure(p_fig5, file.path(figure_dir, "figure_5_HQ_highcopy_MAG_raw_family_stacked_bar"), 185, max(105, 3.4 * nrow(highcopy_df) + 28))
}

# -----------------------------
# 8. Figure 6: top exact group_combo frequency
# -----------------------------
combo_total <- mag_df %>%
  count(group_combo, name = "n_mags") %>%
  arrange(desc(n_mags), group_combo) %>%
  mutate(
    fraction = n_mags / sum(n_mags),
    group_combo_short = shorten_combo(group_combo),
    rank = row_number(),
    combo_plot = if_else(rank <= TOP_N_GROUP_COMBO, group_combo_short, "Rare / lower-ranked combos")
  )

fig6_data <- mag_df %>%
  left_join(combo_total %>% select(group_combo, combo_plot, rank), by = "group_combo") %>%
  count(combo_plot, name = "n_mags") %>%
  mutate(
    fraction = n_mags / sum(n_mags),
    combo_plot = if_else(combo_plot == "Rare / lower-ranked combos", combo_plot, as.character(combo_plot))
  ) %>%
  arrange(desc(n_mags), combo_plot)

fig6_levels <- c(fig6_data$combo_plot[fig6_data$combo_plot != "Rare / lower-ranked combos"], "Rare / lower-ranked combos")
fig6_levels <- unique(fig6_levels[fig6_levels %in% fig6_data$combo_plot])
fig6_data$combo_plot <- factor(fig6_data$combo_plot, levels = rev(fig6_levels))
readr::write_tsv(combo_total, file.path(source_dir, "figure_6_HQ_exact_group_combo_full_ranked_source_data.tsv"))
readr::write_tsv(fig6_data, file.path(source_dir, "figure_6_HQ_top_exact_group_combo_frequency_source_data.tsv"))

p_fig6 <- ggplot(fig6_data, aes(x = fraction, y = combo_plot)) +
  geom_col(width = 0.72, fill = "#6BAED6", colour = "black", linewidth = 0.15) +
  geom_text(aes(label = paste0(n_mags, " | ", fmt_pct(fraction, 0.1))), hjust = -0.05, size = 2.0) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.22))) +
  labs(
    x = "Fraction of HQ actin-positive MAGs",
    y = NULL,
    title = "HQ-only exact raw-family group_combo frequency",
    subtitle = paste0("Top ", TOP_N_GROUP_COMBO, " group_combo types are shown; remaining types are grouped")
  ) +
  theme_nature() +
  theme(axis.text.y = element_text(size = 5.2))

save_figure(p_fig6, file.path(figure_dir, "figure_6_HQ_top_exact_group_combo_frequency"), 180, max(90, 4.2 * nrow(fig6_data) + 24))

# -----------------------------
# 9. Figure 7: architecture complexity and evolutionary architecture
# -----------------------------
fig7a_data <- mag_df %>%
  mutate(p_plot = if_else(p %in% top_phyla, p, "Other phyla")) %>%
  count(p_plot, architecture_complexity, name = "n_mags") %>%
  group_by(p_plot) %>%
  mutate(fraction = n_mags / sum(n_mags), n_total = sum(n_mags), p_label = paste0(p_plot, " (n=", n_total, ")")) %>%
  ungroup()
fig7a_data$p_label <- factor(fig7a_data$p_label, levels = rev(unique(fig7a_data$p_label[match(p_plot_order, fig7a_data$p_plot)])))
readr::write_tsv(fig7a_data, file.path(source_dir, "figure_7a_HQ_architecture_complexity_source_data.tsv"))

p_fig7a <- ggplot(fig7a_data, aes(x = fraction, y = p_label, fill = architecture_complexity)) +
  geom_col(width = 0.78, colour = "white", linewidth = 0.15) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = c(0, 0)) +
  scale_fill_manual(values = c("Single-family architecture" = "#9ECAE1", "Two-family architecture" = "#4292C6", "Multi-family architecture" = "#084594"), name = "Architecture") +
  labs(x = "HQ MAGs (%)", y = NULL, title = "Architecture complexity", subtitle = "Number of raw families present per MAG") +
  theme_nature() +
  theme(legend.position = "right")

fig7b_data <- mag_df %>%
  mutate(p_plot = if_else(p %in% top_phyla, p, "Other phyla")) %>%
  count(p_plot, evolutionary_architecture, name = "n_mags") %>%
  group_by(p_plot) %>%
  mutate(fraction = n_mags / sum(n_mags), n_total = sum(n_mags), p_label = paste0(p_plot, " (n=", n_total, ")")) %>%
  ungroup()
fig7b_data$p_label <- factor(fig7b_data$p_label, levels = rev(unique(fig7b_data$p_label[match(p_plot_order, fig7b_data$p_plot)])))
readr::write_tsv(fig7b_data, file.path(source_dir, "figure_7b_HQ_evolutionary_architecture_source_data.tsv"))

architecture_colors <- c(
  "Canonical Actin + MreB mixed" = "#D73027",
  "Canonical Actin-containing" = "#FC8D59",
  "Crenactin/archaeal actin + MreB mixed" = "#4575B4",
  "Crenactin/archaeal actin-only" = "#91BFDB",
  "MreB-only" = "#1A9850",
  "Accessory/other architecture" = "#BDBDBD"
)

p_fig7b <- ggplot(fig7b_data, aes(x = fraction, y = p_label, fill = evolutionary_architecture)) +
  geom_col(width = 0.78, colour = "white", linewidth = 0.15) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = c(0, 0)) +
  scale_fill_manual(values = architecture_colors, name = "Evolutionary\narchitecture", drop = FALSE) +
  labs(x = "HQ MAGs (%)", y = NULL, title = "Evolutionary architecture", subtitle = "Grouped by canonical/Crenactin/MreB/accessory composition") +
  theme_nature() +
  theme(legend.position = "right")

p_fig7 <- p_fig7a / p_fig7b + plot_layout(heights = c(1, 1)) +
  plot_annotation(
    title = "HQ-only MAG-level architecture summary",
    caption = "Architecture complexity is based on raw-family presence; evolutionary architecture summarizes canonical Actin-like, Crenactin-like, MreB-like, and accessory-family composition."
  )

save_figure(p_fig7, file.path(figure_dir, "figure_7_HQ_MAG_level_architecture_summary"), 190, max(145, 11.0 * length(unique(fig7a_data$p_label)) + 45))

# -----------------------------
# 10. Figure 8: high-copy outlier table and plot
# -----------------------------
outlier_threshold <- max(5, stats::quantile(mag_df$total_copy, probs = 0.99, na.rm = TRUE, names = FALSE))
outlier_threshold <- floor(outlier_threshold)
outlier_df <- mag_df %>%
  filter(total_copy >= outlier_threshold | total_copy >= 5) %>%
  arrange(desc(total_copy), p, mag_id) %>%
  select(mag_id, p, quality_checkm2, total_copy, group_combo, all_of(used_family_cols))

if (nrow(outlier_df) > 0) {
  outlier_df <- outlier_df[seq_len(min(60L, nrow(outlier_df))), , drop = FALSE]
  outlier_df <- outlier_df %>%
    mutate(mag_label = make_mag_label(mag_id, p, total_copy, max_chars = 52))
  readr::write_tsv(outlier_df, file.path(source_dir, "figure_8_HQ_highcopy_outlier_MAGs_source_data.tsv"))

  p_fig8 <- ggplot(outlier_df, aes(x = total_copy, y = reorder(mag_label, total_copy))) +
    geom_col(width = 0.68, fill = "#FB6A4A", colour = "black", linewidth = 0.15) +
    facet_grid(p ~ ., scales = "free_y", space = "free_y") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.08))) +
    labs(
      x = "total_copy",
      y = NULL,
      title = "HQ-only high-copy outlier MAGs",
      subtitle = paste0("Rows with total_copy >= ", outlier_threshold, " or total_copy >= 5 are listed; all rows are HQ in the intended input")
    ) +
    theme_nature() +
    theme(axis.text.y = element_text(size = 5.0), strip.text.y = element_text(angle = 0, hjust = 0))

  save_figure(p_fig8, file.path(figure_dir, "figure_8_HQ_highcopy_outlier_MAGs"), 155, max(70, 5.0 * nrow(outlier_df) + 25))
} else {
  readr::write_tsv(outlier_df, file.path(source_dir, "figure_8_HQ_highcopy_outlier_MAGs_source_data.tsv"))
}

# -----------------------------
# 11. Figure 9: overview
# -----------------------------
p_fig1_compact <- p_fig1 + labs(title = NULL, subtitle = NULL) + theme(legend.position = "none")
p_fig2_compact <- p_fig2 + labs(title = NULL, subtitle = NULL) + theme(legend.position = "bottom", axis.text.y = element_text(size = 5.3))
p_fig3_compact <- p_fig3 + labs(title = NULL, subtitle = NULL) + theme(legend.position = "bottom", axis.text.y = element_text(size = 5.3))
p_fig4_compact <- p_fig4 + labs(title = NULL, subtitle = NULL) + theme(legend.position = "bottom")

overview <- (p_fig1_compact | p_fig4_compact) / (p_fig2_compact | p_fig3_compact) +
  plot_layout(heights = c(0.85, 1.15), guides = "collect") +
  plot_annotation(
    tag_levels = "a",
    title = "HQ-only MAG-level raw-family copy-number overview",
    caption = "Only HQ actin-positive MAGs are included in the intended input. raw-family copy fractions count copy numbers, whereas presence fractions count MAG-level occurrence."
  )

save_figure(overview, file.path(figure_dir, "figure_9_HQ_MAG_level_copy_number_overview"), 200, 155)


# -----------------------------
# 12. Figure 10: raw-family expansion landscape
# -----------------------------
# This panel identifies which raw families are the major copy-number expansion drivers
# in HQ MAGs. Family order is determined by global mean copy number per MAG.

family_global <- mag_df %>%
  summarise(across(all_of(used_family_cols), list(
    total_copy = ~ sum(.x, na.rm = TRUE),
    mean_copy_per_MAG = ~ mean(.x, na.rm = TRUE),
    n_MAG_present = ~ sum(.x > 0, na.rm = TRUE),
    presence_fraction = ~ mean(.x > 0, na.rm = TRUE)
  ), .names = "{.col}__{.fn}")) %>%
  pivot_longer(cols = everything(), names_to = "metric_name", values_to = "value") %>%
  separate(metric_name, into = c("raw_family", "metric"), sep = "__") %>%
  pivot_wider(names_from = metric, values_from = value) %>%
  mutate(
    raw_family = factor(raw_family, levels = used_family_cols),
    raw_family_label = used_family_labels[as.character(raw_family)]
  ) %>%
  arrange(desc(mean_copy_per_MAG), raw_family_label) %>%
  mutate(
    global_rank = row_number(),
    raw_family_ranked = factor(raw_family, levels = as.character(raw_family))
  )

family_rank_order <- as.character(family_global$raw_family)
readr::write_tsv(family_global, file.path(source_dir, "figure_10_HQ_raw_family_global_expansion_landscape_source_data.tsv"))

family_phylum <- mag_df %>%
  mutate(p_plot = if_else(.data[["p"]] %in% top_phyla, .data[["p"]], "Other phyla")) %>%
  select(mag_id, p_plot, all_of(used_family_cols)) %>%
  pivot_longer(cols = all_of(used_family_cols), names_to = "raw_family", values_to = "n_copy") %>%
  group_by(p_plot, raw_family) %>%
  summarise(
    n_MAGs = n_distinct(mag_id),
    total_copy = sum(n_copy, na.rm = TRUE),
    mean_copy_per_MAG = mean(n_copy, na.rm = TRUE),
    n_MAG_present = sum(n_copy > 0, na.rm = TRUE),
    presence_fraction = mean(n_copy > 0, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    raw_family = factor(raw_family, levels = family_rank_order),
    raw_family_label = used_family_labels[as.character(raw_family)],
    p_plot = factor(p_plot, levels = rev(p_plot_order))
  )
readr::write_tsv(family_phylum, file.path(source_dir, "figure_10_HQ_raw_family_expansion_landscape_by_phylum_source_data.tsv"))

p_fig10a <- ggplot(family_global, aes(x = global_rank, y = mean_copy_per_MAG)) +
  geom_line(linewidth = 0.35, colour = "grey35") +
  geom_point(aes(size = presence_fraction), shape = 21, fill = "white", colour = "black", linewidth = 0.25) +
  geom_text(aes(label = shorten_combo(as.character(raw_family))), nudge_y = max(family_global$mean_copy_per_MAG, na.rm = TRUE) * 0.035, size = 2.0, check_overlap = TRUE) +
  scale_x_continuous(breaks = family_global$global_rank, expand = expansion(mult = c(0.04, 0.06))) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.18))) +
  scale_size_continuous(range = c(1.7, 4.2), labels = percent_format(accuracy = 1), name = "Presence") +
  labs(
    x = "Raw-family rank by global mean copy number",
    y = "Mean copy per HQ MAG",
    title = "Global raw-family expansion landscape",
    subtitle = "Raw families are ranked by mean copy number across all HQ actin-positive MAGs"
  ) +
  theme_nature() +
  theme(legend.position = "right")

p_fig10b <- ggplot(family_phylum, aes(x = raw_family, y = p_plot)) +
  geom_point(aes(size = mean_copy_per_MAG, fill = presence_fraction), shape = 21, colour = "black", linewidth = 0.15) +
  scale_x_discrete(labels = function(x) shorten_combo(x)) +
  scale_size_continuous(range = c(0.4, 5.2), name = "Mean copy\nper MAG") +
  scale_fill_gradient(low = "#F7FBFF", high = "#084594", labels = percent_format(accuracy = 1), name = "MAG presence") +
  labs(
    x = "Raw family, ordered by global expansion rank",
    y = NULL,
    title = "Phylum-level raw-family expansion landscape",
    subtitle = "Point size shows mean copy per HQ MAG; fill shows MAG-level presence"
  ) +
  theme_nature() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1), legend.position = "right")

p_fig10 <- p_fig10a / p_fig10b +
  plot_layout(heights = c(0.75, 1.25), guides = "collect") +
  plot_annotation(
    title = "HQ-only expansion landscape of raw actin-family repertoires",
    caption = "Mean copy number is calculated per HQ actin-positive MAG. A family with high mean copy and moderate presence may represent lineage-specific copy expansion."
  )

save_figure(p_fig10, file.path(figure_dir, "figure_10_HQ_raw_family_expansion_landscape"), 190, max(135, 5.5 * length(p_plot_order) + 75))

# -----------------------------
# 13. Figure 11: global conditional raw-family co-occurrence matrix
# -----------------------------
# Matrix values are P(column family is present | row family is present).
# Diagonal cells show the MAG-level presence fraction of that family.

presence_df <- mag_df %>%
  select(mag_id, p, all_of(used_family_cols)) %>%
  mutate(across(all_of(used_family_cols), ~ .x > 0))

make_conditional_matrix <- function(df, family_cols, group_name = "All HQ MAGs") {
  n_total <- nrow(df)
  out <- list()
  k <- 1L
  for (given_family in family_cols) {
    given_present <- df[[given_family]]
    n_given <- sum(given_present, na.rm = TRUE)
    for (target_family in family_cols) {
      target_present <- df[[target_family]]
      n_target <- sum(target_present, na.rm = TRUE)
      n_both <- sum(given_present & target_present, na.rm = TRUE)
      cond <- if (given_family == target_family) {
        ifelse(n_total > 0, n_given / n_total, NA_real_)
      } else {
        ifelse(n_given > 0, n_both / n_given, NA_real_)
      }
      out[[k]] <- data.frame(
        group = group_name,
        given_family = given_family,
        target_family = target_family,
        n_total = n_total,
        n_given = n_given,
        n_target = n_target,
        n_both = n_both,
        conditional_fraction = cond,
        cell_type = ifelse(given_family == target_family, "Diagonal: presence fraction", "Off-diagonal: conditional co-occurrence"),
        stringsAsFactors = FALSE
      )
      k <- k + 1L
    }
  }
  dplyr::bind_rows(out)
}

conditional_global <- make_conditional_matrix(presence_df, used_family_cols, "All HQ MAGs") %>%
  mutate(
    given_family = factor(given_family, levels = rev(used_family_cols)),
    target_family = factor(target_family, levels = used_family_cols)
  )
readr::write_tsv(conditional_global, file.path(source_dir, "figure_11_HQ_raw_family_conditional_cooccurrence_global_source_data.tsv"))

p_fig11 <- ggplot(conditional_global, aes(x = target_family, y = given_family, fill = conditional_fraction)) +
  geom_tile(colour = "white", linewidth = 0.2) +
  geom_text(aes(label = if_else(is.na(conditional_fraction), "", fmt_pct(conditional_fraction, 0))), size = 1.8) +
  scale_x_discrete(labels = used_family_labels) +
  scale_y_discrete(labels = used_family_labels[rev(used_family_cols)]) +
  scale_fill_gradient(low = "#F7FBFF", high = "#08306B", labels = percent_format(accuracy = 1), limits = c(0, 1), name = "Conditional\nfraction") +
  labs(
    x = "Target family B",
    y = "Given family A",
    title = "Global conditional raw-family co-occurrence in HQ MAGs",
    subtitle = "Off-diagonal: P(B present | A present); diagonal: MAG-level presence fraction of A"
  ) +
  theme_nature() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 5.8),
    axis.text.y = element_text(size = 5.8),
    legend.position = "right"
  )

save_figure(p_fig11, file.path(figure_dir, "figure_11_HQ_raw_family_conditional_cooccurrence_global"), 145, 118)

# -----------------------------
# 14. Figure 12: conditional co-occurrence by selected/top phylum
# -----------------------------
cooc_phyla <- selected_five_order[selected_five_order %in% unique(mag_df$p)]
if (length(cooc_phyla) == 0) {
  cooc_phyla <- phylum_counts$p[seq_len(min(5L, nrow(phylum_counts)))]
}

conditional_by_phylum <- lapply(cooc_phyla, function(pp) {
  make_conditional_matrix(presence_df %>% filter(.data[["p"]] == pp), used_family_cols, pp)
}) %>%
  bind_rows() %>%
  mutate(
    group = factor(group, levels = cooc_phyla),
    given_family = factor(given_family, levels = rev(used_family_cols)),
    target_family = factor(target_family, levels = used_family_cols)
  )
readr::write_tsv(conditional_by_phylum, file.path(source_dir, "figure_12_HQ_raw_family_conditional_cooccurrence_by_phylum_source_data.tsv"))

p_fig12 <- ggplot(conditional_by_phylum, aes(x = target_family, y = given_family, fill = conditional_fraction)) +
  geom_tile(colour = "white", linewidth = 0.16) +
  facet_wrap(~ group, ncol = min(3L, length(cooc_phyla))) +
  scale_x_discrete(labels = function(x) shorten_combo(x)) +
  scale_y_discrete(labels = function(x) shorten_combo(x)) +
  scale_fill_gradient(low = "#F7FBFF", high = "#08306B", labels = percent_format(accuracy = 1), limits = c(0, 1), name = "Conditional\nfraction") +
  labs(
    x = "Target family B",
    y = "Given family A",
    title = "Phylum-specific conditional raw-family co-occurrence",
    subtitle = "Off-diagonal: P(B present | A present); diagonal: family presence fraction within phylum"
  ) +
  theme_nature() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 4.8),
    axis.text.y = element_text(size = 4.8),
    legend.position = "right"
  )

save_figure(p_fig12, file.path(figure_dir, "figure_12_HQ_raw_family_conditional_cooccurrence_by_phylum"), 190, ifelse(length(cooc_phyla) <= 3, 105, 160))

# -----------------------------
# 15. Figure 13: phylum-level evolutionary preference
# -----------------------------
# For each phylum, identify the dominant exact group_combo and the dominant raw-family driver.

combo_by_phylum <- mag_df %>%
  count(p, group_combo, architecture_complexity, evolutionary_architecture, name = "n_mags") %>%
  group_by(p) %>%
  mutate(
    n_total = sum(n_mags),
    fraction = n_mags / n_total,
    combo_rank_in_phylum = row_number(desc(n_mags))
  ) %>%
  ungroup() %>%
  mutate(
    group_combo_short = shorten_combo(group_combo),
    p = factor(p, levels = phylum_order)
  )
readr::write_tsv(combo_by_phylum, file.path(source_dir, "figure_13_HQ_phylum_group_combo_preference_full_source_data.tsv"))

dominant_combo_by_phylum <- combo_by_phylum %>%
  arrange(p, desc(n_mags), group_combo) %>%
  group_by(p) %>%
  mutate(rank2 = row_number()) %>%
  ungroup() %>%
  filter(rank2 == 1) %>%
  mutate(
    p_chr = as.character(p),
    p_label = paste0(p_chr, " (n=", n_total, ")"),
    dominant_label = paste0(fmt_pct(fraction, 0.1), " | ", group_combo_short)
  )

dom_order <- dominant_combo_by_phylum %>%
  arrange(match(p_chr, phylum_order)) %>%
  pull(p_label)
dominant_combo_by_phylum$p_label <- factor(dominant_combo_by_phylum$p_label, levels = rev(unique(dom_order)))
readr::write_tsv(dominant_combo_by_phylum, file.path(source_dir, "figure_13_HQ_phylum_dominant_group_combo_source_data.tsv"))

p_fig13 <- ggplot(dominant_combo_by_phylum, aes(x = fraction, y = p_label, fill = evolutionary_architecture)) +
  geom_col(width = 0.70, colour = "black", linewidth = 0.15) +
  geom_text(aes(label = dominant_label), hjust = -0.03, size = 2.0) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.38))) +
  scale_fill_manual(values = architecture_colors, drop = FALSE, name = "Dominant\narchitecture") +
  labs(
    x = "Fraction of HQ actin-positive MAGs in phylum",
    y = NULL,
    title = "HQ-only phylum-level evolutionary preference",
    subtitle = "Each bar shows the most frequent exact raw-family group_combo in that phylum"
  ) +
  theme_nature() +
  theme(axis.text.y = element_text(size = 5.4), legend.position = "right")

save_figure(p_fig13, file.path(figure_dir, "figure_13_HQ_phylum_evolutionary_preference_dominant_group_combo"), 185, max(85, 5.5 * nrow(dominant_combo_by_phylum) + 28))

# -----------------------------
# 16. Figure 14: optional completeness/contamination quality annotation
# -----------------------------
# If MAG completeness/contamination columns are available in the input table, use them to check
# whether high-copy HQ MAGs cluster near HQ boundary values. If columns are absent, write a skip note.

find_column_by_candidates <- function(df, candidates) {
  nm <- names(df)
  nm_norm <- tolower(gsub("[^a-z0-9]+", "", nm))
  cand_norm <- tolower(gsub("[^a-z0-9]+", "", candidates))
  idx <- match(cand_norm, nm_norm)
  idx <- idx[!is.na(idx)]
  if (length(idx) > 0) return(nm[idx[1]])
  return(NA_character_)
}

completeness_col <- find_column_by_candidates(mag_df, c("completeness", "completeness_checkm2", "completeness_percent", "checkm2_completeness", "completeness_checkm"))
contamination_col <- find_column_by_candidates(mag_df, c("contamination", "contamination_checkm2", "contamination_percent", "checkm2_contamination", "contamination_checkm"))

quality_note <- tibble::tibble(
  metric = c("completeness_column_detected", "contamination_column_detected"),
  value = c(ifelse(is.na(completeness_col), "None", completeness_col), ifelse(is.na(contamination_col), "None", contamination_col))
)
readr::write_tsv(quality_note, file.path(source_dir, "figure_14_HQ_highcopy_technical_quality_annotation_detection.tsv"))

if (!is.na(completeness_col) || !is.na(contamination_col)) {
  tech_df <- mag_df %>%
    arrange(desc(total_copy), p, mag_id) %>%
    filter(total_copy >= 2) %>%
    mutate(row_rank = row_number())
  tech_df <- tech_df[seq_len(min(TOP_N_HIGHCOPY_MAG, nrow(tech_df))), , drop = FALSE]

  if (!is.na(completeness_col)) tech_df$completeness_value <- suppressWarnings(as.numeric(tech_df[[completeness_col]]))
  if (is.na(completeness_col)) tech_df$completeness_value <- NA_real_
  if (!is.na(contamination_col)) tech_df$contamination_value <- suppressWarnings(as.numeric(tech_df[[contamination_col]]))
  if (is.na(contamination_col)) tech_df$contamination_value <- NA_real_

  tech_df <- tech_df %>%
    mutate(mag_label = make_mag_label(mag_id, p, total_copy, max_chars = 52))

  readr::write_tsv(tech_df, file.path(source_dir, "figure_14_HQ_highcopy_technical_quality_annotation_source_data.tsv"))

  tech_long <- tech_df %>%
    select(mag_label, p, total_copy, completeness_value, contamination_value) %>%
    pivot_longer(cols = c(completeness_value, contamination_value), names_to = "metric", values_to = "value") %>%
    filter(!is.na(value)) %>%
    mutate(
      metric = recode(metric, completeness_value = "Completeness", contamination_value = "Contamination"),
      mag_label = factor(mag_label, levels = rev(unique(tech_df$mag_label)))
    )

  if (nrow(tech_long) > 0) {
    p_fig14 <- ggplot(tech_long, aes(x = value, y = mag_label)) +
      geom_point(aes(size = total_copy, fill = p), shape = 21, colour = "black", linewidth = 0.15, alpha = 0.88) +
      facet_grid(. ~ metric, scales = "free_x") +
      scale_size_continuous(range = c(1.0, 4.6), name = "total_copy") +
      labs(
        x = "Quality metric value",
        y = NULL,
        title = "Technical quality annotation for high-copy HQ MAGs",
        subtitle = "Shown only when completeness/contamination columns are present in the input table"
      ) +
      theme_nature() +
      theme(axis.text.y = element_text(size = 4.7), legend.position = "right")

    save_figure(p_fig14, file.path(figure_dir, "figure_14_HQ_highcopy_technical_quality_annotation_optional"), 170, max(90, 3.7 * nrow(tech_df) + 25))
  }
}

# -----------------------------
# 17. Figure 15: modular expansion overview
# -----------------------------
p_fig10b_compact <- p_fig10b + labs(title = NULL, subtitle = NULL) + theme(legend.position = "bottom", axis.text.x = element_text(size = 5.0, angle = 45, hjust = 1))
p_fig11_compact <- p_fig11 + labs(title = NULL, subtitle = NULL) + theme(legend.position = "bottom", axis.text.x = element_text(size = 4.8), axis.text.y = element_text(size = 4.8))
p_fig13_compact <- p_fig13 + labs(title = NULL, subtitle = NULL) + theme(legend.position = "bottom", axis.text.y = element_text(size = 5.0))

p_fig15 <- (p_fig10b_compact | p_fig11_compact) / p_fig13_compact +
  plot_layout(heights = c(1.1, 0.9), guides = "collect") +
  plot_annotation(
    tag_levels = "a",
    title = "HQ-only modular expansion and evolutionary preference overview",
    caption = "Expansion landscape ranks raw families by mean copy number; conditional co-occurrence shows MAG-level family recruitment; phylum preference shows the dominant exact group_combo in each phylum."
  )

save_figure(p_fig15, file.path(figure_dir, "figure_15_HQ_modular_expansion_preference_overview"), 200, 160)


# -----------------------------
# 12. Run summary
# -----------------------------
run_summary <- tibble::tibble(
  metric = c(
    "input_file",
    "output_dir",
    "n_HQ_actin_positive_MAG_rows",
    "n_unique_MAGs",
    "n_phyla",
    "used_raw_family_columns",
    "max_total_copy",
    "copy_ge2_MAGs",
    "copy_ge3_MAGs",
    "copy_ge5_MAGs",
    "non_HQ_rows_detected"
  ),
  value = c(
    input_file,
    output_dir,
    as.character(nrow(mag_df)),
    as.character(n_distinct(mag_df$mag_id)),
    as.character(n_distinct(mag_df$p)),
    paste(used_family_cols, collapse = ","),
    as.character(max(mag_df$total_copy, na.rm = TRUE)),
    as.character(sum(mag_df$total_copy >= 2, na.rm = TRUE)),
    as.character(sum(mag_df$total_copy >= 3, na.rm = TRUE)),
    as.character(sum(mag_df$total_copy >= 5, na.rm = TRUE)),
    as.character(non_hq_n)
  )
)
readr::write_tsv(run_summary, file.path(source_dir, "HQ_MAG_level_visualization_run_summary.tsv"))

message("Done. Figures written to: ", normalizePath(figure_dir, winslash = "/", mustWork = FALSE))
message("Source data written to: ", normalizePath(source_dir, winslash = "/", mustWork = FALSE))
