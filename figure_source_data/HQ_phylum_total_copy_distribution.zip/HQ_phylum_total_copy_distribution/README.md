# 2_HQ_phylum_total_copy_distribution

- Manuscript panel: Supp.Fig.10A
- Source figure basename: figure_2_HQ_phylum_total_copy_distribution
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 24 directly referenced or locally packaged source-data file(s)
