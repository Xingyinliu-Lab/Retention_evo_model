from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm, colors
from mpl_toolkits.mplot3d import proj3d

src = Path(r"..")
out = Path(r"..")
out.mkdir(parents=True, exist_ok=True)
d = pd.read_csv(src, sep="\t")
best_r, best_g = 60.79060490760361, 0.04314541044967364
rvals = np.sort(d.r.unique()); gvals = np.sort(d.A.unique())
X, Y = np.meshgrid(np.log2(rvals), gvals)

for col, stem, title, zlabel in [
    ("expected_S_to_C_gain", "dt_events", "actin current584: D+T event expectation", "D+T event expectation"),
    ("expected_C_to_S_resolution", "l_events", "actin current584: L event expectation", "L event expectation"),
]:
    z = d.pivot(index="A", columns="r", values=col).reindex(index=gvals, columns=rvals).to_numpy()
    norm = colors.Normalize(vmin=float(np.nanmin(z)), vmax=float(np.nanmax(z)))
    fig = plt.figure(figsize=(8.6, 7.0), dpi=180)
    ax = fig.add_subplot(111, projection="3d")
    ax.plot_surface(X, Y, z, facecolors=cm.coolwarm(norm(z)), rstride=1, cstride=1,
                    linewidth=0.45, edgecolor="#4d4d4d", antialiased=True, shade=False)
    levels = np.linspace(np.nanmin(z), np.nanmax(z), 8)
    ax.contour(X, Y, z, levels=levels, zdir="z", offset=np.nanmin(z) - 0.06*(np.nanmax(z)-np.nanmin(z)),
               cmap="coolwarm", linewidths=1.0)
    xb, yb = np.log2(best_r), best_g
    iz = float(d.loc[(d.r.sub(best_r).abs()+d.A.sub(best_g).abs()).idxmin(), col])
    zmin = float(np.nanmin(z)); span = float(np.nanmax(z)-zmin)
    ax.scatter([xb], [yb], [iz], s=90, c="#111111", edgecolors="white", linewidths=1.8, depthshade=False)
    ax.plot([xb, xb], [yb, yb], [zmin - 0.06*span, iz], color="#111111", linestyle="--", linewidth=1.0)
    label_xy = (0.70, 0.94)
    ax.text2D(*label_xy, f"OPTIMUM\nr = {best_r:.2f}\nG = {best_g:.3f}\nvalue = {iz:.2f}",
              transform=ax.transAxes, color="#111111", fontsize=9.5, ha="left", va="top",
              bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="#111111", alpha=0.92))
    ax.set_xlabel("r (log2 scale)", labelpad=12); ax.set_ylabel("G (normalized gain scale)", labelpad=10); ax.set_zlabel(zlabel, labelpad=10)
    ax.set_xticks(np.log2(rvals)); ax.set_xticklabels([f"{x:g}" for x in rvals])
    ax.set_title(title, pad=18, fontsize=13, fontweight="bold")
    ax.view_init(elev=28, azim=225); ax.set_box_aspect((1.35, 1.0, 0.85)); ax.grid(True, alpha=0.22)
    fig.canvas.draw()
    xp, yp, _ = proj3d.proj_transform(xb, yb, iz, ax.get_proj())
    ax.annotate("", xy=(xp, yp), xycoords="data", xytext=label_xy, textcoords=ax.transAxes,
                arrowprops=dict(arrowstyle="-|>", color="#111111", lw=1.8, shrinkA=8, shrinkB=4))
    m = cm.ScalarMappable(norm=norm, cmap="coolwarm"); m.set_array(z)
    cbar = fig.colorbar(m, ax=ax, shrink=0.58, pad=0.10, aspect=18); cbar.set_label("blue = lower, red = higher", rotation=90, labelpad=12)
    fig.subplots_adjust(left=0.02, right=0.93, bottom=0.07, top=0.92)
    fig.savefig(out / f"fig_actin_current584_r_G_{stem}.pdf", bbox_inches="tight")
    fig.savefig(out / f"fig_actin_current584_r_G_{stem}.png", dpi=420, bbox_inches="tight")
    plt.close(fig)
