suppressPackageStartupMessages(library(data.table))
src <- ".."
out <- ".."
dir.create(out, recursive = TRUE, showWarnings = FALSE)
d <- fread(src)
stopifnot(all(c("r", "normalized_G", "logL", "delta_logL_vs_null_mle") %in% names(d)))
d[, neg_logL := -logL]
best <- d[which.max(logL)]
fwrite(d, file.path(out, "actin_current584_r_G_likelihood_surface_source.tsv"), sep = "\t")
fwrite(best, file.path(out, "actin_current584_r_G_likelihood_surface_optimum.tsv"), sep = "\t")
writeLines(c("status=complete", "z_axis=logL (higher is better)", paste0("r_hat=", best$r), paste0("G_at_optimum=", best$normalized_G), paste0("maximum_logL=", best$logL), paste0("delta_logL_vs_r1=", best$delta_logL_vs_null_mle), "r=1 is ordinary/null boundary"), file.path(out, "COMPLETE.marker"))
rvals <- sort(unique(d$r)); gvals <- sort(unique(d$normalized_G)); z <- matrix(NA_real_, nrow = length(gvals), ncol = length(rvals), dimnames = list(as.character(gvals), as.character(rvals)))
for (i in seq_len(nrow(d))) z[as.character(d$normalized_G[i]), as.character(d$r[i])] <- d$logL[i]
if (anyNA(z)) stop("r-G grid is not rectangular")
zcols <- colorRampPalette(c("#2C7BB6", "#ABD9E9", "#FFFFBF", "#FDAE61", "#D7191C"))(40)
zbin <- matrix(cut(z, breaks = seq(min(z), max(z), length.out = 41), include.lowest = TRUE, labels = FALSE), nrow = nrow(z), ncol = ncol(z))
face_col <- zcols[pmax(1, pmin(40, zbin[-nrow(z), -ncol(z)]))]
draw_surface <- function(file, width, height, dpi = NULL) {
  if (is.null(dpi)) pdf(file, width = width, height = height, useDingbats = FALSE) else png(file, width = width, height = height, res = dpi)
  par(mar = c(3.5, 3.5, 2.2, 1), family = "sans")
  pp <- persp(rvals, gvals, z, theta = 125, phi = 27, expand = 0.72, col = face_col, border = "#5A6B73", ticktype = "detailed", xlab = "r (coexistence persistence multiplier)", ylab = "G (normalized gain scale)", zlab = "log likelihood", main = "actin current584: r–G likelihood surface")
  trans3d <- function(x, y, zz, p) { q <- cbind(x, y, zz, 1) %*% p; list(x = q[, 1] / q[, 4], y = q[, 2] / q[, 4]) }
  cont <- contourLines(rvals, gvals, z, nlevels = 8)
  for (cl in cont) { xy <- trans3d(cl$x, cl$y, cl$level, pp); lines(xy$x, xy$y, col = "#404040", lwd = 0.7) }
  pt <- trans3d(best$r, best$normalized_G, best$logL, pp)
  points(pt$x, pt$y, pch = 19, col = "#111111", cex = 1.8)
  tx <- pt$x - 0.12; ty <- pt$y + 0.10
  arrows(tx, ty, pt$x, pt$y, length = 0.10, lwd = 1.4, col = "#111111")
  text(tx, ty, labels = sprintf("optimum: r=%.2f, G=%.3f", best$r, best$normalized_G), pos = 2, col = "#111111", cex = .8)
  dev.off()
}
draw_surface(file.path(out, "fig_actin_current584_r_G_logL_surface.pdf"), 8.2, 6.8)
draw_surface(file.path(out, "fig_actin_current584_r_G_logL_surface.png"), 2200, 1800, 300)
