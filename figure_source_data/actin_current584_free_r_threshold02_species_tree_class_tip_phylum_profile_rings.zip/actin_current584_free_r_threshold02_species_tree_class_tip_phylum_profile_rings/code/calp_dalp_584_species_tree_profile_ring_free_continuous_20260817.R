#!/usr/bin/env Rscript
suppressPackageStartupMessages({library(ape); library(ggplot2); library(ggtree); library(ggnewscale); library(dplyr); library(readr)})

base <- ".."
tree_file <- file.path(base, "coupled_retention_dtl_20260811/coexistence_gain_loss_toolkit/examples/clean_local_r128_20260817/cases/actin_current584/input/species_tree.nwk")
meta_file <- ".."
event_file <- file.path(base, "coupled_retention_dtl_20260811/coexistence_gain_loss_toolkit/examples/coexist_gl_v2_outputs_20260817/actin_current584/branchwise_events_v2.tsv")
out <- file.path(base, "actin_current584_species_tree_profile_ring_free_continuous_20260817")
dir.create(out, recursive = TRUE, showWarnings = FALSE)

tr <- read.tree(tree_file)
N <- Ntip(tr); next_id <- 0L
assign_internal <- function(node) { if (node <= N) return(); next_id <<- next_id + 1L; tr$node.label[node-N] <<- sprintf("N%04d", next_id); for (k in tr$edge[tr$edge[,1] == node,2]) assign_internal(k) }
tr$node.label <- character(tr$Nnode); assign_internal(tr$edge[1,1])
lab <- function(node) if (node <= N) tr$tip.label[node] else tr$node.label[node-N]
event_raw <- read.delim(event_file, check.names = FALSE)
event <- event_raw |> transmute(parent, child, event_class,
  value = as.numeric(posterior_or_expected_value), key = paste(parent, child, sep = "||"))
event_classes <- c("aggregate_gain_G", "resolution_L_like", "coexistence_persistence")
event_labels <- c("G: S→C gain", "L-like: C→S resolution", "C→C persistence")
event_cols <- c("#C0392B", "#003F9E", "#087F5B")
event_key <- paste(vapply(tr$edge[,1], lab, character(1)), vapply(tr$edge[,2], lab, character(1)), sep = "||")
event_mat <- sapply(event_classes, function(x) { z <- event$value[event$event_class == x]; setNames(z, event$key[event$event_class == x])[event_key] })
event_mat[is.na(event_mat)] <- 0
event_signal <- apply(event_mat, 1, max)
event_idx <- apply(event_mat, 1, function(z) if (max(z) >= 0.2) which.max(z) else 0L)
blend_event <- function(col, signal) {
  signal <- max(0, min(1, (signal - 0.2) / 0.8))
  vals <- grDevices::colorRamp(c("#E6E6E6", col))(signal)[1, ]
  grDevices::rgb(vals[1], vals[2], vals[3], maxColorValue = 255)
}
event_by_child <- setNames(event_idx, vapply(tr$edge[,2], lab, character(1)))
alpha_by_child <- setNames(ifelse(event_idx == 0L, 1, pmax(0.38, pmin(1, (event_signal - 0.2) / 0.8))), vapply(tr$edge[,2], lab, character(1)))
meta <- read.delim(meta_file, check.names = FALSE)
state_map <- meta |>
  group_by(mag_id) |>
  summarise(
    phylum = first(p), class = first(c),
    state = case_when(
      any(mag_profile_state == "coexist") ~ "cALP+dALP mix",
      any(mag_profile_state == "cALP_only_proxy") ~ "cALP-only",
      any(mag_profile_state == "dALP_only_proxy") ~ "dALP-only",
      TRUE ~ "No profile state"), .groups = "drop")

state_map <- state_map |> mutate(tree_key = sub("^(GB_|RS_)", "", mag_id))
tree_map <- tibble(tree_label = tr$tip.label, tree_key = sub("^(GB_|RS_)", "", tr$tip.label))
state_map <- tree_map |> left_join(state_map, by = "tree_key") |> transmute(mag_id = tree_label, phylum, class, state)
stopifnot(setequal(state_map$mag_id, tr$tip.label), !anyNA(state_map$state), !anyNA(state_map$phylum))
state_levels <- c("dALP-only", "cALP+dALP mix", "cALP-only")
state_palette <- c("dALP-only" = "#5B7DB1", "cALP+dALP mix" = "#C85A73", "cALP-only" = "#2A9D8F")
phylum_order <- state_map |> count(phylum, sort = TRUE) |> pull(phylum)
phylum_base <- c("#4C78A8", "#59A14F", "#F28E2B", "#B07AA1", "#E15759", "#76B7B2", "#EDC948", "#9C755F", "#BAB0AC", "#2F5597")
phylum_palette <- setNames(rep(phylum_base, length.out = length(phylum_order)), phylum_order)
class_order <- state_map |> count(class, sort = TRUE) |> pull(class)
class_base <- c("#264653", "#2A9D8F", "#E9C46A", "#F4A261", "#E76F51", "#457B9D", "#6D597A", "#84A59D", "#BC6C25", "#588157", "#8D99AE", "#9B5DE5")
class_palette <- setNames(rep(class_base, length.out = length(class_order)), class_order)

p <- ggtree(tr, layout = "circular", branch.length = "none")
p$data$edge_event <- factor(ifelse(is.na(event_by_child[p$data$label]), 0L, event_by_child[p$data$label]), levels = 0:3)
p$data$edge_alpha <- ifelse(is.na(alpha_by_child[p$data$label]), 1, alpha_by_child[p$data$label])
p$data$edge_width <- ifelse(
  as.integer(p$data$edge_event) == 0,
  0.022,
  0.075 + 0.24 * apply(event_mat, 1, max)[match(p$data$label, vapply(tr$edge[,2], lab, character(1)))]
)
for (i in seq_along(p$layers)) { p$layers[[i]]$aes_params$linewidth <- 0.07; p$layers[[i]]$aes_params$colour <- "#B8B8B8" }
tip <- p$data |> filter(isTip) |> transmute(label, x, y) |> left_join(state_map, by = c("label" = "mag_id"))
radius <- max(tip$x); gap <- radius * 0.012; ring_w <- radius * 0.032
tip <- tip |> mutate(class_ring_x = radius + gap + ring_w/2,
                     profile_ring_x = radius + 2*gap + 3*ring_w/2)

p <- p +
  geom_tree(data = p$data, aes(colour = edge_event, alpha = edge_alpha, linewidth = edge_width), inherit.aes = FALSE) +
  scale_colour_manual(values = c("0" = "#E6E6E6", "1" = event_cols[1], "2" = event_cols[2], "3" = event_cols[3]), breaks = 1:3, labels = event_labels, drop = FALSE, name = "Max branchwise event posterior") +
  scale_alpha_identity(guide = "none") +
  scale_linewidth_identity(guide = "none") +
  ggnewscale::new_scale_colour() +
  geom_point2(data = p$data |> filter(isTip) |> left_join(state_map, by = c("label" = "mag_id")),
             aes(subset = isTip, colour = class), size = 0.52, shape = 16, alpha = 0.95, inherit.aes = TRUE) +
  scale_colour_manual(values = class_palette, breaks = class_order, name = "Tip taxonomy: class") +
  ggnewscale::new_scale_fill() +
  geom_tile(data = tip, aes(x = class_ring_x, y = y, fill = phylum), inherit.aes = FALSE, width = ring_w, height = 1.04, linewidth = 0) +
  scale_fill_manual(values = phylum_palette, breaks = phylum_order, name = "Outer ring 1: phylum") +
  ggnewscale::new_scale_fill() +
  geom_tile(data = tip, aes(x = profile_ring_x, y = y, fill = state), inherit.aes = FALSE, width = ring_w, height = 1.04, linewidth = 0) +
  scale_fill_manual(values = state_palette, limits = state_levels, name = "MAG profile state") +
  labs(title = "Actin current584 species tree: free-r event posteriors",
       subtitle = "Tip points: phylum; outer ring: MAG-level cALP/dALP profile state",
       caption = "Branch color saturation: posterior 0.2 (pale) → 0.5 (medium) → 1.0 (saturated); line width increases with the same maximum posterior; below 0.2 is grey. Class annotations are retained in the accompanying tip metadata table.") +
  theme_void(base_size = 7, base_family = "Arial") +
  theme(plot.title = element_text(size = 8, face = "bold"), plot.subtitle = element_text(size = 6.3, colour = "#4A4A4A"),
        plot.caption = element_text(size = 5.5, colour = "#555555", hjust = 0), legend.position = "right",
        legend.title = element_text(size = 6.1, face = "bold"), legend.text = element_text(size = 5.2),
        legend.key.height = grid::unit(2.6, "mm"), plot.margin = margin(4, 8, 4, 4))

ggsave(file.path(out, "fig_actin_current584_species_tree_class_tip_phylum_profile_rings.pdf"), p, width = 183, height = 145, units = "mm", device = cairo_pdf)
ggsave(file.path(out, "fig_actin_current584_species_tree_class_tip_phylum_profile_rings.png"), p, width = 183, height = 145, units = "mm", dpi = 450, bg = "white")
write_tsv(state_map, file.path(out, "fig_actin_current584_species_tree_class_tip_phylum_profile_metadata.tsv"))
write.table(count(state_map, state), file.path(out, "fig_actin_current584_species_tree_class_tip_phylum_profile_state_counts.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
