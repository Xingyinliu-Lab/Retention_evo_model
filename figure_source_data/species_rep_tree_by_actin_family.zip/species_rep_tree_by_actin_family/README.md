# 3_species_rep_tree_by_actin_family

- Manuscript panel: Fig.4A
- Source figure basename: figure_3_species_rep_tree_by_actin_family
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 22 directly referenced or locally packaged source-data file(s)
