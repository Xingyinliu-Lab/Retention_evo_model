#!/usr/bin/env Rscript

# Replot the frozen gappyout species-representative tree with family-coloured
# leaf points and an outer Asgard-class annotation ring. No topology, branch
# length input, or sequence classification is altered.

required <- c("ape", "ggplot2", "ggtree", "dplyr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing R packages: ", paste(missing, collapse = ", "))
suppressPackageStartupMessages({ library(ape); library(ggplot2); library(ggtree); library(dplyr) })

project_dir <- "asgrad_species_rep_mag_tree_gappyout"
tree_file <- file.path(project_dir, "trimmed_asgard_species_rep_mag_euk_mix_gappyout.treefile")
meta_file <- file.path(project_dir, "asgard_species_rep_mag_actin_sequences.tsv")
out_dir <- file.path(project_dir, "figures")
source_dir <- file.path(project_dir, "plot_source_data")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

tree <- read.tree(tree_file)
tree_display <- tree
tree_display$edge.length <- sqrt(pmax(tree_display$edge.length, 0))
asgard_meta <- read.delim(meta_file, check.names = FALSE, stringsAsFactors = FALSE, na.strings = c("", "NA"))
if (!all(c("seq", "actin_family_class", "c") %in% names(asgard_meta))) stop("Required sequence metadata columns are absent.")

euk_labels <- setdiff(tree$tip.label, asgard_meta$seq)
euk_meta <- data.frame(
  seq = euk_labels,
  actin_family_class = "Eukaryota_actin",
  c = "Eukaryotic reference",
  stringsAsFactors = FALSE
)
meta <- bind_rows(asgard_meta %>% select(seq, actin_family_class, c), euk_meta)
meta <- meta[match(tree$tip.label, meta$seq), , drop = FALSE]
if (anyNA(meta$seq)) stop("Some tree tips are absent from the sequence metadata.")

family_display_map <- c(
  "canonical Actin-like" = "cALPs",
  "Crenactin-like / archaeal actin" = "dALPs",
  "MreB/Mbl-like" = "MreB/Mbl-like",
  "MreB-like_C/ALP_N-related" = "MreB-C/ALP-N",
  "FtsA/PilM-like" = "FtsA/PilM-like",
  "Volactin" = "Volactin",
  "Salactin" = "Salactin",
  "Eukaryota_actin" = "Eukaryotic actin"
)
family_palette <- c(
  "cALPs" = "#4C78A8", "dALPs" = "#4F9B8F", "MreB/Mbl-like" = "#8B6FA8",
  "MreB-C/ALP-N" = "#C77DA8", "FtsA/PilM-like" = "#777777", "Volactin" = "#E18D4F",
  "Salactin" = "#D6A64A", "Eukaryotic actin" = "#D73027"
)
class_palette <- c(
  "Lokiarchaeia" = "#4F9B8F", "Heimdallarchaeia" = "#33658A", "Thorarchaeia" = "#E08D3C",
  "Hermodarchaeia" = "#7B61A8", "Njordarchaeia" = "#C75C64", "Jordiarchaeia" = "#8C8C3E",
  "Asgardarchaeia" = "#5A7D9A", "Baldrarchaeia" = "#D6A64A", "Odinarchaeia" = "#9C6B4E",
  "Wukongarchaeia" = "#8E6A9E", "Atabeyarchaeia" = "#5C8F45", "Sifarchaeia" = "#6B6B6B",
  "Eukaryotic reference" = "#D73027"
)
class_order <- c(
  "Lokiarchaeia", "Heimdallarchaeia", "Thorarchaeia", "Hermodarchaeia", "Njordarchaeia",
  "Jordiarchaeia", "Asgardarchaeia", "Baldrarchaeia", "Odinarchaeia", "Wukongarchaeia",
  "Atabeyarchaeia", "Sifarchaeia", "Eukaryotic reference"
)

meta$family_display <- factor(unname(family_display_map[meta$actin_family_class]), levels = names(family_palette))
meta$class_display <- factor(meta$c, levels = class_order)
if (anyNA(meta$family_display) || anyNA(meta$class_display)) stop("Unexpected actin-family or Asgard-class label.")

p <- ggtree(tree_display, layout = "circular")
for (i in seq_along(p$layers)) {
  p$layers[[i]]$aes_params$linewidth <- 0.11
  p$layers[[i]]$aes_params$colour <- "#777777"
}
tip_match <- match(p$data$label, meta$seq)
p$data$family_display <- meta$family_display[tip_match]
p$data$class_display <- meta$class_display[tip_match]
tip_ring <- p$data[p$data$isTip, c("label", "x", "y", "class_display"), drop = FALSE]
tree_radius <- max(tip_ring$x)
ring_gap <- tree_radius * 0.012
ring_width <- tree_radius * 0.026
tip_ring$x_ring <- tree_radius + ring_gap + ring_width / 2
write.table(
  tip_ring,
  file.path(source_dir, "figure_3_species_rep_tree_by_actin_family_class_outer_ring_tip_annotations.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

p_out <- p +
  geom_point2(aes(subset = isTip, colour = family_display), shape = 16, size = 1.05, alpha = 0.92) +
  scale_colour_manual(values = family_palette, breaks = names(family_palette), drop = FALSE, name = "Actin family") +
  geom_tile(
    data = tip_ring, aes(x = x_ring, y = y, fill = class_display), inherit.aes = FALSE,
    width = ring_width, height = 1.02, linewidth = 0
  ) +
  scale_fill_manual(values = class_palette, breaks = class_order, drop = FALSE, name = "Outer ring: Asgard class") +
  labs(
    title = "Species-representative Asgard actin tree with class outer ring",
    subtitle = "Leaf points: actin family; outer ring: GTDB class; branch lengths are square-root transformed for display.",
    caption = "One actin-positive MAG per GTDB species is represented; all detected actin copies from selected MAGs are retained."
  ) +
  theme_void(base_family = "Arial") +
  theme(
    plot.title = element_text(size = 12, face = "bold"),
    plot.subtitle = element_text(size = 8.8, colour = "#444444"),
    plot.caption = element_text(size = 7.2, colour = "#444444", hjust = 0),
    legend.position = "right", legend.title = element_text(size = 8.5, face = "bold"),
    legend.text = element_text(size = 7.3), legend.key.height = grid::unit(3.4, "mm"),
    plot.margin = margin(7, 12, 7, 7)
  )

stem <- file.path(out_dir, "figure_3_species_rep_tree_by_actin_family")
ggsave(paste0(stem, ".pdf"), p_out, width = 260, height = 205, units = "mm", device = cairo_pdf)
ggsave(paste0(stem, "_preview.png"), p_out, width = 260, height = 205, units = "mm", dpi = 450, bg = "white")
message("Saved: ", normalizePath(paste0(stem, ".pdf"), winslash = "/"))
