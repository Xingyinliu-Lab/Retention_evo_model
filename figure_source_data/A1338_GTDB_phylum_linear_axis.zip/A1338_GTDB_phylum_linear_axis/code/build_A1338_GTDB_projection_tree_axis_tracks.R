suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(ggtree)
  library(readr)
  library(stringr)
  library(tidyr)
})

root <- ".."
package_root <- ".."
plot_dir <- file.path(package_root, "figures")
data_dir <- file.path(package_root, "data")
dir.create(plot_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

tree_file <- ".."
taxonomy_file <- "../data/ar53_taxonomy_r226.tsv"
full_tip_order_file <- "../data/figure_1b_gtdb_phylum_ring_unfolded_linear_track_tip_order.tsv"
stage06_map_file <- ".."
evidence_file <- file.path(root, "results", "tier1_31_direction_free_A_B_retention_evidence.tsv")
state_file <- file.path(root, "inputs", "tier1_31_neutral_A_B_MAG_states.tsv")
function_file <- file.path(root, "figures", "source_data", "tier1_31_function_theme_mapping.tsv")
stopifnot(all(file.exists(c(tree_file, taxonomy_file, full_tip_order_file,
                            stage06_map_file, evidence_file, state_file, function_file))))

phylum_palette_base <- c(
  "#4C78A8", "#4F9B8F", "#E28E2C", "#7B61A8", "#C75C64",
  "#8C8C3E", "#5A7D9A", "#D6A64A", "#9C6B4E", "#8E6A9E",
  "#5C8F45", "#6B6B6B", "#C77DA8", "#4CB7C5", "#B8A72A",
  "#476A8A", "#D95852", "#9E4A4A", "#4E94C4", "#9B776E",
  "#3F7C85"
)
state_palette <- c(
  "A-only" = "#4C78A8",
  "A+B coexist" = "#D89C2B",
  "B-only" = "#4F9C8E",
  "taxon collision" = "#7A6F8F",
  "no state" = "#F0F0F0"
)

ref_tree <- read.tree(tree_file)
stopifnot(length(ref_tree$tip.label) == 6968L, is.rooted(ref_tree))
full_order <- read_tsv(full_tip_order_file, show_col_types = FALSE) %>%
  select(label, full_tip_order = tip_order)

extract_rank <- function(x, prefix) {
  out <- str_match(x, paste0("(?:^|;)", prefix, "__([^;]*)"))[, 2]
  na_if(out, "")
}

ref_tax <- read_tsv(taxonomy_file, col_names = c("label", "taxonomy"),
                    show_col_types = FALSE, progress = FALSE) %>%
  filter(label %in% ref_tree$tip.label) %>%
  mutate(
    p = extract_rank(taxonomy, "p"), c = extract_rank(taxonomy, "c"),
    o = extract_rank(taxonomy, "o"), f = extract_rank(taxonomy, "f"),
    g = extract_rank(taxonomy, "g"), s = extract_rank(taxonomy, "s")
  ) %>%
  left_join(full_order, by = "label")
stopifnot(nrow(ref_tax) == 6968L, !anyNA(ref_tax$full_tip_order))

phylum_order <- ref_tax %>% count(p, sort = TRUE) %>% pull(p)
phylum_palette <- setNames(rep(phylum_palette_base, length.out = length(phylum_order)),
                           phylum_order)
# Adjacent dominant phyla require visibly distinct hues in the pruned axis.
phylum_palette["Asgardarchaeota"] <- "#8067A2"
phylum_palette["Thermoproteota"] <- "#4C78A8"

stage06 <- read_tsv(stage06_map_file, show_col_types = FALSE, progress = FALSE) %>%
  arrange(mag_id)
stopifnot(nrow(stage06) == 1338L, !anyDuplicated(stage06$mag_id))

rank_levels <- c("s", "g", "f", "o", "c", "p")
rank_lookup <- lapply(rank_levels, function(r) split(ref_tax$label, ref_tax[[r]]))
names(rank_lookup) <- rank_levels
ref_order_lookup <- setNames(ref_tax$full_tip_order, ref_tax$label)

normalize_accession <- function(x) {
  case_when(
    str_detect(x, "^GCA_") ~ paste0("GB_", x),
    str_detect(x, "^GCF_") ~ paste0("RS_", x),
    TRUE ~ x
  )
}

projection <- stage06 %>%
  mutate(
    projection_rank = NA_character_,
    projection_taxon = NA_character_,
    anchor_tip = NA_character_,
    projection_mode = NA_character_
  )

for (i in seq_len(nrow(projection))) {
  exact_tip <- normalize_accession(projection$mag_id[i])
  if (exact_tip %in% ref_tree$tip.label) {
    projection$projection_rank[i] <- "accession"
    projection$projection_taxon[i] <- projection$mag_id[i]
    projection$anchor_tip[i] <- exact_tip
    projection$projection_mode[i] <- "exact_GTDB_accession"
    next
  }
  for (r in rank_levels) {
    value <- projection[[r]][i]
    if (is.na(value) || value == "" || value == "Unclassified") next
    candidates <- rank_lookup[[r]][[value]]
    if (is.null(candidates) || length(candidates) == 0L) next
    candidate_order <- unname(ref_order_lookup[candidates])
    midpoint <- stats::median(candidate_order)
    anchor <- candidates[which.min(abs(candidate_order - midpoint))]
    projection$projection_rank[i] <- r
    projection$projection_taxon[i] <- value
    projection$anchor_tip[i] <- anchor
    projection$projection_mode[i] <- paste0("taxonomy_", r)
    break
  }
}

projection <- projection %>%
  mutate(projection_mapped = !is.na(anchor_tip))
mapped_projection <- projection %>% filter(projection_mapped)
stopifnot(nrow(mapped_projection) >= 1336L)

# Correct projection: MAGs select GTDB reference tips by taxon name, then the
# original GTDB r226 tree is pruned to those tips. No MAG tips are grafted.
anchor_tips <- unique(mapped_projection$anchor_tip)
projection_tree <- keep.tip(ref_tree, anchor_tips)
stopifnot(setequal(projection_tree$tip.label, anchor_tips),
          is.rooted(projection_tree))

tree_out <- file.path(data_dir, "A1338_GTDB_r226_taxon_name_pruned.treefile")
write.tree(projection_tree, tree_out)
obsolete_grafted_tree <- file.path(data_dir, "A1338_GTDB_r226_taxonomy_projection.treefile")
if (file.exists(obsolete_grafted_tree)) unlink(obsolete_grafted_tree)

tip_meta <- ref_tax %>%
  filter(label %in% anchor_tips) %>%
  select(label, p, c, o, f, g, s, full_tip_order)

display_tree <- projection_tree
display_tree$edge.length <- sqrt(pmax(display_tree$edge.length, 0))
tree_base <- ggtree(display_tree, layout = "circular")
for (i in seq_along(tree_base$layers)) {
  tree_base$layers[[i]]$aes_params$linewidth <- 0.045
  tree_base$layers[[i]]$aes_params$colour <- "#969696"
}
tip_xy <- tree_base$data %>%
  filter(isTip) %>%
  transmute(label, x, y) %>%
  left_join(tip_meta, by = "label")
stopifnot(nrow(tip_xy) == length(anchor_tips), !anyNA(tip_xy$p))

tree_radius <- max(tip_xy$x)
ring_gap <- tree_radius * 0.015
ring_width <- tree_radius * 0.025
tip_xy <- tip_xy %>% mutate(phylum_ring_x = tree_radius + ring_gap + ring_width / 2)

p_tree <- tree_base +
  geom_tile(
    data = tip_xy,
    aes(x = phylum_ring_x, y = y, fill = p),
    inherit.aes = FALSE,
    width = ring_width, height = 1.02, linewidth = 0
  ) +
  scale_fill_manual(values = phylum_palette, breaks = phylum_order,
                    drop = FALSE, name = "Phylum") +
  guides(fill = guide_legend(ncol = 2, byrow = TRUE,
                             override.aes = list(colour = NA))) +
  theme_void(base_family = "Arial", base_size = 7) +
  theme(
    legend.position = "right",
    legend.title = element_text(size = 6.2, face = "bold"),
    legend.text = element_text(size = 5.5),
    legend.key.height = grid::unit(2.8, "mm"),
    legend.key.width = grid::unit(3.8, "mm"),
    plot.margin = margin(2.5, 4, 2.5, 2.5)
  )

tree_stem <- "fig_A1338_GTDB_projection_tree_phylum_ring"
ggsave(file.path(plot_dir, paste0(tree_stem, ".pdf")), p_tree,
       width = 183, height = 145, units = "mm", device = cairo_pdf, bg = "white")
ggsave(file.path(plot_dir, paste0(tree_stem, ".png")), p_tree,
       width = 183, height = 145, units = "mm", dpi = 420, bg = "white")

tip_order <- tip_xy %>%
  arrange(y) %>%
  mutate(tip_order = row_number()) %>%
  select(gtdb_tip = label, tip_order, full_tip_order, p, c, o, f, g, s)
stopifnot(!anyDuplicated(tip_order$gtdb_tip), nrow(tip_order) == Ntip(projection_tree))

runs <- rle(tip_order$p)
segment_end <- cumsum(runs$lengths)
segments <- tibble(
  p = runs$values,
  n_tips = runs$lengths,
  start_tip = segment_end - runs$lengths + 1L,
  end_tip = segment_end
) %>%
  mutate(
    midpoint = (start_tip + end_tip) / 2,
    direct_label = n_tips >= pmax(42L, nchar(p) * 8L)
  )
long_segments <- segments %>% filter(direct_label)
short_segments <- segments %>%
  filter(!direct_label) %>%
  arrange(midpoint) %>%
  mutate(label_side = rep(c("above", "below"), length.out = n()))

p_axis <- ggplot() +
  geom_rect(
    data = segments,
    aes(xmin = start_tip - 0.5, xmax = end_tip + 0.5,
        ymin = -0.035, ymax = 0.035, fill = p),
    linewidth = 0
  ) +
  geom_text(
    data = long_segments,
    aes(midpoint, 0.105, label = p, colour = p),
    family = "Arial", size = 1.35, fontface = "bold", check_overlap = TRUE
  ) +
  geom_segment(
    data = long_segments,
    aes(x = midpoint, xend = midpoint, y = 0.042, yend = 0.073, colour = p),
    linewidth = 0.20
  ) +
  geom_text_repel(
    data = filter(short_segments, label_side == "above"),
    aes(midpoint, 0, label = p, colour = p),
    family = "Arial", size = 1.20, nudge_y = 0.20, direction = "x",
    ylim = c(0.13, 0.30), xlim = c(0.5, nrow(tip_order) + 0.5),
    box.padding = 0.18, point.padding = 0.05, min.segment.length = 0,
    segment.size = 0.18,
    arrow = grid::arrow(length = grid::unit(0.58, "mm"), type = "closed"),
    max.overlaps = Inf, seed = 20260818
  ) +
  geom_text_repel(
    data = filter(short_segments, label_side == "below"),
    aes(midpoint, 0, label = p, colour = p),
    family = "Arial", size = 1.20, nudge_y = -0.20, direction = "x",
    ylim = c(-0.30, -0.13), xlim = c(0.5, nrow(tip_order) + 0.5),
    box.padding = 0.18, point.padding = 0.05, min.segment.length = 0,
    segment.size = 0.18,
    arrow = grid::arrow(length = grid::unit(0.58, "mm"), type = "closed"),
    max.overlaps = Inf, seed = 20260819
  ) +
  scale_fill_manual(values = phylum_palette, guide = "none") +
  scale_colour_manual(values = phylum_palette, guide = "none") +
  scale_x_continuous(limits = c(0.5, nrow(tip_order) + 0.5),
                     expand = expansion(mult = 0)) +
  coord_cartesian(ylim = c(-0.36, 0.36), clip = "off") +
  theme_void(base_family = "Arial", base_size = 7) +
  theme(plot.margin = margin(4, 5, 3, 5))

axis_stem <- "fig_A1338_GTDB_phylum_linear_axis"
ggsave(file.path(plot_dir, paste0(axis_stem, ".pdf")), p_axis,
       width = 183, height = 24, units = "mm", device = cairo_pdf, bg = "white")
ggsave(file.path(plot_dir, paste0(axis_stem, ".png")), p_axis,
       width = 183, height = 24, units = "mm", dpi = 420, bg = "white")

evidence <- read_tsv(evidence_file, show_col_types = FALSE)
states <- read_tsv(state_file, show_col_types = FALSE)
functions <- read_tsv(function_file, show_col_types = FALSE)
strict_cases <- evidence %>%
  filter(dataset == "archaea1338",
         retention_check_status == "complete_CPRR_supported_direction_free") %>%
  select(dataset, analysis_type, analysis_id)

short_function <- c(
  "archaea1338_SFV1_0000425" = "glmM / shikimate dehydrogenase",
  "archaea1338_SFV1_0000801" = "RhaB/XylB-like",
  "archaea1338_SFV1_0001024" = "B12-binding protein",
  "OG0000884" = "XylB", "OG0001037" = "alpha/beta hydrolase",
  "OG0001343" = "DUF362", "OG0002752" = "Rossmann oxidoreductase",
  "OG0004325" = "aldehyde:ferredoxin oxidoreductase",
  "OG0004729" = "ADP-ribosylglycohydrolase",
  "OG0006986" = "steroid dehydrogenase / DUF1295"
)
case_meta <- strict_cases %>%
  left_join(functions %>% select(dataset, analysis_type, analysis_id,
                                 function_theme, function_text),
            by = c("dataset", "analysis_type", "analysis_id")) %>%
  mutate(
    short_id = if_else(analysis_type == "merged_superfamily",
                       str_remove(analysis_id, "^archaea1338_"), analysis_id),
    function_short = unname(short_function[analysis_id]),
    case_label = paste0(short_id, "  |  ", function_short),
    case_order = row_number()
  )

case_states <- states %>%
  inner_join(strict_cases,
             by = c("dataset", "analysis_unit_type" = "analysis_type", "analysis_id")) %>%
  filter(!is.na(mag_id), mag_id != "") %>%
  transmute(
    analysis_id, mag_id,
    display_state = recode(MAG_state,
                           CL1_only = "A-only", coexist = "A+B coexist",
                           CL2_only = "B-only")
  ) %>%
  left_join(projection %>% select(mag_id, anchor_tip), by = "mag_id")

tip_case_states <- case_states %>%
  filter(!is.na(anchor_tip)) %>%
  group_by(analysis_id, gtdb_tip = anchor_tip) %>%
  summarise(
    n_MAGs = n_distinct(mag_id),
    observed_states = paste(sort(unique(display_state)), collapse = ";"),
    display_state = case_when(
      "A+B coexist" %in% display_state ~ "A+B coexist",
      n_distinct(display_state) == 1L ~ first(display_state),
      TRUE ~ "taxon collision"
    ),
    .groups = "drop"
  )

track_data <- crossing(
  case_meta %>% select(analysis_id, case_label, case_order),
  tip_order %>% select(gtdb_tip, tip_order)
) %>%
  left_join(tip_case_states, by = c("analysis_id", "gtdb_tip")) %>%
  mutate(
    display_state = replace_na(display_state, "no state"),
    case_label = factor(case_label, levels = rev(case_meta$case_label))
  )

p_tracks <- ggplot(track_data, aes(tip_order, case_label, fill = display_state)) +
  geom_raster(interpolate = FALSE) +
  scale_fill_manual(values = state_palette,
                    breaks = c("A-only", "A+B coexist", "B-only", "taxon collision"),
                    labels = c("A-only", "A+B coexist", "B-only",
                               "multiple MAG states at one GTDB tip"),
                    name = NULL, drop = FALSE) +
  scale_x_continuous(expand = c(0, 0)) +
  labs(x = NULL, y = NULL) +
  theme_void(base_family = "Arial", base_size = 6.5) +
  theme(
    axis.text.y = element_text(size = 5.6, colour = "#202020", hjust = 1,
                               margin = margin(r = 3.5)),
    legend.position = "top", legend.justification = "left",
    legend.text = element_text(size = 5.7, colour = "#303030"),
    legend.key.width = grid::unit(4.4, "mm"),
    legend.key.height = grid::unit(2.1, "mm"),
    legend.margin = margin(0, 0, 1.5, 0),
    plot.margin = margin(1, 1.5, 1, 1.5)
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE,
                             override.aes = list(colour = NA)))

track_stem <- "fig_A1338_positive_GTDB_projection_AB_tracks"
ggsave(file.path(plot_dir, paste0(track_stem, ".pdf")), p_tracks,
       width = 183, height = 54, units = "mm", device = cairo_pdf, bg = "white")
ggsave(file.path(plot_dir, paste0(track_stem, ".png")), p_tracks,
       width = 183, height = 54, units = "mm", dpi = 420, bg = "white")

write_tsv(projection, file.path(data_dir, "A1338_GTDB_projection_mapping.tsv"))
write_tsv(tip_order, file.path(data_dir, "A1338_GTDB_projection_tip_order.tsv"))
write_tsv(segments, file.path(data_dir, "A1338_GTDB_projection_phylum_segments.tsv"))
write_tsv(case_meta, file.path(data_dir, "A1338_positive_case_metadata.tsv"))
write_tsv(track_data, file.path(data_dir, "A1338_positive_GTDB_projection_track_source.tsv"))

strict_unique_mags <- unique(case_states$mag_id)
strict_projection_missing <- case_states %>% filter(is.na(anchor_tip)) %>% pull(mag_id) %>% unique()
marker <- c(
  "status=complete",
  "tree_type=GTDB_r226_reference_tree_pruned_by_A1338_taxon_name_projection",
  paste0("A1338_input_MAGs=", nrow(stage06)),
  paste0("unique_GTDB_tips_after_projection=", Ntip(projection_tree)),
  paste0("projection_unmapped_MAGs=", sum(!projection$projection_mapped)),
  paste0("phyla=", n_distinct(tip_order$p)),
  paste0("strict_positive_cases=", nrow(strict_cases)),
  paste0("strict_case_unique_MAGs=", length(strict_unique_mags)),
  paste0("strict_case_MAGs_missing_from_projection=", length(strict_projection_missing)),
  paste0("taxon_collision_cells=", sum(tip_case_states$display_state == "taxon collision")),
  "linear_axis_order=directly_unfolded_pruned_GTDB_r226_tree_outer_ring",
  "MAG_tips_grafted=false",
  "A_B_direction=undefined"
)
writeLines(marker, file.path(data_dir, "A1338_GTDB_projection_COMPLETE.marker"))
cat(paste(marker, collapse = "\n"), "\n")
