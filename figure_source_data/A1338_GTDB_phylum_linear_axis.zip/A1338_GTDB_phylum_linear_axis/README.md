# A1338_GTDB_phylum_linear_axis

- Manuscript panel: Supp.Fig.13A-part1
- Source figure basename: fig_A1338_GTDB_phylum_linear_axis
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 13 directly referenced or locally packaged source-data file(s)
