# 31_rhat_vs_delta_logL_scatter

- Manuscript panel: Fig.7H
- Source figure basename: fig_31_rhat_vs_delta_logL_scatter
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 4 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)
