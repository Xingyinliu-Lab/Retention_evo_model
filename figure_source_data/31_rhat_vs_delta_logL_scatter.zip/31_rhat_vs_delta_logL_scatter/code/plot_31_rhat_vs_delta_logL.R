#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("Usage: Rscript plot_31_rhat_vs_delta_logL.R input.tsv output_dir")
input_file <- args[[1]]
out <- args[[2]]
dir.create(out, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out, "source_data"), recursive = TRUE, showWarnings = FALSE)

dat <- read_tsv(input_file, show_col_types = FALSE) %>%
  transmute(
    case_id,
    og_id,
    functional_label,
    persistence_status = factor(
      if_else(
        p_persistence_one_sided < 0.05,
        "Reject r=1 (n=29)", "Cannot reject r=1 (n=2)"
      ),
      levels = c("Reject r=1 (n=29)", "Cannot reject r=1 (n=2)")
    ),
    r_hat,
    delta_logL = logL_free_r - logL_r1
  )

stopifnot(
  nrow(dat) == 31,
  all(dat$r_hat >= 1),
  all(dat$delta_logL >= -1e-8),
  sum(dat$persistence_status == "Reject r=1 (n=29)") == 29,
  sum(dat$persistence_status == "Cannot reject r=1 (n=2)") == 2
)
write_tsv(dat, file.path(out, "source_data", "fig_31_rhat_vs_delta_logL_source_data.tsv"))

ct <- cor.test(dat$r_hat, dat$delta_logL, method = "spearman", exact = FALSE)
stats <- tibble(
  n = nrow(dat),
  spearman_rho = unname(ct$estimate),
  spearman_p = ct$p.value,
  median_r_hat = median(dat$r_hat),
  median_delta_logL = median(dat$delta_logL)
)
write_tsv(stats, file.path(out, "source_data", "fig_31_rhat_vs_delta_logL_statistics.tsv"))

p <- ggplot(dat, aes(r_hat, delta_logL)) +
  geom_hline(yintercept = 0, linewidth = 0.35, linetype = "dashed", colour = "#8A8A8A") +
  geom_vline(xintercept = 1, linewidth = 0.35, linetype = "dashed", colour = "#8A8A8A") +
  geom_point(aes(fill = persistence_status), shape = 21, size = 1.9, stroke = 0.32,
             colour = "#25343A", alpha = 0.92) +
  scale_x_continuous(
    trans = "log2",
    breaks = c(1, 2, 4, 8, 16, 32, 64, 128),
    labels = label_number(accuracy = 1),
    limits = c(1, 128),
    expand = expansion(mult = c(0.015, 0.035))
  ) +
  labs(
    x = expression(hat(r)~"(log"[2]~"scale)"),
    y = expression(Delta*"log likelihood"~("free-"*r~"minus"~r==1)),
    subtitle = sprintf("31 matched OGs; Spearman r_s = %.3f, P = %.3g",
                       stats$spearman_rho, stats$spearman_p)
  ) +
  scale_fill_manual(values = c(
    "Reject r=1 (n=29)" = "#4F8791",
    "Cannot reject r=1 (n=2)" = "#D58A55"
  )) +
  theme_classic(base_size = 8, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "black"),
    axis.ticks = element_line(linewidth = 0.35, colour = "black"),
    axis.text = element_text(size = 7, colour = "black"),
    axis.title = element_text(size = 8, colour = "black"),
    plot.subtitle = element_text(size = 7, colour = "#333333"),
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 6.3),
    legend.key.width = grid::unit(4, "mm"),
    plot.margin = margin(5.5, 8, 5.5, 5.5)
  )

ggsave(file.path(out, "fig_31_rhat_vs_delta_logL_scatter.pdf"), p,
       device = cairo_pdf, width = 89/25.4, height = 82/25.4, units = "in")
ggsave(file.path(out, "fig_31_rhat_vs_delta_logL_scatter.png"), p,
       dpi = 500, width = 89/25.4, height = 82/25.4, units = "in", bg = "white")

writeLines(c(
  "status=complete",
  "backend=R",
  "n_cases=31",
  "figure=fig_31_rhat_vs_delta_logL_scatter.pdf"
), file.path(out, "FIGURE_COMPLETE.marker"))
