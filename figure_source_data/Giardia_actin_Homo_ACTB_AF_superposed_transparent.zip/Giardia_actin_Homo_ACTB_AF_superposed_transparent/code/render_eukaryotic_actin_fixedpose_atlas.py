"""Render four eukaryotic actins against the fixed Homo ACTB-AF anchor.

The camera, colors, transparency, lighting and ray settings reproduce
H_Volactin_like_Homo_ACTB_AF_superposed_transparent.png. Source models are
read-only. Outputs are transparent PNG files plus a compact alignment audit.
"""

from csv import DictWriter
from math import acos, degrees, sqrt
from pathlib import Path

from pymol import cmd


TAIL_ROOT = Path(r"..")
COMPLEX_ROOT = Path(
    r".."
)
POSE_REFERENCE = Path(r"..")
OUT = Path(
    r".."
    r"fig3_tail_is_important/eukaryotic_actin_fixedpose_atlas"
)

ACTB_AF = TAIL_ROOT / "Homo_actb_AF-P60709-F1-model_v6.cif"

CASES = [
    {
        "label": "Tetrahymena_actin",
        "species": "Tetrahymena thermophila strain SB210",
        "accession": "I7MG63",
        "model": COMPLEX_ROOT
        / "fold_tail_mutant_euk_tetrahymena_actin_wt_natural_non_kcf_model_0.cif",
        "model_type": "AlphaFold Server model 0",
    },
    {
        "label": "Giardia_actin",
        "species": "Giardia duodenalis assemblage B",
        "accession": "A0A132NN04",
        "model": TAIL_ROOT / "Giardia_act_AF-A0A132NN04-F1-model_v6.cif",
        "model_type": "AlphaFold DB model v6",
    },
    {
        "label": "Rabbit_ACTA1",
        "species": "Oryctolagus cuniculus",
        "accession": "P68135",
        "model": COMPLEX_ROOT
        / "fold_tail_mutant_euk_rabbit_acta1_8f8p_wt_model_0.cif",
        "model_type": "AlphaFold Server model 0",
    },
    {
        "label": "Yeast_actin",
        "species": "Saccharomyces cerevisiae strain S288c",
        "accession": "P60010",
        "model": TAIL_ROOT / "yeast_act_AF-P60010-F1-model_v6.cif",
        "model_type": "AlphaFold DB model v6",
    },
]


def centroid(selection):
    atoms = cmd.get_model(selection).atom
    if not atoms:
        raise ValueError(f"Empty selection: {selection}")
    return [sum(atom.coord[i] for atom in atoms) / len(atoms) for i in range(3)]


def fixedpose_transform():
    core = centroid("pose_ref and chain E and resi 1-340 and not hydro")
    tail = centroid("pose_ref and chain E and resi 351-375 and not hydro")
    vector = [tail[i] - core[i] for i in range(3)]
    norm = sqrt(sum(x * x for x in vector))
    vector = [x / norm for x in vector]
    target = [-0.36, 0.20, 0.91]
    target_norm = sqrt(sum(x * x for x in target))
    target = [x / target_norm for x in target]
    axis = [
        vector[1] * target[2] - vector[2] * target[1],
        vector[2] * target[0] - vector[0] * target[2],
        vector[0] * target[1] - vector[1] * target[0],
    ]
    axis_norm = sqrt(sum(x * x for x in axis))
    axis = [x / axis_norm for x in axis]
    angle = degrees(
        acos(max(-1.0, min(1.0, sum(vector[i] * target[i] for i in range(3)))))
    )
    return core, axis, angle


def color_blue_gradient(obj):
    residues = sorted(
        {int(atom.resi) for atom in cmd.get_model(obj).atom if atom.resi.lstrip("-").isdigit()}
    )
    if not residues:
        raise ValueError(f"No integer residue identifiers in {obj}")
    first, last = residues[0], residues[-1]
    for index in range(75):
        lo = first + (last - first + 1) * index // 75
        hi = first + (last - first + 1) * (index + 1) // 75 - 1
        cmd.color(f"blue_{index:02d}", f"{obj} and resi {lo}-{hi}")


def configure_scene():
    cmd.reinitialize()
    cmd.set_color("ink", [0.071, 0.094, 0.133])
    cmd.set_color("actb_green", [0.20, 0.78, 0.47])
    cmd.set_color("tail_orange", [0.96, 0.40, 0.10])
    cmd.set_color("terminal_magenta", [0.90, 0.23, 0.53])
    for index in range(75):
        fraction = index / 74
        start = [0.298, 0.471, 0.659]
        end = [0.420, 0.620, 0.700]
        cmd.set_color(
            f"blue_{index:02d}",
            [start[k] * (1 - fraction) + end[k] * fraction for k in range(3)],
        )
    cmd.bg_color("ink")
    cmd.set("ray_opaque_background", 0)
    cmd.set("orthoscopic", 0)
    cmd.set("antialias", 2)
    cmd.set("ambient", 0.20)
    cmd.set("direct", 0.80)
    cmd.set("specular", 0.32)
    cmd.set("shininess", 40)
    cmd.set("ray_shadows", 1)
    cmd.set("ambient_occlusion_mode", 2)
    cmd.set("depth_cue", 1)
    cmd.set("fog", 1)
    cmd.set("fog_start", 0.35)
    cmd.set("cartoon_fancy_helices", 1)
    cmd.set("stick_radius", 0.18)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for case in CASES:
        if not case["model"].exists():
            raise FileNotFoundError(case["model"])

    configure_scene()
    cmd.load(str(POSE_REFERENCE), "pose_ref")
    cmd.load(str(ACTB_AF), "actb_af")
    cmd.align("actb_af", "pose_ref and chain E")
    core, axis, angle = fixedpose_transform()
    cmd.translate([-core[0], -core[1], -core[2]], "actb_af", camera=0)
    cmd.rotate(axis, angle, "actb_af", camera=0)
    cmd.dss("actb_af")

    audit_rows = []
    for case in CASES:
        query = "query"
        cmd.load(str(case["model"]), query)
        alignment = cmd.super(query, "actb_af")

        cmd.hide("everything")
        cmd.show("cartoon", "actb_af")
        cmd.color("actb_green", "actb_af")
        cmd.set("cartoon_transparency", 0.40, "actb_af")
        cmd.color("tail_orange", "actb_af and resi 351-372")
        cmd.color("terminal_magenta", "actb_af and resi 373-375")

        cmd.show("cartoon", query)
        color_blue_gradient(query)
        cmd.set("cartoon_transparency", 0.00, query)
        cmd.zoom("actb_af or query", 6)
        cmd.ray(2400, 1800)
        output = OUT / f"{case['label']}_Homo_ACTB_AF_superposed_transparent.png"
        cmd.png(str(output), dpi=300)
        cmd.sync()

        audit_rows.append(
            {
                "label": case["label"],
                "species": case["species"],
                "accession": case["accession"],
                "model_type": case["model_type"],
                "model_file": case["model"].name,
                "query_residue_count": cmd.count_atoms(f"{query} and name CA"),
                "actb_reference": ACTB_AF.name,
                "alignment_method": "PyMOL super",
                "post_refinement_rmsd_A": alignment[0],
                "post_refinement_aligned_atoms": alignment[1],
                "pre_refinement_rmsd_A": alignment[3],
                "pre_refinement_aligned_atoms": alignment[4],
                "raw_alignment_score": alignment[5],
                "alignment_cycles": alignment[6],
                "output_png": output.name,
            }
        )
        cmd.delete(query)

    audit_path = OUT / "eukaryotic_actin_fixedpose_alignment_audit.tsv"
    with audit_path.open("w", newline="", encoding="utf-8") as handle:
        writer = DictWriter(handle, fieldnames=list(audit_rows[0]))
        writer.writeheader()
        writer.writerows(audit_rows)
    cmd.quit()


if __name__ == "__main__":
    main()
