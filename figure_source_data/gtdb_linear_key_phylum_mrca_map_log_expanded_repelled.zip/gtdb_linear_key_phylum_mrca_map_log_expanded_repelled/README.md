# gtdb_linear_key_phylum_mrca_map_log_expanded_repelled

- Manuscript panel: Fig.8A-part1
- Source figure basename: fig_gtdb_linear_key_phylum_mrca_map_log_expanded_repelled
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 3 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 10 directly referenced or locally packaged source-data file(s)
