#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(ragg)
})

root <- ".."
current_dir <- file.path(root, "current_canonical_tail")
data_dir <- file.path(current_dir, "data")
figure_dir <- file.path(current_dir, "figures")
source_dir <- file.path(
  data_dir,
  "kt_gtdb_r226_key_phylum_mrca_map_20260718"
)

key <- read_tsv(
  file.path(source_dir, "gtdb_r226_key_phylum_mrca_map_summary.tsv"),
  show_col_types = FALSE
)

stopifnot(
  nrow(key) == 12,
  all(key$gtdb_release == "r226"),
  all(key$n_gtdb_reference_tips > 0),
  all(!is.na(key$mrca_depth_norm))
)

phylum_colors <- c(
  "Methanobacteriota" = "#3E7CB1",
  "Hadarchaeota" = "#9C755F",
  "Methanobacteriota_B" = "#76B7B2",
  "Thermoplasmatota" = "#E15759",
  "Halobacteriota" = "#F28E2B",
  "Altiarchaeota" = "#B07AA1",
  "Asgardarchaeota" = "#59A14F",
  "Thermoproteota" = "#EDC948",
  "Nanobdellota" = "#4E79A7",
  "Iainarchaeota" = "#FF9DA7",
  "Aenigmatarchaeota" = "#8CD17D",
  "Micrarchaeota" = "#BAB0AC"
)

plot_source <- key %>%
  arrange(x_log_plot, desc(n_gtdb_reference_tips), p) %>%
  mutate(
    interval_start = c(
      max(0, x_log_plot[1] - (x_log_plot[2] - x_log_plot[1]) / 2),
      head((x_log_plot + lead(x_log_plot)) / 2, -1)
    ),
    interval_end = c(
      head((x_log_plot + lead(x_log_plot)) / 2, -1),
      min(
        1,
        x_log_plot[n()] + (x_log_plot[n()] - x_log_plot[n() - 1]) / 2
      )
    ),
    label_row = c(0L, 1L, 2L, 3L, 0L, 2L, 1L, 3L, 0L, 1L, 2L, 3L),
    label_y = c(0.58, 1.02, 1.46, 1.90)[label_row + 1L],
    label_text = paste0(
      p,
      "\nref=", n_gtdb_reference_tips,
      "; actin MAG=", actin_mag_n
    ),
    label_x = case_when(
      p == "Methanobacteriota" ~ 0.34,
      p == "Halobacteriota" ~ 0.47,
      p == "Nanobdellota" ~ 0.60,
      p == "Hadarchaeota" ~ 0.37,
      p == "Asgardarchaeota" ~ 0.50,
      p == "Iainarchaeota" ~ 0.63,
      p == "Methanobacteriota_B" ~ 0.39,
      p == "Altiarchaeota" ~ 0.52,
      p == "Aenigmatarchaeota" ~ 0.65,
      p == "Thermoplasmatota" ~ 0.41,
      p == "Thermoproteota" ~ 0.55,
      p == "Micrarchaeota" ~ 0.69,
      TRUE ~ x_log_plot
    )
  )

window_start_raw <- min(plot_source$interval_start)
window_end_raw <- max(plot_source$interval_end)
display_left <- 0.22
display_right <- 0.78

expand_middle_window <- function(x) {
  ifelse(
    x <= window_start_raw,
    display_left * x / window_start_raw,
    ifelse(
      x <= window_end_raw,
      display_left +
        (display_right - display_left) *
          (x - window_start_raw) / (window_end_raw - window_start_raw),
      display_right +
        (1 - display_right) *
          (x - window_end_raw) / (1 - window_end_raw)
    )
  )
}

plot_source <- plot_source %>%
  mutate(
    x_log_plot_raw = x_log_plot,
    interval_start_raw = interval_start,
    interval_end_raw = interval_end,
    label_x_raw = label_x,
    x_log_plot = expand_middle_window(x_log_plot),
    interval_start = expand_middle_window(interval_start),
    interval_end = expand_middle_window(interval_end),
    label_x = case_when(
      p %in% c("Methanobacteriota", "Hadarchaeota",
               "Methanobacteriota_B", "Thermoplasmatota") ~ 0.30,
      p %in% c("Halobacteriota", "Asgardarchaeota",
               "Altiarchaeota", "Thermoproteota") ~ 0.50,
      p %in% c("Nanobdellota", "Iainarchaeota",
               "Aenigmatarchaeota", "Micrarchaeota") ~ 0.70,
      TRUE ~ expand_middle_window(label_x)
    )
  )

window_start <- display_left
window_end <- display_right
original_depth_breaks <- c(0, 0.01, 0.025, 0.05, 0.10, 0.15, 0.20, 0.30, 0.50, 1)
log_depth_breaks <- log1p(99 * original_depth_breaks) / log(100)
display_depth_breaks <- expand_middle_window(log_depth_breaks)

write_tsv(
  plot_source %>%
    mutate(label_text = gsub("\n", " | ", label_text, fixed = TRUE)),
  file.path(data_dir, "fig_gtdb_r226_key_phylum_mrca_map_plot_source.tsv")
)
write_tsv(
  tibble(
    metric = c(
      "gtdb_release",
      "reference_tip_n",
      "taxonomy_mapped_reference_tip_n",
      "all_phylum_n",
      "key_phylum_n",
      "minimum_reference_tips",
      "figure_status"
    ),
    value = c(
      "r226",
      "6968",
      "6968",
      "21",
      as.character(nrow(plot_source)),
      "50",
      "strict_complete_frozen_context_figure"
    )
  ),
  file.path(data_dir, "fig_gtdb_r226_key_phylum_mrca_map_audit.tsv")
)

p <- ggplot(plot_source) +
  annotate(
    "segment",
    x = 0,
    xend = 1,
    y = 0,
    yend = 0,
    linewidth = 6.2,
    colour = "#C8CDD5",
    lineend = "butt"
  ) +
  geom_segment(
    aes(
      x = interval_start,
      xend = interval_end,
      y = 0,
      yend = 0,
      colour = p
    ),
    linewidth = 6.2,
    lineend = "butt",
    alpha = 0.92
  ) +
  annotate(
    "segment",
    x = 0,
    xend = window_start,
    y = -0.14,
    yend = -0.14,
    linewidth = 0.55,
    colour = "#7C8799"
  ) +
  annotate(
    "segment",
    x = window_start,
    xend = window_end,
    y = -0.14,
    yend = -0.14,
    linewidth = 0.55,
    colour = "#465166"
  ) +
  annotate(
    "segment",
    x = window_end,
    xend = 1,
    y = -0.14,
    yend = -0.14,
    linewidth = 0.55,
    colour = "#7C8799"
  ) +
  annotate(
    "text",
    x = window_start / 2,
    y = -0.24,
    label = "shared archaeal stem",
    family = "Arial",
    size = 2.45,
    colour = "#667085"
  ) +
  annotate(
    "text",
    x = (window_start + window_end) / 2,
    y = -0.24,
    label = "phylum MRCA window",
    family = "Arial",
    size = 2.45,
    colour = "#465166"
  ) +
  annotate(
    "text",
    x = (window_end + 1) / 2,
    y = -0.24,
    label = "within-phylum diversification to tips",
    family = "Arial",
    size = 2.45,
    colour = "#667085"
  ) +
  geom_segment(
    aes(
      x = x_log_plot,
      xend = label_x,
      y = 0.08,
      yend = label_y - 0.07,
      colour = p
    ),
    linewidth = 0.48,
    alpha = 0.82
  ) +
  geom_text(
    aes(
      x = label_x,
      y = label_y,
      label = label_text,
      colour = p
    ),
    family = "Arial",
    size = 2.10,
    lineheight = 0.92,
    hjust = 0.5,
    fontface = "plain"
  ) +
  annotate(
    "text",
    x = 0,
    y = -0.43,
    label = "GTDB r226 root",
    family = "Arial",
    size = 2.65,
    hjust = 0,
    colour = "#555555"
  ) +
  annotate(
    "text",
    x = 1,
    y = -0.43,
    label = "GTDB r226 tips",
    family = "Arial",
    size = 2.65,
    hjust = 1,
    colour = "#555555"
  ) +
  scale_colour_manual(values = phylum_colors, guide = "none") +
  scale_fill_manual(values = phylum_colors, guide = "none") +
  scale_x_continuous(
    limits = c(-0.015, 1.015),
    breaks = display_depth_breaks,
    labels = c("0", "0.01", "0.025", "0.05", "0.1", "0.15", "0.2", "0.3", "0.5", "1"),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(limits = c(-0.62, 2.35), expand = expansion(mult = 0)) +
  labs(
    title = "GTDB r226 archaeal tree linearized by phylum MRCA nodes",
    subtitle = "Log-expanded normalized depth; labels repelled across four tiers",
    caption = paste0(
      "Tick labels show original normalized depth. The phylum window is expanded ",
      "piecewise for readability; source and display coordinates are both provided. ",
      "MRCA is a relative position, not an absolute date."
    ),
    x = "normalized GTDB r226 root-to-MRCA depth (log-expanded display)",
    y = NULL
  ) +
  theme_minimal(base_family = "Arial", base_size = 8.2) +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E5E7EB"),
    axis.line = element_blank(),
    axis.ticks.x = element_line(linewidth = 0.3, colour = "#7C8799"),
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 7.4, colour = "#566174"),
    axis.title.x = element_text(size = 8.0, colour = "#465166", margin = margin(t = 10)),
    plot.title = element_text(face = "plain", size = 11.2, colour = "#111111", hjust = 0.5),
    plot.subtitle = element_text(size = 8.0, colour = "#667085", hjust = 0.5),
    plot.caption = element_text(size = 6.6, colour = "#667085", hjust = 0.5),
    legend.position = "none",
    plot.margin = margin(10, 16, 12, 12)
  ) +
  coord_cartesian(clip = "off")

stem <- file.path(
  figure_dir,
  "fig_gtdb_linear_key_phylum_mrca_map_log_expanded_repelled"
)
ggsave(
  paste0(stem, ".pdf"),
  p,
  width = 12.6,
  height = 4.7,
  units = "in",
  device = cairo_pdf
)
agg_png(
  paste0(stem, ".png"),
  width = 12.6,
  height = 4.7,
  units = "in",
  res = 600
)
print(p)
dev.off()

message("Saved GTDB r226 key-phylum MRCA map with 12 key phyla")
