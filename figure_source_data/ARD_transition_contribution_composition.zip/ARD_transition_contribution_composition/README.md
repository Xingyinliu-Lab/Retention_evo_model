# ARD_transition_contribution_composition

- Manuscript panel: Fig.5J
- Source figure basename: fig_ARD_transition_contribution_composition_corrected_20260901
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 12 directly referenced or locally packaged source-data file(s)
