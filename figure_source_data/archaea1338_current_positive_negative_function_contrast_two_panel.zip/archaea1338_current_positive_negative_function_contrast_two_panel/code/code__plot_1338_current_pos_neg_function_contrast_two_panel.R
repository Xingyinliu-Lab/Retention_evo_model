#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(forcats)
  library(ggplot2)
  library(patchwork)
  library(readr)
  library(scales)
  library(stringr)
  library(tidyr)
})

root <- ".."
current_dir <- file.path(root, "current_canonical_tail")
data_dir <- file.path(current_dir, "data")
figure_dir <- file.path(current_dir, "figures")

contrast <- read_tsv(
  file.path(data_dir, "fig14_1338_current_pos_neg_function_overlap_contrast_source.tsv"),
  show_col_types = FALSE
) %>%
  mutate(
    log2_odds_ratio_pseudocount = log2(
      ((positive_count + 0.5) / (positive_total - positive_count + 0.5)) /
        ((negative_count + 0.5) / (negative_total - negative_count + 0.5))
    )
  )

stopifnot(
  nrow(contrast) == 15,
  all(contrast$positive_total == 615),
  all(contrast$negative_total == 600)
)

plot_source <- contrast %>%
  mutate(
    functional_group_display = functional_group_v2,
    significance = case_when(
      fisher_qvalue_bh < 0.05 & log2_odds_ratio_pseudocount > 0 ~
        "Positive-enriched, BH FDR < 0.05",
      fisher_qvalue_bh < 0.05 & log2_odds_ratio_pseudocount < 0 ~
        "Negative-enriched, BH FDR < 0.05",
      TRUE ~ "Not BH-significant"
    ),
    combined_count = positive_count + negative_count
  ) %>%
  arrange(log2_odds_ratio_pseudocount) %>%
  mutate(
    functional_group_display = factor(
      functional_group_display,
      levels = functional_group_display
    )
  )

write_tsv(
  plot_source,
  file.path(data_dir, "fig17_1338_current_pos_neg_function_contrast_two_panel_source.tsv")
)
write_tsv(
  tibble(
    check = c(
      "input_function_groups_after_biological_split",
      "displayed_resolved_function_groups",
      "unresolved_function_rows_displayed",
      "positive_fraction_denominator",
      "negative_fraction_denominator"
    ),
    value = c(
      nrow(plot_source),
      nrow(plot_source),
      sum(plot_source$functional_group_v2 == "unresolved_function"),
      unique(plot_source$positive_total),
      unique(plot_source$negative_total)
    )
  ),
  file.path(data_dir, "fig17_unresolved_function_exclusion_audit.tsv")
)

fraction_source <- plot_source %>%
  select(
    functional_group_display,
    `Positive: 615 OGs` = positive_fraction,
    `Negative: 600 OGs` = negative_fraction
  ) %>%
  pivot_longer(
    cols = c(`Positive: 615 OGs`, `Negative: 600 OGs`),
    names_to = "selection_set",
    values_to = "fraction"
  ) %>%
  mutate(
    signed_fraction = if_else(
      selection_set == "Negative: 600 OGs",
      -fraction,
      fraction
    ),
    selection_set = factor(
      selection_set,
      levels = c("Negative: 600 OGs", "Positive: 615 OGs")
    )
  )

font_family <- "Arial"
blue <- "#2F6FA3"
orange <- "#C9823F"
neutral <- "#B9C0C9"
dark <- "#243247"

theme_current <- function(base_size = 7.6) {
  theme_classic(base_size = base_size, base_family = font_family) +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = dark),
      axis.ticks = element_line(linewidth = 0.35, colour = dark),
      axis.text = element_text(colour = "#273548"),
      plot.title = element_text(face = "bold", size = base_size + 1),
      plot.subtitle = element_text(size = base_size - 0.1, colour = "#53627A"),
      legend.title = element_text(face = "bold"),
      panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E4E9F0"),
      panel.grid.minor = element_blank(),
      plot.margin = margin(6, 7, 6, 7)
    )
}

panel_a <- ggplot(
  fraction_source,
  aes(
    x = signed_fraction,
    y = functional_group_display,
    fill = selection_set
  )
) +
  geom_col(width = 0.67, alpha = 0.94) +
  geom_vline(xintercept = 0, linewidth = 0.4, colour = "#596579") +
  scale_fill_manual(
    values = c(
      "Negative: 600 OGs" = orange,
      "Positive: 615 OGs" = blue
    ),
    guide = "none"
  ) +
  scale_x_continuous(
    labels = function(x) percent(abs(x), accuracy = 1),
    breaks = seq(-0.4, 0.3, 0.1),
    expand = expansion(mult = c(0.02, 0.02))
  ) +
  labs(
    title = "a  Functional composition",
    subtitle = "Negative fractions extend left; positive fractions extend right",
    x = "Fraction of frozen set",
    y = NULL
  ) +
  theme_current(7.6) +
  theme(
    panel.grid.major.y = element_blank(),
    legend.position = "none",
    axis.text.y = element_text(size = 6.9)
  )

panel_b <- ggplot(
  plot_source,
  aes(
    x = log2_odds_ratio_pseudocount,
    y = functional_group_display
  )
) +
  geom_vline(
    xintercept = 0,
    linewidth = 0.4,
    linetype = "dashed",
    colour = "#596579"
  ) +
  geom_segment(
    aes(x = 0, xend = log2_odds_ratio_pseudocount, yend = functional_group_display),
    linewidth = 0.45,
    colour = "#C4CAD2"
  ) +
  geom_point(
    aes(size = combined_count, fill = significance),
    shape = 21,
    colour = "white",
    stroke = 0.35,
    alpha = 0.96
  ) +
  scale_fill_manual(
    values = c(
      "Positive-enriched, BH FDR < 0.05" = blue,
      "Negative-enriched, BH FDR < 0.05" = orange,
      "Not BH-significant" = neutral
    ),
    breaks = c(
      "Positive-enriched, BH FDR < 0.05",
      "Negative-enriched, BH FDR < 0.05",
      "Not BH-significant"
    ),
    labels = c("Positive FDR<0.05", "Negative FDR<0.05", "Not significant"),
    name = NULL
  ) +
  scale_size_continuous(
    range = c(2.5, 7.5),
    breaks = c(50, 100, 200, 400),
    guide = "none"
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  labs(
    title = "b  Positive versus negative contrast",
    subtitle = "Two-sided Fisher tests\nBenjamini-Hochberg correction",
    x = "log2 odds ratio (positive versus negative)",
    y = NULL
  ) +
  theme_current(7.6) +
  theme(
    panel.grid.major.y = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.text = element_text(size = 6.3),
    legend.key.width = grid::unit(3.5, "mm")
  )

figure <- panel_a | panel_b
figure <- figure +
  plot_layout(widths = c(1.12, 1)) +
  plot_annotation(
    title = "Archaea1338 functional composition and positive-negative contrast",
    subtitle = "Current canonical/tail strategy and functional classification v2",
    caption = paste0(
      "Positive set: 615 non-direct OGs; negative set: 600 frozen OGs; point size = total OG count.\n",
      "Functional annotation is interpretive and does not contribute to association ranking."
    ),
    theme = theme(
      text = element_text(family = font_family, colour = dark),
      plot.title = element_text(face = "bold", size = 10),
      plot.subtitle = element_text(size = 8.2, colour = "#53627A"),
      plot.caption = element_text(size = 6.7, colour = "#65748A", hjust = 0)
    )
  )

stem <- file.path(
  figure_dir,
  "fig17_archaea1338_current_positive_negative_function_contrast_two_panel"
)

grDevices::cairo_pdf(
  paste0(stem, ".pdf"),
  width = 190 / 25.4,
  height = 132 / 25.4,
  family = font_family
)
print(figure)
grDevices::dev.off()

ragg::agg_png(
  paste0(stem, ".png"),
  width = 190,
  height = 132,
  units = "mm",
  res = 600,
  background = "white"
)
print(figure)
grDevices::dev.off()

message("Saved current two-panel functional contrast figure")
