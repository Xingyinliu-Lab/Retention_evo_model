# pymol_7PLZ_native_rabbit_ACTA1_KCF_myosinVa_exact7W50view_residuepatch

- Manuscript panel: Supp.Fig.9H
- Source figure basename: fig_pymol_7PLZ_native_rabbit_ACTA1_KCF_myosinVa_exact7W50view_residuepatch
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
