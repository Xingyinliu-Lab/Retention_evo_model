# formal80_unit_ARD_contribution_vs_likelihood_delta

- Manuscript panel: Supp.Fig.13B
- Source figure basename: fig_formal80_unit_ARD_contribution_vs_likelihood_delta
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 5 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 79 directly referenced or locally packaged source-data file(s)
