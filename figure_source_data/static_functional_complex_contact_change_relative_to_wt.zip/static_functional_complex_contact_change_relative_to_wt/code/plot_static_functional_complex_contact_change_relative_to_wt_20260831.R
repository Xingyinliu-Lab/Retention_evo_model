#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

root <- ".."
detail_file <- file.path(
  root, "source_data/static_tail_full156_residue_contacts_20260804",
  "static_tail_full156_residue_model_detail.tsv"
)
context_file <- file.path(
  root, "source_data/delta_kcf_fullscreen_template_context_audit.tsv"
)
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")
manuscript_dir <- paste0(
  "..",
  "figures/fig3_tail_is_important"
)

detail <- read_tsv(detail_file, show_col_types = FALSE)
context <- read_tsv(context_file, show_col_types = FALSE) %>%
  select(template, partner_family_frozen, context_final, broad_context)

stopifnot(
  n_distinct(detail$template) == 142L,
  setequal(unique(detail$organism), c("Human ACTB", "Rabbit ACTA1")),
  setequal(unique(detail$state), c("WT", "Delta KCF", "Delta tail25")),
  all(detail$actin_ref_position %in% 1:375)
)

# Preserve the frozen partner-family assignment. Only the heterogeneous
# frozen "other" bin is refined, using the pre-existing context audit.
template_map <- detail %>%
  distinct(template, partner_family) %>%
  left_join(context, by = "template") %>%
  mutate(
    functional_category = case_when(
      partner_family != "other" ~ partner_family,
      context_final == "monomer_handling_profilin" ~ "profilin",
      context_final %in% c(
        "nucleation_branching_Arp2_3",
        "nucleation_branching_Arp2_3_actin_related_subunit"
      ) ~ "Arp2/3",
      context_final == "nucleation_elongation_formin_WH2" ~ "formin-WH2",
      context_final == "monomer_handling_DNaseI" ~ "DNase I",
      context_final == "monomer_sensor_MRTF_MAL_RPEL" ~ "MRTF/MAL-RPEL",
      context_final == "monomer_sensor_PHACTR_RPEL" ~ "PHACTR-RPEL",
      context_final == "monomer_sequestration_transport_vitamin_D_binding" ~
        "vitamin D-binding protein",
      context_final == "pathogen_toxin_effector_actin_complex" ~
        "pathogen effector",
      context_final == "filament_polymer_F_actin" ~ "actin-actin filament",
      context_final == "filament_remodeling_archaeal_2DGel" ~
        "archaeal 2DGel",
      context_final == "nuclear_chromatin_actin_complex" ~
        "nuclear/chromatin complex",
      context_final == "small_molecule_or_natural_product_actin_state" ~
        "small-molecule-bound actin",
      TRUE ~ "residual other"
    ),
    mapping_rule = if_else(
      partner_family == "other",
      paste0("refined from frozen context_final: ", context_final),
      "retained frozen partner_family"
    )
  )

stopifnot(
  nrow(template_map) == 142L,
  !anyNA(template_map$functional_category),
  sum(template_map$functional_category == "residual other") == 0L
)

category_counts <- template_map %>%
  count(functional_category, name = "n_templates") %>%
  arrange(desc(n_templates), functional_category)

display_names <- c(
  "ADF/cofilin" = "ADF/cofilin",
  "gelsolin" = "Gelsolin",
  "myosin" = "Myosin",
  "profilin" = "Profilin",
  "formin" = "Formin",
  "WH2/thymosin" = "WH2/thymosin",
  "crosslinker" = "Crosslinker",
  "Arp2/3" = "Arp2/3",
  "cytoskeletal_partner" = "Cytoskeletal partner",
  "formin-WH2" = "Formin-WH2",
  "DNase I" = "DNase I",
  "MRTF/MAL-RPEL" = "MRTF/MAL-RPEL",
  "PHACTR-RPEL" = "PHACTR-RPEL",
  "vitamin D-binding protein" = "Vitamin D-binding protein",
  "pathogen effector" = "Pathogen effector",
  "actin-actin filament" = "Actin-actin filament",
  "archaeal 2DGel" = "Archaeal 2DGel",
  "nuclear/chromatin complex" = "Nuclear/chromatin complex",
  "small-molecule-bound actin" = "Small-molecule-bound actin"
)

category_counts <- category_counts %>%
  mutate(
    category_display = unname(display_names[functional_category]),
    facet_label = paste0(category_display, " (n=", n_templates, ")")
  )
stopifnot(!anyNA(category_counts$category_display))

paired <- detail %>%
  inner_join(template_map %>% select(template, functional_category), by = "template") %>%
  mutate(
    contact_observed = if_else(coordinate_observed == 1, as.numeric(contact_5A), NA_real_)
  ) %>%
  select(
    template, organism, functional_category, actin_ref_position,
    state, contact_observed
  ) %>%
  pivot_wider(names_from = state, values_from = contact_observed) %>%
  pivot_longer(
    cols = c(`Delta KCF`, `Delta tail25`),
    names_to = "variant", values_to = "variant_contact"
  ) %>%
  mutate(
    paired_delta_contact = if_else(
      is.finite(WT) & is.finite(variant_contact), variant_contact - WT, NA_real_
    )
  )

summary_df <- paired %>%
  group_by(functional_category, variant, actin_ref_position) %>%
  summarise(
    n_paired_models = sum(is.finite(paired_delta_contact)),
    n_templates_paired = n_distinct(template[is.finite(paired_delta_contact)]),
    mean_delta_contact = if_else(
      n_paired_models > 0L, mean(paired_delta_contact, na.rm = TRUE), NA_real_
    ),
    sd_paired_delta = if_else(
      n_paired_models > 1L, sd(paired_delta_contact, na.rm = TRUE), NA_real_
    ),
    se_paired_delta = sd_paired_delta / sqrt(n_paired_models),
    .groups = "drop"
  ) %>%
  left_join(category_counts, by = "functional_category") %>%
  mutate(
    variant = factor(variant, levels = c("Delta KCF", "Delta tail25")),
    facet_label = factor(
      facet_label,
      levels = category_counts$facet_label
    ),
    comparison = "paired variant contact indicator minus WT contact indicator",
    contact_cutoff_A = 5,
    organism_pool = "Human ACTB and Rabbit ACTA1 pooled"
  )

# Deleted residues must remain absent rather than being encoded as zero change.
stopifnot(
  all(is.na(summary_df$mean_delta_contact[
    summary_df$variant == "Delta tail25" & summary_df$actin_ref_position >= 351
  ])),
  all(is.na(summary_df$mean_delta_contact[
    summary_df$variant == "Delta KCF" & summary_df$actin_ref_position >= 373
  ]))
)

map_out <- file.path(
  source_dir, "static_functional_complex_template_category_mapping.tsv"
)
source_out <- file.path(
  source_dir, "fig_static_functional_complex_contact_change_relative_to_wt_source.tsv"
)
write_tsv(template_map %>% arrange(functional_category, template), map_out)
write_tsv(summary_df, source_out)

cols <- c("Delta KCF" = "#D2765D", "Delta tail25" = "#3E6F9E")

p <- ggplot(
  summary_df,
  aes(x = actin_ref_position, y = mean_delta_contact, colour = variant)
) +
  annotate(
    "rect", xmin = 351, xmax = 372.5, ymin = -Inf, ymax = Inf,
    fill = "#E8EDF1", alpha = 0.55
  ) +
  annotate(
    "rect", xmin = 372.5, xmax = 375.5, ymin = -Inf, ymax = Inf,
    fill = "#F2DED6", alpha = 0.66
  ) +
  geom_hline(yintercept = 0, linewidth = 0.32, linetype = "22", colour = "#555555") +
  geom_line(linewidth = 0.48, na.rm = TRUE) +
  facet_wrap(~facet_label, ncol = 4, axes = "all", axis.labels = "all") +
  scale_colour_manual(
    values = cols, name = NULL,
    labels = c(
      "Delta KCF" = expression(Delta*KCF),
      "Delta tail25" = expression(Delta*tail25)
    )
  ) +
  scale_x_continuous(
    breaks = c(1, 100, 200, 300, 375),
    limits = c(1, 375.5),
    expand = expansion(mult = c(0.005, 0.01))
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(-1, 1), breaks = c(-1, -0.5, 0, 0.5, 1)
  ) +
  labs(
    title = "Static actin-partner contact changes relative to WT",
    subtitle = paste0(
      "Paired 5 A contact changes across 142 templates; human ACTB and rabbit ACTA1 pooled by functional context"
    ),
    x = "Human ACTB-aligned residue position",
    y = "Mean change in paired contact support",
    caption = paste0(
      "Each line is the mean of paired variant-minus-WT contact indicators for the same template, actin background and residue. ",
      "n denotes experimental templates; both actin backgrounds are pooled. Deleted residues are left blank.\n",
      "Pale blue-grey and coral regions mark tail-body (351-372) and terminal-KCF (373-375) coordinates. ",
      "Static 5 A geometry does not measure affinity or in-vivo function."
    )
  ) +
  theme_classic(base_family = "Arial", base_size = 7.6) +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.30, colour = "#222222"),
    axis.text = element_text(colour = "#222222", size = 5.7),
    axis.title = element_text(size = 7.1),
    strip.background = element_rect(fill = "#F1F3F5", colour = NA),
    strip.text = element_text(face = "bold", size = 6.3, margin = margin(2.5, 1, 2.5, 1)),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 6.8),
    legend.key.width = grid::unit(6.5, "mm"),
    panel.spacing.x = grid::unit(1.4, "mm"),
    panel.spacing.y = grid::unit(2.2, "mm"),
    panel.grid.major.y = element_line(linewidth = 0.18, colour = "#ECECEC"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 10),
    plot.subtitle = element_text(size = 7.4, colour = "#555555"),
    plot.caption = element_text(size = 5.8, colour = "#666666", hjust = 0),
    plot.margin = margin(7, 8, 7, 7)
  )

stem <- file.path(
  figure_dir, "fig_static_functional_complex_contact_change_relative_to_wt"
)
ggsave(
  paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
  width = 183, height = 225, units = "mm", family = "Arial", bg = "white"
)
ggsave(
  paste0(stem, ".png"), p, device = ragg::agg_png,
  width = 183, height = 225, units = "mm", dpi = 600, background = "white"
)

stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
file.copy(paste0(stem, ".pdf"), manuscript_dir, overwrite = TRUE)
file.copy(paste0(stem, ".png"), manuscript_dir, overwrite = TRUE)
file.copy(source_out, manuscript_dir, overwrite = TRUE)
file.copy(map_out, manuscript_dir, overwrite = TRUE)

writeLines(
  c(
    "PASS",
    "backend=R",
    "templates_assessable=142",
    "actin_backgrounds_pooled=Human_ACTB,Rabbit_ACTA1",
    paste0("functional_categories=", nrow(category_counts)),
    "residual_other_templates=0",
    "comparison=paired_variant_minus_WT_contact_indicator",
    "contact_cutoff_A=5",
    "deleted_residues=NA_not_zero",
    "statistical_unit=paired_template_by_actin_background",
    "inference=descriptive_static_geometry"
  ),
  paste0(stem, ".QA.marker")
)
