#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
  library(ragg)
})

root <- ".."
input_file <- file.path(
  root, "source_data",
  "fig_static_functional_complex_contact_change_relative_to_wt_source.tsv"
)
figure_dir <- file.path(root, "figures")
manuscript_dir <- paste0(
  "..",
  "figures/fig3_tail_is_important"
)

d <- read_tsv(input_file, show_col_types = FALSE)
stopifnot(
  n_distinct(d$functional_category) == 19L,
  setequal(unique(d$variant), c("Delta KCF", "Delta tail25")),
  all(d$actin_ref_position %in% 1:375)
)

category_order <- d %>%
  distinct(functional_category, category_display, facet_label, n_templates) %>%
  arrange(desc(n_templates), category_display)

breaks <- c(-Inf, -0.25, -0.10, -0.02, 0.02, 0.10, 0.25, Inf)
bin_levels <- c(
  "Loss >25%", "Loss 10-25%", "Loss 2-10%", "Within +/-2%",
  "Gain 2-10%", "Gain 10-25%", "Gain >25%"
)

plot_d <- d %>%
  mutate(
    variant = factor(
      variant,
      levels = c("Delta KCF", "Delta tail25"),
      labels = c("Delta KCF", "Delta tail25")
    ),
    facet_label = factor(
      facet_label,
      levels = rev(category_order$facet_label)
    ),
    change_bin = cut(
      mean_delta_contact,
      breaks = breaks,
      labels = bin_levels,
      include.lowest = TRUE,
      right = TRUE
    )
  )

# Deletions are structurally absent and must not be encoded as zero change.
stopifnot(
  all(is.na(plot_d$change_bin[
    plot_d$variant == "Delta tail25" & plot_d$actin_ref_position >= 351
  ])),
  all(is.na(plot_d$change_bin[
    plot_d$variant == "Delta KCF" & plot_d$actin_ref_position >= 373
  ]))
)

palette <- c(
  "Loss >25%" = "#9C3F3F",
  "Loss 10-25%" = "#D06A5D",
  "Loss 2-10%" = "#F0B3A5",
  "Within +/-2%" = "#F2F2F2",
  "Gain 2-10%" = "#AEC9DC",
  "Gain 10-25%" = "#5F8FB4",
  "Gain >25%" = "#285D86"
)

p <- ggplot(plot_d, aes(x = actin_ref_position, y = facet_label, fill = change_bin)) +
  geom_tile(width = 1.02, height = 0.88, colour = NA) +
  geom_vline(xintercept = 350.5, linewidth = 0.28, colour = "#64717A") +
  geom_vline(xintercept = 372.5, linewidth = 0.32, colour = "#B65D4A") +
  facet_grid(. ~ variant) +
  scale_fill_manual(
    values = palette,
    limits = bin_levels,
    drop = FALSE,
    na.value = "#FFFFFF",
    name = "Paired contact-support change vs WT"
  ) +
  scale_x_continuous(
    breaks = c(1, 50, 100, 150, 200, 250, 300, 350, 375),
    expand = expansion(mult = c(0, 0))
  ) +
  coord_cartesian(xlim = c(0.5, 375.5), expand = FALSE) +
  scale_y_discrete(drop = FALSE) +
  labs(
    title = "Static actin-partner contact changes across functional contexts",
    subtitle = paste0(
      "Variant-minus-WT change in paired 5-A contact support; human ACTB and rabbit ACTA1 backgrounds pooled"
    ),
    x = "Human ACTB-aligned residue position",
    y = NULL,
    caption = paste0(
      "Each cell summarizes paired template-background observations at one actin residue; n denotes experimental templates.\n",
      "Vertical lines mark the tail body (351) and terminal KCF (373); pure-white terminal cells are deleted/unmapped, not zero change.\n",
      "Static 5-A geometry does not measure affinity or in-vivo function."
    )
  ) +
  theme_classic(base_family = "Arial", base_size = 8) +
  theme(
    axis.line = element_line(linewidth = 0.34, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.32, colour = "#222222"),
    axis.text.x = element_text(size = 6.5, colour = "#222222"),
    axis.text.y = element_text(size = 6.8, colour = "#222222"),
    axis.title.x = element_text(size = 7.6),
    strip.background = element_rect(fill = "#EEF1F3", colour = NA),
    strip.text = element_text(face = "bold", size = 8.2),
    panel.spacing.x = grid::unit(4.0, "mm"),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.title = element_text(size = 7.1),
    legend.text = element_text(size = 6.2),
    legend.key.width = grid::unit(8.5, "mm"),
    legend.key.height = grid::unit(3.3, "mm"),
    plot.title = element_text(face = "bold", size = 10.5),
    plot.subtitle = element_text(size = 7.7, colour = "#555555"),
    plot.caption = element_text(size = 6.0, colour = "#666666", hjust = 0),
    plot.margin = margin(8, 9, 7, 8)
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE, title.position = "top"))

stem <- file.path(
  figure_dir,
  "fig_static_functional_complex_contact_change_relative_to_wt_heatmap"
)
ggsave(
  paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
  width = 183, height = 150, units = "mm", family = "Arial", bg = "white"
)
ggsave(
  paste0(stem, ".png"), p, device = ragg::agg_png,
  width = 183, height = 150, units = "mm", dpi = 600, background = "white"
)

stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
file.copy(paste0(stem, ".pdf"), manuscript_dir, overwrite = TRUE)
file.copy(paste0(stem, ".png"), manuscript_dir, overwrite = TRUE)

writeLines(
  c(
    "PASS",
    "backend=R",
    "templates_assessable=142",
    "functional_categories=19",
    "variants=Delta_KCF,Delta_tail25",
    "metric=paired_contact_support_change_vs_WT",
    "contact_cutoff_A=5",
    "colour_scale=seven_explicit_percentage_point_bins",
    "deleted_residues=white_NA_not_zero",
    "actin_backgrounds_pooled=Human_ACTB,Rabbit_ACTA1",
    "inference=descriptive_static_geometry"
  ),
  paste0(stem, ".QA.marker")
)
