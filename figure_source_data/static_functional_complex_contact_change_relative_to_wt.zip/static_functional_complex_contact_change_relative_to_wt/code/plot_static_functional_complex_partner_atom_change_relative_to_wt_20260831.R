#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ragg)
})

root <- ".."
detail_file <- file.path(
  root, "source_data/static_tail_full156_residue_contacts_20260804",
  "static_tail_full156_residue_model_detail.tsv"
)
mapping_file <- file.path(
  root, "source_data/static_functional_complex_template_category_mapping.tsv"
)
category_file <- file.path(
  root, "source_data/fig_static_functional_complex_contact_change_relative_to_wt_source.tsv"
)
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")
manuscript_dir <- paste0(
  "..",
  "figures/fig3_tail_is_important"
)

detail <- read_tsv(detail_file, show_col_types = FALSE)
template_map <- read_tsv(mapping_file, show_col_types = FALSE) %>%
  select(template, functional_category)
category_meta <- read_tsv(category_file, show_col_types = FALSE) %>%
  distinct(functional_category, category_display, facet_label, n_templates) %>%
  arrange(desc(n_templates), category_display)

stopifnot(
  n_distinct(detail$template) == 142L,
  nrow(template_map) == 142L,
  nrow(category_meta) == 19L,
  setequal(unique(detail$state), c("WT", "Delta KCF", "Delta tail25"))
)

paired <- detail %>%
  inner_join(template_map, by = "template") %>%
  mutate(
    partner_atoms_observed = if_else(
      coordinate_observed == 1,
      as.numeric(n_partner_atoms_5A),
      NA_real_
    )
  ) %>%
  select(
    template, organism, functional_category, actin_ref_position,
    state, partner_atoms_observed
  ) %>%
  pivot_wider(names_from = state, values_from = partner_atoms_observed) %>%
  pivot_longer(
    cols = c(`Delta KCF`, `Delta tail25`),
    names_to = "variant", values_to = "variant_partner_atoms"
  ) %>%
  mutate(
    delta_partner_atoms_5A = if_else(
      is.finite(WT) & is.finite(variant_partner_atoms),
      variant_partner_atoms - WT,
      NA_real_
    )
  )

summary_df <- paired %>%
  group_by(functional_category, variant, actin_ref_position) %>%
  summarise(
    n_paired_models = sum(is.finite(delta_partner_atoms_5A)),
    n_templates_paired = n_distinct(template[is.finite(delta_partner_atoms_5A)]),
    mean_delta_partner_atoms_5A = if_else(
      n_paired_models > 0L,
      mean(delta_partner_atoms_5A, na.rm = TRUE),
      NA_real_
    ),
    sd_delta_partner_atoms_5A = if_else(
      n_paired_models > 1L,
      sd(delta_partner_atoms_5A, na.rm = TRUE),
      NA_real_
    ),
    se_delta_partner_atoms_5A =
      sd_delta_partner_atoms_5A / sqrt(n_paired_models),
    .groups = "drop"
  ) %>%
  left_join(category_meta, by = "functional_category") %>%
  mutate(
    variant = factor(variant, levels = c("Delta KCF", "Delta tail25")),
    facet_label = factor(facet_label, levels = category_meta$facet_label),
    comparison = "paired variant minus WT number of partner atoms within 5 A",
    organism_pool = "Human ACTB and Rabbit ACTA1 pooled"
  )

stopifnot(
  all(is.na(summary_df$mean_delta_partner_atoms_5A[
    summary_df$variant == "Delta tail25" & summary_df$actin_ref_position >= 351
  ])),
  all(is.na(summary_df$mean_delta_partner_atoms_5A[
    summary_df$variant == "Delta KCF" & summary_df$actin_ref_position >= 373
  ]))
)

source_out <- file.path(
  source_dir,
  "fig_static_functional_complex_partner_atom_change_relative_to_wt_source.tsv"
)
write_tsv(summary_df, source_out)

cols <- c("Delta KCF" = "#D2765D", "Delta tail25" = "#3E6F9E")
y_limit <- ceiling(max(abs(summary_df$mean_delta_partner_atoms_5A), na.rm = TRUE))

p <- ggplot(
  summary_df,
  aes(
    x = actin_ref_position,
    y = mean_delta_partner_atoms_5A,
    colour = variant
  )
) +
  annotate(
    "rect", xmin = 351, xmax = 372.5, ymin = -Inf, ymax = Inf,
    fill = "#E8EDF1", alpha = 0.55
  ) +
  annotate(
    "rect", xmin = 372.5, xmax = 375.5, ymin = -Inf, ymax = Inf,
    fill = "#F2DED6", alpha = 0.66
  ) +
  geom_hline(yintercept = 0, linewidth = 0.32, linetype = "22", colour = "#555555") +
  geom_line(linewidth = 0.50, na.rm = TRUE) +
  facet_wrap(~facet_label, ncol = 4, axes = "all", axis.labels = "all") +
  scale_colour_manual(
    values = cols, name = NULL,
    labels = c(
      "Delta KCF" = expression(Delta*KCF),
      "Delta tail25" = expression(Delta*tail25)
    )
  ) +
  scale_x_continuous(
    breaks = c(1, 100, 200, 300, 375),
    limits = c(1, 375.5),
    expand = expansion(mult = c(0.005, 0.01))
  ) +
  scale_y_continuous(
    limits = c(-y_limit, y_limit),
    breaks = scales::pretty_breaks(n = 5)
  ) +
  labs(
    title = "Static actin-partner contact changes relative to WT",
    subtitle = paste0(
      "Mean paired change in partner atoms within 5 A; human ACTB and rabbit ACTA1 backgrounds pooled"
    ),
    x = "Human ACTB-aligned residue position",
    y = "Mean change in partner atoms within 5 A",
    caption = paste0(
      "Values are variant minus WT for the same template, actin background and residue; n denotes experimental templates.\n",
      "Positive values indicate more partner atoms within 5 A and negative values fewer; deleted residues are blank.\n",
      "This is an absolute geometric contact-count change, not a percentage, affinity measurement or in-vivo functional effect."
    )
  ) +
  theme_classic(base_family = "Arial", base_size = 7.6) +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.30, colour = "#222222"),
    axis.text = element_text(colour = "#222222", size = 5.7),
    axis.title = element_text(size = 7.1),
    strip.background = element_rect(fill = "#F1F3F5", colour = NA),
    strip.text = element_text(face = "bold", size = 6.3),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 6.8),
    legend.key.width = grid::unit(6.5, "mm"),
    panel.spacing.x = grid::unit(1.4, "mm"),
    panel.spacing.y = grid::unit(2.2, "mm"),
    panel.grid.major.y = element_line(linewidth = 0.18, colour = "#ECECEC"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 10),
    plot.subtitle = element_text(size = 7.4, colour = "#555555"),
    plot.caption = element_text(size = 5.8, colour = "#666666", hjust = 0),
    plot.margin = margin(7, 8, 7, 7)
  )

stem <- file.path(
  figure_dir, "fig_static_functional_complex_contact_change_relative_to_wt"
)
ggsave(
  paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
  width = 183, height = 225, units = "mm", family = "Arial", bg = "white"
)
ggsave(
  paste0(stem, ".png"), p, device = ragg::agg_png,
  width = 183, height = 225, units = "mm", dpi = 600, background = "white"
)

stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
file.copy(paste0(stem, ".pdf"), manuscript_dir, overwrite = TRUE)
file.copy(paste0(stem, ".png"), manuscript_dir, overwrite = TRUE)
file.copy(source_out, manuscript_dir, overwrite = TRUE)

writeLines(
  c(
    "PASS",
    "backend=R",
    "templates_assessable=142",
    "functional_categories=19",
    "metric=mean_paired_change_in_partner_atoms_within_5A",
    "percentage_axis=false",
    "actin_backgrounds_pooled=Human_ACTB,Rabbit_ACTA1",
    "deleted_residues=NA_not_zero",
    paste0("common_symmetric_y_limit=", y_limit),
    "inference=descriptive_static_geometry"
  ),
  paste0(stem, ".QA.marker")
)
