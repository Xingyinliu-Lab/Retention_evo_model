# static_functional_complex_contact_change_relative_to_wt

- Manuscript panel: Supp.Fig.8
- Source figure basename: fig_static_functional_complex_contact_change_relative_to_wt
- Package type: data
- Inclusion status: conditional_currently_included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 3 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 8 directly referenced or locally packaged source-data file(s)
