# local_duplication_alternative_compact

- Manuscript panel: Fig.5C
- Source figure basename: fig_local_duplication_alternative_compact_v2
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
