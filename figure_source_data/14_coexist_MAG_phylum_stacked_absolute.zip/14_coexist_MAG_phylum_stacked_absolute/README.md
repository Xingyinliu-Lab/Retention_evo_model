# 14_coexist_MAG_phylum_stacked_absolute

- Manuscript panel: Fig.6E
- Source figure basename: fig_14_coexist_MAG_phylum_stacked_absolute
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 8 directly referenced or locally packaged source-data file(s)
