suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(stringr)
  library(grid)
})

root <- ".."
source_file <- file.path(root, "tables", "Supplementary_Table_2_31_OG_sequence_MAG_lineage_details.tsv")
out_data <- file.path(root, "data", "coexist_MAG_phylum_stacked_14_strong_supported")
out_fig <- file.path(root, "figures", "coexist_MAG_phylum_stacked_14_strong_supported")
dir.create(out_data, recursive = TRUE, showWarnings = FALSE)
dir.create(out_fig, recursive = TRUE, showWarnings = FALSE)

all_cases <- read_tsv(source_file, show_col_types = FALSE)
stopifnot(nrow(all_cases) == 31L, !anyDuplicated(all_cases$og_id))

d <- all_cases %>%
  filter(evidence_class %in% c("strong", "supported"))

stopifnot(
  nrow(d) == 14L,
  sum(d$evidence_class == "strong") == 2L,
  sum(d$evidence_class == "supported") == 12L
)

parse_composition <- function(og, x) {
  if (is.na(x) || x == "") {
    return(tibble(og_id = character(), phylum = character(), n_MAGs = integer()))
  }
  parts <- str_split(x, ";", simplify = FALSE)[[1]]
  parsed <- str_match(str_trim(parts), "^(.*?)\\s*\\(([0-9]+)\\)$")
  if (any(is.na(parsed[, 1]))) {
    stop("Unparsed phylum composition for ", og, ": ", x)
  }
  tibble(
    og_id = og,
    phylum = str_trim(parsed[, 2]),
    n_MAGs = as.integer(parsed[, 3])
  )
}

counts <- bind_rows(Map(
  parse_composition,
  d$og_id,
  d$coexist_MAG_phylum_composition
))

count_audit <- counts %>%
  group_by(og_id) %>%
  summarise(parsed_coexist_MAG = sum(n_MAGs), .groups = "drop") %>%
  left_join(
    d %>% select(og_id, expected_coexist_MAG = n_AB_coexist_MAG),
    by = "og_id"
  ) %>%
  mutate(match = parsed_coexist_MAG == expected_coexist_MAG)

stopifnot(nrow(count_audit) == 14L, all(count_audit$match))

# Match the 14-case A/B state figures exactly.
og_order <- d %>%
  arrange(desc(n_AB_coexist_MAG), desc(n_host_MAG), og_id) %>%
  pull(og_id)

phylum_totals <- counts %>%
  group_by(phylum) %>%
  summarise(total = sum(n_MAGs), .groups = "drop")
rare_phyla <- phylum_totals %>%
  filter(total < 4) %>%
  pull(phylum)

counts_plot <- counts %>%
  mutate(phylum_plot = if_else(phylum %in% rare_phyla, "Other archaea", phylum)) %>%
  group_by(og_id, phylum_plot) %>%
  summarise(n_MAGs = sum(n_MAGs), .groups = "drop")

preferred_levels <- c(
  "Halobacteriota", "Thermoproteota", "Asgardarchaeota",
  "Thermoplasmatota", "Hydrothermarchaeota", "Methanobacteriota",
  "Methanobacteriota_B", "Altiarchaeota", "Hadarchaeota",
  "Nanobdellota", "Other archaea"
)
observed_levels <- unique(counts_plot$phylum_plot)
phylum_levels <- c(
  preferred_levels[preferred_levels %in% observed_levels],
  sort(setdiff(observed_levels, preferred_levels))
)

phylum_palette <- c(
  Halobacteriota = "#7897B7",
  Thermoproteota = "#D8B273",
  Asgardarchaeota = "#C98973",
  Thermoplasmatota = "#9488B5",
  Hydrothermarchaeota = "#75AAA5",
  Methanobacteriota = "#87A777",
  Methanobacteriota_B = "#A8C292",
  Altiarchaeota = "#C99AAA",
  Hadarchaeota = "#A38D79",
  Nanobdellota = "#8CAEB5",
  Korarchaeota = "#8EA5BC",
  Micrarchaeota = "#D1A679",
  `SpSt-1190` = "#8EAD8E",
  `Other archaea` = "#C5C9CF"
)

missing_colours <- setdiff(phylum_levels, names(phylum_palette))
if (length(missing_colours) > 0L) {
  fallback <- c("#91A6BA", "#D1AD83", "#98AE91", "#B39AAC", "#93AAA8")
  phylum_palette[missing_colours] <- rep(fallback, length.out = length(missing_colours))
}

counts_absolute <- counts_plot %>%
  mutate(
    og_id = factor(og_id, levels = og_order),
    phylum_plot = factor(phylum_plot, levels = phylum_levels)
  )

counts_percent <- counts_plot %>%
  group_by(og_id) %>%
  mutate(percent = 100 * n_MAGs / sum(n_MAGs)) %>%
  ungroup() %>%
  mutate(
    og_id = factor(og_id, levels = og_order),
    phylum_plot = factor(phylum_plot, levels = phylum_levels)
  )

labels_df <- d %>%
  mutate(
    function_short = str_trunc(functional_label, 32, ellipsis = "..."),
    axis_label = paste0(og_id, "\n", function_short)
  )
axis_labels <- setNames(labels_df$axis_label, labels_df$og_id)

theme_pub <- theme_classic(base_family = "Arial", base_size = 8) +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#202733"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#202733"),
    axis.text.x = element_text(
      angle = 52, hjust = 1, vjust = 1,
      size = 6.6, colour = "#28364A", lineheight = 0.90
    ),
    axis.text.y = element_text(size = 7.2, colour = "#28364A"),
    axis.title.x = element_blank(),
    axis.title.y = element_text(
      size = 8.8, face = "bold", colour = "#1C293C",
      margin = margin(r = 7)
    ),
    legend.text = element_text(size = 6.5),
    legend.title = element_text(size = 7.4, face = "bold"),
    legend.key.height = unit(2.8, "mm"),
    legend.key.width = unit(3.8, "mm"),
    legend.position = "bottom",
    panel.grid = element_blank(),
    plot.margin = margin(5, 6, 22, 7)
  )

p_absolute <- ggplot(counts_absolute, aes(x = og_id, y = n_MAGs, fill = phylum_plot)) +
  geom_col(width = 0.70, colour = NA, linewidth = 0) +
  scale_fill_manual(
    values = phylum_palette,
    limits = phylum_levels,
    drop = FALSE,
    name = "Phylum",
    guide = guide_legend(nrow = 2, byrow = TRUE)
  ) +
  scale_x_discrete(labels = axis_labels, drop = FALSE) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.04))) +
  labs(y = "Coexist MAGs") +
  theme_pub

p_percent <- ggplot(counts_percent, aes(x = og_id, y = percent, fill = phylum_plot)) +
  geom_col(width = 0.70, colour = NA, linewidth = 0) +
  scale_fill_manual(
    values = phylum_palette,
    limits = phylum_levels,
    drop = FALSE,
    name = "Phylum",
    guide = guide_legend(nrow = 2, byrow = TRUE)
  ) +
  scale_x_discrete(labels = axis_labels, drop = FALSE) +
  scale_y_continuous(
    limits = c(0, 100), breaks = seq(0, 100, 20),
    labels = function(x) paste0(x, "%"), expand = c(0, 0)
  ) +
  labs(y = "Coexist MAG composition (%)") +
  theme_pub

ggsave(
  file.path(out_fig, "fig_14_coexist_MAG_phylum_stacked_absolute.pdf"),
  p_absolute, width = 235, height = 124, units = "mm",
  device = cairo_pdf, bg = "white"
)
ggsave(
  file.path(out_fig, "fig_14_coexist_MAG_phylum_stacked_absolute.png"),
  p_absolute, width = 235, height = 124, units = "mm",
  dpi = 600, bg = "white"
)
ggsave(
  file.path(out_fig, "fig_14_coexist_MAG_phylum_stacked_percent.pdf"),
  p_percent, width = 235, height = 124, units = "mm",
  device = cairo_pdf, bg = "white"
)
ggsave(
  file.path(out_fig, "fig_14_coexist_MAG_phylum_stacked_percent.png"),
  p_percent, width = 235, height = 124, units = "mm",
  dpi = 600, bg = "white"
)

write_tsv(counts, file.path(out_data, "fig_14_coexist_MAG_phylum_counts.tsv"))
write_tsv(
  counts_percent %>% arrange(og_id, phylum_plot) %>% mutate(across(where(is.factor), as.character)),
  file.path(out_data, "fig_14_coexist_MAG_phylum_percent.tsv")
)
write_tsv(
  tibble(x_position = seq_along(og_order), og_id = og_order),
  file.path(out_data, "fig_14_shared_OG_x_order.tsv")
)
write_tsv(
  labels_df %>% select(
    og_id, evidence_class, functional_label,
    functional_description, functional_confidence, axis_label
  ),
  file.path(out_data, "fig_14_case_function_labels.tsv")
)
write_tsv(count_audit, file.path(out_data, "fig_14_coexist_MAG_count_audit.tsv"))

writeLines(
  c(
    "status=PASS",
    "cases=14",
    "selection=evidence_class_in_strong_supported",
    "strong=2",
    "supported=12",
    "coexist_definition=copy_associated_A_B_MAG_state_coexist",
    "x_order=identical_to_14_case_AB_state_figures",
    "palette=fixed_muted_phylum_palette",
    paste0("rare_phyla_combined_in_plot=", paste(rare_phyla, collapse = ";")),
    paste0("parsed_counts_match_expected=", all(count_audit$match)),
    paste0("n_phyla_before_visual_pooling=", n_distinct(counts$phylum))
  ),
  file.path(out_data, "COEXIST_PHYLA_STACKED_14_COMPLETE.marker")
)
