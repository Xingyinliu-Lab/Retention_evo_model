suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
})

# Figure contract
# Conclusion: cALP+dALP coexistence includes clean copy-level assembly contexts
# in both HQ and MQ MAGs, with stronger proportional support among HQ MAGs.
# This is an assembly-context screen, not proof of retention or bin purity.

assembly_file <- "../data/full_6769_coexist_MAG_assembly_context_20260808.tsv"
out_dir <- ".."

tier_levels <- c(
  "ALL_COPIES_STRICT_CLEAN",
  "AT_LEAST_ONE_STRICT_COPY_PER_PROFILE",
  "STRICT_COPY_IN_ONE_PROFILE_ONLY",
  "NO_STRICT_COPY"
)

tier_labels <- c(
  "Both profiles contain a strict-clean copy",
  "Strict-clean copy in one profile only",
  "No strict-clean copy"
)

tier_colours <- c(
  "Both profiles contain a strict-clean copy" = "#27776F",
  "Strict-clean copy in one profile only" = "#A9C4D5",
  "No strict-clean copy" = "#D9DEE5"
)

dat <- read.delim(assembly_file, check.names = FALSE, stringsAsFactors = FALSE) %>%
  transmute(
    quality = factor(quality_checkm2, levels = c("HQ", "MQ")),
    tier = case_when(
      evidence_tier %in% tier_levels[1:2] ~ tier_labels[1],
      evidence_tier == tier_levels[3] ~ tier_labels[2],
      evidence_tier == tier_levels[4] ~ tier_labels[3],
      TRUE ~ NA_character_
    ),
    tier = factor(tier, levels = tier_labels)
  )

stopifnot(nrow(dat) == 342L, !anyNA(dat$quality), !anyNA(dat$tier))

plot_dat <- dat %>%
  count(quality, tier, name = "n_MAGs") %>%
  complete(quality, tier, fill = list(n_MAGs = 0L)) %>%
  group_by(quality) %>%
  mutate(
    total_MAGs = sum(n_MAGs),
    fraction = n_MAGs / total_MAGs,
    percent = 100 * fraction,
    bar_label = sprintf("%d\n%.1f%%", n_MAGs, percent),
    label_colour = if_else(tier == tier_labels[1], "white", "#273444"),
    quality_label = sprintf("%s  (n=%d)", quality, total_MAGs)
  ) %>%
  ungroup() %>%
  mutate(quality_label = factor(quality_label, levels = c("MQ  (n=284)", "HQ  (n=58)")))

stopifnot(
  identical(plot_dat$n_MAGs[plot_dat$quality == "HQ"], c(29L, 17L, 12L)),
  identical(plot_dat$n_MAGs[plot_dat$quality == "MQ"], c(79L, 95L, 110L))
)

write.table(
  plot_dat %>% select(quality, tier, n_MAGs, total_MAGs, fraction, percent),
  file.path(out_dir, "fig_7_all342_coexist_MAG_assembly_context_compact_v2_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)

p <- ggplot(plot_dat, aes(y = quality_label, x = n_MAGs, fill = tier)) +
  geom_col(
    position = position_fill(reverse = TRUE),
    width = 0.58,
    colour = "white",
    linewidth = 0.55
  ) +
  geom_text(
    aes(label = bar_label, colour = label_colour, group = tier),
    position = position_fill(vjust = 0.5, reverse = TRUE),
    family = "Arial",
    fontface = "bold",
    size = 2.65,
    lineheight = 0.90,
    show.legend = FALSE
  ) +
  scale_fill_manual(values = tier_colours, breaks = tier_labels, drop = FALSE, name = NULL) +
  scale_colour_identity() +
  scale_x_continuous(
    breaks = seq(0, 1, 0.25),
    labels = percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Assembly-context support among cALP+dALP coexist MAGs",
    subtitle = "Segment labels show MAG count and within-quality percentage",
    x = "Fraction of coexist MAGs",
    y = NULL
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line.y = element_blank(),
    axis.line.x = element_line(linewidth = 0.35, colour = "#31363C"),
    axis.ticks.y = element_blank(),
    axis.ticks.x = element_line(linewidth = 0.35, colour = "#31363C"),
    axis.text.y = element_text(size = 7.0, colour = "#20262D", face = "bold", margin = margin(r = 4)),
    axis.text.x = element_text(size = 6.2, colour = "#4D5763"),
    axis.title.x = element_text(size = 6.8, colour = "#303840", margin = margin(t = 3)),
    plot.title = element_text(size = 8.1, face = "bold", colour = "#18212B", margin = margin(b = 1.5)),
    plot.subtitle = element_text(size = 6.1, colour = "#5A6572", margin = margin(b = 5)),
    legend.position = "bottom",
    legend.justification = "left",
    legend.box.just = "left",
    legend.text = element_text(size = 5.8, colour = "#303840"),
    legend.key.width = grid::unit(3.3, "mm"),
    legend.key.height = grid::unit(3.0, "mm"),
    legend.spacing.x = grid::unit(1.2, "mm"),
    plot.margin = margin(4, 5, 3, 4)
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE))

pdf_file <- file.path(out_dir, "fig_7_all342_coexist_MAG_assembly_context_compact_v2.pdf")
png_file <- file.path(out_dir, "fig_7_all342_coexist_MAG_assembly_context_compact_v2.png")

ggsave(pdf_file, p, width = 118, height = 62, units = "mm", device = cairo_pdf)
ragg::agg_png(png_file, width = 118, height = 62, units = "mm", res = 450, background = "white")
print(p)
dev.off()

message("Wrote: ", pdf_file)
message("Wrote: ", png_file)
