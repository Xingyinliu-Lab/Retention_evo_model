# 7_all342_coexist_MAG_assembly_context_compact

- Manuscript panel: Fig.5B
- Source figure basename: fig_7_all342_coexist_MAG_assembly_context_compact_v2
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
