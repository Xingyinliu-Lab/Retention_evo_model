# 5b_tsne_embedding_by_actin_family_with_ellipses

- Manuscript panel: Supp.Fig.2A
- Source figure basename: figure_5b_tsne_embedding_by_actin_family_with_ellipses
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 15 directly referenced or locally packaged source-data file(s)
