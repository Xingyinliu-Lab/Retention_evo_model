# 2C1_tail_euk_pssm_distribution_by_merged_group

- Manuscript panel: Supp.Fig.5B
- Source figure basename: figure_2C1_tail_euk_pssm_distribution_by_merged_group
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
