# ============================================================
# Figure 2C: tail eukaryote-like PSSM score distribution
# Interactive R / RStudio version
#
# This version MERGES compare_group according to the user-defined rules:
#
#   Eukaryota_actin
#   Asgard_high_euk_like  <- Asgard_high_euk_like, Baldr_high_euk_like, Loki_high_euk_like
#   Asgard_intermediate   <- Asgard_intermediate, Loki_intermediate, Thor_intermediate
#   Asgard_low_divergent  <- Asgard_low_divergent, Loki_low_divergent, Njord_low_divergent
#   Asgard_short_or_missing
#   Thermoproteota_canonical
#
# Main input:
#   full_hmm_analysis/tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv
#
# How to use:
#   setwd("parent_folder_of_full_hmm_analysis")
#   source("plot_Figure2C_tail_euk_pssm_distribution_merged_groups.R")
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(scales)
})

PROJECT_DIR <- getwd()

SCORE_FILE <- file.path(
  PROJECT_DIR,
  "tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv"
)

OUTPUT_ROOT <- file.path(
  PROJECT_DIR,
  "Figure2C_tail_euk_pssm_distribution_merged_groups"
)

GROUP_COL <- "compare_group"
SCORE_COL <- "tail_euk_pssm_score_gap_penalty"

MIN_TAIL_NOGAP_LEN <- 0L
INCLUDE_SHORT_OR_MISSING <- TRUE
DROP_UNMAPPED_GROUPS <- FALSE
JITTER_MAX_POINTS <- 3000L

MERGED_GROUP_ORDER <- c(
  "Eukaryota_actin",
  "Asgard_high_euk_like",
  "Asgard_intermediate",
  "Asgard_low_divergent",
  "Asgard_short_or_missing",
  "Thermoproteota_canonical"
)

MERGED_GROUP_COLORS <- c(
  "Eukaryota_actin" = "#E64B35",
  "Asgard_high_euk_like" = "#D95F02",
  "Asgard_intermediate" = "#F6A04D",
  "Asgard_low_divergent" = "#FDD0A2",
  "Asgard_short_or_missing" = "#FEE6CE",
  "Thermoproteota_canonical" = "#00A087",
  "Other" = "#BDBDBD"
)

# Higher-contrast palette and point shapes for the tail length-score scatter only.
SCATTER_GROUP_COLORS <- c(
  "Eukaryota_actin" = "#C73E32",
  "Asgard_high_euk_like" = "#009E73",
  "Asgard_intermediate" = "#E69F00",
  "Asgard_low_divergent" = "#0072B2",
  "Asgard_short_or_missing" = "#6D6D6D",
  "Thermoproteota_canonical" = "#7B61A8",
  "Other" = "#BDBDBD"
)

SCATTER_GROUP_SHAPES <- c(
  "Eukaryota_actin" = 16,
  "Asgard_high_euk_like" = 17,
  "Asgard_intermediate" = 15,
  "Asgard_low_divergent" = 18,
  "Asgard_short_or_missing" = 8,
  "Thermoproteota_canonical" = 3,
  "Other" = 1
)

dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)

safe_file_stem <- function(x) {
  x <- gsub("[^A-Za-z0-9_\\-]+", "_", x)
  x <- gsub("_+", "_", x)
  x <- gsub("^_|_$", "", x)
  x
}

make_fig_dir <- function(fig_name) {
  out <- file.path(OUTPUT_ROOT, safe_file_stem(fig_name))
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out
}

write_tsv <- function(x, file) {
  utils::write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

fmt_int <- function(x) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", format(round(x), big.mark = ",", scientific = FALSE, trim = TRUE))
}

fmt_num <- function(x, digits = 2) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", format(round(x, digits), nsmall = digits, scientific = FALSE, trim = TRUE))
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size, colour = "black"),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = "black"),
      plot.title = element_text(size = base_size + 0.8, face = "bold", colour = "black"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.caption = element_text(size = base_size - 1.0, colour = "#4D4D4D", hjust = 0),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure_in_own_folder <- function(plot, fig_name, source_data, width_mm, height_mm, dpi = 300, config_df = NULL, extra_files = list()) {
  fig_dir <- make_fig_dir(fig_name)
  stem <- file.path(fig_dir, safe_file_stem(fig_name))
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  pdf_file <- paste0(stem, ".pdf")
  png_file <- paste0(stem, "_preview.png")

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(pdf_file, width = width_in, height = height_in, family = "sans")
  } else {
    grDevices::pdf(pdf_file, width = width_in, height = height_in, family = "sans")
  }
  print(plot)
  grDevices::dev.off()

  if (capabilities("cairo")) {
    grDevices::png(png_file, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo", bg = "white")
  } else {
    grDevices::png(png_file, width = width_in, height = height_in, units = "in", res = dpi, bg = "white")
  }
  print(plot)
  grDevices::dev.off()

  write_tsv(source_data, file.path(fig_dir, "source_data.tsv"))
  if (!is.null(config_df)) write_tsv(config_df, file.path(fig_dir, "plot_config.tsv"))
  if (length(extra_files) > 0) {
    for (nm in names(extra_files)) write_tsv(extra_files[[nm]], file.path(fig_dir, nm))
  }

  invisible(data.frame(
    figure = fig_name,
    folder = fig_dir,
    pdf = pdf_file,
    png_preview = png_file,
    stringsAsFactors = FALSE
  ))
}

sample_points <- function(df, max_n = JITTER_MAX_POINTS) {
  if (nrow(df) <= max_n) return(df)
  set.seed(1)
  df[sample(seq_len(nrow(df)), max_n), , drop = FALSE]
}

merge_compare_group <- function(x) {
  x <- as.character(x)
  dplyr::case_when(
    x %in% c("Eukaryota_actin") ~ "Eukaryota_actin",
    x %in% c("Asgard_high_euk_like", "Baldr_high_euk_like", "Loki_high_euk_like") ~ "Asgard_high_euk_like",
    x %in% c("Asgard_intermediate", "Loki_intermediate", "Thor_intermediate") ~ "Asgard_intermediate",
    x %in% c("Asgard_low_divergent", "Loki_low_divergent", "Njord_low_divergent") ~ "Asgard_low_divergent",
    x %in% c("Asgard_short_or_missing") ~ "Asgard_short_or_missing",
    x %in% c("Thermoproteota_canonical") ~ "Thermoproteota_canonical",
    TRUE ~ x
  )
}

if (!file.exists(SCORE_FILE)) {
  stop("Score file not found: ", SCORE_FILE)
}

score_raw <- read.delim(
  SCORE_FILE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_cols <- c("seq", GROUP_COL, SCORE_COL, "tail_nogap_len")
missing_cols <- setdiff(required_cols, names(score_raw))
if (length(missing_cols) > 0) {
  stop("Missing required columns in score file: ", paste(missing_cols, collapse = ", "))
}

df <- score_raw %>%
  mutate(
    seq = as.character(seq),
    compare_group_original = as.character(.data[[GROUP_COL]]),
    compare_group_merged = merge_compare_group(compare_group_original),
    score_value = suppressWarnings(as.numeric(.data[[SCORE_COL]])),
    tail_nogap_len = suppressWarnings(as.numeric(tail_nogap_len)),
    species = if ("species" %in% names(.)) as.character(species) else "",
    s = if ("s" %in% names(.)) as.character(s) else "",
    c = if ("c" %in% names(.)) as.character(c) else "",
    mag_id = if ("mag_id" %in% names(.)) as.character(mag_id) else "",
    actin_family_class = if ("actin_family_class" %in% names(.)) as.character(actin_family_class) else "",
    tail_class = if ("tail_class" %in% names(.)) as.character(tail_class) else ""
  ) %>%
  filter(!is.na(seq), seq != "") %>%
  filter(!is.na(compare_group_original), compare_group_original != "") %>%
  filter(!is.na(score_value))

if (!INCLUDE_SHORT_OR_MISSING) {
  df <- df %>% filter(compare_group_merged != "Asgard_short_or_missing")
}

if (DROP_UNMAPPED_GROUPS) {
  df <- df %>% filter(compare_group_merged %in% MERGED_GROUP_ORDER)
}

df <- df %>% filter(is.na(tail_nogap_len) | tail_nogap_len >= MIN_TAIL_NOGAP_LEN)

present_groups <- unique(df$compare_group_merged)
group_order <- c(
  MERGED_GROUP_ORDER[MERGED_GROUP_ORDER %in% present_groups],
  setdiff(sort(present_groups), MERGED_GROUP_ORDER)
)

missing_colors <- setdiff(group_order, names(MERGED_GROUP_COLORS))
if (length(missing_colors) > 0) {
  extra_cols <- rep("#BDBDBD", length(missing_colors))
  names(extra_cols) <- missing_colors
  MERGED_GROUP_COLORS <- c(MERGED_GROUP_COLORS, extra_cols)
}

stats_df <- df %>%
  mutate(compare_group_merged = factor(compare_group_merged, levels = group_order)) %>%
  group_by(compare_group_merged) %>%
  summarise(
    n_seq = n(),
    mean_score = mean(score_value, na.rm = TRUE),
    median_score = median(score_value, na.rm = TRUE),
    sd_score = sd(score_value, na.rm = TRUE),
    q1_score = quantile(score_value, 0.25, na.rm = TRUE),
    q3_score = quantile(score_value, 0.75, na.rm = TRUE),
    min_score = min(score_value, na.rm = TRUE),
    max_score = max(score_value, na.rm = TRUE),
    mean_tail_len = mean(tail_nogap_len, na.rm = TRUE),
    median_tail_len = median(tail_nogap_len, na.rm = TRUE),
    frac_tail_ge20 = mean(tail_nogap_len >= 20, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(match(as.character(compare_group_merged), group_order)) %>%
  mutate(compare_group_label = paste0(as.character(compare_group_merged), " (n=", fmt_int(n_seq), ")"))

mapping_df <- df %>%
  distinct(compare_group_original, compare_group_merged) %>%
  arrange(compare_group_merged, compare_group_original)

label_levels <- stats_df$compare_group_label

plot_df <- df %>%
  mutate(compare_group_merged = factor(compare_group_merged, levels = group_order)) %>%
  left_join(stats_df %>% select(compare_group_merged, compare_group_label), by = "compare_group_merged") %>%
  mutate(compare_group_label = factor(compare_group_label, levels = rev(label_levels)))

plot_points <- sample_points(plot_df)

base_config <- data.frame(
  parameter = c(
    "project_dir", "score_file", "output_root", "group_col",
    "score_col", "min_tail_nogap_len", "include_short_or_missing",
    "drop_unmapped_groups", "jitter_max_points",
    "n_sequences_plotted", "n_groups_plotted"
  ),
  value = c(
    PROJECT_DIR, SCORE_FILE, OUTPUT_ROOT, GROUP_COL,
    SCORE_COL, MIN_TAIL_NOGAP_LEN, INCLUDE_SHORT_OR_MISSING,
    DROP_UNMAPPED_GROUPS, JITTER_MAX_POINTS,
    nrow(plot_df), length(group_order)
  ),
  stringsAsFactors = FALSE
)

fig2C1_data <- plot_df %>%
  select(
    seq, compare_group_original, compare_group_merged, compare_group_label,
    species, s, c, mag_id, actin_family_class, tail_class,
    tail_nogap_len, score_value
  )

p2C1 <- ggplot(fig2C1_data, aes(x = compare_group_label, y = score_value, fill = compare_group_merged)) +
  geom_violin(trim = FALSE, colour = "grey35", linewidth = 0.22, alpha = 0.85, na.rm = TRUE) +
  geom_boxplot(width = 0.15, outlier.shape = NA, fill = "white", colour = "black", linewidth = 0.25, na.rm = TRUE) +
  geom_jitter(data = plot_points, width = 0.13, height = 0, size = 0.42, alpha = 0.16, colour = "black") +
  coord_flip() +
  scale_fill_manual(values = SCATTER_GROUP_COLORS[group_order], drop = FALSE) +
  labs(
    x = NULL,
    y = SCORE_COL,
    fill = "Merged compare_group",
    title = "Tail eukaryote-like PSSM score distribution",
    subtitle = "compare_group merged according to the user-defined rule set",
    caption = "Original groups are preserved in source_data.tsv; plotting uses merged groups."
  ) +
  theme_nature() +
  theme(legend.position = "none")

out1 <- save_figure_in_own_folder(
  p2C1,
  "figure_2C1_tail_euk_pssm_distribution_by_merged_group",
  fig2C1_data,
  width_mm = 150,
  height_mm = max(90, 40 + 7.6 * length(group_order)),
  config_df = base_config,
  extra_files = list(
    "group_summary_stats.tsv" = stats_df,
    "group_mapping.tsv" = mapping_df
  )
)

if (identical(Sys.getenv("ONLY_FIG2C1"), "1")) {
  message("Done: figure_2C1 only.")
  quit(save = "no", status = 0)
}

fig2C2_data <- stats_df %>%
  mutate(
    compare_group_label = factor(compare_group_label, levels = rev(label_levels)),
    median_label = paste0("median=", fmt_num(median_score, 2))
  )

p2C2 <- ggplot(fig2C2_data, aes(y = compare_group_label)) +
  geom_segment(aes(x = q1_score, xend = q3_score, yend = compare_group_label), linewidth = 1.0, colour = "#A6A6A6") +
  geom_point(aes(x = median_score, fill = compare_group_merged, size = n_seq), shape = 21, colour = "black", linewidth = 0.22) +
  geom_text(aes(x = q3_score, label = median_label), hjust = -0.08, size = 1.9) +
  scale_fill_manual(values = MERGED_GROUP_COLORS[group_order], drop = FALSE) +
  scale_size_continuous(range = c(2.2, 8.0), breaks = pretty(fig2C2_data$n_seq, n = 4)) +
  labs(
    x = paste0(SCORE_COL, " (median with IQR)"),
    y = NULL,
    fill = "Merged compare_group",
    size = "n_seq",
    title = "Tail eukaryote-like PSSM score summary",
    subtitle = "Point = median; thick segment = interquartile range"
  ) +
  theme_nature() +
  theme(legend.position = "right")

out2 <- save_figure_in_own_folder(
  p2C2,
  "figure_2C2_tail_euk_pssm_median_iqr_by_merged_group",
  fig2C2_data,
  width_mm = 190,
  height_mm = max(85, 38 + 6.8 * length(group_order)),
  config_df = base_config,
  extra_files = list(
    "group_summary_stats.tsv" = stats_df,
    "group_mapping.tsv" = mapping_df
  )
)

fig2C3_data <- plot_df %>%
  select(
    seq, compare_group_original, compare_group_merged,
    tail_nogap_len, score_value, actin_family_class, tail_class
  )

p2C3 <- ggplot(fig2C3_data, aes(x = tail_nogap_len, y = score_value)) +
  geom_smooth(aes(colour = compare_group_merged), method = "loess", se = FALSE,
              linewidth = 0.70, na.rm = TRUE, show.legend = FALSE) +
  geom_point(aes(colour = compare_group_merged, shape = compare_group_merged),
             size = 1.35, alpha = 0.88, stroke = 0.20, na.rm = TRUE) +
  scale_colour_manual(values = SCATTER_GROUP_COLORS[group_order], drop = FALSE) +
  scale_shape_manual(values = SCATTER_GROUP_SHAPES[group_order], drop = FALSE) +
  scale_x_continuous(breaks = seq(0, 25, by = 5), limits = c(0, 25)) +
  labs(
    x = "tail_nogap_len",
    y = SCORE_COL,
    colour = "Merged compare_group",
    shape = "Merged compare_group",
    title = "Tail eukaryote-like score versus tail length",
    subtitle = "QC view after merging compare_group"
  ) +
  theme_nature() +
  theme(legend.position = "right") +
  guides(
    colour = guide_legend(override.aes = list(size = 3.0, alpha = 1, linetype = 0)),
    shape = "none"
  )

out3 <- save_figure_in_own_folder(
  p2C3,
  "figure_2C3_tail_score_vs_tail_length_by_merged_group",
  fig2C3_data,
  width_mm = 170,
  height_mm = 110,
  config_df = base_config,
  extra_files = list(
    "group_summary_stats.tsv" = stats_df,
    "group_mapping.tsv" = mapping_df
  )
)

output_index <- bind_rows(out1, out2, out3)

write_tsv(base_config, file.path(OUTPUT_ROOT, "run_summary.tsv"))
write_tsv(output_index, file.path(OUTPUT_ROOT, "figure_output_index.tsv"))
write_tsv(stats_df, file.path(OUTPUT_ROOT, "group_summary_stats.tsv"))
write_tsv(mapping_df, file.path(OUTPUT_ROOT, "group_mapping.tsv"))
write_tsv(plot_df, file.path(OUTPUT_ROOT, "processed_score_table_with_merged_groups.tsv"))

message("Done.")
message("Working directory: ", PROJECT_DIR)
message("Output root: ", OUTPUT_ROOT)
message("Primary input used: ", SCORE_FILE)
message("compare_group has been merged using the requested rules.")
