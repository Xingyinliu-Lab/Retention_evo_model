# 1C_PF00022_full_coverage_and_pssm_overview

- Manuscript panel: Fig.2D
- Source figure basename: figure_1C_PF00022_full_coverage_and_pssm_overview
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
