# ============================================================
# Figure 1A: PF00022 full-length coverage + euk-PSSM score curves
# Interactive R / RStudio version
#
# How to use:
#   1. Set working directory to the parent folder of full_hmm_analysis/
#      Example:
#        setwd("..")
#
#   2. Run:
#        source("plot_Figure1A_PF00022_full_coverage_euk_pssm_interactive.R")
#
# Expected input:
#   full_hmm_analysis/PF00022_full_metrics_with_euk_rolling15.tsv
#
# Main columns used:
#   group
#   hmm_pos
#   coverage_roll15
#   mean_score_gap_penalty_roll15
#
# Output organization:
#   Figure1A_PF00022_full_hmm_plot/
#     figure_1A_PF00022_full_coverage_roll15/
#       figure_1A_PF00022_full_coverage_roll15.pdf
#       figure_1A_PF00022_full_coverage_roll15_preview.png
#       source_data.tsv
#       plot_config.tsv
#     figure_1B_PF00022_full_euk_pssm_gap_penalty_roll15/
#       ...
#     figure_1C_PF00022_full_coverage_and_pssm_overview/
#       ...
#     figure_1D_PF00022_tail_zoom_coverage_and_pssm/
#       ...
#     figure_1E_PF00022_tail_vs_nontail_summary/
#       ...
#     run_summary.tsv
#
# Notes:
#   - This script does not use commandArgs() or Rscript arguments.
#   - It assumes getwd() is the parent folder of full_hmm_analysis/.
#   - Each figure has its own folder containing the figure and source data.
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
})

# ============================================================
# 0. User settings
# ============================================================

PROJECT_DIR <- getwd()

INPUT_FILE <- file.path(
  PROJECT_DIR,
  "full_hmm_analysis",
  "PF00022_full_metrics_with_euk_rolling15.tsv"
)

OUTPUT_ROOT <- file.path(
  PROJECT_DIR,
  "Figure1A_PF00022_full_hmm_plot"
)

TAIL_START <- 386L
TAIL_END <- 410L

# Tail zoom region.
# Use c(386, 410) if you only want the exact tail.
ZOOM_START <- 340L
ZOOM_END <- 410L

# Recommended score for tail analysis:
# gap-penalty score keeps deletion/gap signal.
COVERAGE_COL <- "coverage_roll15"
SCORE_COL <- "mean_score_gap_penalty_roll15"

COVERAGE_LABEL <- "Non-gap coverage, rolling 15"
SCORE_LABEL <- "Eukaryotic PSSM score, gap penalty, rolling 15"

# If TRUE, figure 1C uses faceted overview with both metrics.
MAKE_OVERVIEW <- TRUE

dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 1. Helper functions
# ============================================================

fmt_int <- function(x) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", format(round(x), big.mark = ",", scientific = FALSE, trim = TRUE))
}

fmt_num <- function(x, digits = 3) {
  x <- suppressWarnings(as.numeric(as.character(x)))
  ifelse(is.na(x), "", format(round(x, digits), nsmall = digits, scientific = FALSE, trim = TRUE))
}

safe_file_stem <- function(x) {
  x <- gsub("[^A-Za-z0-9_\\-]+", "_", x)
  x <- gsub("_+", "_", x)
  x <- gsub("^_|_$", "", x)
  x
}

make_fig_dir <- function(fig_name) {
  out <- file.path(OUTPUT_ROOT, safe_file_stem(fig_name))
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out
}

write_tsv <- function(x, file) {
  utils::write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size, colour = "black"),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = "black"),
      plot.title = element_text(size = base_size + 0.8, face = "bold", colour = "black"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.caption = element_text(size = base_size - 1.0, colour = "#4D4D4D", hjust = 0),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure_in_own_folder <- function(plot, fig_name, source_data, width_mm, height_mm, dpi = 300, config_df = NULL) {
  fig_dir <- make_fig_dir(fig_name)
  stem <- file.path(fig_dir, safe_file_stem(fig_name))
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  pdf_file <- paste0(stem, ".pdf")
  png_file <- paste0(stem, "_preview.png")

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(pdf_file, width = width_in, height = height_in, family = "sans")
  } else {
    grDevices::pdf(pdf_file, width = width_in, height = height_in, family = "sans")
  }
  print(plot)
  grDevices::dev.off()

  if (capabilities("cairo")) {
    grDevices::png(png_file, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo", bg = "white")
  } else {
    grDevices::png(png_file, width = width_in, height = height_in, units = "in", res = dpi, bg = "white")
  }
  print(plot)
  grDevices::dev.off()

  write_tsv(source_data, file.path(fig_dir, "source_data.tsv"))

  if (is.null(config_df)) {
    config_df <- data.frame(
      parameter = c("input_file", "tail_start", "tail_end", "zoom_start", "zoom_end", "coverage_col", "score_col"),
      value = c(INPUT_FILE, TAIL_START, TAIL_END, ZOOM_START, ZOOM_END, COVERAGE_COL, SCORE_COL),
      stringsAsFactors = FALSE
    )
  }
  write_tsv(config_df, file.path(fig_dir, "plot_config.tsv"))

  invisible(data.frame(
    figure = fig_name,
    folder = fig_dir,
    pdf = pdf_file,
    png_preview = png_file,
    stringsAsFactors = FALSE
  ))
}

# ============================================================
# 2. Read and validate input
# ============================================================

if (!file.exists(INPUT_FILE)) {
  stop(
    "Input file not foun..", INPUT_FILE,
    "\n\nPlease set working directory to the parent folder of full_hmm_analysis/, then run source()."
  )
}

df_raw <- read.delim(
  INPUT_FILE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_cols <- c("group", "hmm_pos", COVERAGE_COL, SCORE_COL)
missing_cols <- setdiff(required_cols, names(df_raw))
if (length(missing_cols) > 0) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}

df_raw$hmm_pos <- suppressWarnings(as.integer(df_raw$hmm_pos))
df_raw$coverage_roll15_value <- suppressWarnings(as.numeric(df_raw[[COVERAGE_COL]]))
df_raw$euk_pssm_score_roll15_value <- suppressWarnings(as.numeric(df_raw[[SCORE_COL]]))
df_raw$group <- as.character(df_raw$group)

df <- df_raw %>%
  filter(!is.na(hmm_pos), !is.na(group), group != "") %>%
  mutate(
    is_tail = hmm_pos >= TAIL_START & hmm_pos <= TAIL_END,
    region = if_else(is_tail, "HMM386–410 tail", "Other PF00022 positions")
  )

# Preferred order. Includes both pretty labels and underscore labels.
group_order_preferred <- c(
  "Eukaryota_actin",
  "Eukaryota actin",
  "canonical Actin-like",
  "canonical_Actin_like",
  "Crenactin-like / archaeal actin",
  "Crenactin_like_archaeal_actin",
  "MreB/Mbl-like",
  "MreB_Mbl_like",
  "MreB-like_C/ALP_N-related",
  "MreB_like_C_ALP_N_related",
  "FtsA/PilM-like",
  "FtsA_PilM_like",
  "Salactin",
  "Volactin"
)

present_groups <- unique(df$group)
group_order <- c(
  group_order_preferred[group_order_preferred %in% present_groups],
  setdiff(sort(present_groups), group_order_preferred)
)

df <- df %>%
  mutate(
    group = factor(group, levels = group_order),
    region = factor(region, levels = c("Other PF00022 positions", "HMM386–410 tail"))
  )

# Colors. New/unexpected groups are grey.
group_colors <- c(
  "Eukaryota_actin" = "#D73027",
  "Eukaryota actin" = "#D73027",
  "canonical Actin-like" = "#4C78A8",
  "canonical_Actin_like" = "#4C78A8",
  "Crenactin-like / archaeal actin" = "#4F9B8F",
  "Crenactin_like_archaeal_actin" = "#4F9B8F",
  "MreB/Mbl-like" = "#8B6FA8",
  "MreB_Mbl_like" = "#8B6FA8",
  "MreB-like_C/ALP_N-related" = "#C77DA8",
  "MreB_like_C_ALP_N_related" = "#C77DA8",
  "FtsA/PilM-like" = "#777777",
  "FtsA_PilM_like" = "#777777",
  "Salactin" = "#D6A64A",
  "Volactin" = "#E18D4F"
)

group_legend_labels <- c(
  "Eukaryota_actin" = "Eukaryotic actin",
  "Eukaryota actin" = "Eukaryotic actin",
  "canonical Actin-like" = "canonical actin-like proteins (cALPs)",
  "canonical_Actin_like" = "canonical actin-like proteins (cALPs)",
  "Crenactin-like / archaeal actin" = "divergent actin-like proteins (dALPs)",
  "Crenactin_like_archaeal_actin" = "divergent actin-like proteins (dALPs)",
  "MreB/Mbl-like" = "MreB/Mbl-profile proteins",
  "MreB_Mbl_like" = "MreB/Mbl-profile proteins",
  "MreB-like_C/ALP_N-related" = "MreB_C/ALP_N domain-profile proteins",
  "MreB_like_C_ALP_N_related" = "MreB_C/ALP_N domain-profile proteins",
  "FtsA/PilM-like" = "FtsA/PilM-profile proteins",
  "FtsA_PilM_like" = "FtsA/PilM-profile proteins",
  "Salactin" = "Salactin-like proteins",
  "Volactin" = "Volactin-like proteins"
)

missing_group_colors <- setdiff(group_order, names(group_colors))
if (length(missing_group_colors) > 0) {
  extra_cols <- rep("#7F7F7F", length(missing_group_colors))
  names(extra_cols) <- missing_group_colors
  group_colors <- c(group_colors, extra_cols)
}

base_config <- data.frame(
  parameter = c(
    "project_dir",
    "input_file",
    "output_root",
    "tail_start",
    "tail_end",
    "zoom_start",
    "zoom_end",
    "coverage_col",
    "score_col",
    "n_rows",
    "n_groups",
    "hmm_pos_min",
    "hmm_pos_max"
  ),
  value = c(
    PROJECT_DIR,
    INPUT_FILE,
    OUTPUT_ROOT,
    TAIL_START,
    TAIL_END,
    ZOOM_START,
    ZOOM_END,
    COVERAGE_COL,
    SCORE_COL,
    nrow(df),
    dplyr::n_distinct(df$group),
    min(df$hmm_pos, na.rm = TRUE),
    max(df$hmm_pos, na.rm = TRUE)
  ),
  stringsAsFactors = FALSE
)

# ============================================================
# 3. Figure 1A: full-length coverage
# ============================================================

fig1A_data <- df %>%
  select(group, hmm_pos, coverage_roll15_value, is_tail, region)

p_cov <- ggplot(fig1A_data, aes(x = hmm_pos, y = coverage_roll15_value, colour = group)) +
  annotate("rect", xmin = TAIL_START, xmax = TAIL_END, ymin = -Inf, ymax = Inf, fill = "#F2C94C", alpha = 0.20) +
  geom_line(linewidth = 0.45, alpha = 0.92, na.rm = TRUE) +
  geom_vline(xintercept = c(TAIL_START, TAIL_END), linetype = 2, linewidth = 0.28, colour = "#8C6D1F") +
  scale_colour_manual(values = group_colors[group_order], breaks = group_order, labels = group_legend_labels[group_order], drop = FALSE) +
  scale_x_continuous(breaks = unique(c(1, 50, 100, 150, 200, 250, 300, 350, TAIL_START, TAIL_END))) +
  scale_y_continuous(labels = percent_format(accuracy = 1), limits = c(0, 1), expand = expansion(mult = c(0.01, 0.03))) +
  labs(
    x = "PF00022 HMM position",
    y = COVERAGE_LABEL,
    colour = "Actin family",
    title = "PF00022 full-length non-gap coverage",
    subtitle = paste0("Rolling-15 coverage; shaded region marks HMM", TAIL_START, "–", TAIL_END, " C-terminal tail")
  ) +
  theme_nature() +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(ncol = 2, byrow = TRUE))

out1A <- save_figure_in_own_folder(
  p_cov,
  "figure_1A_PF00022_full_coverage_roll15",
  fig1A_data,
  width_mm = 185,
  height_mm = 125,
  config_df = base_config
)

# ============================================================
# 4. Figure 1B: full-length euk-PSSM score
# ============================================================

fig1B_data <- df %>%
  select(group, hmm_pos, euk_pssm_score_roll15_value, is_tail, region)

p_score <- ggplot(fig1B_data, aes(x = hmm_pos, y = euk_pssm_score_roll15_value, colour = group)) +
  annotate("rect", xmin = TAIL_START, xmax = TAIL_END, ymin = -Inf, ymax = Inf, fill = "#F2C94C", alpha = 0.20) +
  geom_line(linewidth = 0.45, alpha = 0.92, na.rm = TRUE) +
  geom_vline(xintercept = c(TAIL_START, TAIL_END), linetype = 2, linewidth = 0.28, colour = "#8C6D1F") +
  scale_colour_manual(values = group_colors[group_order], breaks = group_order, labels = group_legend_labels[group_order], drop = FALSE) +
  scale_x_continuous(breaks = unique(c(1, 50, 100, 150, 200, 250, 300, 350, TAIL_START, TAIL_END))) +
  scale_y_continuous(expand = expansion(mult = c(0.03, 0.05))) +
  labs(
    x = "PF00022 HMM position",
    y = SCORE_LABEL,
    colour = "Actin family",
    title = "PF00022 full-length eukaryote-like PSSM score",
    subtitle = paste0("Rolling-15 score; shaded region marks HMM", TAIL_START, "–", TAIL_END, " C-terminal tail")
  ) +
  theme_nature() +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(ncol = 2, byrow = TRUE))

out1B <- save_figure_in_own_folder(
  p_score,
  "figure_1B_PF00022_full_euk_pssm_gap_penalty_roll15",
  fig1B_data,
  width_mm = 185,
  height_mm = 125,
  config_df = base_config
)

# ============================================================
# 5. Figure 1C: combined overview with facets
# ============================================================

fig1C_data <- df %>%
  select(group, hmm_pos, coverage_roll15_value, euk_pssm_score_roll15_value, is_tail, region) %>%
  pivot_longer(
    cols = c(coverage_roll15_value, euk_pssm_score_roll15_value),
    names_to = "metric",
    values_to = "value"
  ) %>%
  mutate(
    metric = recode(
      metric,
      "coverage_roll15_value" = "a. Non-gap coverage, rolling 15",
      "euk_pssm_score_roll15_value" = "b. Eukaryotic PSSM score, rolling 15"
    ),
    metric = factor(metric, levels = c("a. Non-gap coverage, rolling 15", "b. Eukaryotic PSSM score, rolling 15"))
  )

p_overview <- ggplot(fig1C_data, aes(x = hmm_pos, y = value, colour = group)) +
  annotate("rect", xmin = TAIL_START, xmax = TAIL_END, ymin = -Inf, ymax = Inf, fill = "#F2C94C", alpha = 0.20) +
  geom_line(linewidth = 0.45, alpha = 0.92, na.rm = TRUE) +
  geom_vline(xintercept = c(TAIL_START, TAIL_END), linetype = 2, linewidth = 0.28, colour = "#8C6D1F") +
  facet_wrap(~ metric, ncol = 1, scales = "free_y") +
  scale_colour_manual(values = group_colors[group_order], breaks = group_order, labels = group_legend_labels[group_order], drop = FALSE) +
  scale_x_continuous(breaks = unique(c(1, 50, 100, 150, 200, 250, 300, 350, TAIL_START, TAIL_END))) +
  labs(
    x = "PF00022 HMM position",
    y = "Rolling-15 metric value",
    colour = "Actin family",
    title = "PF00022 full-length coverage and eukaryote-like score",
    subtitle = paste0("Shaded region marks HMM", TAIL_START, "–", TAIL_END, " C-terminal tail")
  ) +
  theme_nature() +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(ncol = 2, byrow = TRUE))

out1C <- save_figure_in_own_folder(
  p_overview,
  "figure_1C_PF00022_full_coverage_and_pssm_overview",
  fig1C_data,
  width_mm = 190,
  height_mm = 180,
  config_df = base_config
)

# ============================================================
# 6. Figure 1D: C-terminal zoom
# ============================================================

fig1D_data <- fig1C_data %>%
  filter(hmm_pos >= ZOOM_START, hmm_pos <= ZOOM_END)

p_zoom <- ggplot(fig1D_data, aes(x = hmm_pos, y = value, colour = group)) +
  annotate("rect", xmin = TAIL_START, xmax = TAIL_END, ymin = -Inf, ymax = Inf, fill = "#F2C94C", alpha = 0.20) +
  geom_line(linewidth = 0.55, alpha = 0.92, na.rm = TRUE) +
  geom_vline(xintercept = c(TAIL_START, TAIL_END), linetype = 2, linewidth = 0.28, colour = "#8C6D1F") +
  facet_wrap(~ metric, ncol = 1, scales = "free_y") +
  scale_colour_manual(values = group_colors[group_order], breaks = group_order, labels = group_legend_labels[group_order], drop = FALSE) +
  scale_x_continuous(breaks = unique(c(seq(ZOOM_START, ZOOM_END, by = 10), TAIL_START, TAIL_END))) +
  labs(
    x = "PF00022 HMM position",
    y = "Rolling-15 metric value",
    colour = "Actin family",
    title = paste0("PF00022 C-terminal region zoom: HMM", ZOOM_START, "–", ZOOM_END),
    subtitle = paste0("Shaded region marks HMM", TAIL_START, "–", TAIL_END, " C-terminal tail")
  ) +
  theme_nature() +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(ncol = 2, byrow = TRUE))

out1D <- save_figure_in_own_folder(
  p_zoom,
  "figure_1D_PF00022_tail_zoom_coverage_and_pssm",
  fig1D_data,
  width_mm = 190,
  height_mm = 180,
  config_df = base_config
)

# ============================================================
# 7. Figure 1E: tail vs non-tail summary
# ============================================================

summary_region <- df %>%
  group_by(group, region) %>%
  summarise(
    n_hmm_positions = n_distinct(hmm_pos),
    mean_coverage_roll15 = mean(coverage_roll15_value, na.rm = TRUE),
    median_coverage_roll15 = median(coverage_roll15_value, na.rm = TRUE),
    mean_euk_pssm_score_roll15 = mean(euk_pssm_score_roll15_value, na.rm = TRUE),
    median_euk_pssm_score_roll15 = median(euk_pssm_score_roll15_value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(group = factor(group, levels = group_order))

fig1E_data <- summary_region %>%
  select(group, region, mean_coverage_roll15, mean_euk_pssm_score_roll15) %>%
  pivot_longer(
    cols = c(mean_coverage_roll15, mean_euk_pssm_score_roll15),
    names_to = "metric",
    values_to = "value"
  ) %>%
  mutate(
    metric = recode(
      metric,
      "mean_coverage_roll15" = "a. Mean coverage",
      "mean_euk_pssm_score_roll15" = "b. Mean euk-PSSM score"
    ),
    metric = factor(metric, levels = c("a. Mean coverage", "b. Mean euk-PSSM score"))
  )

p_summary <- ggplot(fig1E_data, aes(x = group, y = value, fill = region)) +
  geom_col(position = position_dodge(width = 0.72), width = 0.64, colour = "white", linewidth = 0.18) +
  facet_wrap(~ metric, scales = "free_y", ncol = 1) +
  scale_fill_manual(values = c("Other PF00022 positions" = "#BDBDBD", "HMM386–410 tail" = "#F2C94C"), drop = FALSE) +
  labs(
    x = NULL,
    y = "Mean rolling-15 value",
    fill = "Region",
    title = "Tail versus non-tail summary",
    subtitle = "Mean rolling-15 coverage and euk-PSSM score summarized by region"
  ) +
  theme_nature() +
  theme(axis.text.x = element_text(angle = 30, hjust = 1), legend.position = "bottom")

out1E <- save_figure_in_own_folder(
  p_summary,
  "figure_1E_PF00022_tail_vs_nontail_summary",
  fig1E_data,
  width_mm = 185,
  height_mm = 145,
  config_df = base_config
)

# Also save the wider summary table inside figure 1E folder.
fig1E_dir <- make_fig_dir("figure_1E_PF00022_tail_vs_nontail_summary")
write_tsv(summary_region, file.path(fig1E_dir, "tail_vs_nontail_summary_wide.tsv"))

# ============================================================
# 8. Global run summary
# ============================================================

all_outputs <- bind_rows(out1A, out1B, out1C, out1D, out1E)

write_tsv(base_config, file.path(OUTPUT_ROOT, "run_summary.tsv"))
write_tsv(all_outputs, file.path(OUTPUT_ROOT, "figure_output_index.tsv"))

message("Done.")
message("Working directory: ", PROJECT_DIR)
message("Input file: ", INPUT_FILE)
message("Output root: ", OUTPUT_ROOT)
message("Each figure folder contains PDF, PNG preview, source_data.tsv, and plot_config.tsv.")
