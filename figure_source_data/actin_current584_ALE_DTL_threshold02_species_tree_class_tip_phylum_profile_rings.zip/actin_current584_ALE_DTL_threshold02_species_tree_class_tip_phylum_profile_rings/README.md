# actin_current584_ALE_DTL_threshold02_species_tree_class_tip_phylum_profile_rings

- Manuscript panel: Fig.7A
- Source figure basename: fig_actin_current584_ALE_DTL_threshold02_species_tree_class_tip_phylum_profile_rings
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
