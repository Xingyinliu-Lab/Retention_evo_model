#!/usr/bin/env Rscript
# Figure contract
# a) cALP remains closer to eukaryotic WT than dALP in selected complex contexts.
# b) Within each metric, positive dALP excess deviation identifies functional modules
#    where cALP is closer to the eukaryotic benchmark.  No cross-metric composite is made.

suppressPackageStartupMessages({library(ggplot2); library(dplyr); library(readr); library(tidyr)})
root <- ".."
data_dir <- file.path(root, "data"); fig_dir <- file.path(root, "fig")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
if (!requireNamespace("ragg", quietly = TRUE)) stop("Missing R package: ragg")

theme_pub <- function(base_size = 7) theme_classic(base_size = base_size, base_family = "Arial") + theme(
  axis.line = element_line(linewidth = .35), axis.ticks = element_line(linewidth = .35),
  strip.text = element_text(size = base_size, face = "bold"), strip.background = element_rect(fill = "#F2F2F2", colour = NA),
  plot.title = element_text(size = base_size + 1.4, face = "bold"), plot.subtitle = element_text(size = base_size - .2, colour = "#4D4D4D"),
  legend.position = "top", legend.title = element_blank(), legend.text = element_text(size = base_size - .4),
  panel.spacing = grid::unit(7, "pt"), plot.margin = margin(5.5, 8, 5.5, 5.5))
save_pub <- function(plot, stem, width_mm, height_mm) {
  w <- width_mm / 25.4; h <- height_mm / 25.4
  ggsave(paste0(stem, ".pdf"), plot, width = w, height = h, device = cairo_pdf)
  ggsave(paste0(stem, ".png"), plot, width = w, height = h, dpi = 600, device = ragg::agg_png)
}

src <- read_tsv(file.path(data_dir, "fig_dalp_calp_euk_benchmark_by_actin_complex_20260820_source.tsv"), show_col_types = FALSE) %>%
  # Core-function figures exclude pathogen-effector and extracellular DBP
  # scavenging/monomer-sequestration contexts; retain them in the full audit
  # source and supplement candidate inventory.
  filter(module != "pathogen_effector", complex != "Vitamin-D-binding protein") %>%
  mutate(state = factor(state, levels = c("cALP", "dALP")))
stopifnot(n_distinct(src$template) == 151L, !any(src$complex %in% c("other", "unknown", "Pathogen effector", "Vitamin-D-binding protein")))

# Panel a: detailed complex context.  All metric facets use one fixed complex
# order, ranked once by the pooled dALP absolute deviation from euk WT.
order_a <- src %>% filter(state == "dALP") %>% group_by(complex) %>%
  summarise(rank_score = median(abs(effect_normalized)), .groups = "drop") %>% arrange(rank_score)
levels_a <- order_a$complex
a <- src %>% mutate(complex_panel = factor(complex, levels = levels_a))
write_tsv(a, file.path(data_dir, "fig_dalp_calp_complex_boxplot_20260820_source.tsv"))
p_a <- ggplot(a, aes(x = effect_normalized, y = complex_panel, fill = state, colour = state)) +
  geom_vline(xintercept = 0, colour = "#A9A9A9", linewidth = .32) +
  geom_boxplot(position = position_dodge2(width = .74, preserve = "single"), width = .62, outlier.shape = NA, alpha = .55, linewidth = .28) +
  geom_point(position = position_jitterdodge(jitter.height = .11, dodge.width = .74), size = .42, alpha = .18, show.legend = FALSE) +
  facet_wrap(
    ~metric_display,
    scales = "free_x",
    ncol = 2,
    axes = "all_y",
    axis.labels = "all_y"
  ) +
  scale_y_discrete(drop = FALSE) +
  scale_fill_manual(values = c(cALP = "#5B84B1", dALP = "#CE7B56")) + scale_colour_manual(values = c(cALP = "#41688F", dALP = "#B55B3D")) +
  labs(x = "Candidate minus matched eukaryotic WT (per actin chain where applicable)", y = NULL,
       title = "cALP and dALP deviations from eukaryotic actin resolve by complex context",
       subtitle = "All facets use the same complex order; boxes show median and IQR") + theme_pub(7)
save_pub(p_a, file.path(fig_dir, "fig_dalp_calp_euk_benchmark_complex_boxplots_20260820"), 230, 250)

# Panel b: direct benchmark advantage, calculated before aggregation.
# Positive values mean cALP lies closer to euk WT than the matched dALP for that metric.
wide <- src %>% select(mag_id, template, complex, module, metric, metric_display, state, effect_normalized) %>%
  pivot_wider(names_from = state, values_from = effect_normalized) %>% filter(!is.na(cALP), !is.na(dALP)) %>%
  mutate(cALP_advantage = abs(dALP) - abs(cALP))
template_adv <- wide %>% group_by(template, complex, module, metric, metric_display) %>%
  summarise(cALP_advantage = median(cALP_advantage), n_MAG_pairs = n(), .groups = "drop")
module_n <- template_adv %>% distinct(module, template) %>% count(module, name = "n_templates")
order_b <- template_adv %>% group_by(metric_display, module) %>% summarise(rank_score = median(cALP_advantage), .groups = "drop") %>% arrange(metric_display, rank_score)
levels_b <- paste(order_b$metric_display, order_b$module, sep = "___")
label_b <- module_n %>% mutate(module_label = paste0(gsub("_", " ", module), " (n=", n_templates, ")"))
b <- template_adv %>% left_join(label_b %>% select(module, module_label), by = "module") %>%
  mutate(module_panel = factor(paste(metric_display, module, sep = "___"), levels = levels_b), direction = if_else(cALP_advantage >= 0, "cALP closer to euk WT", "dALP closer to euk WT"))
write_tsv(wide, file.path(data_dir, "fig_dalp_calp_functional_benchmark_advantage_20260820_paired_source.tsv"))
write_tsv(b, file.path(data_dir, "fig_dalp_calp_functional_benchmark_advantage_20260820_template_summary.tsv"))

lookup_b <- b %>% distinct(module_panel, module_label) %>% tibble::deframe()
p_b <- ggplot(b, aes(x = cALP_advantage, y = module_panel)) +
  geom_vline(xintercept = 0, colour = "#A9A9A9", linewidth = .32) +
  geom_boxplot(fill = "#D8E2EC", colour = "#68809A", width = .62, outlier.shape = NA, linewidth = .3) +
  geom_point(aes(colour = direction), position = position_jitter(height = .11, width = 0), size = 1.05, alpha = .78) +
  facet_wrap(~metric_display, scales = "free", ncol = 2) +
  scale_y_discrete(labels = function(x) unname(lookup_b[x])) +
  scale_colour_manual(values = c("cALP closer to euk WT" = "#3D6D95", "dALP closer to euk WT" = "#C56C4B")) +
  labs(x = "|dALP minus euk WT| minus |cALP minus euk WT| (per actin chain where applicable)", y = NULL,
       title = "Functional modules identify where cALP is closer to the eukaryotic benchmark",
       subtitle = "Positive values: cALP is closer to eukaryotic WT; each point is a template-level median across matched MAG pairs") + theme_pub(7)
save_pub(p_b, file.path(fig_dir, "fig_dalp_calp_functional_benchmark_advantage_boxplots_20260820"), 210, 190)

qa <- c("# Figure QA — boxplot revision — 2026-08-20", "",
  "- Backend: R/ggplot2 only.",
  "- Detailed-complex figure: all eligible templates are mapped to explicit audited contexts; no other/unknown class or pathogen-effector context is plotted.",
  "- Vitamin-D-binding protein contexts (1MA9/1LOT) are extracellular actin-scavenging/monomer-sequestration controls and are excluded from the core-function figures; they remain in the full audit/source inventory and supplement candidate list.",
  "- Detailed-complex sort: one fixed complex order across all metric facets, ranked by pooled dALP median absolute deviation from matched eukaryotic WT.",
  "- Functional figure effect: |dALP-euk WT| - |cALP-euk WT|; positive is closer-to-euk cALP, not a direct functional rescue claim.",
  "- Functional points: template medians across matched MAG pairs; boxes summarize template contexts and do not pool metrics.",
  "- Pathogen-effector contexts remain in the underlying audit/source inventory but are excluded from these core-function figures.",
  "- Reviewer boundary: metrics are independent structural-interface estimates, not biological replicates or direct cellular functional assays.")
writeLines(qa, file.path(root, "audit", "fig_dalp_calp_boxplot_revision_20260820_QA.md"), useBytes = TRUE)
