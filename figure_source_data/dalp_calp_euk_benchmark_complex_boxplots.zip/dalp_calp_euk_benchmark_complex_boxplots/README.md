# dalp_calp_euk_benchmark_complex_boxplots

- Manuscript panel: Supp.Fig.11A-B
- Source figure basename: fig_dalp_calp_euk_benchmark_complex_boxplots_20260820
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 3 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
