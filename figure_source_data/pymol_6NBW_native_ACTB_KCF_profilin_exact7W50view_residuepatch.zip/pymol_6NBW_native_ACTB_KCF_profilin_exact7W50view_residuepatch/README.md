# pymol_6NBW_native_ACTB_KCF_profilin_exact7W50view_residuepatch

- Manuscript panel: Fig.3G
- Source figure basename: fig_pymol_6NBW_native_ACTB_KCF_profilin_exact7W50view_residuepatch
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
