# cALP_AB_five_model_AIC_GTDB_unit_vs_source_branch_lengths_dual_axis

- Source figure: `fig_cALP_AB_five_model_AIC_GTDB_unit_vs_source_branch_lengths_dual_axis`
- Analysis basis: five-model comparison for gappyout584-derived cALP A/B states on the matched GTDB r226 host tree.
- Contents: final PDF/PNG, R plotting code and the plotted unit/source branch-treatment model table.
- Display order: ARD, Sequential Retention, A-middle, B-middle and ancestral coexistence.
- Status: included; the former automated1-derived version is superseded.
- Packaging rule: files were copied; the analysis outputs were not moved.
