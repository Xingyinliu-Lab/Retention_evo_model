suppressPackageStartupMessages({
  library(ggplot2); library(dplyr); library(tidyr); library(readr); library(scales)
})

root <- ".."
fig_dir <- file.path(root, "figures")
src_dir <- file.path(fig_dir, "source_data")
dir.create(src_dir, recursive=TRUE, showWarnings=FALSE)
state_file <- file.path(root, "results/copy_associated_AB_v2_orderCV/copy_associated_AB_host_states.tsv")
unit_file <- file.path(root, "five_model_GTDB_gappyout_backbone/cases/asgard_cALP_copy_associated_AB_gappyout584_GTDB_r226_full737/results/five_model_fit_GTDB.tsv")
unit_ard_file <- file.path(root, "five_model_GTDB_gappyout_backbone/cases/asgard_cALP_copy_associated_AB_gappyout584_GTDB_r226_full737/results/ARD_transition_contribution_GTDB.tsv")
source_file <- file.path(root, "five_model_GTDB_gappyout_backbone/results/source_branch_length_validation/five_model_fit_GTDB_source_branch_lengths.tsv")
source_ard_file <- file.path(root, "five_model_GTDB_gappyout_backbone/results/source_branch_length_validation/ARD_contribution_GTDB_source_branch_lengths.tsv")

theme_pub <- function(base_size=7.2) theme_classic(base_size=base_size, base_family="Arial") +
  theme(axis.line=element_line(linewidth=.30), axis.ticks=element_line(linewidth=.28),
        axis.text=element_text(colour="#252525"), legend.title=element_blank(),
        plot.title=element_text(size=8.1, face="bold"),
        plot.caption=element_text(size=5.3, colour="#555555", hjust=0, margin=margin(t=4)),
        plot.margin=margin(4,7,4,5))
save_plot <- function(p, stem, w, h) {
  ggsave(file.path(fig_dir,paste0(stem,".pdf")),p,width=w,height=h,units="mm",device=cairo_pdf,bg="white")
  ggsave(file.path(fig_dir,paste0(stem,".png")),p,width=w,height=h,units="mm",dpi=600,bg="white")
}

states <- read_tsv(state_file, show_col_types=FALSE)
state_levels <- c("A-only","A+B coexist","B-only")
state_counts <- states %>% count(state,name="n_MAGs") %>%
  complete(state=state_levels,fill=list(n_MAGs=0)) %>%
  mutate(state=factor(state,levels=state_levels))
write_tsv(state_counts,file.path(src_dir,"cALP_AB_observed_state_counts.tsv"))
state_fill <- c("A-only"="#7897B5","A+B coexist"="#79B7A8","B-only"="#DDA06A")
state_edge <- c("A-only"="#4C6B87","A+B coexist"="#4E8378","B-only"="#A96C3E")
p1 <- ggplot(state_counts,aes(state,n_MAGs,fill=state,colour=state))+
  geom_col(width=.58,linewidth=.38)+
  geom_text(aes(label=comma(n_MAGs)),vjust=-.45,size=2.45,family="Arial",fontface="bold",colour="#303030")+
  scale_fill_manual(values=state_fill)+scale_colour_manual(values=state_edge)+
  scale_x_discrete(labels=c("A-only","A + B\ncoexist","B-only"))+
  scale_y_continuous(labels=comma,expand=expansion(mult=c(0,.1)))+
  labs(x=NULL,y="Number of MAGs",title="Observed cALP copy-associated states")+
  theme_pub()+theme(legend.position="none",axis.text.x=element_text(size=6.2),axis.title.y=element_text(size=6.5))
save_plot(p1,"fig_cALP_AB_observed_state_counts",92,72)

lineage <- states %>% filter(state=="A+B coexist") %>% count(class,order,name="coexist_MAGs")
class_levels <- lineage %>% group_by(class) %>% summarise(total=sum(coexist_MAGs),.groups="drop") %>% arrange(desc(total)) %>% pull(class)
order_levels <- lineage %>% group_by(order) %>% summarise(total=sum(coexist_MAGs),.groups="drop") %>% arrange(desc(total)) %>% pull(order)
lineage <- lineage %>% mutate(class=factor(class,levels=class_levels),order=factor(order,levels=order_levels))
write_tsv(lineage,file.path(src_dir,"cALP_AB_coexistence_by_class_order.tsv"))
order_cols <- setNames(c("#527AA3","#D79A5B","#5A9C8B","#9B82B2","#C56E78","#9A9562")[seq_along(order_levels)],order_levels)
p2 <- ggplot(lineage,aes(class,coexist_MAGs,fill=order))+
  geom_col(width=.62,colour="white",linewidth=.35)+
  geom_text(data=lineage %>% filter(coexist_MAGs>=4),aes(label=coexist_MAGs),position=position_stack(vjust=.5),size=2.25,family="Arial",fontface="bold",colour="white")+
  geom_text(data=lineage %>% group_by(class) %>% summarise(coexist_MAGs=sum(coexist_MAGs),.groups="drop"),
            aes(x=class,label=coexist_MAGs,y=coexist_MAGs),vjust=-.45,size=2.35,family="Arial",fontface="bold",inherit.aes=FALSE)+
  scale_fill_manual(values=order_cols)+scale_y_continuous(expand=expansion(mult=c(0,.12)))+
  labs(x=NULL,y="Coexistence MAGs",title="cALP A + B coexistence spans Asgard lineages")+
  theme_pub()+theme(legend.position="right",legend.text=element_text(size=5.5),axis.text.x=element_text(size=5.9))
save_plot(p2,"fig_cALP_AB_coexistence_lineage_breadth",128,82)

model_levels <- c("ARD unrestricted","Sequential\nretention","B-middle\nadjacency","A-middle\nadjacency","Ancestral coexist\n(strict)")
unit <- read_tsv(unit_file,show_col_types=FALSE) %>% mutate(branch_scale="Unit topology")
source <- read_tsv(source_file,show_col_types=FALSE) %>% mutate(branch_scale="Source branch lengths")
models <- bind_rows(unit,source) %>% mutate(model_label=recode(model,
  ARD_unrestricted="ARD unrestricted",adjacency_coexist_middle="Sequential\nretention",
  adjacency_B_middle="B-middle\nadjacency",adjacency_A_middle="A-middle\nadjacency",
  ancestral_coexistence_strict="Ancestral coexist\n(strict)"),
  model_label=factor(model_label,levels=model_levels),branch_scale=factor(branch_scale,levels=c("Unit topology","Source branch lengths")),
  label=sprintf("%.1f",delta_AIC))
unit_max <- max(models$delta_AIC[models$branch_scale=="Unit topology"])
source_max <- max(models$delta_AIC[models$branch_scale=="Source branch lengths"])
scale_factor <- source_max/unit_max
models <- models %>% mutate(y_plot=if_else(branch_scale=="Source branch lengths",delta_AIC/scale_factor,delta_AIC))
write_tsv(models,file.path(src_dir,"cALP_AB_five_model_AIC_GTDB_unit_vs_source.tsv"))
branch_cols <- c("Unit topology"="#777777","Source branch lengths"="#4F857D")
p3 <- ggplot(models,aes(model_label,y_plot,fill=branch_scale))+
  geom_col(position=position_dodge(width=.74),width=.64)+
  geom_text(aes(label=label),position=position_dodge(width=.74),vjust=-.45,size=1.95,family="Arial",colour="#303030")+
  scale_fill_manual(values=branch_cols)+
  scale_y_continuous(name=expression("Unit-topology "*Delta*"AIC"),limits=c(0,unit_max*1.13),breaks=pretty_breaks(6),expand=expansion(mult=c(0,0)),
    sec.axis=sec_axis(~.*scale_factor,name=expression("Source branch-length "*Delta*"AIC"),breaks=pretty_breaks(6)(c(0,source_max))))+
  labs(title="GTDB r226 model comparison",x=NULL,caption="Bars use separate linear axes; labels show raw delta-AIC values.")+
  theme_pub()+theme(axis.text.x=element_text(size=5.9,lineheight=.92),axis.text.y.left=element_text(size=6.2,colour=branch_cols[[1]]),
    axis.text.y.right=element_text(size=6.2,colour=branch_cols[[2]]),axis.title.y.left=element_text(size=7,colour=branch_cols[[1]]),
    axis.title.y.right=element_text(size=7,colour=branch_cols[[2]]),legend.position="top",legend.text=element_text(size=6))
save_plot(p3,"fig_cALP_AB_five_model_AIC_GTDB_unit_vs_source_branch_lengths_dual_axis",148,98)

uard <- read_tsv(unit_ard_file,show_col_types=FALSE) %>% transmute(branch_scale="Unit topology",`Coexist-mediated`=100*coexist_mediated_fraction,`Direct endpoint transition`=100*direct_endpoint_fraction)
sard <- read_tsv(source_ard_file,show_col_types=FALSE) %>% transmute(branch_scale="Source branch lengths",`Coexist-mediated`=100*coexist_mediated_fraction,`Direct endpoint transition`=100*direct_endpoint_fraction)
ard <- bind_rows(uard,sard) %>% pivot_longer(-branch_scale,names_to="route",values_to="percent") %>%
  mutate(route=factor(route,levels=c("Coexist-mediated","Direct endpoint transition")),branch_scale=factor(branch_scale,levels=c("Unit topology","Source branch lengths")),label=sprintf("%.2f%%",percent))
ard <- ard %>% mutate(label=if_else(percent < 0.01 | percent > 99.99,
                                    sprintf("%.3f%%",percent),sprintf("%.2f%%",percent)))
write_tsv(ard,file.path(src_dir,"cALP_AB_ARD_transition_contribution_GTDB_unit_vs_source.tsv"))
p4 <- ggplot(ard,aes(route,percent,fill=branch_scale))+
  geom_col(position=position_dodge(width=.72),width=.62)+
  geom_text(aes(label=label),position=position_dodge(width=.72),vjust=-.45,size=2.15,family="Arial",colour="#303030")+
  scale_fill_manual(values=branch_cols)+scale_x_discrete(labels=c("Coexist-mediated","Direct endpoint\ntransition"))+
  scale_y_continuous(limits=c(0,104),breaks=seq(0,100,20),expand=expansion(mult=c(0,0)))+
  labs(title="GTDB r226 ARD transition routes",x=NULL,y="Share of inferred ARD transitions (%)",
       caption="Fixed-Q stochastic-history posterior means under two branch-length scales.")+
  theme_pub()+theme(legend.position="top",legend.text=element_text(size=6),axis.text.x=element_text(size=6.2),axis.title.y=element_text(size=7))
save_plot(p4,"fig_cALP_AB_ARD_transition_contribution_GTDB_unit_vs_source_branch_lengths",108,92)

writeLines(c("status=complete","backend=R","figures=4","formats=pdf,png"),file.path(fig_dir,"CALP_AB_FOUR_SUBFIGURES_COMPLETE.marker"))
