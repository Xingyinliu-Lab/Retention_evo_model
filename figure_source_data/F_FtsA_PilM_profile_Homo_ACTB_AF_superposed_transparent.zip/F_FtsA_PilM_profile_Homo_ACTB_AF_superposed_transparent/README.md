# F_FtsA_PilM_profile_Homo_ACTB_AF_superposed_transparent

- Manuscript panel: Supp.Fig.4B
- Source figure basename: F_FtsA_PilM_profile_Homo_ACTB_AF_superposed_transparent
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
