# selected_context_boxplot_contacts

- Manuscript panel: Supp.Fig.7E
- Source figure basename: fig_selected_context_boxplot_contacts
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
