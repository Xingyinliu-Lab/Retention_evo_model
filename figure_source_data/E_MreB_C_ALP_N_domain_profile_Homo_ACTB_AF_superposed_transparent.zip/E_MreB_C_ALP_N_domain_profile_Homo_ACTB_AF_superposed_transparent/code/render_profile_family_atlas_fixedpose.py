"""Fixed-pose profile-family atlas anchored to Homo ACTB AlphaFold.

Run in a PyMOL Python environment, for example: pymol -cq render_profile_family_atlas_fixedpose.py
Outputs are PNG only. Archaeal models use the frozen coordinates already superposed
to Homo ACTB AlphaFold, then receive the same 8F8P fixed-pose transform and view.
"""
from math import acos, degrees, sqrt
from pathlib import Path
import csv
import os
from pymol import cmd

ROOT = Path(r"..")
OUT = ROOT / "pymol_profile_family_atlas_fixedpose"
SUPER_DIR = ROOT / "pymol_super_to_human_ACTB_AF"
MAP_ROOT = ROOT / "batch_hmm_structure_diff_to_Homo_ACTB_AF/per_site_spatial_monotonic_max10"
POSE_REFERENCE = Path(r"../data/8VKH.cif")
OUT.mkdir(exist_ok=True)
RENDER_MODE = os.environ.get("PYMOL_RENDER_MODE", "composite")

CASES = [
    ("B", "cALPs", "fold_GCA_054384275.1_S.8_46_model_0_super_to_human_ACTB_AF.pdb"),
    ("C", "dALPs", "fold_GCA_023269865.1_S.28_30_model_0_super_to_human_ACTB_AF.pdb"),
    ("D", "MreB/Mbl-profile proteins", "fold_GCA_002718195.1_S.3_40_model_0_super_to_human_ACTB_AF.pdb"),
    ("E", "MreB_C/ALP_N domain-profile proteins", "fold_GCA_000965745.1_S.1_503_model_0_super_to_human_ACTB_AF.pdb"),
    ("F", "FtsA/PilM-profile proteins", "fold_gca_038861055_1_s_68_5_model_0_super_to_human_ACTB_AF.pdb"),
    ("G", "Salactin-like proteins", "fold_gca_002494725_1_s_24_134_model_0_super_to_human_ACTB_AF.pdb"),
    ("H", "Volactin-like proteins", "fold_gca_046546175_1_s_27_11_model_0_super_to_human_ACTB_AF.pdb"),
]
RAW_FILES = {
    "fold_GCA_054384275.1_S.8_46_model_0_super_to_human_ACTB_AF.pdb": "fold_GCA_054384275.1_S.8_46_model_0.cif",
}

def centroid(selection):
    atoms = cmd.get_model(selection).atom
    if not atoms:
        raise ValueError(f"Empty selection: {selection}")
    return [sum(atom.coord[i] for atom in atoms) / len(atoms) for i in range(3)]

def residue_list(super_name, start, end):
    """Final HMM/spatial mapped residue identifiers, preserving only observed residues."""
    path = MAP_ROOT / f"{Path(super_name).stem}_hmm_structure_diff_spatial_monotonic_max10.tsv"
    values = []
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            hmm = int(row["HMM_Pos"])
            if not start <= hmm <= end:
                continue
            resi = row["Qry_StructResi"] if row["Final_Mapping_Source"] == "HMM" else row["Spatial_Qry_StructResi"]
            if resi:
                values.append(resi.split(".")[0])
    return "+".join(dict.fromkeys(values))

def fixedpose_8f8p_transform():
    """Exact 8F8P reference transform, calculated from 8VKH actin chain E."""
    core = centroid("pose_reference and chain E and resi 1-340 and not hydro")
    tail = centroid("pose_reference and chain E and resi 351-375 and not hydro")
    vector = [tail[i] - core[i] for i in range(3)]
    norm = sqrt(sum(x * x for x in vector))
    vector = [x / norm for x in vector]
    target = [-0.36, 0.20, 0.91]
    target_norm = sqrt(sum(x * x for x in target))
    target = [x / target_norm for x in target]
    axis = [vector[1] * target[2] - vector[2] * target[1], vector[2] * target[0] - vector[0] * target[2], vector[0] * target[1] - vector[1] * target[0]]
    axis_norm = sqrt(sum(x * x for x in axis))
    if axis_norm < 1e-8:
        return core, [1.0, 0.0, 0.0], 0.0 if vector[2] > 0 else 180.0
    axis = [x / axis_norm for x in axis]
    angle = degrees(acos(max(-1.0, min(1.0, sum(vector[i] * target[i] for i in range(3))))))
    return core, axis, angle

def apply_gradient(obj):
    model = cmd.get_model(obj).atom
    resi = sorted({int(a.resi) for a in model if a.resi.lstrip("-").isdigit()})
    if not resi:
        return
    first, last, bins = min(resi), max(resi), 75
    for index in range(bins):
        start = first + (last - first + 1) * index // bins
        end = first + (last - first + 1) * (index + 1) // bins - 1
        cmd.color(f"actin_gradient_{index:02d}", f"{obj} and resi {start}-{end}")

def render_case(panel, label, super_name):
    obj = f"panel_{panel.lower()}"
    if RENDER_MODE == "cALP_layer":
        # The visual overlay is a fresh full-length PyMOL superposition to the same
        # frozen AF reference; frozen superposed coordinates remain unmodified.
        cmd.load(str(ROOT / RAW_FILES[super_name]), obj)
        cmd.align(obj, "anchor")
    else:
        cmd.load(str(SUPER_DIR / super_name), obj)
        # Preserve frozen superposed coordinates for non-layer renders.
        cmd.matrix_copy("anchor", obj)
    if RENDER_MODE != "cALP_layer":
        cmd.show("ribbon", "anchor")
        cmd.color("actb_reference_gold", "anchor")
        cmd.set("line_width", 3.5, "anchor")
    cmd.hide("everything", obj)
    cmd.show("cartoon", obj)
    apply_gradient(obj)
    cmd.set("cartoon_transparency", 0.35, obj)
    body = residue_list(super_name, 386, 407)
    cap = residue_list(super_name, 408, 410)
    if body:
        cmd.color("tail_body_cyan", f"{obj} and resi {body}")
    if cap:
        cmd.color("terminal_kcf_rose", f"{obj} and resi {cap}")
        cmd.show("sticks", f"{obj} and resi {cap}")
    cmd.set_view(FIXED_VIEW)
    cmd.ray(2400, 1800)
    suffix = "_cALP_layer" if RENDER_MODE == "cALP_layer" else ""
    cmd.png(str(OUT / f"{panel}_{label.replace('/', '_').replace(' ', '_')}{suffix}.png"), dpi=300)
    cmd.sync()

cmd.reinitialize()
cmd.set_color("ink", [0.071, 0.094, 0.133])
cmd.bg_color("ink")
cmd.set_color("tail_body_cyan", [0.32, 0.72, 0.85])
cmd.set_color("terminal_kcf_rose", [0.941, 0.310, 0.471])
cmd.set_color("actb_reference_gold", [0.95, 0.62, 0.05])
for index in range(75):
    fraction = index / 74
    start, end = [0.298, 0.471, 0.659], [0.420, 0.620, 0.700]
    cmd.set_color(f"actin_gradient_{index:02d}", [start[i] * (1 - fraction) + end[i] * fraction for i in range(3)])
cmd.set("ray_opaque_background", 1)
cmd.set("orthoscopic", 0)
cmd.set("antialias", 2)
cmd.set("ambient", 0.20)
cmd.set("direct", 0.80)
cmd.set("specular", 0.32)
cmd.set("shininess", 40)
cmd.set("ray_shadows", 1)
cmd.set("ambient_occlusion_mode", 2)
cmd.set("depth_cue", 1)
cmd.set("fog", 1)
cmd.set("fog_start", 0.35)
cmd.set("cartoon_fancy_helices", 1)
cmd.set("stick_radius", 0.18)

# First place the frozen analytical reference, Homo ACTB AlphaFold, in the exact 8F8P pose.
cmd.load(str(ROOT / "Homo_actb_AF-P60709-F1-model_v6.cif"), "anchor")
cmd.load(str(POSE_REFERENCE), "pose_reference")
cmd.align("anchor", "pose_reference and chain E")
POSE_CENTER, POSE_AXIS, POSE_ANGLE = fixedpose_8f8p_transform()
cmd.translate([-POSE_CENTER[0], -POSE_CENTER[1], -POSE_CENTER[2]], "anchor", camera=0)
cmd.rotate(POSE_AXIS, POSE_ANGLE, "anchor", camera=0)
cmd.hide("everything", "pose_reference")
cmd.zoom("anchor", 6)
FIXED_VIEW = cmd.get_view()
cmd.hide("everything", "anchor")
requested = {x.strip().upper() for x in os.environ.get("PYMOL_PANEL", "").split(",") if x.strip()}
if RENDER_MODE == "reference_layer":
    cmd.show("cartoon", "anchor")
    cmd.color("actb_reference_gold", "anchor")
    cmd.set_view(FIXED_VIEW)
    cmd.ray(2400, 1800)
    cmd.png(str(OUT / "B_cALPs_ACTB_AF_layer.png"), dpi=300)
    cmd.sync()
else:
    for case in CASES:
        if requested and case[0] not in requested:
            continue
        render_case(*case)
cmd.quit()
