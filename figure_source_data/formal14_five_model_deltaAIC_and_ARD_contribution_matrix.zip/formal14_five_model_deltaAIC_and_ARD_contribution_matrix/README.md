# formal14_five_model_deltaAIC_and_ARD_contribution_matrix

- Manuscript panel: Fig.6G
- Source figure basename: fig_formal14_five_model_deltaAIC_and_ARD_contribution_matrix_prototype
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
