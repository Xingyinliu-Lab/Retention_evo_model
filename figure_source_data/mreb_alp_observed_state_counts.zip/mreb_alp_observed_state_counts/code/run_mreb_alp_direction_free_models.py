#!/usr/bin/env python3
"""Small, reproducible CTMC comparison for frozen MreB-type versus ALP-type states."""
from __future__ import annotations

import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import csv, json, math
from collections import Counter
from pathlib import Path
import numpy as np
from Bio import Phylo
from Bio.Phylo.BaseTree import Clade, Tree
from scipy.linalg import expm
from scipy.optimize import minimize

WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK.parents[0] / "mreb_cd_aggregate_retention_lowcost_audit_20260810"
STATE_FILE = SOURCE / "data" / "MAG_MreB_CD_aggregate_states.tsv"
MAP_FILE = SOURCE / "results" / "gtdb_exact_mapping.tsv"
TREE_FILE = WORK.parents[1] / "actin_origin_species_tree" / "plot_source_data" / "gtdb_ar53_expanded_with_user_mags.treefile"
OUT = WORK / "results"
LEVELS = ("M-only", "M+ALP coexist", "ALP-only")
CODE = {x:i for i,x in enumerate(LEVELS)}
SOURCE_TO_FORMAL = {"M-state": "M-only", "coexistence": "M+ALP coexist", "C/D-state": "ALP-only"}

def rows(path):
    with path.open(encoding="utf-8", newline="") as h: return list(csv.DictReader(h, delimiter="\t"))
def write(path, data):
    with path.open("w", encoding="utf-8", newline="") as h:
        w=csv.DictWriter(h, fieldnames=list(data[0]) if data else [], delimiter="\t", lineterminator="\n"); w.writeheader(); w.writerows(data)
def norm(x):
    x = (x or "").split("|")[0]
    return x.split("_", 1)[1] if x.startswith(("GB_", "RS_")) else x
def restrict(source, states):
    def visit(node, root=False):
        if node.is_terminal():
            return Clade(branch_length=node.branch_length, name=node.name) if node.name in states else None
        kids=[v for c in node.clades if (v:=visit(c)) is not None]
        if not kids: return None
        if len(kids)==1 and not root:
            kid=kids[0]; kid.branch_length=float(kid.branch_length or 0)+float(node.branch_length or 0); return kid
        return Clade(branch_length=node.branch_length, clades=kids)
    root=visit(source.root, True)
    while len(root.clades)==1 and not root.is_terminal(): root=root.clades[0]; root.branch_length=None
    return Tree(root=root, rooted=source.rooted)
def stationary(q):
    vals, vecs=np.linalg.eig(q.T); v=np.abs(np.real(vecs[:,np.argmin(np.abs(vals))])); return v/v.sum()
def fit(tree, tipstate, scale, name, root_mode, edges):
    nodes=list(tree.find_clades(order="postorder")); idx={id(n):i for i,n in enumerate(nodes)}
    kids=[[(idx[id(c)],1.0 if scale=="unit_topology" else max(float(c.branch_length or 0),1e-8)) for c in n.clades] for n in nodes]
    names=[n.name if n.is_terminal() else None for n in nodes]
    def objective(logr):
        q=np.zeros((3,3))
        for r,(a,b) in zip(np.exp(logr),edges): q[a,b]=r
        np.fill_diagonal(q,-q.sum(axis=1)); cache={}; likes=[np.ones(3) for _ in nodes]; logscale=0.0
        for i,n in enumerate(nodes):
            if n.is_terminal():
                v=np.zeros(3); v[tipstate[names[i]]]=1; likes[i]=v; continue
            v=np.ones(3)
            for ci,bl in kids[i]:
                key=round(bl,12); cache.setdefault(key,expm(q*bl)); v*=cache[key]@likes[ci]
            total=v.sum()
            if total<=0 or not np.isfinite(total): return 1e100
            likes[i]=v/total; logscale+=math.log(total)
        prior=stationary(q) if root_mode=="stationary" else np.eye(3)[root_mode]
        value=float(prior@likes[-1])
        return 1e100 if value<=0 or not np.isfinite(value) else -(math.log(value)+logscale)
    best=min((minimize(objective,s,method="L-BFGS-B",bounds=[(-10,10)]*len(edges),options={"maxiter":300,"ftol":1e-10}) for s in (np.zeros(len(edges)),np.full(len(edges),-1.0))),key=lambda x:x.fun)
    return {"model":name,"root_mode":LEVELS[root_mode] if isinstance(root_mode,int) else root_mode,"branch_scale":scale,"k":len(edges),"log_likelihood":-float(best.fun),"AIC":2*len(edges)+2*float(best.fun),"success":str(bool(best.success)).upper(),"rates":";".join(f"{LEVELS[a]}->{LEVELS[b]}:{math.exp(x):.7g}" for x,(a,b) in zip(best.x,edges))}
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    raw=rows(STATE_FILE)
    source_tree=Phylo.read(str(TREE_FILE),"newick")
    state_by_mag={r["mag_id"]:SOURCE_TO_FORMAL[r["state"]] for r in raw if r["state"] in SOURCE_TO_FORMAL}
    mapped={r["gtdb_tip"]:state_by_mag[r["mag_id"]] for r in rows(MAP_FILE) if r["gtdb_tip"] and r["mag_id"] in state_by_mag}
    if not mapped:
        raise RuntimeError(f"No exact GTDB MAG matches; state_sample={raw[0]['mag_id']}; tree_sample={source_tree.get_terminals()[0].name}; lookup={norm(source_tree.get_terminals()[0].name)}")
    tree=restrict(source_tree,mapped); tips=[x.name for x in tree.get_terminals()]
    if set(tips)!=set(mapped): raise RuntimeError(f"Tree state map mismatch: {len(tips)} tips vs {len(mapped)} states")
    states={x:CODE[mapped[x]] for x in tips}; adjacent=((0,1),(1,0),(1,2),(2,1)); all_edges=tuple((i,j) for i in range(3) for j in range(3) if i!=j)
    out=[]
    # Topology is the primary formal test.  Branch-length sensitivity is stored
    # separately only after a length-scale audit; do not silently round lengths.
    for scale in ("unit_topology",):
        endpoint_m=fit(tree,states,scale,"retention_sequential_M_endpoint",0,adjacent)
        endpoint_alp=fit(tree,states,scale,"retention_sequential_ALP_endpoint",2,adjacent)
        current=[endpoint_m,endpoint_alp,fit(tree,states,scale,"ancestral_coexistence_strict",1,((1,0),(1,2))),fit(tree,states,scale,"ARD_unrestricted","stationary",all_edges),fit(tree,states,scale,"adjacent_reversible_sensitivity","stationary",adjacent)]
        best=min(x["AIC"] for x in current)
        for x in current: x["delta_AIC"]=x["AIC"]-best; x["tree"]="GTDB_r226_expanded"; x["mapped_MAGs"]=len(tips); out.append(x)
    write(OUT/"MreB_ALP_three_state_model_comparison_v2.tsv",out)
    summary={"tree":"GTDB_r226_expanded","mapped_MAGs":len(tips),"state_counts":dict(Counter(mapped.values())),"models":"direction-free union of separately fitted M-endpoint and ALP-endpoint retention, strict ancestral coexistence, ARD; adjacent reversible sensitivity","boundary":"No M-to-ALP direction, replacement, gene-tree, DTL, or HGT inference."}
    (OUT/"MreB_ALP_three_state_model_summary_v2.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    (WORK/"MREB_ALP_DIRECTION_FREE_MODEL_V2_COMPLETE.marker").write_text("status=complete\nversion=v2_separate_endpoint_models\n",encoding="utf-8")
    print(json.dumps(summary))
if __name__=="__main__": main()
