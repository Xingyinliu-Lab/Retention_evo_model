suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
})

task_dir <- ".."
source_dir <- ".."
fig_dir <- file.path(task_dir, "figures")
data_dir <- file.path(fig_dir, "source_data")
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

theme_pub <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(axis.line = element_line(linewidth = 0.35), axis.ticks = element_line(linewidth = 0.35),
          axis.text = element_text(colour = "#252525"), legend.title = element_blank(),
          plot.title = element_text(face = "bold", size = base_size + 1),
          plot.subtitle = element_text(size = base_size - 0.2, colour = "#555555"),
          plot.margin = margin(5, 7, 5, 5))
}
save_plot <- function(p, stem, width_mm = 90, height_mm = 72) {
  ggsave(file.path(fig_dir, paste0(stem, ".pdf")), p, width = width_mm, height = height_mm,
         units = "mm", device = cairo_pdf, bg = "white")
  ggsave(file.path(fig_dir, paste0(stem, ".png")), p, width = width_mm, height = height_mm,
         units = "mm", dpi = 600, bg = "white")
}

states <- read.delim(file.path(source_dir, "results/state_counts.tsv"), check.names = FALSE) %>%
  filter(include_in_main_transition == "yes") %>%
  mutate(state = recode(state, `M-state` = "M-only", `C/D-state` = "ALP-only", coexistence = "M + ALP coexist"),
         state = factor(state, levels = c("M-only", "M + ALP coexist", "ALP-only")))
write.table(states, file.path(data_dir, "MreB_ALP_state_counts.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
p_states <- ggplot(states, aes(state, n_MAGs, fill = state, colour = state)) +
  geom_col(width = 0.58, linewidth = 0.38) +
  geom_text(aes(label = scales::comma(n_MAGs)), vjust = -0.45, size = 2.45,
            family = "Arial", fontface = "bold", colour = "#303030") +
  scale_fill_manual(values = c(
    "M-only" = "#7897B5",
    "M + ALP coexist" = "#79B7A8",
    "ALP-only" = "#DDA06A"
  )) +
  scale_colour_manual(values = c(
    "M-only" = "#4C6B87",
    "M + ALP coexist" = "#4E8378",
    "ALP-only" = "#A96C3E"
  )) +
  scale_x_discrete(labels = c("M-only", "M + ALP\ncoexist", "ALP-only")) +
  scale_y_continuous(labels = scales::comma, expand = expansion(mult = c(0, 0.1))) +
  labs(x = NULL, y = "Number of MAGs", title = "Observed MreB/ALP aggregate states") +
  theme_pub() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 0, hjust = 0.5, size = 6.2),
    axis.title.y = element_text(size = 6.5),
    plot.title = element_text(size = 8.1, face = "bold")
  )
save_plot(p_states, "fig_mreb_alp_observed_state_counts", 92, 72)

coexist <- read.delim(file.path(source_dir, "results/coexistence_MAGs.tsv"), check.names = FALSE)
orders <- coexist %>% count(phylum, class, order, name = "coexist_MAGs") %>% arrange(coexist_MAGs)
write.table(orders, file.path(data_dir, "MreB_ALP_coexistence_by_lineage.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
class_levels <- c(
  "Heimdallarchaeia", "Njordarchaeia", "Lokiarchaeia",
  "Bathyarchaeia", "Thermoprotei", "Aenigmatarchaeia"
)
phylum_class <- orders %>%
  group_by(phylum, class) %>%
  summarise(coexist_MAGs = sum(coexist_MAGs), .groups = "drop") %>%
  mutate(class = factor(class, levels = class_levels))
phylum_levels <- phylum_class %>%
  group_by(phylum) %>%
  summarise(total_MAGs = sum(coexist_MAGs), .groups = "drop") %>%
  arrange(desc(total_MAGs)) %>%
  pull(phylum)
phylum_class <- phylum_class %>%
  mutate(phylum = factor(phylum, levels = phylum_levels)) %>%
  arrange(phylum, class) %>%
  group_by(phylum) %>%
  mutate(
    total_MAGs = sum(coexist_MAGs),
    cumulative_MAGs = cumsum(coexist_MAGs),
    previous_MAGs = cumulative_MAGs - coexist_MAGs,
    ymin_plot = log10(previous_MAGs + 1),
    ymax_plot = log10(cumulative_MAGs + 1),
    ymid_plot = (ymin_plot + ymax_plot) / 2,
    x_plot = as.numeric(phylum)
  ) %>%
  ungroup()
write.table(
  phylum_class,
  file.path(data_dir, "MreB_ALP_coexistence_by_phylum_class_stacked.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE
)
phylum_totals <- phylum_class %>% distinct(phylum, x_plot, total_MAGs) %>%
  mutate(y_plot = log10(total_MAGs + 1) + 0.075)

p_orders <- ggplot(phylum_class) +
  geom_rect(
    aes(xmin = x_plot - 0.31, xmax = x_plot + 0.31,
        ymin = ymin_plot, ymax = ymax_plot, fill = class),
    colour = "white", linewidth = 0.42
  ) +
  geom_text(
    data = filter(phylum_class, coexist_MAGs >= 5),
    aes(x = x_plot, y = ymid_plot, label = coexist_MAGs),
    family = "Arial", size = 2.25, fontface = "bold", colour = "white"
  ) +
  geom_text(
    data = phylum_totals,
    aes(x = x_plot, y = y_plot, label = scales::comma(total_MAGs)),
    family = "Arial", size = 2.35, fontface = "bold", colour = "#303030"
  ) +
  scale_fill_manual(values = c(
    Aenigmatarchaeia = "#C68A7A",
    Bathyarchaeia = "#B6A166",
    Heimdallarchaeia = "#5F9A87",
    Lokiarchaeia = "#6489B4",
    Njordarchaeia = "#8C9FC5",
    Thermoprotei = "#9A84B5"
  )) +
  scale_x_continuous(
    breaks = seq_along(phylum_levels), labels = phylum_levels,
    limits = c(0.55, length(phylum_levels) + 0.45)
  ) +
  scale_y_continuous(
    breaks = log10(c(0, 1, 3, 10, 30, 100, 200) + 1),
    labels = c(0, 1, 3, 10, 30, 100, 200),
    limits = c(0, log10(max(phylum_totals$total_MAGs) + 1) + 0.18),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = NULL,
    y = "Coexistence MAGs (log10[count + 1] scale)",
    title = "MreB + ALP coexistence spans phyla and classes"
  ) +
  theme_pub() +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 5.5),
    axis.text.x = element_text(size = 5.9),
    axis.title.y = element_text(size = 6.2)
  )
save_plot(p_orders, "fig_mreb_alp_coexistence_lineage_breadth", 128, 82)

loo <- read.delim(file.path(source_dir, "results/LOCO_lineage_confounder_audit.tsv"), check.names = FALSE) %>%
  mutate(label = paste(leave_out_level, lineage_removed, sep = ": "))
write.table(loo, file.path(data_dir, "MreB_ALP_LOCO.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
p_loo <- ggplot(loo, aes(coexistence_remaining, reorder(label, coexistence_remaining), shape = leave_out_level, colour = leave_out_level)) +
  geom_vline(xintercept = 191, linewidth = 0.35, linetype = 2, colour = "#999999") +
  geom_point(size = 2.2) +
  scale_colour_manual(values = c(class = "#4C78A8", order = "#4FAF9F")) +
  labs(x = "Coexistence MAGs remaining after lineage removal", y = NULL,
       title = "Coexistence persists in every leave-one-lineage-out test") +
  theme_pub(6.5) + theme(legend.position = "top", axis.text.y = element_text(size = 5.5))
save_plot(p_loo, "fig_mreb_alp_leave_one_lineage_out", 112, 85)

prox <- read.delim(file.path(source_dir, "results/coexistence_nearest_endpoint_context.tsv"), check.names = FALSE)
write.table(prox, file.path(data_dir, "MreB_ALP_coexistence_endpoint_distances.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
p_prox <- ggplot(prox, aes(nearest_M_state_topology_edges, nearest_CD_state_topology_edges, colour = closer_endpoint)) +
  geom_abline(slope = 1, intercept = 0, linewidth = 0.4, linetype = 2, colour = "#777777") +
  geom_point(size = 1.5, alpha = 0.7) +
  scale_colour_manual(values = c(`M-state` = "#4C78A8", `C/D-state` = "#E89C5B", tie = "#777777"),
                      labels = c(`M-state` = "Closer to M-only", `C/D-state` = "Closer to ALP-only", tie = "Tie")) +
  coord_equal() +
  labs(x = "Topology edges to nearest M-only MAG", y = "Topology edges to nearest ALP-only MAG",
       title = "Coexistence occurs near both endpoint states") +
  theme_pub() + theme(legend.position = "top")
save_plot(p_prox, "fig_mreb_alp_coexistence_endpoint_context", 92, 88)

model_file <- file.path(task_dir, "results/MreB_ALP_three_state_model_comparison_v2.tsv")
if (file.exists(model_file)) {
  models <- read.delim(model_file, check.names = FALSE) %>%
    mutate(model_label = recode(model,
      retention_sequential_M_endpoint = "Sequential retention (M endpoint)",
      retention_sequential_ALP_endpoint = "Sequential retention (ALP endpoint)",
      ancestral_coexistence_strict = "Ancestral coexistence (strict)",
      ARD_unrestricted = "Unrestricted ARD",
      adjacent_reversible_sensitivity = "Adjacent-state reversible"),
      model_label = factor(model_label, levels = rev(c("Unrestricted ARD", "Sequential retention (M endpoint)",
        "Adjacent-state reversible", "Sequential retention (ALP endpoint)", "Ancestral coexistence (strict)"))))
  write.table(models, file.path(data_dir, "MreB_ALP_model_AIC_v2.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
  p_model <- ggplot(models, aes(delta_AIC, model_label)) +
    geom_segment(aes(x = 0, xend = delta_AIC, yend = model_label), colour = "#D8D8D8", linewidth = 0.7) +
    geom_point(aes(colour = model == "ARD_unrestricted"), size = 2.7) +
    geom_text(aes(label = sprintf("%.1f", delta_AIC)), hjust = -0.18, size = 2.3, family = "Arial") +
    scale_colour_manual(values = c(`TRUE` = "#4FAF9F", `FALSE` = "#606060")) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.18))) +
    labs(x = "Difference in AIC from the best model", y = NULL,
         title = "ARD is preferred over homogeneous sequential models") +
    theme_pub(6.5) + theme(legend.position = "none")
  save_plot(p_model, "fig_mreb_alp_three_state_model_AIC", 125, 72)

  ard <- models %>% filter(model == "ARD_unrestricted") %>% select(rates) %>%
    separate_rows(rates, sep = ";") %>% separate(rates, into = c("transition", "rate"), sep = ":") %>%
    mutate(rate = as.numeric(rate), transition_class = ifelse(transition %in% c("M-only->ALP-only", "ALP-only->M-only"),
                                                               "Direct endpoint", "Via coexistence"),
           transition = factor(transition, levels = transition[order(rate)]))
  write.table(ard, file.path(data_dir, "MreB_ALP_ARD_transition_rates.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
  p_ard <- ggplot(ard, aes(rate, transition, colour = transition_class)) +
    geom_segment(aes(x = 0, xend = rate, yend = transition), colour = "#D8D8D8", linewidth = 0.7) +
    geom_point(size = 2.7) +
    scale_colour_manual(values = c("Via coexistence" = "#4FAF9F", "Direct endpoint" = "#B8786B")) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.08))) +
    labs(x = "Estimated transition rate (unit-topology scale)", y = NULL,
         title = "ARD includes coexistence-mediated and direct routes") +
    theme_pub(6.5) + theme(legend.position = "top", axis.text.y = element_text(size = 5.8))
  save_plot(p_ard, "fig_mreb_alp_ARD_transition_rates", 125, 78)
}
