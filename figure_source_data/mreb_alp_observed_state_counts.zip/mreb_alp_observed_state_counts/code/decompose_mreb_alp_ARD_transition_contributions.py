#!/usr/bin/env python3
"""Decompose fixed-Q MreB/ALP ARD histories into coexist-mediated and direct routes."""
from __future__ import annotations

import csv
import importlib.util
import json
import math
from pathlib import Path

import numpy as np
from Bio import Phylo


ROOT = Path(__file__).resolve().parents[1]
FOUR_PATH = ROOT / "code" / "run_mreb_alp_four_tree_models.py"
GENERIC_PATH = (
    ROOT.parents[0]
    / "calp_dalp_full2606_placement584_retention_20260810"
    / "code"
    / "decompose_ARD_transition_contributions.py"
)
RESULTS = ROOT / "results"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


FOUR = load_module(FOUR_PATH, "mreb_four_tree_inputs")
GENERIC = load_module(GENERIC_PATH, "generic_ard_decomposition")
BASE = FOUR.BASE

TRANSITIONS = {
    "M-only->M+ALP coexist": (0, 1),
    "M-only->ALP-only": (0, 2),
    "M+ALP coexist->M-only": (1, 0),
    "M+ALP coexist->ALP-only": (1, 2),
    "ALP-only->M-only": (2, 0),
    "ALP-only->M+ALP coexist": (2, 1),
}
GROUPS = {
    "via_coexist_adjacent": ((0, 1), (1, 0), (1, 2), (2, 1)),
    "direct_single_state": ((0, 2), (2, 0)),
    "all_transitions": tuple(TRANSITIONS.values()),
}


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def parse_q(text: str):
    q = np.zeros((3, 3), dtype=float)
    index = {name: i for i, name in enumerate(BASE.LEVELS)}
    for token in text.split(";"):
        edge, value = token.rsplit(":", 1)
        source, target = edge.split("->", 1)
        q[index[source], index[target]] = float(value)
    np.fill_diagonal(q, -q.sum(axis=1))
    return q


def prepare_trees(states):
    trees = {}

    source = Phylo.read(str(BASE.TREE_FILE), "newick")
    mapped = {
        row["gtdb_tip"]: states[row["mag_id"]]
        for row in BASE.rows(BASE.MAP_FILE)
        if row["gtdb_tip"] and row["mag_id"] in states
    }
    trees["GTDB_r226"] = (BASE.restrict(source, mapped), mapped, 0)

    guide_source = Phylo.read(str(FOUR.GUIDE_TREE), "newick")
    guide_tips = FOUR.leaves(guide_source)
    for tree_name, path in FOUR.TREE_SPECS.items():
        target_source = Phylo.read(str(path), "newick")
        shared = FOUR.leaves(target_source) & guide_tips & set(states)
        mapped = {mag: states[mag] for mag in shared}
        target = BASE.restrict(target_source, mapped)
        guide = BASE.restrict(guide_source, mapped)
        mismatch = FOUR.project_operational_root(target, guide)
        trees[tree_name] = (target, mapped, mismatch)
    return trees


def main():
    states = FOUR.read_states()
    trees = prepare_trees(states)
    fits = [
        row for row in read_tsv(RESULTS / "MreB_ALP_three_state_model_comparison_four_trees.tsv")
        if row["model"] == "ARD_unrestricted"
    ]

    group_rows, transition_rows, summary_rows = [], [], []
    for fit in fits:
        tree, mapped, mismatch = trees[fit["tree"]]
        coded = {tip: BASE.CODE[state] for tip, state in mapped.items()}
        q = parse_q(fit["rates"])
        engine = GENERIC.TreeLikelihood(tree, coded, "unit_topology", GENERIC.stationary(q))

        group_moments = {}
        for group, edges in GROUPS.items():
            moments = GENERIC.posterior_moments(engine, q, edges)
            group_moments[group] = moments
            group_rows.append({
                "tree": fit["tree"],
                "transition_group": group,
                "mapped_MAGs": len(coded),
                "root_projection_mismatch": mismatch,
                "fitted_log_likelihood": fit["log_likelihood"],
                "log_likelihood_abs_difference": abs(float(fit["log_likelihood"]) - moments["log_likelihood_recomputed"]),
                **moments,
            })

        for label, edge in TRANSITIONS.items():
            moments = GENERIC.posterior_moments(engine, q, (edge,))
            transition_rows.append({
                "tree": fit["tree"],
                "transition": label,
                "transition_class": "direct_single_state" if edge in GROUPS["direct_single_state"] else "via_coexist_adjacent",
                "fitted_rate": q[edge],
                **moments,
            })

        adjacent = group_moments["via_coexist_adjacent"]
        direct = group_moments["direct_single_state"]
        total = group_moments["all_transitions"]
        covariance = (total["posterior_variance"] - adjacent["posterior_variance"] - direct["posterior_variance"]) / 2
        denominator = adjacent["posterior_mean"] + direct["posterior_mean"]
        fraction = direct["posterior_mean"] / denominator
        grad_d = adjacent["posterior_mean"] / (denominator * denominator)
        grad_a = -direct["posterior_mean"] / (denominator * denominator)
        var_fraction = (
            grad_d * grad_d * direct["posterior_variance"]
            + grad_a * grad_a * adjacent["posterior_variance"]
            + 2 * grad_d * grad_a * covariance
        )
        sd_fraction = math.sqrt(max(0.0, var_fraction))
        per_branch = total["posterior_mean"] / engine.branch_count
        max_rate = float(np.max(q - np.diag(np.diag(q))))
        status = "boundary_saturated" if max_rate >= math.exp(10) * 0.99 else "high_turnover" if per_branch > 1 else "stable"
        summary_rows.append({
            "tree": fit["tree"],
            "branch_scale": "unit_topology",
            "mapped_MAGs": len(coded),
            "adjacent_via_coexist_mean": adjacent["posterior_mean"],
            "direct_single_state_mean": direct["posterior_mean"],
            "direct_fraction": fraction,
            "direct_fraction_95_low_delta": max(0.0, fraction - 1.96 * sd_fraction),
            "direct_fraction_95_high_delta": min(1.0, fraction + 1.96 * sd_fraction),
            "expected_total_mean": total["posterior_mean"],
            "expected_total_per_branch": per_branch,
            "max_fitted_rate": max_rate,
            "history_identifiability": status,
            "root_projection_mismatch": mismatch,
        })

    write_tsv(RESULTS / "MreB_ALP_ARD_transition_group_posterior_moments.tsv", group_rows)
    write_tsv(RESULTS / "MreB_ALP_ARD_individual_transition_posterior_moments.tsv", transition_rows)
    write_tsv(RESULTS / "MreB_ALP_ARD_transition_contribution_summary.tsv", summary_rows)
    audit = {
        "status": "complete",
        "model": "existing_MreB_ALP_ARD_unrestricted_fixed_Q",
        "trees": len(trees),
        "stable_histories": sum(x["history_identifiability"] == "stable" for x in summary_rows),
        "maximum_log_likelihood_reproduction_error": max(x["log_likelihood_abs_difference"] for x in group_rows),
        "uncertainty": "fixed-Q stochastic-history posterior moments; normal/delta 95% approximation",
        "new_model_fitted": False,
    }
    (RESULTS / "MreB_ALP_ARD_TRANSITION_DECOMPOSITION_AUDIT.json").write_text(
        json.dumps(audit, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(audit))


if __name__ == "__main__":
    main()
