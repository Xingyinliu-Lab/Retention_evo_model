suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

task_dir <- ".."
input_file <- file.path(task_dir, "results", "MreB_ALP_three_state_model_comparison_four_trees.tsv")
figure_dir <- file.path(task_dir, "figures")
source_dir <- file.path(figure_dir, "source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

model_levels <- c("Unrestricted benchmark", "Sequential retention", "Ancestral coexist (strict)")
tree_levels <- c("GTDB r226", "A1338 add-core", "A1338 de novo", "A1338 ASTRAL64")

dat <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE) %>%
  mutate(
    model_label = recode(
      model,
      ARD_unrestricted = "Unrestricted benchmark",
      retention_sequential_endpoint_best = "Sequential retention",
      ancestral_coexistence_strict = "Ancestral coexist (strict)"
    ),
    tree_label = recode(
      tree,
      GTDB_r226 = "GTDB r226",
      A1338_addcore = "A1338 add-core",
      A1338_denovo = "A1338 de novo",
      A1338_ASTRAL64 = "A1338 ASTRAL64"
    ),
    model_label = factor(model_label, levels = model_levels),
    tree_label = factor(tree_label, levels = tree_levels),
    model_x = as.integer(model_label),
    tree_offset = recode(
      as.character(tree_label),
      `GTDB r226` = -0.12,
      `A1338 add-core` = -0.04,
      `A1338 de novo` = 0.04,
      `A1338 ASTRAL64` = 0.12
    ),
    x_plot = model_x + as.numeric(tree_offset),
    log_delta_AIC = log10(delta_AIC + 1)
  )

stopifnot(
  nrow(dat) == 12,
  all(table(dat$model_label) == 4),
  all(table(dat$tree_label) == 3),
  all(dat$branch_scale == "unit_topology"),
  all(dat$success)
)

write.table(
  dat,
  file.path(source_dir, "MreB_ALP_three_model_AIC_four_trees.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE, fileEncoding = "UTF-8"
)

tree_cols <- c(
  "GTDB r226" = "#3F3F3F",
  "A1338 add-core" = "#C17A35",
  "A1338 de novo" = "#B6505A",
  "A1338 ASTRAL64" = "#77609A"
)
tree_shapes <- c(
  "GTDB r226" = 16,
  "A1338 add-core" = 17,
  "A1338 de novo" = 15,
  "A1338 ASTRAL64" = 18
)
original_breaks <- c(0, 1, 2, 5, 10, 20, 50, 100, 200, 500)

p <- ggplot(dat, aes(model_x, log_delta_AIC, group = model_label)) +
  geom_hline(yintercept = 0, linewidth = 0.30, colour = "#666666", linetype = "22") +
  geom_boxplot(
    width = 0.36, linewidth = 0.30, outlier.shape = NA,
    fill = NA, colour = "#8F8F8F"
  ) +
  geom_point(
    aes(x = x_plot, colour = tree_label, shape = tree_label),
    size = 2.15, alpha = 0.98, stroke = 0.45
  ) +
  scale_x_continuous(
    breaks = 1:3,
    labels = c("Unrestricted\nbenchmark", "Sequential\nretention", "Ancestral coexist\n(strict)"),
    limits = c(0.72, 3.28)
  ) +
  scale_y_continuous(
    breaks = log10(original_breaks + 1),
    labels = original_breaks,
    minor_breaks = NULL,
    expand = expansion(mult = c(0.02, 0.07))
  ) +
  scale_colour_manual(values = tree_cols, breaks = tree_levels, drop = FALSE, name = NULL) +
  scale_shape_manual(values = tree_shapes, breaks = tree_levels, drop = FALSE, name = NULL) +
  labs(
    title = "MreB-ALP aggregate state models",
    x = NULL,
    y = expression(Delta*"AIC"),
    caption = paste0(
      "Unit topology; A1338 trees use the projected GTDB r226 operational root. ",
      "Y-axis spacing is logarithmic; tick labels show original values."
    )
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "black"),
    axis.ticks = element_line(linewidth = 0.28, colour = "black"),
    axis.text.x = element_text(size = 6.5, lineheight = 0.93),
    axis.text.y = element_text(size = 6.3),
    axis.title.y = element_text(size = 7.0),
    plot.title = element_text(size = 8.2, face = "bold", hjust = 0),
    plot.caption = element_text(size = 5.3, colour = "#555555", hjust = 0),
    legend.position = "top",
    legend.text = element_text(size = 5.9),
    legend.key.width = grid::unit(4.1, "mm"),
    legend.spacing.x = grid::unit(1.5, "mm"),
    plot.margin = margin(3, 6, 2, 5)
  )

ggsave(
  file.path(figure_dir, "fig_mreb_alp_three_state_model_AIC.pdf"), p,
  width = 178, height = 102, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_mreb_alp_three_state_model_AIC.png"), p,
  width = 178, height = 102, units = "mm", dpi = 600, bg = "white"
)
