#!/usr/bin/env python3
"""Fit the frozen MreB/ALP three-state models on GTDB and three A1338 trees."""
from __future__ import annotations

import csv
import importlib.util
from collections import Counter
from pathlib import Path

from Bio import Phylo


ROOT = Path(__file__).resolve().parents[1]
BASE_SCRIPT = ROOT / "code" / "run_mreb_alp_direction_free_models.py"
STATE_FILE = (
    ROOT.parents[0]
    / "mreb_cd_aggregate_retention_lowcost_audit_20260810"
    / "data"
    / "MAG_MreB_CD_aggregate_states.tsv"
)
GUIDE_TREE = (
    ROOT.parents[0]
    / "actin_retention_exemplar_search_20260727"
    / "inputs"
    / "species_trees"
    / "gtdb_expanded_18261_with_asgard971.tree"
)
TREE_SPECS = {
    "A1338_addcore": ROOT.parents[0]
    / "actin_retention_exemplar_search_20260727"
    / "inputs"
    / "species_trees"
    / "archaea1338"
    / "archaea1338_orthofinder_species_tree_rooted.txt",
    "A1338_denovo": ROOT.parents[0]
    / "actin_retention_exemplar_search_20260727"
    / "inputs"
    / "species_trees"
    / "archaea1338"
    / "archaea1338_denovo_species_tree_unrooted.txt",
    "A1338_ASTRAL64": ROOT.parents[0]
    / "archaea1338_full_og_species_marker_screen_20260801"
    / "astral_pro_third_species_tree_20260805"
    / "archaea1338_64_formal_astral_pro3.tree",
}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


BASE = load_module(BASE_SCRIPT, "mreb_models_base")


def leaves(clade):
    return {x.name for x in clade.get_terminals()}


def project_operational_root(target, guide):
    universe = leaves(target)
    guide_children = [leaves(x) & universe for x in guide.root.clades]
    guide_children = [x for x in guide_children if x and x != universe]
    guide_side = min(guide_children, key=len)
    best = None
    for clade in target.find_clades(order="preorder"):
        if clade is target.root:
            continue
        candidate = leaves(clade)
        if not candidate or candidate == universe:
            continue
        direct = len(candidate.symmetric_difference(guide_side))
        complement = len((universe - candidate).symmetric_difference(guide_side))
        score = (min(direct, complement), abs(len(candidate) - len(guide_side)))
        if best is None or score < best[0]:
            best = (score, clade)
    if best is None:
        raise RuntimeError("No edge available for GTDB operational-root projection")
    target.root_with_outgroup(best[1])
    return best[0][0]


def read_states():
    with STATE_FILE.open(encoding="utf-8", newline="") as handle:
        rows = csv.DictReader(handle, delimiter="\t")
        return {
            row["mag_id"]: BASE.SOURCE_TO_FORMAL[row["state"]]
            for row in rows
            if row["state"] in BASE.SOURCE_TO_FORMAL
        }


def selected_models(tree, coded, tree_name):
    adjacent = ((0, 1), (1, 0), (1, 2), (2, 1))
    all_edges = tuple((i, j) for i in range(3) for j in range(3) if i != j)
    endpoint_m = BASE.fit(
        tree, coded, "unit_topology", "retention_sequential_M_endpoint", 0, adjacent
    )
    endpoint_alp = BASE.fit(
        tree, coded, "unit_topology", "retention_sequential_ALP_endpoint", 2, adjacent
    )
    sequential = min((endpoint_m, endpoint_alp), key=lambda x: x["AIC"])
    sequential = dict(sequential)
    sequential["model"] = "retention_sequential_endpoint_best"
    sequential["selected_endpoint"] = (
        "M-only" if endpoint_m["AIC"] <= endpoint_alp["AIC"] else "ALP-only"
    )
    models = [
        BASE.fit(tree, coded, "unit_topology", "ARD_unrestricted", "stationary", all_edges),
        sequential,
        BASE.fit(
            tree,
            coded,
            "unit_topology",
            "ancestral_coexistence_strict",
            1,
            ((1, 0), (1, 2)),
        ),
    ]
    best = min(x["AIC"] for x in models)
    for row in models:
        row.setdefault("selected_endpoint", "NA")
        row["delta_AIC"] = row["AIC"] - best
        row["tree"] = tree_name
    return models


def main():
    states = read_states()
    out = []

    # Preserve the already frozen GTDB fit and reduce it to the requested models.
    with (ROOT / "results" / "MreB_ALP_three_state_model_comparison_v2.tsv").open(
        encoding="utf-8", newline=""
    ) as handle:
        frozen = list(csv.DictReader(handle, delimiter="\t"))
    ard = next(x for x in frozen if x["model"] == "ARD_unrestricted")
    strict = next(x for x in frozen if x["model"] == "ancestral_coexistence_strict")
    endpoints = [x for x in frozen if x["model"].startswith("retention_sequential_")]
    sequential = min(endpoints, key=lambda x: float(x["AIC"]))
    selected = []
    for source in (ard, sequential, strict):
        row = dict(source)
        if source is sequential:
            row["model"] = "retention_sequential_endpoint_best"
            row["selected_endpoint"] = source["root_mode"]
        else:
            row["selected_endpoint"] = "NA"
        row["tree"] = "GTDB_r226"
        selected.append(row)
    best = min(float(x["AIC"]) for x in selected)
    for row in selected:
        row["delta_AIC"] = float(row["AIC"]) - best
        row["mapped_MAGs"] = int(row["mapped_MAGs"])
        row["root_projection_mismatch"] = 0
    out.extend(selected)

    guide_source = Phylo.read(str(GUIDE_TREE), "newick")
    guide_tips = leaves(guide_source)
    for tree_name, tree_path in TREE_SPECS.items():
        target_source = Phylo.read(str(tree_path), "newick")
        shared = leaves(target_source) & guide_tips & set(states)
        mapped = {mag: states[mag] for mag in shared}
        if not mapped:
            raise RuntimeError(f"No mapped states for {tree_name}")
        target = BASE.restrict(target_source, mapped)
        guide = BASE.restrict(guide_source, mapped)
        mismatch = project_operational_root(target, guide)
        coded = {mag: BASE.CODE[state] for mag, state in mapped.items()}
        rows = selected_models(target, coded, tree_name)
        counts = Counter(mapped.values())
        for row in rows:
            row["mapped_MAGs"] = len(mapped)
            row["root_projection_mismatch"] = mismatch
            row["n_M_only"] = counts["M-only"]
            row["n_coexist"] = counts["M+ALP coexist"]
            row["n_ALP_only"] = counts["ALP-only"]
        out.extend(rows)

    # Normalize columns because frozen GTDB rows predate the four-tree audit fields.
    fields = [
        "tree", "model", "selected_endpoint", "branch_scale", "root_mode", "k",
        "log_likelihood", "AIC", "delta_AIC", "success", "rates", "mapped_MAGs",
        "root_projection_mismatch", "n_M_only", "n_coexist", "n_ALP_only",
    ]
    for row in out:
        for field in fields:
            row.setdefault(field, "NA")
    path = ROOT / "results" / "MreB_ALP_three_state_model_comparison_four_trees.tsv"
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows([{k: row[k] for k in fields} for row in out])
    print(f"wrote={path} rows={len(out)}")


if __name__ == "__main__":
    main()
