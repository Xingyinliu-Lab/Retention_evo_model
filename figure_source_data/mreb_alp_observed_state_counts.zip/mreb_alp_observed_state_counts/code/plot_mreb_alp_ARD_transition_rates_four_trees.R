suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
})

root <- ".."
input_file <- file.path(root, "results", "MreB_ALP_three_state_model_comparison_four_trees.tsv")
figure_dir <- file.path(root, "figures")
source_dir <- file.path(figure_dir, "source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

tree_levels <- c("GTDB r226", "A1338 add-core", "A1338 de novo", "A1338 ASTRAL64")
tree_cols <- c(
  "GTDB r226" = "#3F3F3F",
  "A1338 add-core" = "#C17A35",
  "A1338 de novo" = "#B6505A",
  "A1338 ASTRAL64" = "#77609A"
)
tree_shapes <- c(
  "GTDB r226" = 16,
  "A1338 add-core" = 17,
  "A1338 de novo" = 15,
  "A1338 ASTRAL64" = 18
)

directional <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE) %>%
  filter(model == "ARD_unrestricted") %>%
  select(tree, rates) %>%
  separate_rows(rates, sep = ";") %>%
  separate(rates, into = c("transition", "rate"), sep = ":") %>%
  mutate(
    rate = as.numeric(rate),
    tree_label = recode(
      tree,
      GTDB_r226 = "GTDB r226",
      A1338_addcore = "A1338 add-core",
      A1338_denovo = "A1338 de novo",
      A1338_ASTRAL64 = "A1338 ASTRAL64"
    ),
    tree_label = factor(tree_label, levels = tree_levels),
    state_pair = recode(
      transition,
      `M-only->M+ALP coexist` = "M-only <-> coexist",
      `M+ALP coexist->M-only` = "M-only <-> coexist",
      `M+ALP coexist->ALP-only` = "coexist <-> ALP-only",
      `ALP-only->M+ALP coexist` = "coexist <-> ALP-only",
      `M-only->ALP-only` = "M-only <-> ALP-only  (direct)",
      `ALP-only->M-only` = "M-only <-> ALP-only  (direct)"
    )
  )

write.table(
  directional,
  file.path(source_dir, "MreB_ALP_ARD_transition_rates_four_trees_directional_raw.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE, fileEncoding = "UTF-8"
)

# Direction is not interpreted. Each plotted value is q(i->j) + q(j->i).
dat <- directional %>%
  group_by(tree, tree_label, state_pair) %>%
  summarise(combined_bidirectional_rate = sum(rate), .groups = "drop")

transition_order <- dat %>%
  group_by(state_pair) %>%
  summarise(median_rate = median(combined_bidirectional_rate), .groups = "drop") %>%
  arrange(median_rate) %>%
  pull(state_pair)
dat$state_pair <- factor(dat$state_pair, levels = transition_order)

stopifnot(
  nrow(dat) == 12,
  all(table(dat$state_pair) == 4),
  all(dat$combined_bidirectional_rate > 0)
)

write.table(
  dat,
  file.path(source_dir, "MreB_ALP_ARD_transition_rates_four_trees.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE, fileEncoding = "UTF-8"
)

rate_breaks <- c(0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03, 0.1, 0.3)
p <- ggplot(dat, aes(combined_bidirectional_rate, state_pair, group = state_pair)) +
  geom_boxplot(
    width = 0.42, linewidth = 0.30, outlier.shape = NA,
    fill = NA, colour = "#929292"
  ) +
  geom_point(
    aes(colour = tree_label, shape = tree_label),
    position = position_dodge(width = 0.34),
    size = 2.05, alpha = 0.98, stroke = 0.45
  ) +
  scale_x_log10(
    breaks = rate_breaks,
    labels = c("0.0001", "0.0003", "0.001", "0.003", "0.01", "0.03", "0.1", "0.3"),
    limits = c(0.0001, 0.3),
    expand = expansion(mult = c(0.02, 0.03))
  ) +
  scale_colour_manual(values = tree_cols, breaks = tree_levels, drop = FALSE, name = NULL) +
  scale_shape_manual(values = tree_shapes, breaks = tree_levels, drop = FALSE, name = NULL) +
  labs(
    title = "MreB-ALP bidirectional ARD rates across species trees",
    x = "Combined reciprocal rate, q(i->j) + q(j->i) (unit-topology scale)",
    y = NULL,
    caption = paste0(
      "Direction is not interpreted; reciprocal rates are summed within each state pair. ",
      "Rates are CTMC parameters, not inferred event counts."
    )
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "black"),
    axis.ticks = element_line(linewidth = 0.28, colour = "black"),
    axis.text.x = element_text(size = 6.1),
    axis.text.y = element_text(size = 5.9),
    axis.title.x = element_text(size = 6.8),
    plot.title = element_text(size = 8.1, face = "bold"),
    plot.caption = element_text(size = 5.2, colour = "#555555", hjust = 0, margin = margin(t = 4)),
    legend.position = "top",
    legend.text = element_text(size = 5.8),
    legend.key.width = grid::unit(4.0, "mm"),
    legend.spacing.x = grid::unit(1.3, "mm"),
    plot.margin = margin(4, 6, 4, 5)
  )

ggsave(
  file.path(figure_dir, "fig_mreb_alp_ARD_transition_rates.pdf"),
  p, width = 142, height = 100, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_mreb_alp_ARD_transition_rates.png"),
  p, width = 142, height = 100, units = "mm", dpi = 600, bg = "white"
)
