suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

root <- ".."
figure_dir <- file.path(root, "figures")
source_dir <- file.path(figure_dir, "source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

theme_bar <- function() {
  theme_classic(base_size = 7.2, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.30, colour = "black"),
      axis.ticks = element_line(linewidth = 0.28, colour = "black"),
      axis.text.x = element_text(size = 6.3, lineheight = 0.93),
      axis.text.y = element_text(size = 6.2),
      axis.title.y = element_text(size = 7.0),
      plot.title = element_text(size = 8.1, face = "bold"),
      plot.caption = element_text(size = 5.3, colour = "#555555", hjust = 0, margin = margin(t = 4)),
      plot.margin = margin(4, 6, 4, 5),
      legend.position = "none"
    )
}

# GTDB-only model comparison.
model_dat <- read.delim(
  file.path(root, "results", "MreB_ALP_three_state_model_comparison_four_trees.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
) %>%
  filter(tree == "GTDB_r226") %>%
  mutate(
    model_label = recode(
      model,
      ARD_unrestricted = "Unrestricted\nbenchmark",
      retention_sequential_endpoint_best = "Sequential\nretention",
      ancestral_coexistence_strict = "Ancestral coexist\n(strict)"
    ),
    model_label = factor(
      model_label,
      levels = c("Unrestricted\nbenchmark", "Sequential\nretention", "Ancestral coexist\n(strict)")
    ),
    value_label = sprintf("%.1f", delta_AIC)
  )

stopifnot(nrow(model_dat) == 3)
write.table(
  model_dat,
  file.path(source_dir, "MreB_ALP_three_state_model_AIC_GTDB_only.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE, fileEncoding = "UTF-8"
)

model_cols <- c(
  "Unrestricted\nbenchmark" = "#4D4D4D",
  "Sequential\nretention" = "#5E8F87",
  "Ancestral coexist\n(strict)" = "#B76A5D"
)
p_aic <- ggplot(model_dat, aes(model_label, delta_AIC, fill = model_label)) +
  geom_col(width = 0.62, colour = NA) +
  geom_text(aes(label = value_label), vjust = -0.45, size = 2.25, family = "Arial", colour = "#303030") +
  scale_fill_manual(values = model_cols) +
  scale_y_continuous(
    limits = c(0, 430), breaks = seq(0, 400, 100),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(
    title = "GTDB r226 model comparison",
    x = NULL,
    y = expression(Delta*"AIC"),
    caption = "MreB-ALP aggregate states; GTDB r226 expanded tree, unit topology."
  ) +
  theme_bar()

ggsave(
  file.path(figure_dir, "fig_mreb_alp_three_state_model_AIC_GTDB_only.pdf"),
  p_aic, width = 105, height = 88, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_mreb_alp_three_state_model_AIC_GTDB_only.png"),
  p_aic, width = 105, height = 88, units = "mm", dpi = 600, bg = "white"
)

# GTDB-only ARD route contribution.
route_dat <- read.delim(
  file.path(root, "results", "MreB_ALP_ARD_transition_contribution_summary.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
) %>%
  filter(tree == "GTDB_r226") %>%
  transmute(
    coexist_mediated = 100 * (1 - direct_fraction),
    direct_endpoint = 100 * direct_fraction
  ) %>%
  tidyr::pivot_longer(
    cols = everything(), names_to = "route", values_to = "contribution_percent"
  ) %>%
  mutate(
    route_label = recode(
      route,
      coexist_mediated = "Coexist-mediated",
      direct_endpoint = "Direct endpoint\ntransition"
    ),
    route_label = factor(route_label, levels = c("Coexist-mediated", "Direct endpoint\ntransition")),
    value_label = sprintf("%.1f%%", contribution_percent)
  )

stopifnot(nrow(route_dat) == 2, abs(sum(route_dat$contribution_percent) - 100) < 1e-8)
write.table(
  route_dat,
  file.path(source_dir, "MreB_ALP_ARD_direct_transition_contribution_GTDB_only.tsv"),
  sep = "\t", row.names = FALSE, quote = FALSE, fileEncoding = "UTF-8"
)

route_cols <- c(
  "Coexist-mediated" = "#5E8F87",
  "Direct endpoint\ntransition" = "#B76A5D"
)
p_route <- ggplot(route_dat, aes(route_label, contribution_percent, fill = route_label)) +
  geom_col(width = 0.58, colour = NA) +
  geom_text(aes(label = value_label), vjust = -0.45, size = 2.35, family = "Arial", colour = "#303030") +
  scale_fill_manual(values = route_cols) +
  scale_y_continuous(
    limits = c(0, 100), breaks = seq(0, 100, 20),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(
    title = "GTDB r226 ARD transition routes",
    x = NULL,
    y = "Share of inferred ARD transitions (%)",
    caption = "Fixed-Q stochastic-history posterior means; unit topology."
  ) +
  theme_bar()

ggsave(
  file.path(figure_dir, "fig_mreb_alp_ARD_direct_transition_contribution_GTDB_only.pdf"),
  p_route, width = 96, height = 88, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_mreb_alp_ARD_direct_transition_contribution_GTDB_only.png"),
  p_route, width = 96, height = 88, units = "mm", dpi = 600, bg = "white"
)
