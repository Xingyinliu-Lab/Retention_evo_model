suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

root <- ".."
input_file <- file.path(root, "results", "MreB_ALP_ARD_transition_contribution_summary.tsv")
figure_dir <- file.path(root, "figures")
source_dir <- file.path(figure_dir, "source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

tree_levels <- c("GTDB r226", "A1338 add-core", "A1338 de novo", "A1338 ASTRAL64")
tree_cols <- c(
  "GTDB r226" = "#3F3F3F",
  "A1338 add-core" = "#C17A35",
  "A1338 de novo" = "#B6505A",
  "A1338 ASTRAL64" = "#77609A"
)
tree_shapes <- c(
  "GTDB r226" = 16,
  "A1338 add-core" = 17,
  "A1338 de novo" = 15,
  "A1338 ASTRAL64" = 18
)

dat <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE) %>%
  mutate(
    tree_label = recode(
      tree,
      GTDB_r226 = "GTDB r226",
      A1338_addcore = "A1338 add-core",
      A1338_denovo = "A1338 de novo",
      A1338_ASTRAL64 = "A1338 ASTRAL64"
    ),
    tree_label = factor(tree_label, levels = tree_levels),
    direct_percent = 100 * direct_fraction
  )

stopifnot(nrow(dat) == 4, all(dat$history_identifiability == "stable"))

plot_dat <- bind_rows(
  dat %>% transmute(
    tree, tree_label,
    route = "Coexist-mediated",
    contribution_percent = 100 - direct_percent
  ),
  dat %>% transmute(
    tree, tree_label,
    route = "Direct endpoint transition",
    contribution_percent = direct_percent
  )
) %>%
  mutate(
    route = factor(route, levels = c("Coexist-mediated", "Direct endpoint transition")),
    route_x = as.integer(route),
    tree_offset = recode(
      as.character(tree_label),
      `GTDB r226` = -0.12,
      `A1338 add-core` = -0.04,
      `A1338 de novo` = 0.04,
      `A1338 ASTRAL64` = 0.12
    ),
    x_plot = route_x + as.numeric(tree_offset)
  )

write.table(
  plot_dat,
  file.path(source_dir, "fig_mreb_alp_ARD_direct_transition_contribution_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)

p <- ggplot(plot_dat, aes(route_x, contribution_percent, group = route)) +
  geom_boxplot(
    width = 0.36, linewidth = 0.30, outlier.shape = NA,
    fill = NA, colour = "#8F8F8F"
  ) +
  geom_point(
    aes(x = x_plot, colour = tree_label, shape = tree_label),
    size = 2.15, alpha = 0.98, stroke = 0.45
  ) +
  scale_x_continuous(
    breaks = 1:2,
    labels = c("Coexist-mediated\ncontribution", "Direct endpoint-transition\ncontribution"),
    limits = c(0.72, 2.28)
  ) +
  scale_y_continuous(
    limits = c(0, 100), breaks = seq(0, 100, 20),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  scale_colour_manual(values = tree_cols, breaks = tree_levels, drop = FALSE, name = NULL) +
  scale_shape_manual(values = tree_shapes, breaks = tree_levels, drop = FALSE, name = NULL) +
  labs(
    title = "MreB-ALP ARD transition-route contributions",
    x = NULL,
    y = "Share of inferred ARD transitions (%)",
    caption = paste0(
      "Fixed-Q stochastic-history posterior means; unit topology. ",
      "A1338 trees use the projected GTDB r226 operational root."
    )
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "black"),
    axis.ticks = element_line(linewidth = 0.28, colour = "black"),
    axis.text.x = element_text(size = 6.5, lineheight = 0.93),
    axis.text.y = element_text(size = 6.3),
    axis.title.y = element_text(size = 7.0),
    plot.title = element_text(size = 8.1, face = "bold"),
    plot.caption = element_text(size = 5.3, colour = "#555555", hjust = 0, margin = margin(t = 4)),
    legend.position = "top",
    legend.text = element_text(size = 5.8),
    legend.key.width = grid::unit(4.0, "mm"),
    legend.spacing.x = grid::unit(1.3, "mm"),
    plot.margin = margin(4, 6, 4, 5)
  )

ggsave(
  file.path(figure_dir, "fig_mreb_alp_ARD_direct_transition_contribution.pdf"),
  p, width = 142, height = 96, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_mreb_alp_ARD_direct_transition_contribution.png"),
  p, width = 142, height = 96, units = "mm", dpi = 600, bg = "white"
)
