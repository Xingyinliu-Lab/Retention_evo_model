# mreb_alp_observed_state_counts

- Manuscript panel: Supp.Fig.12A
- Source figure basename: fig_mreb_alp_observed_state_counts
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 8 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 29 directly referenced or locally packaged source-data file(s)
