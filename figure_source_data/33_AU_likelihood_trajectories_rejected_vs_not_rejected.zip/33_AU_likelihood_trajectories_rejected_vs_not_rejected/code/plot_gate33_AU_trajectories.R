suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(scales)
  library(tibble)
})

base <- ".."
out <- file.path(base, "gate33_AU_trajectories_20260902")
old_source <- file.path(base, "full31_support_and_AU_figures_20260827/data/figure_source_data/full31_AU_likelihood_trajectories.tsv")
dir.create(file.path(out, "figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out, "source_data"), recursive = TRUE, showWarnings = FALSE)

candidate_labels <- c(
  "2" = "Reciprocal A/B reference",
  "3" = "All coexist copies cluster by MAG",
  "4" = "Cross-order core copies cluster by MAG"
)

existing31 <- read_tsv(old_source, show_col_types = FALSE, progress = FALSE) %>%
  transmute(
    og_id, candidate = as.integer(candidate), deltaL, pAU,
    topology = as.character(topology),
    source_scope = "frozen local 31-OG AU source",
    raw_AU_source = NA_character_
  )

# These six rows were read from the authoritative completed IQ-TREE AU outputs
# on kt. No likelihood or topology calculation is performed in this script.
additional2 <- tribble(
  ~og_id,       ~candidate, ~deltaL,  ~pAU,     ~topology,                                      ~source_scope,                         ~raw_AU_source,
  "OG0000323", 2L,          16.199,   0.365,    "Reciprocal A/B reference",                     "authoritative kt IQ-TREE AU output", "..",
  "OG0000323", 3L,        2813.2,     4.55e-31, "All coexist copies cluster by MAG",            "authoritative kt IQ-TREE AU output", "..",
  "OG0000323", 4L,        1000.7,     0.00228,  "Cross-order core copies cluster by MAG",        "authoritative kt IQ-TREE AU output", "..",
  "OG0001582", 2L,          20.586,   0.199,    "Reciprocal A/B reference",                     "authoritative kt IQ-TREE AU output", "..",
  "OG0001582", 3L,        1104.9,     0.353,    "All coexist copies cluster by MAG",            "authoritative kt IQ-TREE AU output", "..",
  "OG0001582", 4L,         600.6,     0.0788,   "Cross-order core copies cluster by MAG",        "authoritative kt IQ-TREE AU output", ".."
)

d <- bind_rows(existing31, additional2) %>%
  mutate(
    topology = factor(topology, levels = unname(candidate_labels)),
    AU_status = factor(if_else(pAU < 0.05, "Rejected", "Not rejected"),
                       levels = c("Not rejected", "Rejected"))
  )

stopifnot(
  nrow(d) == 99L,
  n_distinct(d$og_id) == 33L,
  all(table(d$og_id) == 3L),
  !anyNA(d$deltaL),
  !anyNA(d$pAU),
  all(d$pAU >= 0 & d$pAU <= 1)
)

offsets <- tibble(
  og_id = sort(unique(d$og_id)),
  unit_offset = seq(-0.10, 0.10, length.out = n_distinct(d$og_id))
)
plot_d <- d %>%
  left_join(offsets, by = "og_id") %>%
  mutate(topology_x = as.integer(topology) + unit_offset)

status_palette <- c("Not rejected" = "#2C7F86", "Rejected" = "#C65B55")

p <- ggplot(plot_d, aes(topology_x, deltaL, group = og_id)) +
  geom_line(linewidth = 0.42, alpha = 0.34, colour = "#6F7780") +
  geom_point(
    aes(fill = AU_status), shape = 21, size = 1.85,
    stroke = 0.32, colour = "white", alpha = 0.96
  ) +
  scale_fill_manual(
    values = status_palette,
    breaks = c("Not rejected", "Rejected"),
    name = "AU test result",
    drop = FALSE
  ) +
  scale_x_continuous(
    breaks = 1:3,
    labels = c(
      "Reciprocal A/B\nreference",
      "All coexist copies\ncluster by MAG",
      "Cross-order core copies\ncluster by MAG"
    ),
    limits = c(0.78, 3.22),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    trans = pseudo_log_trans(base = 10, sigma = 1),
    breaks = c(0, 1, 3, 10, 30, 100, 300, 1000, 3000, 10000, 30000,
               100000, 300000),
    labels = c("0", "1", "3", "10", "30", "100", "300", "1k", "3k",
               "10k", "30k", "100k", "300k"),
    expand = expansion(mult = c(0.015, 0.055))
  ) +
  labs(
    x = NULL,
    y = expression("Likelihood loss from the formal tree ("*Delta*"lnL)")
  ) +
  theme_classic(base_family = "Arial", base_size = 7) +
  theme(
    axis.line = element_line(linewidth = 0.34, colour = "#242424"),
    axis.ticks = element_line(linewidth = 0.32, colour = "#242424"),
    axis.text.x = element_text(size = 6.2, lineheight = 0.94, colour = "#252525"),
    axis.text.y = element_text(size = 5.8, colour = "#252525"),
    axis.title.y = element_text(size = 7.2, colour = "#202020"),
    legend.position = "top",
    legend.justification = "left",
    legend.title = element_text(size = 6.2, face = "bold"),
    legend.text = element_text(size = 5.9),
    legend.key.height = grid::unit(3.3, "mm"),
    legend.key.width = grid::unit(4.0, "mm"),
    plot.margin = margin(4, 6, 4, 5)
  )

stem <- "fig_33_AU_likelihood_trajectories_rejected_vs_not_rejected"
ggsave(file.path(out, "figures", paste0(stem, ".pdf")), p,
       width = 145, height = 100, units = "mm", device = cairo_pdf, bg = "white")
ggsave(file.path(out, "figures", paste0(stem, ".png")), p,
       width = 145, height = 100, units = "mm", dpi = 600,
       device = ragg::agg_png, bg = "white")

write_tsv(d %>% arrange(og_id, candidate),
          file.path(out, "source_data", paste0(stem, "_source.tsv")))
writeLines(c(
  "status=complete",
  "cases=33",
  "candidate_rows=99",
  paste0("not_rejected_points=", sum(d$AU_status == "Not rejected")),
  paste0("rejected_points=", sum(d$AU_status == "Rejected")),
  "candidate_AU_rule=pAU_lt_0.05_rejected_else_not_rejected",
  "classification_display=evidence_class_not_used",
  "analysis_rerun=false"
), file.path(out, "PACKAGE_COMPLETE.marker"))
