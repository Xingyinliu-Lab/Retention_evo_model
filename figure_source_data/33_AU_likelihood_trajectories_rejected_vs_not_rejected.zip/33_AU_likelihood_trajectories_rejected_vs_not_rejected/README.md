# 33_AU_likelihood_trajectories_rejected_vs_not_rejected

- Manuscript panel: Fig.7E
- Source figure basename: fig_33_AU_likelihood_trajectories_rejected_vs_not_rejected
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)
