# cALP_AB_coexistence_lineage_breadth

- Source figure: `fig_cALP_AB_coexistence_lineage_breadth`
- Analysis basis: class and order composition of gappyout584 A+B coexistence MAGs.
- Contents: final PDF/PNG, R plotting code and plotted lineage-count table.
- Status: included; the former automated1-derived version is superseded.
- Packaging rule: files were copied; the analysis outputs were not moved.
