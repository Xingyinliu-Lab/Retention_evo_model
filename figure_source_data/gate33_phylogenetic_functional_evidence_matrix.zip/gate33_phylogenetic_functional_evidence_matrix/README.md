# gate33_phylogenetic_functional_evidence_matrix

- Manuscript panel: Fig.6C
- Source figure basename: fig_gate33_phylogenetic_functional_evidence_matrix
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 5 directly referenced or locally packaged source-data file(s)
