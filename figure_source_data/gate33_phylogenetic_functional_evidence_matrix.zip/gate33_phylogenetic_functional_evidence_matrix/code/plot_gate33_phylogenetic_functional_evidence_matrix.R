suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(scales)
  library(ragg)
})

root <- ".."
final31_file <- "../data/final31_phylogenetic_functional_evidence_matrix_source.tsv"
formal80_file <- "../data/formal80_five_model_gate_global_scatter_source.tsv"

dir.create(file.path(root, "figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(root, "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(root, "qa"), recursive = TRUE, showWarnings = FALSE)

final31 <- read_tsv(final31_file, show_col_types = FALSE) %>%
  transmute(
    og_id,
    evidence_class = as.character(evidence_class),
    functional_label,
    functional_description,
    functional_confidence,
    broad_function_category = as.character(broad_function_category),
    category_display,
    mapping_basis,
    n_host_MAG,
    n_AB_coexist_MAG,
    n_coexist_phyla,
    coexist_MAG_phylum_composition,
    post_AU_final31 = TRUE,
    source_basis = "Frozen final31 evidence-matrix source"
  )

formal80 <- read_tsv(formal80_file, show_col_types = FALSE)
gate33 <- formal80 %>%
  filter(final_class != "fail") %>%
  distinct(og_id, final_class, final31, gate_only)

stopifnot(nrow(gate33) == 33L)
stopifnot(sum(gate33$final_class == "strong") == 2L)
stopifnot(sum(gate33$final_class == "supported") == 12L)
stopifnot(sum(gate33$final_class == "compatible") == 19L)
stopifnot(setequal(setdiff(gate33$og_id, final31$og_id), c("OG0000323", "OG0001582")))

# The two gate-positive cases excluded by AU are added from frozen formal-gate
# annotation/state summaries. AU status remains in Source Data for auditing but
# is deliberately not displayed in this pre-AU 33-OG matrix.
gate_only_metadata <- tibble::tribble(
  ~og_id,       ~functional_label, ~functional_description,                  ~functional_confidence, ~broad_function_category, ~category_display,    ~mapping_basis,                                      ~n_host_MAG, ~n_AB_coexist_MAG, ~n_coexist_phyla, ~coexist_MAG_phylum_composition,
  "OG0000323", "PK_C",           "Pyruvate kinase, alpha/beta domain",     "high",                 "Metabolism",             "Metabolism",        "Pyruvate-kinase-domain annotation",                 300L,        44L,               6L,                "Asgardarchaeota (7); Halobacteriota (3); Korarchaeota (1); Methanobacteriota (1); Methanobacteriota_B (2); Thermoproteota (30)",
  "OG0001582", "Usp",            "Universal stress protein family",       "high",                 "Cellular/scaffold",      "Cellular/scaffold", "Stress-response/cellular-maintenance annotation",   126L,        10L,               5L,                NA_character_
) %>%
  mutate(
    evidence_class = "compatible",
    post_AU_final31 = FALSE,
    source_basis = "Frozen formal80 gate class plus frozen annotated formal-gate/state summaries"
  )

dat <- bind_rows(final31, gate_only_metadata) %>%
  left_join(
    gate33 %>% select(og_id, gate_class = final_class, post_AU_from_gate_table = final31),
    by = "og_id"
  )

stopifnot(nrow(dat) == 33L, n_distinct(dat$og_id) == 33L)
stopifnot(all(dat$evidence_class == dat$gate_class))
stopifnot(all(dat$post_AU_final31 == dat$post_AU_from_gate_table))

grade_levels <- c("strong", "supported", "compatible")
grade_colours <- c(
  strong = "#C95858",
  supported = "#2C8C82",
  compatible = "#C89A3D"
)
category_levels <- c(
  "Membrane/transport", "Metabolism", "Information processing",
  "Cofactor/redox", "Cellular/scaffold", "Unknown/DUF"
)
category_colours <- c(
  "Membrane/transport" = "#5B86A8",
  "Metabolism" = "#6E9877",
  "Information processing" = "#8877A3",
  "Cofactor/redox" = "#C1834B",
  "Cellular/scaffold" = "#788692",
  "Unknown/DUF" = "#A3A3A3"
)

dat <- dat %>%
  mutate(
    evidence_class = factor(evidence_class, levels = grade_levels),
    broad_function_category = factor(broad_function_category, levels = category_levels),
    category_display = case_when(
      as.character(broad_function_category) == "Information processing" ~ "Gene regulation/repair",
      as.character(broad_function_category) == "Unknown/DUF" ~ "Uncharacterized families",
      TRUE ~ category_display
    ),
    functional_label_display = case_when(
      functional_label == "T2SSF" ~ "Type II secretion protein F",
      functional_label == "tenA1" ~ "TenA/THI4/PQQC-family protein",
      functional_label == "ABC_tran" ~ "ABC transporter ATPase",
      functional_label == "T2SSE" ~ "Type II/IV secretion protein E",
      functional_label == "ftr" ~ "FTR proximal-lobe domain",
      functional_label == "PPDK_N" ~ "PPDK AMP/ATP-binding domain",
      functional_label == "carbohydrate_transport_and_metabolism" ~ "Carbohydrate transport/metabolism*",
      functional_label == "Cys_Met_Meta_PP" ~ "Cys/Met PLP-dependent enzyme",
      functional_label == "TrmB" ~ "TrmB transcriptional regulator",
      functional_label == "MoCoBD_1" ~ "Molybdopterin-binding domain",
      functional_label == "FAD_binding_5" ~ "FAD-binding dehydrogenase domain",
      functional_label == "FMN_red" ~ "NADPH-dependent FMN reductase",
      functional_label == "GFO_IDH_MocA" ~ "NAD-binding oxidoreductase",
      functional_label == "bcp" ~ "AhpC/TSA peroxiredoxin",
      functional_label == "SSF" ~ "Sodium:solute symporter",
      functional_label == "CbiQ" ~ "Cobalt transporter component",
      functional_label == "trkA" ~ "TrkA-N regulatory domain",
      functional_label == "PK_C" ~ "Pyruvate-kinase domain",
      functional_label == "PfkB" ~ "PfkB-family carbohydrate kinase",
      functional_label == "AIRS" ~ "AIR-synthase-related domain",
      functional_label == "fen" ~ "XPG I-region domain",
      functional_label == "B12-binding" ~ "Vitamin B12-binding domain",
      functional_label == "Nitroreductase" ~ "Nitroreductase-family protein",
      functional_label == "Prismane" ~ "Prismane/CO-dehydrogenase family",
      functional_label == "PqqD" ~ "PQQ-biosynthesis protein PqqD",
      functional_label == "Rhodanese" ~ "Rhodanese-like domain",
      functional_label == "Usp" ~ "Universal stress protein",
      functional_label == "AAA" ~ "AAA+ ATPase",
      functional_label == "HEAT_2" ~ "HEAT-repeat protein",
      functional_label == "DUF169" ~ "DUF169/ArCR protein",
      functional_label == "DUF8471" ~ "DUF8471 protein",
      TRUE ~ gsub("_", " ", functional_label)
    ),
    grade_display = recode(
      as.character(evidence_class),
      strong = "Strong", supported = "Supported", compatible = "Compatible"
    )
  ) %>%
  arrange(evidence_class, broad_function_category, desc(n_coexist_phyla), functional_label, og_id) %>%
  mutate(
    row_index = rev(seq_len(n())),
    grade_colour = unname(grade_colours[as.character(evidence_class)]),
    category_colour = unname(category_colours[as.character(broad_function_category)]),
    phylum_colour = colour_ramp(c("#E8F0F4", "#2F6F8F"))(
      rescale(n_coexist_phyla, to = c(0, 1), from = c(1, 8))
    ),
    phylum_size = rescale(n_coexist_phyla, to = c(3.3, 6.7), from = c(1, 8))
  )

stopifnot(sum(dat$evidence_class == "strong") == 2L)
stopifnot(sum(dat$evidence_class == "supported") == 12L)
stopifnot(sum(dat$evidence_class == "compatible") == 19L)
stopifnot(n_distinct(dat$broad_function_category) == 6L)

write_tsv(
  dat %>%
    transmute(
      og_id, evidence_class = as.character(evidence_class),
      functional_label, representative_annotation_display = functional_label_display,
      functional_description, functional_confidence,
      broad_function_category = as.character(broad_function_category),
      category_display, mapping_basis,
      n_host_MAG, n_AB_coexist_MAG, n_coexist_phyla,
      coexist_MAG_phylum_composition,
      post_AU_final31, source_basis
    ),
  file.path(root, "source_data", "gate33_phylogenetic_functional_evidence_matrix_source.tsv")
)

summary_qa <- tibble(
  metric = c(
    "n_gate_positive_OG", "n_strong", "n_supported", "n_compatible",
    "n_post_AU_final31", "n_gate_positive_not_final31",
    "n_broad_function_categories", "n_unique_function_labels",
    "coexist_host_phylum_breadth_min", "coexist_host_phylum_breadth_median",
    "coexist_host_phylum_breadth_max"
  ),
  value = c(
    nrow(dat), sum(dat$evidence_class == "strong"),
    sum(dat$evidence_class == "supported"), sum(dat$evidence_class == "compatible"),
    sum(dat$post_AU_final31), sum(!dat$post_AU_final31),
    n_distinct(dat$broad_function_category), n_distinct(dat$functional_label),
    min(dat$n_coexist_phyla), median(dat$n_coexist_phyla), max(dat$n_coexist_phyla)
  )
)
write_tsv(summary_qa, file.path(root, "qa", "gate33_evidence_matrix_counts.tsv"))
write_tsv(
  dat %>% count(broad_function_category, name = "n_OG"),
  file.path(root, "qa", "gate33_broad_function_category_counts.tsv")
)

row_bands <- dat %>%
  transmute(
    xmin = 0.15, xmax = 7.58,
    ymin = row_index - 0.48, ymax = row_index + 0.48,
    band = row_index %% 2 == 0
  )

grade_boundaries <- dat %>%
  group_by(evidence_class) %>%
  summarise(ymin = min(row_index) - 0.5, .groups = "drop") %>%
  filter(ymin > 0.5)

header_y <- nrow(dat) + 1.25
summary_y <- nrow(dat) + 2.15

p <- ggplot() +
  geom_rect(
    data = row_bands %>% filter(band),
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
    inherit.aes = FALSE, fill = "#F7F7F7", colour = NA
  ) +
  geom_hline(
    data = grade_boundaries, aes(yintercept = ymin),
    linewidth = 0.5, colour = "#B5B5B5"
  ) +
  geom_text(
    data = dat, aes(x = 0.25, y = row_index, label = og_id),
    hjust = 0, family = "Arial", size = 2.18, colour = "#262626"
  ) +
  geom_text(
    data = dat, aes(x = 1.42, y = row_index, label = functional_label_display),
    hjust = 0, family = "Arial", size = 1.76,
    colour = ifelse(dat$functional_confidence == "low", "#777777", "#262626")
  ) +
  geom_tile(
    data = dat, aes(x = 5.03, y = row_index, fill = category_colour),
    width = 1.48, height = 0.66, colour = "white", linewidth = 0.25
  ) +
  geom_text(
    data = dat, aes(x = 5.03, y = row_index, label = category_display),
    family = "Arial", fontface = "bold", size = 1.54, colour = "white"
  ) +
  geom_point(
    data = dat, aes(x = 6.19, y = row_index, size = phylum_size, fill = phylum_colour),
    shape = 21, colour = "white", stroke = 0.25
  ) +
  geom_text(
    data = dat, aes(x = 6.19, y = row_index, label = n_coexist_phyla),
    family = "Arial", fontface = "bold", size = 1.95, colour = "white"
  ) +
  geom_tile(
    data = dat, aes(x = 7.05, y = row_index, fill = grade_colour),
    width = 0.92, height = 0.66, colour = "white", linewidth = 0.25
  ) +
  geom_text(
    data = dat, aes(x = 7.05, y = row_index, label = grade_display),
    family = "Arial", fontface = "bold", size = 1.56, colour = "white"
  ) +
  scale_size_identity() +
  scale_fill_identity() +
  annotate("text", x = 0.25, y = header_y, label = "OG", hjust = 0,
           family = "Arial", fontface = "bold", size = 2.45) +
  annotate("text", x = 1.42, y = header_y, label = "Representative protein/domain annotation", hjust = 0,
           family = "Arial", fontface = "bold", size = 2.20) +
  annotate("text", x = 5.03, y = header_y, label = "Broad category", hjust = 0.5,
           family = "Arial", fontface = "bold", size = 2.35) +
  annotate("text", x = 6.19, y = header_y, label = "Coexist-host\nphyla", hjust = 0.5,
           family = "Arial", fontface = "bold", size = 2.05, lineheight = 0.9) +
  annotate("text", x = 7.05, y = header_y, label = "Gate\nclass", hjust = 0.5,
           family = "Arial", fontface = "bold", size = 2.05, lineheight = 0.9) +
  annotate(
    "text", x = 0.25, y = summary_y,
    label = paste0(
      "33 gate-positive OGs | 2 strong, 12 supported, 19 compatible | ",
      n_distinct(dat$broad_function_category), " broad functional categories | ",
      n_distinct(dat$functional_label), " function labels"
    ),
    hjust = 0, family = "Arial", fontface = "bold", size = 2.55, colour = "#222222"
  ) +
  annotate(
    "text", x = 7.55, y = -0.18,
    label = "Five-model gate-positive set before AU filtering. Broad categories are annotation-derived; coexist-host breadth is sampling-dependent. *Low-confidence annotation.",
    hjust = 1, family = "Arial", size = 1.82, colour = "#555555"
  ) +
  coord_cartesian(xlim = c(0.1, 7.62), ylim = c(-0.45, summary_y + 0.38), clip = "off") +
  labs(title = "Five-model gate-positive histories span diverse archaeal functions and lineages") +
  theme_void(base_family = "Arial") +
  theme(
    plot.title = element_text(size = 8.5, face = "bold", colour = "#202020", hjust = 0),
    plot.margin = margin(7, 7, 8, 7, unit = "pt")
  )

pdf_file <- file.path(root, "figures", "fig_gate33_phylogenetic_functional_evidence_matrix.pdf")
png_file <- file.path(root, "figures", "fig_gate33_phylogenetic_functional_evidence_matrix.png")

grDevices::cairo_pdf(pdf_file, width = 183 / 25.4, height = 178 / 25.4, family = "Arial")
print(p)
dev.off()

ragg::agg_png(
  png_file, width = 183 / 25.4, height = 178 / 25.4,
  units = "in", res = 450, background = "white"
)
print(p)
dev.off()

writeLines(
  c(
    "status=complete",
    "backend=R",
    "n_gate_positive_OG=33",
    "n_strong=2",
    "n_supported=12",
    "n_compatible=19",
    "displayed_columns=OG,function_annotation,broad_category,coexist_host_phyla,five_model_gate_class",
    "excluded_display_columns=AU_gate,clustering,persistence",
    "exports=PDF,PNG",
    paste0("source_final31=", final31_file),
    paste0("source_formal80=", formal80_file)
  ),
  file.path(root, "FIGURE_COMPLETE.marker")
)
