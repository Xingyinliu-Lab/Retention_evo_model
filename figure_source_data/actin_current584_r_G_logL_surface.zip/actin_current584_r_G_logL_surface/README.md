# actin_current584_r_G_logL_surface

- Manuscript panel: Fig.7C
- Source figure basename: fig_actin_current584_r_G_logL_surface
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
