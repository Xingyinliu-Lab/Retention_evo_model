import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm, colors
from mpl_toolkits.mplot3d import proj3d
from pathlib import Path

src = Path(r"..")
out = Path(r"..")
out.mkdir(parents=True, exist_ok=True)
d = pd.read_csv(src, sep="\t")
best = d.loc[d["logL"].idxmax()]
rvals = np.sort(d["r"].unique())
gvals = np.sort(d["normalized_G"].unique())
z = d.pivot(index="normalized_G", columns="r", values="logL").reindex(index=gvals, columns=rvals).to_numpy()
X, Y = np.meshgrid(np.log2(rvals), gvals)
norm = colors.Normalize(vmin=float(np.nanmin(z)), vmax=float(np.nanmax(z)))
face = cm.coolwarm(norm(z))

fig = plt.figure(figsize=(8.6, 7.0), dpi=180)
ax = fig.add_subplot(111, projection="3d")
surf = ax.plot_surface(X, Y, z, facecolors=face, rstride=1, cstride=1, linewidth=0.45, edgecolor="#4d4d4d", antialiased=True, shade=False)
levels = np.linspace(np.nanmin(z), np.nanmax(z), 8)
ax.contour(X, Y, z, levels=levels, zdir="z", offset=np.nanmin(z) - 7, cmap="coolwarm", linewidths=1.0)
xb, yb, zb = np.log2(float(best["r"])), float(best["normalized_G"]), float(best["logL"])
ax.scatter([xb], [yb], [zb], s=90, c="#111111", edgecolors="white", linewidths=1.8, depthshade=False, zorder=20)
ax.plot([xb, xb], [yb, yb], [np.nanmin(z) - 7, zb], color="#111111", linestyle="--", linewidth=1.0)
# Put the label in a fixed upper-right overlay so the surface cannot occlude it.
label_xy = (0.70, 0.94)
ax.text2D(*label_xy, f"OPTIMUM\nr = {best['r']:.2f}\nG = {best['normalized_G']:.3f}\nlogL = {best['logL']:.2f}",
          transform=ax.transAxes, color="#111111", fontsize=9.5, ha="left", va="top",
          bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="#111111", alpha=0.92))

ax.set_xlabel("r (log2 scale; coexistence persistence multiplier)", labelpad=12)
ax.set_ylabel("G (normalized gain scale)", labelpad=10)
ax.set_zlabel("log likelihood", labelpad=10)
ax.set_xticks(np.log2(rvals)); ax.set_xticklabels([f"{x:g}" for x in rvals])
ax.set_title("actin current584: r–G likelihood surface", pad=18, fontsize=13, fontweight="bold")
ax.view_init(elev=28, azim=225)
ax.set_box_aspect((1.35, 1.0, 0.85))
ax.grid(True, alpha=0.22)
mappable = cm.ScalarMappable(norm=norm, cmap="coolwarm"); mappable.set_array(z)
cbar = fig.colorbar(mappable, ax=ax, shrink=0.58, pad=0.10, aspect=18)
cbar.set_label("log likelihood (blue = lower, red = higher)", rotation=90, labelpad=12)
fig.text(0.02, 0.015, f"Relative to r=1: ΔlogL = {float(best['delta_logL_vs_null_mle']):.2f}; higher log likelihood is better", fontsize=8.5)
fig.subplots_adjust(left=0.02, right=0.93, bottom=0.07, top=0.92)
fig.canvas.draw()
xp, yp, _ = proj3d.proj_transform(xb, yb, zb, ax.get_proj())
ax.annotate("", xy=(xp, yp), xycoords="data", xytext=label_xy, textcoords=ax.transAxes,
            arrowprops=dict(arrowstyle="-|>", color="#111111", lw=1.8, shrinkA=8, shrinkB=4))
fig.savefig(out / "fig_actin_current584_r_G_logL_surface.pdf", bbox_inches="tight")
fig.savefig(out / "fig_actin_current584_r_G_logL_surface.png", dpi=420, bbox_inches="tight")
plt.close(fig)
best.to_frame().T.to_csv(out / "actin_current584_r_G_likelihood_surface_optimum.tsv", sep="\t", index=False)
