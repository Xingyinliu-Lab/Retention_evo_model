suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
  library(ggplot2)
  library(ggrepel)
  library(ragg)
})

font_family <- "Arial"

category_levels <- c(
  "Nuclear-information regulation",
  "Cytoskeletal-cellular architecture",
  "Membrane-trafficking dynamics",
  "Proteostasis-metabolism-stress"
)

category_labels <- c(
  "Nuclear-information regulation" = "Nuclear / information",
  "Cytoskeletal-cellular architecture" = "Cytoskeletal / cellular",
  "Membrane-trafficking dynamics" = "Membrane trafficking",
  "Proteostasis-metabolism-stress" = "Proteostasis / metabolism / stress"
)

category_colours <- c(
  "Nuclear-information regulation" = "#7663A6",
  "Cytoskeletal-cellular architecture" = "#3F78A8",
  "Membrane-trafficking dynamics" = "#2E8B78",
  "Proteostasis-metabolism-stress" = "#C9823E"
)

module_labels <- c(
  "Actin/cytoskeletal machinery" = "Actin/cytoskeletal machinery",
  "Chromatin/genome organization" = "Chromatin/genome organization",
  "ESCRT/Cdv membrane abscission" = "ESCRT/Cdv membrane abscission",
  "Folding/chaperone systems" = "Folding/chaperone systems",
  "Membrane remodeling/endocytosis" = "Membrane remodeling/endocytosis",
  "Motility/motor systems" = "Motility/motor systems",
  "Proteolysis/ubiquitin systems" = "Proteolysis/ubiquitin systems",
  "Repeat/coiled-coil scaffolds" = "Repeat/coiled-coil scaffolds",
  "Trafficking/secretion" = "Trafficking/secretion",
  "Vesicle trafficking small GTPases" = "Vesicle trafficking/small GTPases"
)

prepare_data <- function(path, x_col, mag_col) {
  dat <- read_tsv(path, show_col_types = FALSE) %>%
    mutate(
      x_value = as.numeric(.data[[x_col]]),
      mag_n = as.numeric(.data[[mag_col]])
    ) %>%
    filter(is.finite(x_value), x_value > 0) %>%
    mutate(
      functional_category = factor(functional_category, levels = category_levels),
      module_label = recode(network_module, !!!module_labels),
      base_label = if_else(
        is.na(short_gene) | short_gene == "" | short_gene == "NA",
        OG,
        short_gene
      )
    )

  duplicate_labels <- dat %>%
    count(base_label, name = "label_n") %>%
    filter(label_n > 1)

  dat %>%
    left_join(duplicate_labels, by = "base_label") %>%
    mutate(
      label_text = if_else(
        !is.na(label_n), paste0(base_label, " / ", OG), base_label
      )
    ) %>%
    select(-label_n)
}

make_plot <- function(dat, title, subtitle, x_title, seed) {
  module_order <- dat %>%
    distinct(functional_category, module_label) %>%
    arrange(functional_category, module_label) %>%
    pull(module_label)

  dat <- dat %>%
    mutate(module_label = factor(module_label, levels = rev(unique(module_order))))

  ggplot(dat, aes(x = x_value, y = module_label)) +
    geom_vline(
      xintercept = seq(0.1, 0.9, 0.1),
      colour = "#ECEFF3", linewidth = 0.30
    ) +
    geom_point(
      aes(size = mag_n, fill = functional_category),
      shape = 21, colour = "white", stroke = 0.35, alpha = 0.88
    ) +
    geom_text_repel(
      aes(label = label_text, colour = functional_category),
      family = font_family,
      size = 2.05,
      lineheight = 0.88,
      box.padding = 0.20,
      point.padding = 0.08,
      min.segment.length = 0,
      segment.size = 0.20,
      segment.alpha = 0.65,
      force = 1.6,
      force_pull = 0.20,
      direction = "both",
      max.time = 15,
      max.iter = 150000,
      max.overlaps = Inf,
      seed = seed,
      show.legend = FALSE
    ) +
    facet_grid(
      rows = vars(functional_category),
      scales = "free_y", space = "free_y",
      labeller = as_labeller(category_labels),
      switch = "y"
    ) +
    scale_fill_manual(values = category_colours, guide = "none") +
    scale_colour_manual(values = category_colours, guide = "none") +
    scale_size_continuous(
      range = c(2.0, 5.0),
      name = "MAGs carrying OG"
    ) +
    scale_x_continuous(
      limits = c(0, 1), breaks = seq(0, 1, 0.2),
      expand = expansion(mult = c(0.005, 0.02))
    ) +
    labs(
      title = title,
      subtitle = subtitle,
      x = x_title,
      y = NULL,
      caption = paste0(
        "Only OGs with MRCA-axis position > 0 are shown and labelled; ",
        "shared-stem OGs at x = 0 are excluded from this annotation-focused view."
      )
    ) +
    theme_classic(base_family = font_family, base_size = 8.5) +
    theme(
      axis.line.y = element_blank(),
      axis.line.x = element_line(colour = "#737B86", linewidth = 0.5),
      axis.ticks.y = element_blank(),
      axis.text.y = element_text(
        size = 7.2, colour = "#303844", margin = margin(r = 7)
      ),
      axis.text.x = element_text(size = 7.5, colour = "#4B5563"),
      axis.title.x = element_text(size = 8.5, margin = margin(t = 7)),
      strip.background = element_rect(fill = "#F4F6F8", colour = NA),
      strip.text.y.left = element_text(
        angle = 0, face = "bold", size = 7.6, colour = "#303844",
        margin = margin(3, 5, 3, 5)
      ),
      strip.placement = "outside",
      panel.spacing.y = grid::unit(5, "pt"),
      panel.border = element_blank(),
      plot.title = element_text(size = 11.2, face = "bold", colour = "#111827"),
      plot.subtitle = element_text(size = 8.2, colour = "#5E6877", margin = margin(b = 6)),
      plot.caption = element_text(size = 6.7, colour = "#667085", hjust = 0),
      legend.position = "bottom",
      legend.title = element_text(size = 7.5, face = "bold"),
      legend.text = element_text(size = 7.1),
      plot.margin = margin(10, 20, 10, 10)
    ) +
    coord_cartesian(clip = "off")
}

export_plot <- function(plot, stem, width, height) {
  ggsave(
    paste0(stem, ".pdf"), plot = plot,
    width = width, height = height, units = "in",
    device = cairo_pdf, bg = "white"
  )
  agg_png(
    paste0(stem, ".png"),
    width = width, height = height, units = "in",
    res = 450, background = "white"
  )
  print(plot)
  dev.off()
}

asgard_source <- paste0(
  "..",
  "fig_asgard_current_positive_functional_network_module_axis_source.tsv"
)
asgard_out <- paste0(
  "..",
  "fig_asgard_current_positive_euk_actin_functional_network_module_axis_",
  "xgt0_more_annotated"
)

archaea_source <- paste0(
  "..",
  "fig20_1338_current_positive_functional_network_module_axis_four_classes_source.tsv"
)
archaea_out <- paste0(
  "..",
  "fig20_1338_current_positive_euk_actin_functional_network_module_axis_",
  "four_classes_xgt0_more_annotated"
)

asgard <- prepare_data(asgard_source, "x_display", "n_mags_present_matrix")
archaea <- prepare_data(archaea_source, "axis_position_shared", "n_mags_present_gene_count")

asgard_plot <- make_plot(
  asgard,
  "Asgard actin-associated modules beyond the shared-stem position",
  paste0(nrow(asgard), " lineage-restricted OGs; every displayed OG is labelled"),
  "GTDB r226 Asgard root-to-MRCA display axis",
  202609031
)

archaea_plot <- make_plot(
  archaea,
  "Archaeal actin-associated modules beyond the shared-stem position",
  paste0(nrow(archaea), " lineage-restricted OGs; every displayed OG is labelled"),
  "Shared GTDB r226 root-to-MRCA display axis",
  202609032
)

export_plot(asgard_plot, asgard_out, 16.0, 10.2)
export_plot(archaea_plot, archaea_out, 16.0, 11.0)

write_tsv(
  asgard %>% arrange(functional_category, network_module, x_value, OG),
  paste0(asgard_out, "_source.tsv")
)
write_tsv(
  archaea %>% arrange(functional_category, network_module, x_value, OG),
  paste0(archaea_out, "_source.tsv")
)

message("Asgard labelled x>0 OGs: ", nrow(asgard))
message("Archaea1338 labelled x>0 OGs: ", nrow(archaea))
