# asgard_current_positive_euk_actin_functional_network_module_axis

- Manuscript panel: Supp.Fig.15A-part1
- Source figure basename: fig_asgard_current_positive_euk_actin_functional_network_module_axis
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 3 directly referenced or locally packaged source-data file(s)
