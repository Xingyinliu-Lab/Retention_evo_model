# MAG, genus and species counts within each archaeal phylum
# Scope: MAGs passing GUNC and classified as CheckM2 HQ or MQ

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
script_dir <- if (length(script_arg) == 1) {
  dirname(normalizePath(sub("^--file=", "", script_arg)))
} else {
  normalizePath("arch_mag_desc")
}

input_file <- file.path(script_dir, "18261_arch_mag_meta.txt")
output_dir <- file.path(script_dir, "figures")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

mag <- read.delim(
  input_file,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

gunc_pass <- tolower(trimws(as.character(mag$pass.GUNC))) == "true"
quality <- trimws(as.character(mag$quality_checkm2))
final_mag <- mag[gunc_pass & quality %in% c("HQ", "MQ"), , drop = FALSE]

if (nrow(final_mag) != 15914) {
  warning("Expected 15,914 retained MAGs; observed ", nrow(final_mag), ".")
}

count_unique_nonblank <- function(x) {
  x <- trimws(as.character(x))
  length(unique(x[nzchar(x)]))
}

phylum_names <- sort(unique(trimws(as.character(final_mag$p))))
phylum_names <- phylum_names[nzchar(phylum_names)]

phylum_summary <- do.call(
  rbind,
  lapply(phylum_names, function(phylum_name) {
    subset_data <- final_mag[trimws(as.character(final_mag$p)) == phylum_name, ]
    data.frame(
      phylum = phylum_name,
      mag_count = nrow(subset_data),
      genus_count = count_unique_nonblank(subset_data$g),
      species_count = count_unique_nonblank(subset_data$s),
      genus_assigned_mags = sum(nzchar(trimws(as.character(subset_data$g)))),
      species_assigned_mags = sum(nzchar(trimws(as.character(subset_data$s)))),
      stringsAsFactors = FALSE
    )
  })
)

phylum_summary <- phylum_summary[
  order(phylum_summary$mag_count, decreasing = TRUE),
]
phylum_summary$phylum <- factor(
  phylum_summary$phylum,
  levels = as.character(phylum_summary$phylum)
)

write.csv(
  phylum_summary,
  file.path(output_dir, "source_data_phylum_mag_genus_species.csv"),
  row.names = FALSE
)

format_count <- function(x) {
  format(x, big.mark = ",", scientific = FALSE, trim = TRUE)
}

theme_phylum <- function(show_x = TRUE) {
  theme_classic(base_size = 6.7, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.32, colour = "#293241"),
      axis.line.x = if (show_x) {
        element_line(linewidth = 0.32, colour = "#293241")
      } else {
        element_blank()
      },
      axis.ticks = element_line(linewidth = 0.32, colour = "#293241"),
      axis.ticks.x = if (show_x) {
        element_line(linewidth = 0.32, colour = "#293241")
      } else {
        element_blank()
      },
      axis.ticks.length = grid::unit(1.0, "mm"),
      axis.title = element_text(size = 6.7, colour = "#293241"),
      axis.text.y = element_text(size = 5.8, colour = "#293241"),
      axis.text.x = if (show_x) {
        element_text(
          size = 5.45,
          colour = "#293241",
          angle = 90,
          hjust = 1,
          vjust = 0.5
        )
      } else {
        element_blank()
      },
      plot.title = element_text(size = 7.4, face = "bold", colour = "#172033"),
      plot.subtitle = element_text(size = 5.8, colour = "#687386"),
      plot.tag = element_text(size = 8.5, face = "bold", colour = "#172033"),
      plot.margin = margin(3, 4, if (show_x) 3 else 0.5, 3),
      panel.grid.major.y = element_line(linewidth = 0.22, colour = "#E7EBF0"),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank()
    )
}

make_bar_panel <- function(
    data,
    value_column,
    title,
    subtitle,
    fill,
    line_colour,
    show_x = TRUE) {
  ggplot(
    data,
    aes(x = phylum, y = .data[[value_column]])
  ) +
    geom_col(
      width = 0.68,
      fill = fill,
      colour = line_colour,
      linewidth = 0.32
    ) +
    geom_text(
      aes(label = format_count(.data[[value_column]])),
      vjust = -0.42,
      size = 1.82,
      colour = "#293241",
      family = "Arial"
    ) +
    scale_y_sqrt(
      expand = expansion(mult = c(0, 0.18))
    ) +
    labs(
      x = NULL,
      y = "Count (square-root axis)",
      title = title,
      subtitle = subtitle
    ) +
    theme_phylum(show_x = show_x)
}

p_mag <- make_bar_panel(
  phylum_summary,
  "mag_count",
  "MAGs",
  paste0("Total retained, n = ", format_count(nrow(final_mag))),
  "#B7C8D8",
  "#496B8A",
  show_x = FALSE
)

p_genus <- make_bar_panel(
  phylum_summary,
  "genus_count",
  "Genera",
  "Unique assigned GTDB genera",
  "#B7D3CD",
  "#477F74",
  show_x = FALSE
)

p_species <- make_bar_panel(
  phylum_summary,
  "species_count",
  "Species",
  "Unique assigned GTDB species",
  "#E6C0B8",
  "#9A594E",
  show_x = TRUE
)

figure <- p_mag / p_genus / p_species +
  plot_layout(heights = c(1, 1, 1.28)) +
  plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size = 8.5, face = "bold", family = "Arial"))

width_mm <- 183
height_mm <- 165
width_in <- width_mm / 25.4
height_in <- height_mm / 25.4
output_stem <- file.path(output_dir, "arch_mag_phylum_mag_genus_species")

grDevices::cairo_pdf(
  paste0(output_stem, ".pdf"),
  width = width_in,
  height = height_in,
  family = "Arial"
)
print(figure)
grDevices::dev.off()

grDevices::png(
  paste0(output_stem, "_preview.png"),
  width = width_in,
  height = height_in,
  units = "in",
  res = 300,
  type = "cairo",
  bg = "white"
)
print(figure)
grDevices::dev.off()

message(
  "Created phylum summary for ",
  nrow(phylum_summary),
  " phyla and ",
  format_count(nrow(final_mag)),
  " retained MAGs."
)
