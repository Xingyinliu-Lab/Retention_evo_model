"""Fixed-pose structural control: Homo ACTB AlphaFold versus 8DNH chain A."""
from math import acos, degrees, sqrt
import os
from pathlib import Path
from pymol import cmd

ROOT = Path(r"..")
POSE = Path(r"..")
transparent_bg = os.environ.get("PYMOL_TRANSPARENT_BG", "0") == "1"
actb_transparency = float(os.environ.get("ACTB_CARTOON_TRANSPARENCY", "0.70"))
suffix = "_transparent" if transparent_bg else ""
OUT = ROOT / "pymol_profile_family_atlas_fixedpose" / f"A_Homo_ACTB_AF_vs_8DNH_experimental_superposed{suffix}.png"

def centroid(selection):
    atoms = cmd.get_model(selection).atom
    return [sum(atom.coord[i] for atom in atoms) / len(atoms) for i in range(3)]

cmd.reinitialize()
cmd.set_color("ink", [0.071, 0.094, 0.133])
cmd.set_color("af_green", [0.20, 0.78, 0.47])
cmd.set_color("experimental_blue", [0.298, 0.471, 0.659])
cmd.set_color("tail_orange", [0.96, 0.40, 0.10])
cmd.set_color("terminal_magenta", [0.90, 0.23, 0.53])
cmd.bg_color("ink")
cmd.set("ray_opaque_background", 0 if transparent_bg else 1); cmd.set("orthoscopic", 0)
cmd.set("ambient", 0.20); cmd.set("direct", 0.80); cmd.set("specular", 0.32)
cmd.set("shininess", 40); cmd.set("ray_shadows", 1); cmd.set("ambient_occlusion_mode", 2)
cmd.set("cartoon_fancy_helices", 1)

cmd.load(str(POSE), "pose_ref")
cmd.load(str(ROOT / "Homo_actb_AF-P60709-F1-model_v6.cif"), "actb_af")
cmd.load(str(ROOT / "Homo_actb_8DNH_A_clean.pdb"), "actb_8dnh")
cmd.align("actb_af", "pose_ref and chain E")
cmd.super("actb_8dnh", "actb_af")

core = centroid("pose_ref and chain E and resi 1-340 and not hydro")
tail = centroid("pose_ref and chain E and resi 351-375 and not hydro")
vector = [tail[i] - core[i] for i in range(3)]
norm = sqrt(sum(x*x for x in vector)); vector = [x/norm for x in vector]
target = [-0.36, 0.20, 0.91]
norm = sqrt(sum(x*x for x in target)); target = [x/norm for x in target]
axis = [vector[1]*target[2]-vector[2]*target[1], vector[2]*target[0]-vector[0]*target[2], vector[0]*target[1]-vector[1]*target[0]]
norm = sqrt(sum(x*x for x in axis)); axis = [x/norm for x in axis]
angle = degrees(acos(max(-1.0, min(1.0, sum(vector[i]*target[i] for i in range(3))))))
for obj in ("actb_af", "actb_8dnh"):
    cmd.translate([-core[0], -core[1], -core[2]], obj, camera=0)
    cmd.rotate(axis, angle, obj, camera=0)
cmd.dss("actb_af")

cmd.hide("everything")
cmd.show("cartoon", "actb_af"); cmd.color("af_green", "actb_af")
cmd.set("cartoon_transparency", actb_transparency, "actb_af")
cmd.color("tail_orange", "actb_af and resi 351-372")
cmd.color("terminal_magenta", "actb_af and resi 373-375")
cmd.show("cartoon", "actb_8dnh"); cmd.color("experimental_blue", "actb_8dnh")
cmd.zoom("actb_af or actb_8dnh", 6)
cmd.ray(2400, 1800)
cmd.png(str(OUT), dpi=300)
cmd.quit()
