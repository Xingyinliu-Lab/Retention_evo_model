#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

input_file <- ".."
source_dir <- ".."
figure_dir <- ".."
manuscript_dir <- ".."
quality_filter <- toupper(trimws(Sys.getenv("MULTICOPY_QUALITY_FILTER", "ALL")))
if (!(quality_filter %in% c("ALL", "HQ"))) stop("MULTICOPY_QUALITY_FILTER must be ALL or HQ")
stem <- if (quality_filter == "HQ") {
  "figure_1_HQ_multicopy_top8_family_combinations_pie"
} else {
  "figure_1_multicopy_top8_family_combinations_pie"
}

dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(manuscript_dir, recursive = TRUE, showWarnings = FALSE)

raw_mag <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE)
stopifnot("combo" %in% names(raw_mag))
if (quality_filter == "HQ") {
  stopifnot("quality" %in% names(raw_mag))
  raw_mag <- raw_mag %>% filter(quality == "HQ")
}
raw <- raw_mag %>%
  count(combo, name = "n_mags") %>%
  arrange(desc(n_mags), combo)

top8 <- raw %>%
  slice_head(n = 8) %>%
  mutate(
    pattern_id = sprintf("C%02d", row_number()),
    combo = gsub("MreB-like C/ALP-N-related", "MreB_C/ALP_N", combo, fixed = TRUE)
  )
other_n <- sum(raw$n_mags) - sum(top8$n_mags)
plot_data <- bind_rows(
  top8 %>% select(pattern_id, combo, n_mags),
  data.frame(pattern_id = "Other", combo = "Other combinations", n_mags = other_n)
) %>%
  mutate(
    fraction = n_mags / sum(n_mags),
    percent = 100 * fraction,
    legend_label = ifelse(
      pattern_id == "Other",
      sprintf("Other (%d patterns); %d MAGs (%.1f%%)", nrow(raw) - 8L, n_mags, percent),
      sprintf("%s  %s; %d MAGs (%.1f%%)", pattern_id, combo, n_mags, percent)
    ),
    pattern_id = factor(pattern_id, levels = c(sprintf("C%02d", 1:8), "Other")),
    legend_label = factor(legend_label, levels = legend_label)
  )

write.table(
  plot_data %>% mutate(pattern_id = as.character(pattern_id), legend_label = as.character(legend_label)),
  file.path(source_dir, paste0(stem, "_source.tsv")),
  sep = "\t", quote = FALSE, row.names = FALSE, na = ""
)

combo_palette <- c(
  "MreB/Mbl-like" = "#778AA2",
  "cALP + dALP" = "#9A82B8",
  "cALP + MreB_C/ALP_N" = "#67A69E",
  "cALP + dALP + MreB_C/ALP_N" = "#B79FC7",
  "cALP" = "#7195BC",
  "dALP" = "#73ADA5",
  "Salactin + Volactin" = "#DDB565",
  "dALP + MreB_C/ALP_N" = "#9AB9A3",
  "MreB_C/ALP_N + Salactin" = "#D1A070",
  "MreB/Mbl-like + FtsA/PilM-like" = "#A69889",
  "MreB/Mbl-like + Volactin" = "#98AE92",
  "Other combinations" = "#E2E3E5"
)
palette <- setNames(
  unname(combo_palette[as.character(plot_data$combo)]),
  as.character(plot_data$pattern_id)
)
stopifnot(!any(is.na(palette)))

p <- ggplot(plot_data, aes(x = "", y = n_mags, fill = pattern_id)) +
  geom_col(width = 1, colour = NA) +
  coord_polar(theta = "y", start = 0, direction = -1) +
  scale_fill_manual(
    values = palette,
    breaks = levels(plot_data$pattern_id),
    labels = as.character(plot_data$legend_label),
    drop = FALSE
  ) +
  labs(fill = NULL) +
  guides(fill = guide_legend(ncol = 1, byrow = TRUE, keyheight = grid::unit(3.2, "mm"), keywidth = grid::unit(3.2, "mm"))) +
  theme_void(base_family = "Arial", base_size = 6.2) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 5.8, colour = "#222222", lineheight = 0.95),
    legend.spacing.y = grid::unit(0.4, "mm"),
    plot.margin = margin(2, 2, 2, 2)
  )

width_mm <- 132
height_mm <- 78
pdf_path <- file.path(figure_dir, paste0(stem, ".pdf"))
png_path <- file.path(figure_dir, paste0(stem, ".png"))

grDevices::cairo_pdf(pdf_path, width = width_mm / 25.4, height = height_mm / 25.4, family = "Arial")
print(p)
grDevices::dev.off()

grDevices::png(
  png_path,
  width = width_mm / 25.4,
  height = height_mm / 25.4,
  units = "in",
  res = 600,
  type = "cairo",
  bg = "white"
)
print(p)
grDevices::dev.off()

file.copy(pdf_path, file.path(manuscript_dir, basename(pdf_path)), overwrite = TRUE)
file.copy(png_path, file.path(manuscript_dir, basename(png_path)), overwrite = TRUE)
file.copy(
  file.path(source_dir, paste0(stem, "_source.tsv")),
  file.path(manuscript_dir, paste0(stem, "_source.tsv")),
  overwrite = TRUE
)

qa <- data.frame(
  quality_filter = quality_filter,
  total_multicopy_mags = sum(plot_data$n_mags),
  top8_mags = sum(top8$n_mags),
  top8_fraction = sum(top8$n_mags) / sum(plot_data$n_mags),
  other_patterns = nrow(raw) - 8L,
  other_mags = other_n,
  output_width_mm = width_mm,
  output_height_mm = height_mm,
  stringsAsFactors = FALSE
)
write.table(
  qa,
  file.path(source_dir, paste0(stem, "_QA.tsv")),
  sep = "\t", quote = FALSE, row.names = FALSE, na = ""
)
