# A1338_GTDB_cALP_AB_state_track

- Source figure: `fig_A1338_GTDB_cALP_AB_state_track`
- Analysis basis: gappyout584 cALP A/B partition projected onto the established Archaea1338-to-GTDB r226 linear axis.
- Contents: final PDF/PNG, R plotting code and the plotted tip-order/state table.
- Status: included; the former automated1-derived version is superseded.
- Packaging rule: files were copied; the analysis outputs were not moved.
