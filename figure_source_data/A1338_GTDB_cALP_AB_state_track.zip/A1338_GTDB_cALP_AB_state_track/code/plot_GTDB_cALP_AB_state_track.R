#!/usr/bin/env Rscript

# Single-row cALP A/B state track aligned to the established
# Archaea1338-to-GTDB r226 phylum linear axis.

required <- c("dplyr", "ggplot2", "readr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing R packages: ", paste(missing, collapse = ", "))

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
})

root <- ".."
state_file <- file.path(root, "results/copy_associated_AB_v2_orderCV/copy_associated_AB_host_states.tsv")
axis_file <- ".."
mapping_file <- ".."
fig_dir <- file.path(root, "figures")
src_dir <- file.path(fig_dir, "source_data")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(src_dir, recursive = TRUE, showWarnings = FALSE)

states <- read_tsv(state_file, show_col_types = FALSE) %>%
  select(host_id, state)
if (anyDuplicated(states$host_id)) stop("Duplicated host states.")
axis <- read_tsv(axis_file, show_col_types = FALSE) %>% arrange(tip_order)
mapping <- read_tsv(mapping_file, show_col_types = FALSE) %>% select(mag_id, anchor_tip)
if (anyDuplicated(axis$gtdb_tip) || anyDuplicated(axis$tip_order)) stop("Duplicated A1338 GTDB axis entries.")

# Apply exactly the same host-to-anchor aggregation used by the established
# A1338 GTDB cALP/dALP track: coexist takes precedence; incompatible states
# at one reference tip are shown as a collision rather than guessed.
projected <- states %>%
  inner_join(mapping, by = c("host_id" = "mag_id")) %>%
  group_by(anchor_tip) %>%
  summarise(
    state = case_when(
      "A+B coexist" %in% state ~ "A+B coexist",
      n_distinct(state) == 1L ~ first(state),
      TRUE ~ "multiple MAG states"
    ),
    n_mapped_MAGs = n(),
    .groups = "drop"
  )

track <- axis %>%
  left_join(projected, by = c("gtdb_tip" = "anchor_tip")) %>%
  mutate(
    state = ifelse(is.na(state), "No assigned cALP", state),
    n_mapped_MAGs = ifelse(is.na(n_mapped_MAGs), 0L, n_mapped_MAGs)
  )
stopifnot(nrow(track) == nrow(axis), identical(track$tip_order, axis$tip_order))

state_levels <- c("A-only", "A+B coexist", "B-only", "multiple MAG states", "No assigned cALP")
track$state <- factor(track$state, levels = state_levels)

write_tsv(track, file.path(src_dir, "fig_A1338_GTDB_cALP_AB_state_track_source.tsv"))

state_palette <- c(
  "A-only" = "#7897B5",
  "A+B coexist" = "#79B7A8",
  "B-only" = "#DDA06A",
  "multiple MAG states" = "#7A6F8F",
  "No assigned cALP" = "#EEEEEE"
)

p <- ggplot(track, aes(tip_order, 1, fill = state)) +
  geom_raster(interpolate = FALSE) +
  scale_fill_manual(
    values = state_palette,
    breaks = c("A-only", "A+B coexist", "B-only"),
    labels = c("A-only", "A + B coexist", "B-only"),
    name = NULL,
    drop = FALSE
  ) +
  scale_x_continuous(expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  theme_void(base_family = "Arial", base_size = 7) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 5.7, colour = "#303030"),
    legend.key.width = grid::unit(4.4, "mm"),
    legend.key.height = grid::unit(2.1, "mm"),
    legend.margin = margin(0, 0, 1.5, 0),
    plot.margin = margin(1, 1.5, 1, 1.5)
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE, override.aes = list(colour = NA)))

stem <- file.path(fig_dir, "fig_A1338_GTDB_cALP_AB_state_track")
ggsave(paste0(stem, ".pdf"), p, width = 183, height = 12, units = "mm", device = cairo_pdf, bg = "white")
ggsave(paste0(stem, ".png"), p, width = 183, height = 12, units = "mm", dpi = 420, bg = "white")

writeLines(
  c(
    "status=complete",
    "axis=A1338_GTDB_r226_phylum_linear_axis",
    paste0("n_axis_tips=", nrow(track)),
    paste0("n_exact_A_B_MAGs_projected=", sum(states$host_id %in% mapping$mag_id)),
    paste0("n_coloured_GTDB_tips=", sum(track$state != "No assigned cALP")),
    paste0("A_only=", sum(track$state == "A-only")),
    paste0("coexist=", sum(track$state == "A+B coexist")),
    paste0("B_only=", sum(track$state == "B-only")),
    paste0("multiple_MAG_states=", sum(track$state == "multiple MAG states")),
    paste0("pdf=", stem, ".pdf")
  ),
  file.path(fig_dir, "A1338_GTDB_CALP_AB_STATE_TRACK_COMPLETE.marker")
)
