"""Render native experimental actin-partner chain pairs in one fixed pose.

No actin chain is replaced, rebuilt, mutated or minimized. Each complete native
PDB object is moved only by a rigid-body PyMOL superposition to the established
view anchor, after which only the selected native actin and target partner
chains are retained for rendering.
"""

from collections import defaultdict
from math import dist
import os
from pathlib import Path
import shutil

from pymol import cmd


ACTIN_ROOT = Path(r"..")
ROOT = ACTIN_ROOT / "complex_assess"
CIF_ROOT = ACTIN_ROOT / "8F8P" / "cif"
FIGURE_ROOT = ROOT / "figures"
SOURCE_ROOT = ROOT / "source_data"
MANUSCRIPT_ROOT = (
    ACTIN_ROOT
    / "manuscript_writing_20260801"
    / "figures"
    / "fig3_tail_is_important"
)
VIEW_ANCHOR = ROOT / "pymol_models" / "7W50_ACTB_WT_job02798_input_Repair.pdb"

CASES = (
    {
        "pdb_id": "6NBW",
        "actin_chains": ("A",),
        "partner_chains": ("P",),
        "actin_label": "native_ACTB",
        "partner_label": "profilin",
        "species": "Homo sapiens",
    },
    {
        "pdb_id": "8VKH",
        "actin_chains": ("E",),
        "partner_chains": ("H",),
        "actin_label": "native_rabbit_ACTA1",
        "partner_label": "gelsolin_G1G3",
        "species": "Oryctolagus cuniculus",
    },
    {
        "pdb_id": "8RU2",
        "actin_chains": ("D",),
        "partner_chains": ("E", "F"),
        "actin_label": "native_ACTB",
        "partner_label": "formin_mDia1",
        "species": "Homo sapiens",
    },
    {
        "pdb_id": "3DAW",
        "actin_chains": ("A",),
        "partner_chains": ("B",),
        "actin_label": "native_rabbit_ACTA1",
        "partner_label": "twinfilin1_ADFH",
        "species": "Oryctolagus cuniculus",
    },
    {
        "pdb_id": "9QFJ",
        "actin_chains": ("A",),
        "partner_chains": ("G",),
        "actin_label": "native_ACTB",
        "partner_label": "cofilin1",
        "species": "Homo sapiens",
    },
    {
        "pdb_id": "9QEW",
        "actin_chains": ("A",),
        "partner_chains": ("C",),
        "actin_label": "native_ACTB",
        "partner_label": "actin_neighbor",
        "species": "Homo sapiens",
    },
    {
        "pdb_id": "7PLZ",
        "actin_chains": ("C",),
        "partner_chains": ("A",),
        "actin_label": "native_rabbit_ACTA1",
        "partner_label": "myosinVa",
        "species": "Oryctolagus cuniculus",
    },
)

REGIONS = (
    {
        "name": "full_tail",
        "resi": "351-375",
        "file_label": "full_tail",
        "suffix": "interface_facing_oblique_exact7W50view_splitpatches",
    },
    {
        "name": "KCF",
        "resi": "373-375",
        "file_label": "KCF",
        "suffix": "exact7W50view_residuepatch",
    },
)


def chain_selection(object_name, chains):
    return "(" + " or ".join(
        f"({object_name} and chain {chain})" for chain in chains
    ) + ")"


def capture_reference_view():
    cmd.reinitialize()
    cmd.load(str(VIEW_ANCHOR), "ref")
    cmd.remove("ref and solvent")
    cmd.select(
        "ref_partner_near_tail",
        "byres ((ref and chain B) within 5.0 of (ref and chain A and resi 351-375))",
    )
    cmd.orient("(ref and chain A and resi 351-375) or ref_partner_near_tail")
    cmd.turn("y", 15)
    cmd.turn("x", 8)
    cmd.zoom("ref", -10.0)
    return cmd.get_view()


def contact_rows(region_sel, partner_sel):
    contacts = defaultdict(lambda: {"pairs": 0, "minimum_A": 999.0})
    region_atoms = cmd.get_model(f"({region_sel}) and not hydro").atom
    partner_atoms = cmd.get_model(f"({partner_sel}) and not hydro").atom
    for atom_a in region_atoms:
        for atom_b in partner_atoms:
            distance = dist(atom_a.coord, atom_b.coord)
            if distance <= 5.0:
                key = (
                    atom_a.chain,
                    atom_a.resn,
                    atom_a.resi,
                    atom_b.chain,
                    atom_b.resn,
                    atom_b.resi,
                )
                contacts[key]["pairs"] += 1
                contacts[key]["minimum_A"] = min(
                    contacts[key]["minimum_A"], distance
                )
    return sorted(
        contacts.items(), key=lambda item: (-item[1]["pairs"], item[1]["minimum_A"])
    )


def render(case, region, reference_view):
    cmd.reinitialize()
    cmd.load(str(VIEW_ANCHOR), "ref")
    cmd.remove("ref and solvent")
    cmd.load(str(CIF_ROOT / f"{case['pdb_id']}.cif"), "native")
    cmd.remove("native and solvent")

    actin_chain = case["actin_chains"][0]
    cmd.super(
        f"native and chain {actin_chain} and resi 50-350 and name CA",
        "ref and chain A and resi 50-350 and name CA",
        cycles=5,
        quiet=1,
    )

    selected_chains = case["actin_chains"] + case["partner_chains"]
    selected = chain_selection("native", selected_chains)
    cmd.create("pair", selected)
    cmd.delete("native")
    cmd.delete("ref")

    actin = chain_selection("pair", case["actin_chains"])
    partner = chain_selection("pair", case["partner_chains"])
    displayed_region = f"({actin}) and resi {region['resi']}"
    rows = contact_rows(displayed_region, partner)

    partner_residue_terms = sorted(
        {
            f"(pair and chain {key[3]} and resi {key[5]})"
            for key, _value in rows
        }
    )
    if partner_residue_terms:
        partner_patch_sel = "(" + " or ".join(partner_residue_terms) + ")"
        partner_base_sel = f"({partner}) and not ({partner_patch_sel})"
    else:
        partner_patch_sel = "none"
        partner_base_sel = partner

    stem = (
        f"fig_pymol_{case['pdb_id']}_{case['actin_label']}_"
        f"{region['file_label']}_{case['partner_label']}_{region['suffix']}"
    )
    png = FIGURE_ROOT / f"{stem}.png"
    pse = FIGURE_ROOT / f"{stem}.pse"
    tsv = SOURCE_ROOT / f"{stem}_source.tsv"

    with tsv.open("w", encoding="utf-8", newline="\n") as out:
        out.write(
            "template\tnative_actin_entity\tnative_actin_species\tpartner_context\t"
            "actin_chain\tpartner_chain\tdisplayed_region\tactin_residue\t"
            "partner_residue\tatom_pairs_5A\tminimum_distance_A\tchain_replacement\t"
            "coordinate_operation\tview_reference\n"
        )
        if not rows:
            out.write(
                f"{case['pdb_id']}\t{case['actin_label']}\t{case['species']}\t"
                f"{case['partner_label']}\t{'+'.join(case['actin_chains'])}\t"
                f"{'+'.join(case['partner_chains'])}\t{region['name']}\tNA\tNA\t0\tNA\t"
                "none\trigid_body_superposition_only\t7W50_exact_view_matrix\n"
            )
        for (ac, ar, ai, bc, br, bi), value in rows:
            out.write(
                f"{case['pdb_id']}\t{case['actin_label']}\t{case['species']}\t"
                f"{case['partner_label']}\t{ac}\t{bc}\t{region['name']}\t{ar}{ai}\t"
                f"{br}{bi}\t{value['pairs']}\t{value['minimum_A']:.3f}\tnone\t"
                "rigid_body_superposition_only\t7W50_exact_view_matrix\n"
            )

    cmd.create("actin_base", f"({actin}) and not resi {region['resi']}")
    cmd.create("tail_patch", displayed_region)
    cmd.create("partner_base", partner_base_sel)
    if partner_residue_terms:
        cmd.create("partner_patch", partner_patch_sel)
    cmd.delete("pair")

    cmd.set_color("ink", [0.071, 0.094, 0.133])
    cmd.set_color("actin_blue", [0.36, 0.55, 0.74])
    cmd.set_color("partner_green", [0.57, 0.69, 0.61])
    cmd.set_color("tail_rose", [0.88, 0.43, 0.56])
    cmd.set_color("contact_gold", [0.97, 0.62, 0.12])
    cmd.bg_color("ink")
    cmd.hide("everything", "all")
    cmd.show("surface", "actin_base or tail_patch or partner_base")
    if partner_residue_terms:
        cmd.show("surface", "partner_patch")
    cmd.color("actin_blue", "actin_base")
    cmd.color("tail_rose", "tail_patch")
    cmd.color("partner_green", "partner_base")
    if partner_residue_terms:
        cmd.color("contact_gold", "partner_patch")

    cmd.set("surface_quality", 0)
    cmd.set("transparency", 0.00, "actin_base")
    cmd.set("transparency", 0.00, "tail_patch")
    cmd.set("transparency", 0.55, "partner_base")
    if partner_residue_terms:
        cmd.set("transparency", 0.35, "partner_patch")

    cmd.set_view(reference_view)
    cmd.set("orthoscopic", 0)
    cmd.set("ray_opaque_background", 0)
    cmd.set("transparency_mode", 1)
    cmd.set("antialias", 2)
    cmd.set("ambient", 0.28)
    cmd.set("direct", 0.72)
    cmd.set("specular", 0.24)
    cmd.set("shininess", 30)
    cmd.set("ray_shadows", 0)
    cmd.set("ambient_occlusion_mode", 0)
    cmd.set("depth_cue", 0)
    cmd.set("fog", 0)
    cmd.set("ray_trace_mode", 0)
    cmd.set("ray_interior_color", "partner_green")

    cmd.save(str(pse))
    cmd.ray(1600, 1200)
    cmd.png(str(png), dpi=300)
    shutil.copy2(png, MANUSCRIPT_ROOT / png.name)
    shutil.copy2(pse, MANUSCRIPT_ROOT / pse.name)
    shutil.copy2(tsv, MANUSCRIPT_ROOT / tsv.name)

    return {
        "template": case["pdb_id"],
        "native_actin_entity": case["actin_label"],
        "native_actin_species": case["species"],
        "partner_context": case["partner_label"],
        "actin_chains": "+".join(case["actin_chains"]),
        "partner_chains": "+".join(case["partner_chains"]),
        "region": region["name"],
        "n_contact_residue_pairs": len(rows),
        "chain_replacement": "none",
        "coordinate_operation": "rigid_body_superposition_only",
        "png": png.name,
        "pse": pse.name,
        "source_tsv": tsv.name,
    }


def main():
    FIGURE_ROOT.mkdir(parents=True, exist_ok=True)
    SOURCE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_ROOT.mkdir(parents=True, exist_ok=True)
    case_filter = os.environ.get("PYMOL_NATIVE_CASE", "").strip().upper()
    selected_cases = tuple(
        case for case in CASES if not case_filter or case["pdb_id"] == case_filter
    )
    if not selected_cases:
        raise ValueError(f"Unknown PYMOL_NATIVE_CASE: {case_filter}")
    for case in selected_cases:
        if not (CIF_ROOT / f"{case['pdb_id']}.cif").exists():
            raise FileNotFoundError(case["pdb_id"])

    reference_view = capture_reference_view()
    audit_rows = []
    for case in selected_cases:
        for region in REGIONS:
            audit_rows.append(render(case, region, reference_view))

    audit_stem = (
        f"native_actin_tail_partner_render_{case_filter}_audit_20260831.tsv"
        if case_filter
        else "native_actin_tail_partner_render_audit_20260831.tsv"
    )
    audit = SOURCE_ROOT / audit_stem
    fields = tuple(audit_rows[0].keys())
    with audit.open("w", encoding="utf-8", newline="\n") as out:
        out.write("\t".join(fields) + "\n")
        for row in audit_rows:
            out.write("\t".join(str(row[field]) for field in fields) + "\n")
    shutil.copy2(audit, MANUSCRIPT_ROOT / audit.name)

    marker_stem = (
        f"native_actin_tail_partner_render_{case_filter}_20260831.QA.marker"
        if case_filter
        else "native_actin_tail_partner_render_20260831.QA.marker"
    )
    marker = FIGURE_ROOT / marker_stem
    marker.write_text(
        "\n".join(
            (
                "PASS",
                "backend=Python_PyMOL",
                f"rendered_pairs={len(audit_rows)}",
                "native_experimental_PDB_chains_only=true",
                "actin_chain_replacement=none",
                "coordinate_operation=rigid_body_superposition_only",
                "contact_cutoff_A=5",
                "output=PNG,PSE,TSV",
                "SVG=false",
                "TIFF=false",
                "transparent_background=true",
                "ray_size=1600x1200",
            )
        )
        + "\n",
        encoding="utf-8",
    )
    cmd.quit()


if __name__ == "__main__":
    main()
