# Quality-control and taxonomic overview of 18,261 archaeal MAGs
# Backend: R + ggplot2/patchwork

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
script_dir <- if (length(script_arg) == 1) {
  dirname(normalizePath(sub("^--file=", "", script_arg)))
} else {
  normalizePath("arch_mag_desc")
}

input_file <- file.path(script_dir, "18261_arch_mag_meta.txt")
output_dir <- file.path(script_dir, "figures")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

mag <- read.delim(
  input_file,
  header = TRUE,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_columns <- c(
  "user_genome", "Completeness", "Contamination", "pass.GUNC",
  "quality_checkm2", "p", "c", "o", "f", "g", "s"
)
missing_columns <- setdiff(required_columns, names(mag))
if (length(missing_columns) > 0) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}

mag$Completeness <- as.numeric(mag$Completeness)
mag$Contamination <- as.numeric(mag$Contamination)
mag$gunc_pass <- tolower(trimws(as.character(mag$pass.GUNC))) == "true"
mag$quality_file <- trimws(as.character(mag$quality_checkm2))

# Reconstruct the exact thresholds used in the metadata file.
mag$quality_derived <- ifelse(
  mag$Completeness > 90 & mag$Contamination < 5,
  "HQ",
  ifelse(
    mag$Completeness > 50 & mag$Contamination < 10,
    "MQ",
    ""
  )
)

rule_mismatch <- mag$quality_file != mag$quality_derived
if (any(rule_mismatch)) {
  stop(
    "The reconstructed HQ/MQ rule disagrees with ",
    sum(rule_mismatch),
    " metadata rows."
  )
}

mag$retained <- mag$gunc_pass & mag$quality_file %in% c("HQ", "MQ")
final_mag <- mag[mag$retained, , drop = FALSE]

total_n <- nrow(mag)
final_n <- nrow(final_mag)
hq_n <- sum(final_mag$quality_file == "HQ")
mq_n <- sum(final_mag$quality_file == "MQ")

if (total_n != 18261 || final_n != 15914) {
  warning(
    "Observed counts differ from the expected 18,261 total and 15,914 retained."
  )
}

fmt_int <- function(x) format(x, big.mark = ",", scientific = FALSE, trim = TRUE)
fmt_pct <- function(x, digits = 1) paste0(round(100 * x, digits), "%")

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 0.4),
      plot.title = element_text(size = base_size + 0.5, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.tag = element_text(size = 8, face = "bold"),
      plot.margin = margin(4, 5, 4, 5),
      panel.grid = element_blank()
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 300) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  grDevices::cairo_pdf(
    paste0(stem, ".pdf"),
    width = width_in,
    height = height_in,
    family = "sans"
  )
  print(plot)
  grDevices::dev.off()

  grDevices::png(
    paste0(stem, "_preview.png"),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    type = "cairo",
    bg = "white"
  )
  print(plot)
  grDevices::dev.off()
}

# -------------------------------------------------------------------------
# Figure 1: quality-control overview
# -------------------------------------------------------------------------

qc_counts <- data.frame(
  filter = c(
    "All archaeal MAGs",
    "Pass GUNC",
    "CheckM2 HQ or MQ",
    "Pass both filters"
  ),
  count = c(
    total_n,
    sum(mag$gunc_pass),
    sum(mag$quality_file %in% c("HQ", "MQ")),
    final_n
  )
)
qc_counts$filter <- factor(qc_counts$filter, levels = rev(qc_counts$filter))
qc_counts$label <- paste0(
  fmt_int(qc_counts$count),
  "  (",
  fmt_pct(qc_counts$count / total_n),
  ")"
)

p_qc_counts <- ggplot(qc_counts, aes(x = count, y = filter)) +
  geom_col(width = 0.66, fill = "#5B7FA3") +
  geom_text(
    aes(label = label),
    hjust = 1.04,
    colour = "white",
    size = 2.35,
    family = "sans"
  ) +
  scale_x_continuous(
    limits = c(0, total_n * 1.02),
    breaks = c(0, 5000, 10000, 15000),
    labels = function(x) format(x, big.mark = ",", scientific = FALSE)
  ) +
  labs(
    x = "Number of MAGs",
    y = NULL,
    title = "Quality-control retention",
    subtitle = "Percentages use all MAGs as denominator"
  ) +
  theme_nature() +
  theme(axis.line.y = element_blank(), axis.ticks.y = element_blank())

mag$plot_status <- ifelse(
  mag$retained & mag$quality_file == "HQ",
  "Retained HQ",
  ifelse(
    mag$retained & mag$quality_file == "MQ",
    "Retained MQ",
    "Not retained"
  )
)
mag$plot_status <- factor(
  mag$plot_status,
  levels = c("Not retained", "Retained MQ", "Retained HQ")
)
mag_plot <- mag[order(mag$plot_status), , drop = FALSE]

quality_palette <- c(
  "Not retained" = "#BDBDBD",
  "Retained MQ" = "#5B8DB8",
  "Retained HQ" = "#D66B5D"
)

p_qc_scatter <- ggplot(
  mag_plot,
  aes(x = Completeness, y = Contamination, colour = plot_status)
) +
  geom_point(size = 0.55, alpha = 0.38, stroke = 0) +
  geom_vline(
    xintercept = c(50, 90),
    linewidth = 0.35,
    linetype = "22",
    colour = "#333333"
  ) +
  geom_hline(
    yintercept = c(5, 10),
    linewidth = 0.35,
    linetype = "22",
    colour = "#333333"
  ) +
  annotate(
    "text",
    x = 94,
    y = 3.5,
    label = "HQ",
    size = 2.3,
    fontface = "bold",
    family = "sans"
  ) +
  annotate(
    "text",
    x = 72,
    y = 7.7,
    label = "MQ",
    size = 2.3,
    fontface = "bold",
    family = "sans"
  ) +
  scale_colour_manual(values = quality_palette, drop = FALSE) +
  scale_x_continuous(
    limits = c(20, 101),
    breaks = c(25, 50, 75, 90, 100)
  ) +
  scale_y_sqrt(
    limits = c(0, 36),
    breaks = c(0, 1, 2, 5, 10, 20, 30)
  ) +
  labs(
    x = "CheckM2 completeness (%)",
    y = "CheckM2 contamination (%)\n(square-root scale)",
    title = "Completeness–contamination landscape",
    subtitle = "Dashed lines show strict HQ/MQ thresholds"
  ) +
  theme_nature() +
  theme(
    legend.position = "bottom",
    legend.justification = "left",
    legend.margin = margin(t = 1),
    legend.key.width = grid::unit(3, "mm")
  ) +
  guides(colour = guide_legend(override.aes = list(size = 1.8, alpha = 1)))

quality_figure <- p_qc_counts + p_qc_scatter +
  plot_layout(widths = c(0.88, 1.32)) +
  plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size = 8, face = "bold", family = "sans"))

save_figure(
  quality_figure,
  file.path(output_dir, "arch_mag_quality_overview"),
  width_mm = 183,
  height_mm = 88
)

# -------------------------------------------------------------------------
# Figure 2: taxonomy assignment and abundance distributions
# -------------------------------------------------------------------------

rank_columns <- c("p", "c", "o", "f", "g", "s")
rank_labels <- c("Phylum", "Class", "Order", "Family", "Genus", "Species")

assignment_data <- do.call(
  rbind,
  lapply(seq_along(rank_columns), function(i) {
    values <- trimws(as.character(final_mag[[rank_columns[i]]]))
    assigned_n <- sum(nzchar(values))
    data.frame(
      rank = rank_labels[i],
      assigned = assigned_n,
      unassigned = final_n - assigned_n,
      fraction = assigned_n / final_n,
      unique_taxa = length(unique(values[nzchar(values)]))
    )
  })
)
assignment_data$rank <- factor(
  assignment_data$rank,
  levels = rev(rank_labels)
)
assignment_data$label <- paste0(
  fmt_pct(assignment_data$fraction),
  "  (",
  fmt_int(assignment_data$unique_taxa),
  " taxa)"
)

p_assignment <- ggplot(assignment_data, aes(x = fraction, y = rank)) +
  geom_col(width = 0.66, fill = "#4F9B8F") +
  geom_text(
    aes(label = label),
    hjust = 1.03,
    colour = "white",
    size = 2.15,
    family = "sans"
  ) +
  scale_x_continuous(
    limits = c(0, 1.02),
    breaks = c(0, 0.25, 0.5, 0.75, 1),
    labels = function(x) paste0(round(100 * x), "%")
  ) +
  labs(
    x = "MAGs assigned at rank",
    y = NULL,
    title = "Taxonomic assignment coverage",
    subtitle = paste0("Among ", fmt_int(final_n), " retained MAGs")
  ) +
  theme_nature() +
  theme(axis.line.y = element_blank(), axis.ticks.y = element_blank())

top_taxa <- function(data, column, rank_name, n_top) {
  values <- trimws(as.character(data[[column]]))
  values <- values[nzchar(values)]
  counts <- sort(table(values), decreasing = TRUE)
  counts <- head(counts, n_top)
  out <- data.frame(
    rank = rank_name,
    taxon = names(counts),
    count = as.integer(counts),
    stringsAsFactors = FALSE
  )
  out$fraction_all <- out$count / final_n
  out$label <- paste0(fmt_int(out$count), " (", fmt_pct(out$fraction_all), ")")
  out$taxon <- factor(out$taxon, levels = rev(out$taxon))
  out
}

plot_top_taxa <- function(data, title, subtitle, colour, italic = FALSE) {
  ggplot(data, aes(x = count, y = taxon)) +
    geom_col(width = 0.68, fill = colour) +
    geom_text(
      aes(label = label),
      hjust = -0.08,
      size = 2.05,
      family = "sans"
    ) +
    scale_x_continuous(
      expand = expansion(mult = c(0, 0.27)),
      labels = function(x) format(x, big.mark = ",", scientific = FALSE)
    ) +
    labs(
      x = "Number of MAGs",
      y = NULL,
      title = title,
      subtitle = subtitle
    ) +
    theme_nature() +
    theme(
      axis.line.y = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_text(
        face = if (italic) "italic" else "plain",
        size = 5.8
      )
    )
}

phylum_data <- top_taxa(final_mag, "p", "Phylum", 15)
genus_data <- top_taxa(final_mag, "g", "Genus", 15)
species_data <- top_taxa(final_mag, "s", "Species", 15)

p_phylum <- plot_top_taxa(
  phylum_data,
  "Most abundant phyla",
  "Top 15; percentages use all retained MAGs",
  "#6F8FB5"
)
p_genus <- plot_top_taxa(
  genus_data,
  "Most abundant genera",
  "Top 15; 508 MAGs lack a genus assignment",
  "#B07AA1",
  italic = TRUE
)
p_species <- plot_top_taxa(
  species_data,
  "Most abundant species",
  "Top 15; 2,151 MAGs lack a species assignment",
  "#D68455",
  italic = TRUE
)

taxonomy_figure <- (p_assignment | p_phylum) / (p_genus | p_species) +
  plot_layout(heights = c(0.74, 1.26)) +
  plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size = 8, face = "bold", family = "sans"))

save_figure(
  taxonomy_figure,
  file.path(output_dir, "arch_mag_taxonomy_overview"),
  width_mm = 183,
  height_mm = 178
)

# -------------------------------------------------------------------------
# Reproducible source-data tables and audit summary
# -------------------------------------------------------------------------

write.csv(
  qc_counts,
  file.path(output_dir, "source_data_quality_counts.csv"),
  row.names = FALSE
)
write.csv(
  assignment_data,
  file.path(output_dir, "source_data_taxonomy_assignment.csv"),
  row.names = FALSE
)
write.csv(
  rbind(phylum_data, genus_data, species_data),
  file.path(output_dir, "source_data_top_taxa.csv"),
  row.names = FALSE
)

audit_lines <- c(
  "Archaeal MAG metadata audit",
  paste0("Input rows: ", fmt_int(total_n)),
  "",
  "Reconstructed quality thresholds (zero mismatches):",
  "HQ: Completeness > 90 and Contamination < 5",
  "MQ: not HQ, Completeness > 50 and Contamination < 10",
  "Below threshold: all remaining records",
  "Final retained: pass.GUNC == TRUE and quality_checkm2 in {HQ, MQ}",
  "",
  paste0("CheckM2 HQ before GUNC: ", fmt_int(sum(mag$quality_file == "HQ"))),
  paste0("CheckM2 MQ before GUNC: ", fmt_int(sum(mag$quality_file == "MQ"))),
  paste0("Pass GUNC: ", fmt_int(sum(mag$gunc_pass))),
  paste0("Final retained: ", fmt_int(final_n), " (", fmt_pct(final_n / total_n), ")"),
  paste0("Final HQ: ", fmt_int(hq_n)),
  paste0("Final MQ: ", fmt_int(mq_n)),
  "",
  "Taxonomic assignment among retained MAGs:",
  paste0(
    as.character(assignment_data$rank),
    ": ",
    fmt_int(assignment_data$assigned),
    " assigned; ",
    fmt_int(assignment_data$unassigned),
    " unassigned; ",
    fmt_int(assignment_data$unique_taxa),
    " unique taxa"
  )
)
writeLines(
  audit_lines,
  con = file.path(output_dir, "arch_mag_audit_summary.txt"),
  useBytes = TRUE
)

message(
  "Completed: ",
  fmt_int(total_n),
  " input MAGs; ",
  fmt_int(final_n),
  " retained (",
  fmt_int(hq_n),
  " HQ, ",
  fmt_int(mq_n),
  " MQ)."
)
