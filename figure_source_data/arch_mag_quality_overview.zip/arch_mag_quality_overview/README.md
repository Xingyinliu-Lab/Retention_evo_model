# arch_mag_quality_overview

- Manuscript panel: Fig.1A-B
- Source figure basename: arch_mag_quality_overview
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 9 directly referenced or locally packaged source-data file(s)
