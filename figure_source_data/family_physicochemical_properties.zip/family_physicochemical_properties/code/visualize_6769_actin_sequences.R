# Publication-ready visualization of 6,769 archaeal actin-superfamily proteins
# Backend: R 4.4.1 + ggplot2 + patchwork

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(scales)
})

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
script_dir <- if (length(script_arg) == 1) {
  dirname(normalizePath(sub("^--file=", "", script_arg)))
} else {
  normalizePath(file.path("6769_seq_desc", "code"))
}

output_root <- normalizePath(file.path(script_dir, ".."), mustWork = FALSE)
project_root <- normalizePath(file.path(output_root, ".."))
data_dir <- file.path(output_root, "data")
figure_dir <- file.path(output_root, "figures")
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

sequence_meta_file <- file.path(
  project_root,
  "6769_actin_seq_finding",
  "seq_meta_with_aa_seq.tsv"
)
hmm_file <- file.path(
  project_root,
  "6769_actin_seq_finding",
  "actin_all_arch_cleaned_fifth_cluster.tsv"
)
mag_meta_file <- file.path(
  project_root,
  "arch_mag_desc",
  "18261_arch_mag_meta.txt"
)

sequence_meta <- read.delim(
  sequence_meta_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)
hmm_data <- read.delim(
  hmm_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)
mag_meta <- read.delim(
  mag_meta_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

if (
  nrow(sequence_meta) != 6769 ||
  length(unique(sequence_meta$seq)) != 6769 ||
  nrow(hmm_data) != 6769 ||
  length(unique(hmm_data$target_name)) != 6769
) {
  stop("The final sequence or HMM table does not contain 6,769 unique IDs.")
}
if (!setequal(sequence_meta$seq, hmm_data$target_name)) {
  stop("Sequence IDs differ between the final metadata and HMM tables.")
}

physicochemical_cols <- c("mw", "pi", "gravy", "aromaticity", "length")
hmm_score_cols <- c(
  "Actin", "MreB_Mbl", "Salactin", "Volactin", "FtsA",
  "MreB-like_C", "ALP_N", "HSP70", "EutA"
)
hmm_marker_cols <- c(
  "PF00022", "PF06723", "PF14450",
  "PF21522", "PTHR11937", "PTHR32432"
)

hmm_keep <- hmm_data[
  ,
  c("target_name", physicochemical_cols, hmm_score_cols, hmm_marker_cols),
  drop = FALSE
]

sequence_data <- merge(
  sequence_meta,
  hmm_keep,
  by.x = "seq",
  by.y = "target_name",
  all.x = TRUE,
  sort = FALSE
)

if (anyNA(sequence_data[physicochemical_cols])) {
  stop("Missing physicochemical values after joining sequence and HMM data.")
}

family_order_full <- c(
  "canonical Actin-like",
  "Crenactin-like / archaeal actin",
  "Volactin",
  "Salactin",
  "MreB/Mbl-like",
  "MreB-like_C/ALP_N-related",
  "FtsA/PilM-like"
)
family_labels <- c(
  "canonical Actin-like" = "cALPs",
  "Crenactin-like / archaeal actin" = "dALPs",
  "Volactin" = "Volactin-like",
  "Salactin" = "Salactin-like",
  "MreB/Mbl-like" = "MreB/Mbl-profile",
  "MreB-like_C/ALP_N-related" = "MreB_C/ALP_N-profile",
  "FtsA/PilM-like" = "FtsA/PilM-profile"
)
family_order_display <- unname(family_labels[family_order_full])
family_palette <- c(
  "cALPs" = "#4C78A8",
  "dALPs" = "#4F9B8F",
  "Volactin-like" = "#E18D4F",
  "Salactin-like" = "#D6A64A",
  "MreB/Mbl-profile" = "#8B6FA8",
  "MreB_C/ALP_N-profile" = "#C77DA8",
  "FtsA/PilM-profile" = "#777777"
)

sequence_data$family_display <- unname(
  family_labels[sequence_data$actin_family_class]
)
if (anyNA(sequence_data$family_display)) {
  stop("Unrecognized actin family label.")
}
sequence_data$family_display <- factor(
  sequence_data$family_display,
  levels = rev(family_order_display)
)

# Reconstruct the same final MAG quality set used in the sequence search.
mag_meta$mag_id <- as.character(mag_meta$user_genome)
mag_meta$gunc_pass <- (
  tolower(trimws(as.character(mag_meta$pass.GUNC))) == "true"
)
mag_meta$quality_label <- trimws(as.character(mag_meta$quality_checkm2))
qc_mag <- mag_meta[
  mag_meta$gunc_pass & mag_meta$quality_label %in% c("HQ", "MQ"),
  ,
  drop = FALSE
]
if (nrow(qc_mag) != 15914) {
  stop("Expected 15,914 GUNC-pass HQ/MQ MAGs.")
}

positive_mag_ids <- unique(as.character(sequence_data$mag_id))
if (!all(positive_mag_ids %in% qc_mag$mag_id)) {
  stop("Some actin-positive MAG IDs are absent from the quality-controlled MAG set.")
}

tax_cols <- c("p", "c", "o", "f", "g", "s")
for (column in tax_cols) {
  qc_mag[[column]] <- trimws(as.character(qc_mag[[column]]))
  qc_mag[[column]][is.na(qc_mag[[column]])] <- ""
  sequence_data[[column]] <- trimws(as.character(sequence_data[[column]]))
  sequence_data[[column]][is.na(sequence_data[[column]])] <- ""
}

qc_mag$actin_positive <- qc_mag$mag_id %in% positive_mag_ids
qc_mag$species_assigned <- nzchar(qc_mag$s)
qc_mag$species_key <- apply(
  qc_mag[tax_cols],
  1,
  paste,
  collapse = "|"
)
qc_mag$species_key[!qc_mag$species_assigned] <- ""

# Add authoritative MAG taxonomy to each sequence for family-specific prevalence.
sequence_tax <- merge(
  sequence_data[, c("seq", "mag_id", "actin_family_class", "family_display")],
  qc_mag[, c("mag_id", tax_cols, "species_assigned", "species_key")],
  by = "mag_id",
  all.x = TRUE,
  sort = FALSE
)
if (anyNA(sequence_tax$p)) {
  stop("Taxonomy join failed for one or more actin-positive MAGs.")
}

fmt_int <- function(x) {
  format(x, big.mark = ",", scientific = FALSE, trim = TRUE)
}
fmt_pct <- function(x, digits = 1) {
  paste0(round(100 * x, digits), "%")
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size),
      axis.text = element_text(size = base_size - 0.4, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.text = element_text(size = base_size, face = "bold"),
      plot.title = element_text(size = base_size + 0.7, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.tag = element_text(size = 8, face = "bold"),
      plot.caption = element_text(
        size = base_size - 1.0,
        colour = "#4D4D4D",
        hjust = 0
      ),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 300) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  grDevices::cairo_pdf(
    paste0(stem, ".pdf"),
    width = width_in,
    height = height_in,
    family = "sans"
  )
  print(plot)
  grDevices::dev.off()

  grDevices::png(
    paste0(stem, "_preview.png"),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    type = "cairo",
    bg = "white"
  )
  print(plot)
  grDevices::dev.off()
}

# -------------------------------------------------------------------------
# Source data: joined sequence-level table and family summaries
# -------------------------------------------------------------------------

sequence_output_cols <- c(
  "seq", "mag_id", "actin_family_class", tax_cols,
  "quality_checkm2", "aa_len", physicochemical_cols,
  hmm_score_cols, hmm_marker_cols
)
write.table(
  sequence_data[, sequence_output_cols],
  file.path(data_dir, "sequence_level_6769_plot_data.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE,
  na = ""
)

family_counts <- as.data.frame(table(sequence_data$actin_family_class))
names(family_counts) <- c("actin_family_class", "sequence_count")
family_counts$actin_family_class <- as.character(
  family_counts$actin_family_class
)
family_counts <- family_counts[
  match(family_order_full, family_counts$actin_family_class),
]
family_counts$family_display <- unname(
  family_labels[family_counts$actin_family_class]
)

family_axis_labels <- setNames(
  paste0(
    family_counts$family_display,
    " (n=",
    fmt_int(family_counts$sequence_count),
    ")"
  ),
  family_counts$family_display
)

summarize_metric <- function(metric, label) {
  do.call(
    rbind,
    lapply(family_order_full, function(family_name) {
      values <- sequence_data[
        sequence_data$actin_family_class == family_name,
        metric
      ]
      data.frame(
        actin_family_class = family_name,
        family_display = unname(family_labels[family_name]),
        metric = label,
        n = length(values),
        q1 = unname(quantile(values, 0.25)),
        median = median(values),
        q3 = unname(quantile(values, 0.75)),
        mean = mean(values),
        sd = sd(values),
        min = min(values),
        max = max(values),
        stringsAsFactors = FALSE
      )
    })
  )
}

family_property_summary <- rbind(
  summarize_metric("length", "Protein length (aa)"),
  summarize_metric("pi", "Isoelectric point"),
  summarize_metric("gravy", "GRAVY"),
  summarize_metric("aromaticity", "Aromaticity")
)
write.csv(
  family_property_summary,
  file.path(data_dir, "family_physicochemical_summary.csv"),
  row.names = FALSE
)

# -------------------------------------------------------------------------
# Figure 1: physicochemical properties
# -------------------------------------------------------------------------

make_family_boxplot <- function(
    metric,
    title,
    x_label,
    show_y = TRUE,
    x_scale = NULL) {
  plot <- ggplot(
    sequence_data,
    aes(x = .data[[metric]], y = family_display, fill = family_display)
  ) +
    geom_violin(
      scale = "width",
      trim = FALSE,
      width = 0.76,
      alpha = 0.22,
      colour = NA
    ) +
    geom_boxplot(
      width = 0.18,
      linewidth = 0.42,
      outlier.shape = NA,
      alpha = 0.92,
      colour = "#333333"
    ) +
    stat_summary(
      fun = median,
      geom = "point",
      shape = 21,
      size = 1.25,
      stroke = 0.35,
      fill = "white",
      colour = "#222222"
    ) +
    scale_fill_manual(values = family_palette, drop = FALSE) +
    scale_y_discrete(
      labels = if (show_y) family_axis_labels else waiver(),
      drop = FALSE
    ) +
    labs(x = x_label, y = NULL, title = title) +
    theme_nature() +
    theme(
      legend.position = "none",
      axis.line.y = element_blank(),
      axis.ticks.y = element_blank(),
      panel.grid.major.x = element_line(
        colour = "#E6E8EB",
        linewidth = 0.28
      ),
      panel.grid.major.y = element_blank(),
      plot.title = element_text(
        size = 7.4,
        face = "bold",
        hjust = 0,
        margin = margin(b = 3)
      ),
      axis.text.y = if (show_y) {
        element_text(size = 6.2, colour = "#24292F")
      } else {
        element_blank()
      },
      plot.margin = margin(3, 4, 3, 4)
    )
  if (!is.null(x_scale)) {
    plot <- plot + x_scale
  }
  plot
}

p_length <- make_family_boxplot(
  "length",
  "Protein length",
  "Length (aa)",
  show_y = TRUE,
  x_scale = scale_x_continuous(breaks = c(250, 300, 350, 400, 450, 500, 550))
)
p_pi <- make_family_boxplot(
  "pi",
  "Isoelectric point",
  "Predicted pI",
  show_y = FALSE
)
p_gravy <- make_family_boxplot(
  "gravy",
  "Hydropathicity",
  "GRAVY score",
  show_y = TRUE
)
p_aromaticity <- make_family_boxplot(
  "aromaticity",
  "Aromaticity",
  "Aromaticity fraction",
  show_y = FALSE,
  x_scale = scale_x_continuous(labels = label_number(accuracy = 0.01))
)

figure_properties <- (p_length | p_pi) / (p_gravy | p_aromaticity) +
  plot_annotation(
    tag_levels = "a"
  )

save_figure(
  figure_properties,
  file.path(figure_dir, "figure_1_family_physicochemical_properties"),
  width_mm = 183,
  height_mm = 126
)

if (identical(Sys.getenv("ACTIN_SEQ_EXPORT_MODE"), "properties_only")) {
  quit(save = "no", status = 0)
}

# -------------------------------------------------------------------------
# Figure 2: HMM score signatures and marker prevalence
# -------------------------------------------------------------------------

hmm_score_labels <- c(
  "Actin" = "Actin",
  "MreB_Mbl" = "MreB/Mbl",
  "Salactin" = "Salactin",
  "Volactin" = "Volactin",
  "FtsA" = "FtsA",
  "MreB-like_C" = "MreB-like_C",
  "ALP_N" = "ALP_N",
  "HSP70" = "HSP70",
  "EutA" = "EutA"
)

hmm_signature_data <- do.call(
  rbind,
  lapply(family_order_full, function(family_name) {
    family_subset <- sequence_data[
      sequence_data$actin_family_class == family_name,
      ,
      drop = FALSE
    ]
    do.call(
      rbind,
      lapply(hmm_score_cols, function(hmm_name) {
        values <- as.numeric(family_subset[[hmm_name]])
        positive_values <- values[values > 0]
        data.frame(
          actin_family_class = family_name,
          family_display = unname(family_labels[family_name]),
          hmm_profile = hmm_name,
          hmm_label = unname(hmm_score_labels[hmm_name]),
          n = length(values),
          positive_count = sum(values > 0),
          positive_fraction = mean(values > 0),
          median_positive_score = if (length(positive_values) > 0) {
            median(positive_values)
          } else {
            0
          },
          stringsAsFactors = FALSE
        )
      })
    )
  })
)
hmm_signature_data$family_display <- factor(
  hmm_signature_data$family_display,
  levels = rev(family_order_display)
)
hmm_signature_data$hmm_label <- factor(
  hmm_signature_data$hmm_label,
  levels = unname(hmm_score_labels[hmm_score_cols])
)
hmm_signature_data$log_median_positive_score <- log10(
  1 + hmm_signature_data$median_positive_score
)
write.csv(
  hmm_signature_data,
  file.path(data_dir, "hmm_score_signature_summary.csv"),
  row.names = FALSE
)

hmm_marker_data <- do.call(
  rbind,
  lapply(family_order_full, function(family_name) {
    family_subset <- sequence_data[
      sequence_data$actin_family_class == family_name,
      ,
      drop = FALSE
    ]
    do.call(
      rbind,
      lapply(hmm_marker_cols, function(marker_name) {
        values <- as.numeric(family_subset[[marker_name]])
        data.frame(
          actin_family_class = family_name,
          family_display = unname(family_labels[family_name]),
          marker = marker_name,
          n = length(values),
          positive_count = sum(values > 0),
          positive_fraction = mean(values > 0),
          stringsAsFactors = FALSE
        )
      })
    )
  })
)
hmm_marker_data$family_display <- factor(
  hmm_marker_data$family_display,
  levels = rev(family_order_display)
)
hmm_marker_data$marker <- factor(
  hmm_marker_data$marker,
  levels = hmm_marker_cols
)
hmm_marker_data$label <- ifelse(
  hmm_marker_data$positive_fraction >= 0.005,
  paste0(round(100 * hmm_marker_data$positive_fraction), "%"),
  ""
)
write.csv(
  hmm_marker_data,
  file.path(data_dir, "hmm_marker_prevalence_summary.csv"),
  row.names = FALSE
)

p_hmm_scores <- ggplot(
  hmm_signature_data,
  aes(
    x = hmm_label,
    y = family_display,
    size = positive_fraction,
    colour = log_median_positive_score
  )
) +
  geom_point(alpha = 0.92) +
  scale_size_continuous(
    name = "Sequences with hit",
    range = c(0.2, 7),
    limits = c(0, 1),
    breaks = c(0.25, 0.50, 0.75, 1),
    labels = label_percent(accuracy = 1)
  ) +
  scale_colour_gradientn(
    name = "Median positive score\n(log10[score + 1])",
    colours = c("#E8EEF3", "#7FA7C4", "#2F5D7C"),
    limits = c(0, max(hmm_signature_data$log_median_positive_score))
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "Major hmmscan score signatures",
    subtitle = "Point size denotes hit prevalence; colour denotes positive-hit strength"
  ) +
  theme_nature() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 35, hjust = 1),
    axis.text.y = element_text(size = 6.2),
    legend.position = "right"
  )

p_hmm_markers <- ggplot(
  hmm_marker_data,
  aes(x = marker, y = family_display, fill = positive_fraction)
) +
  geom_tile(colour = "white", linewidth = 0.45) +
  geom_text(
    aes(label = label),
    size = 2.0,
    family = "sans",
    colour = "#1F2937"
  ) +
  scale_fill_gradientn(
    name = "Marker-positive\nsequences",
    colours = c("#F7FBFF", "#9ECAE1", "#3182BD"),
    limits = c(0, 1),
    labels = label_percent(accuracy = 1)
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "HMM marker prevalence",
    subtitle = "Values are percentages within each actin-superfamily class"
  ) +
  theme_nature() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 35, hjust = 1),
    axis.text.y = element_text(size = 6.2),
    legend.position = "right"
  )

figure_hmm <- p_hmm_scores / p_hmm_markers +
  plot_layout(heights = c(1.08, 0.92)) +
  plot_annotation(tag_levels = "a")

save_figure(
  figure_hmm,
  file.path(figure_dir, "figure_2_hmm_signatures"),
  width_mm = 183,
  height_mm = 145
)

# -------------------------------------------------------------------------
# Phylum-level counts and prevalence, with species deduplicated by taxonomy
# -------------------------------------------------------------------------

phylum_order <- names(sort(table(qc_mag$p), decreasing = TRUE))
positive_phyla <- phylum_order[
  phylum_order %in% unique(sequence_data$p)
]

phylum_family_counts <- as.data.frame(
  table(sequence_data$p, sequence_data$actin_family_class),
  stringsAsFactors = FALSE
)
names(phylum_family_counts) <- c(
  "phylum", "actin_family_class", "sequence_count"
)
phylum_family_counts <- phylum_family_counts[
  phylum_family_counts$phylum %in% positive_phyla,
]
phylum_family_counts$family_display <- unname(
  family_labels[phylum_family_counts$actin_family_class]
)
phylum_family_counts$family_display <- factor(
  phylum_family_counts$family_display,
  levels = family_order_display
)
phylum_family_counts$phylum <- factor(
  phylum_family_counts$phylum,
  levels = rev(positive_phyla)
)
write.csv(
  phylum_family_counts,
  file.path(data_dir, "phylum_family_sequence_counts.csv"),
  row.names = FALSE
)

all_species_by_phylum <- qc_mag[
  qc_mag$species_assigned,
  c("p", "species_key"),
  drop = FALSE
] |>
  distinct() |>
  count(p, name = "all_species")

positive_species_by_phylum <- qc_mag[
  qc_mag$actin_positive & qc_mag$species_assigned,
  c("p", "species_key"),
  drop = FALSE
] |>
  distinct() |>
  count(p, name = "positive_species")

family_positive_species <- sequence_tax[
  sequence_tax$species_assigned,
  c("p", "actin_family_class", "family_display", "species_key"),
  drop = FALSE
] |>
  distinct() |>
  count(
    p,
    actin_family_class,
    family_display,
    name = "positive_species"
  )

phylum_family_species_prevalence <- merge(
  expand.grid(
    p = positive_phyla,
    actin_family_class = family_order_full,
    stringsAsFactors = FALSE
  ),
  family_positive_species,
  by = c("p", "actin_family_class"),
  all.x = TRUE,
  sort = FALSE
)
phylum_family_species_prevalence$positive_species[
  is.na(phylum_family_species_prevalence$positive_species)
] <- 0
phylum_family_species_prevalence$family_display <- unname(
  family_labels[phylum_family_species_prevalence$actin_family_class]
)
phylum_family_species_prevalence <- merge(
  phylum_family_species_prevalence,
  all_species_by_phylum,
  by = "p",
  all.x = TRUE,
  sort = FALSE
)
phylum_family_species_prevalence$species_positive_fraction <- (
  phylum_family_species_prevalence$positive_species /
  phylum_family_species_prevalence$all_species
)
phylum_family_species_prevalence$phylum <- factor(
  phylum_family_species_prevalence$p,
  levels = rev(positive_phyla)
)
phylum_family_species_prevalence$family_display <- factor(
  phylum_family_species_prevalence$family_display,
  levels = family_order_display
)
phylum_family_species_prevalence$label <- ifelse(
  phylum_family_species_prevalence$species_positive_fraction >= 0.005,
  paste0(
    round(
      100 * phylum_family_species_prevalence$species_positive_fraction,
      1
    )
  ),
  ""
)
write.csv(
  phylum_family_species_prevalence,
  file.path(data_dir, "phylum_family_species_prevalence.csv"),
  row.names = FALSE
)

p_phylum_counts <- ggplot(
  phylum_family_counts,
  aes(x = sequence_count, y = phylum, fill = family_display)
) +
  geom_col(width = 0.72) +
  scale_fill_manual(
    values = family_palette,
    drop = FALSE,
    name = "Actin-superfamily class"
  ) +
  scale_x_continuous(
    labels = label_comma(),
    expand = expansion(mult = c(0, 0.03))
  ) +
  labs(
    x = "Number of sequences",
    y = NULL,
    title = "Sequence composition across archaeal phyla",
    subtitle = "Only phyla containing at least one of the 6,769 sequences are shown"
  ) +
  theme_nature() +
  theme(
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.text.y = element_text(size = 5.9),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.key.width = grid::unit(3.5, "mm")
  ) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE))

p_family_species_heatmap <- ggplot(
  phylum_family_species_prevalence,
  aes(
    x = family_display,
    y = phylum,
    fill = species_positive_fraction
  )
) +
  geom_tile(colour = "white", linewidth = 0.45) +
  geom_text(
    aes(label = label),
    size = 1.45,
    family = "sans",
    colour = "#1F2937"
  ) +
  scale_fill_gradientn(
    name = "Positive species",
    colours = c("#F7FBFF", "#9ECAE1", "#3182BD"),
    limits = c(0, 1),
    labels = label_percent(accuracy = 1)
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "Family-specific species prevalence",
    subtitle = "Percentage of unique GTDB species positive for each family"
  ) +
  theme_nature() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 5.5),
    axis.text.y = element_blank(),
    legend.position = "right"
  )

figure_phylum_distribution <- p_phylum_counts | p_family_species_heatmap +
  plot_layout(widths = c(0.82, 1.18)) +
  plot_annotation(
    tag_levels = "a",
    caption = paste0(
      "Species prevalence uses unique full GTDB taxonomies; ",
      "multiple MAGs assigned to the same species are counted once."
    )
  )

save_figure(
  figure_phylum_distribution,
  file.path(figure_dir, "figure_3_phylum_family_distribution"),
  width_mm = 183,
  height_mm = 142
)

# Overall phylum prevalence across all quality-controlled MAGs and species.
all_mag_by_phylum <- qc_mag |>
  count(p, name = "all_mags")
positive_mag_by_phylum <- qc_mag |>
  filter(actin_positive) |>
  count(p, name = "positive_mags")

phylum_prevalence <- merge(
  data.frame(p = phylum_order, stringsAsFactors = FALSE),
  all_mag_by_phylum,
  by = "p",
  all.x = TRUE,
  sort = FALSE
)
phylum_prevalence <- merge(
  phylum_prevalence,
  positive_mag_by_phylum,
  by = "p",
  all.x = TRUE,
  sort = FALSE
)
phylum_prevalence <- merge(
  phylum_prevalence,
  all_species_by_phylum,
  by = "p",
  all.x = TRUE,
  sort = FALSE
)
phylum_prevalence <- merge(
  phylum_prevalence,
  positive_species_by_phylum,
  by = "p",
  all.x = TRUE,
  sort = FALSE
)
for (column in c("positive_mags", "positive_species")) {
  phylum_prevalence[[column]][is.na(phylum_prevalence[[column]])] <- 0
}
phylum_prevalence$mag_positive_fraction <- (
  phylum_prevalence$positive_mags / phylum_prevalence$all_mags
)
phylum_prevalence$species_positive_fraction <- (
  phylum_prevalence$positive_species / phylum_prevalence$all_species
)
phylum_prevalence$phylum <- factor(
  phylum_prevalence$p,
  levels = rev(phylum_order)
)
phylum_prevalence$mag_label <- paste0(
  fmt_int(phylum_prevalence$positive_mags),
  "/",
  fmt_int(phylum_prevalence$all_mags)
)
phylum_prevalence$species_label <- paste0(
  fmt_int(phylum_prevalence$positive_species),
  "/",
  fmt_int(phylum_prevalence$all_species)
)
write.csv(
  phylum_prevalence,
  file.path(data_dir, "phylum_mag_species_prevalence.csv"),
  row.names = FALSE
)

make_prevalence_plot <- function(
    value_column,
    label_column,
    title,
    subtitle,
    colour,
    show_y = TRUE) {
  ggplot(
    phylum_prevalence,
    aes(x = .data[[value_column]], y = phylum)
  ) +
    geom_segment(
      aes(
        x = 0,
        xend = .data[[value_column]],
        yend = phylum
      ),
      linewidth = 0.65,
      colour = colour,
      alpha = 0.75
    ) +
    geom_point(
      size = 2.2,
      shape = 21,
      fill = colour,
      colour = "white",
      stroke = 0.35
    ) +
    geom_text(
      aes(label = .data[[label_column]]),
      hjust = -0.20,
      size = 1.95,
      family = "sans"
    ) +
    scale_x_continuous(
      limits = c(0, 1.25),
      breaks = c(0, 0.25, 0.50, 0.75, 1),
      labels = label_percent(accuracy = 1),
      expand = expansion(mult = c(0, 0))
    ) +
    labs(
      x = "Positive fraction",
      y = NULL,
      title = title,
      subtitle = subtitle
    ) +
    theme_nature() +
    theme(
      axis.line.y = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = if (show_y) {
        element_text(size = 5.8)
      } else {
        element_blank()
      }
    )
}

p_mag_prevalence <- make_prevalence_plot(
  "mag_positive_fraction",
  "mag_label",
  "MAG-level prevalence",
  "Actin-positive MAGs / all quality-controlled MAGs",
  "#5B7FA3",
  show_y = TRUE
)
p_species_prevalence <- make_prevalence_plot(
  "species_positive_fraction",
  "species_label",
  "Species-level prevalence",
  "Positive unique GTDB species / all assigned species",
  "#4F9B8F",
  show_y = FALSE
)

figure_prevalence <- p_mag_prevalence | p_species_prevalence +
  plot_layout(widths = c(1, 1)) +
  plot_annotation(
    tag_levels = "a",
    caption = paste0(
      "Species-level prevalence excludes MAGs without a GTDB species assignment. ",
      "A species is positive if at least one MAG contains an actin-superfamily sequence."
    )
  )

save_figure(
  figure_prevalence,
  file.path(figure_dir, "figure_4_phylum_mag_species_prevalence"),
  width_mm = 183,
  height_mm = 150
)

# -------------------------------------------------------------------------
# Audit summary
# -------------------------------------------------------------------------

positive_mag_meta <- qc_mag[qc_mag$actin_positive, , drop = FALSE]
all_species_total <- length(unique(
  qc_mag$species_key[qc_mag$species_assigned]
))
positive_species_total <- length(unique(
  positive_mag_meta$species_key[positive_mag_meta$species_assigned]
))

summary_lines <- c(
  "Archaeal actin-superfamily visualization audit",
  paste0("Sequences: ", fmt_int(nrow(sequence_data))),
  paste0("Unique sequence IDs: ", fmt_int(length(unique(sequence_data$seq)))),
  paste0("Positive MAGs: ", fmt_int(length(positive_mag_ids))),
  paste0("All quality-controlled MAGs: ", fmt_int(nrow(qc_mag))),
  paste0(
    "MAG-level prevalence: ",
    fmt_pct(length(positive_mag_ids) / nrow(qc_mag))
  ),
  paste0(
    "Positive species: ",
    fmt_int(positive_species_total)
  ),
  paste0(
    "All assigned species: ",
    fmt_int(all_species_total)
  ),
  paste0(
    "Species-level prevalence: ",
    fmt_pct(positive_species_total / all_species_total)
  ),
  paste0(
    "Positive MAGs without species assignment: ",
    fmt_int(sum(!positive_mag_meta$species_assigned))
  ),
  "",
  "Family counts:",
  paste0(
    family_counts$actin_family_class,
    ": ",
    fmt_int(family_counts$sequence_count)
  ),
  "",
  "Species prevalence definition:",
  paste0(
    "A species is positive if at least one quality-controlled MAG assigned ",
    "to that full GTDB species taxonomy contains one or more of the 6,769 sequences."
  ),
  paste0(
    "Multiple MAGs assigned to the same species are counted once. ",
    "MAGs without species assignments are excluded from species-level fractions."
  )
)
writeLines(
  summary_lines,
  file.path(output_root, "analysis_summary.txt"),
  useBytes = TRUE
)

message(
  "Completed four figures for ",
  fmt_int(nrow(sequence_data)),
  " sequences from ",
  fmt_int(length(positive_mag_ids)),
  " MAGs; positive species ",
  fmt_int(positive_species_total),
  "/",
  fmt_int(all_species_total),
  "."
)
