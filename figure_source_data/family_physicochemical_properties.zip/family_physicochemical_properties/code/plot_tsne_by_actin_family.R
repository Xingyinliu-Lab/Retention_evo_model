#!/usr/bin/env Rscript

# Visualize the sequence-level t-SNE embedding by final actin-family class.
# Usage:
#   Rscript plot_tsne_by_actin_family.R
#   Rscript plot_tsne_by_actin_family.R path/to/actin_all_arch_cleaned_fifth_cluster.tsv

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  stop("Missing R package: ggplot2\nInstall with: install.packages('ggplot2')")
}

suppressPackageStartupMessages(library(ggplot2))

get_script_dir <- function() {
  full_args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", full_args, value = TRUE)
  if (length(file_arg) == 0) return(getwd())
  dirname(normalizePath(sub("^--file=", "", file_arg[1]), winslash = "/"))
}

args <- commandArgs(trailingOnly = TRUE)
script_dir <- get_script_dir()
output_dir <- dirname(script_dir)
workspace_dir <- dirname(output_dir)

input_file <- if (length(args) >= 1) {
  args[1]
} else {
  file.path(
    workspace_dir,
    "6769_actin_seq_finding",
    "actin_all_arch_cleaned_fifth_cluster.tsv"
  )
}

figure_dir <- file.path(output_dir, "figures")
data_dir <- file.path(output_dir, "data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

required_cols <- c("TSNE-1", "TSNE-2", "actin_family_class")
tsne_data <- read.delim(
  input_file,
  sep = "\t",
  header = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  quote = "",
  comment.char = ""
)

missing_cols <- setdiff(required_cols, names(tsne_data))
if (length(missing_cols) > 0) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}

tsne_data <- tsne_data[, required_cols]
names(tsne_data) <- c("tsne_1", "tsne_2", "actin_family_class")
tsne_data$tsne_1 <- as.numeric(tsne_data$tsne_1)
tsne_data$tsne_2 <- as.numeric(tsne_data$tsne_2)
tsne_data$actin_family_class <- trimws(tsne_data$actin_family_class)

if (anyNA(tsne_data[, c("tsne_1", "tsne_2")])) {
  stop("TSNE-1 or TSNE-2 contains missing or non-numeric values.")
}
if (any(!nzchar(tsne_data$actin_family_class))) {
  stop("actin_family_class contains missing or empty values.")
}

family_order_full <- c(
  "canonical Actin-like",
  "Crenactin-like / archaeal actin",
  "Volactin",
  "Salactin",
  "MreB/Mbl-like",
  "MreB-like_C/ALP_N-related",
  "FtsA/PilM-like"
)

family_labels <- c(
  "canonical Actin-like" = "cALPs",
  "Crenactin-like / archaeal actin" = "dALPs",
  "Volactin" = "Volactin-like",
  "Salactin" = "Salactin-like",
  "MreB/Mbl-like" = "MreB/Mbl-profile",
  "MreB-like_C/ALP_N-related" = "MreB_C/ALP_N-profile",
  "FtsA/PilM-like" = "FtsA/PilM-profile"
)

family_palette <- c(
  "cALPs" = "#4C78A8",
  "dALPs" = "#4F9B8F",
  "Volactin-like" = "#E18D4F",
  "Salactin-like" = "#D6A64A",
  "MreB/Mbl-profile" = "#8B6FA8",
  "MreB_C/ALP_N-profile" = "#C77DA8",
  "FtsA/PilM-profile" = "#777777"
)

unknown_families <- setdiff(
  unique(tsne_data$actin_family_class),
  family_order_full
)
if (length(unknown_families) > 0) {
  stop(
    "Unrecognized actin_family_class values: ",
    paste(unknown_families, collapse = ", ")
  )
}

tsne_data$family_display <- unname(
  family_labels[tsne_data$actin_family_class]
)
display_order <- c(
  "cALPs",
  "dALPs",
  "MreB/Mbl-profile",
  "MreB_C/ALP_N-profile",
  "FtsA/PilM-profile",
  "Salactin-like",
  "Volactin-like"
)
tsne_data$family_display <- factor(
  tsne_data$family_display,
  levels = display_order
)

family_counts <- as.data.frame(table(tsne_data$family_display))
names(family_counts) <- c("family_display", "n_seq")
family_counts$family_display <- as.character(family_counts$family_display)

legend_labels <- setNames(
  paste0(
    family_counts$family_display,
    " (n=",
    format(
      family_counts$n_seq,
      big.mark = ",",
      scientific = FALSE,
      trim = TRUE
    ),
    ")"
  ),
  family_counts$family_display
)

# Draw abundant classes first and rare classes last to reduce occlusion.
count_lookup <- setNames(family_counts$n_seq, family_counts$family_display)
tsne_data$n_family <- unname(count_lookup[as.character(tsne_data$family_display)])
tsne_data <- tsne_data[
  order(-tsne_data$n_family, tsne_data$family_display),
  ,
  drop = FALSE
]

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.32, colour = "#293241"),
      axis.ticks = element_line(linewidth = 0.32, colour = "#293241"),
      axis.ticks.length = grid::unit(1.1, "mm"),
      axis.title = element_text(size = base_size, colour = "#293241"),
      axis.text = element_text(size = base_size - 0.5, colour = "#293241"),
      legend.title = element_text(size = base_size - 0.1, face = "bold", colour = "#172033"),
      legend.text = element_text(size = base_size - 0.7, colour = "#293241"),
      legend.key.height = grid::unit(3.0, "mm"),
      legend.spacing.y = grid::unit(0.15, "mm"),
      plot.title = element_text(size = base_size + 0.8, face = "bold", colour = "#172033"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#687386"),
      panel.grid = element_blank(),
      plot.margin = margin(4, 4, 4, 4)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 300) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  grDevices::cairo_pdf(
    paste0(stem, ".pdf"),
    width = width_in,
    height = height_in,
    family = "Arial"
  )
  print(plot)
  grDevices::dev.off()

  grDevices::png(
    paste0(stem, "_preview.png"),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    type = "cairo",
    bg = "white"
  )
  print(plot)
  grDevices::dev.off()
}

p_tsne <- ggplot(
  tsne_data,
  aes(x = tsne_1, y = tsne_2, colour = family_display)
) +
  geom_point(size = 0.65, alpha = 0.68, stroke = 0) +
  scale_colour_manual(
    values = family_palette,
    breaks = display_order,
    labels = legend_labels[display_order],
    drop = FALSE
  ) +
  coord_equal() +
  labs(
    x = "t-SNE 1",
    y = "t-SNE 2",
    colour = "Actin family",
    title = "Sequence-level t-SNE embedding of archaeal actin-superfamily proteins",
    subtitle = paste0(
      "Colours indicate final actin-family classifications (n = ",
      format(nrow(tsne_data), big.mark = ",", scientific = FALSE),
      ")"
    )
  ) +
  guides(
    colour = guide_legend(
      override.aes = list(size = 2.4, alpha = 1),
      keyheight = grid::unit(3.5, "mm")
    )
  ) +
  theme_nature() +
  theme(
    legend.position = "right",
    legend.box.just = "top",
    aspect.ratio = 1
  )

p_tsne_ellipse <- ggplot(
  tsne_data,
  aes(x = tsne_1, y = tsne_2, colour = family_display)
) +
  stat_ellipse(
    type = "norm",
    level = 0.95,
    linewidth = 0.42,
    linetype = "22",
    alpha = 0.72,
    show.legend = FALSE
  ) +
  geom_point(size = 0.48, alpha = 0.52, stroke = 0) +
  scale_colour_manual(
    values = family_palette,
    breaks = display_order,
    labels = legend_labels[display_order],
    drop = FALSE
  ) +
  coord_equal() +
  labs(
    x = "t-SNE 1",
    y = "t-SNE 2",
    colour = "Profile class",
    title = "Sequence-feature embedding by profile class",
    subtitle = paste0(
      format(nrow(tsne_data), big.mark = ",", scientific = FALSE),
      " proteins; dashed outlines show 95% normal-data ellipses"
    )
  ) +
  guides(
    colour = guide_legend(
      override.aes = list(size = 2.2, alpha = 1),
      keyheight = grid::unit(3.0, "mm")
    )
  ) +
  theme_nature(base_size = 6.8) +
  theme(
    legend.position = "right",
    legend.box.just = "top",
    aspect.ratio = 1
  )

write.table(
  tsne_data[, c("tsne_1", "tsne_2", "actin_family_class")],
  file.path(data_dir, "tsne_actin_family_plot_data.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE,
  na = ""
)

write.table(
  family_counts,
  file.path(data_dir, "tsne_actin_family_counts.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE,
  na = ""
)

figure_stem <- file.path(
  figure_dir,
  "figure_5_tsne_embedding_by_actin_family"
)
export_mode <- Sys.getenv("ACTIN_TSNE_EXPORT_MODE", unset = "all")
if (export_mode != "ellipse_only") {
  save_figure(
    p_tsne,
    figure_stem,
    width_mm = 165,
    height_mm = 112,
    dpi = 300
  )
}

ellipse_figure_stem <- file.path(
  figure_dir,
  "figure_5b_tsne_embedding_by_actin_family_with_ellipses"
)
save_figure(
  p_tsne_ellipse,
  ellipse_figure_stem,
  width_mm = 165,
  height_mm = 112,
  dpi = 300
)

if (export_mode != "ellipse_only") {
  message("Saved: ", normalizePath(paste0(figure_stem, ".pdf"), winslash = "/"))
  message("Saved: ", normalizePath(paste0(figure_stem, "_preview.png"), winslash = "/"))
}
message("Saved: ", normalizePath(paste0(ellipse_figure_stem, ".pdf"), winslash = "/"))
message("Saved: ", normalizePath(paste0(ellipse_figure_stem, "_preview.png"), winslash = "/"))
