# 1_family_physicochemical_properties

- Manuscript panel: Supp.Fig.2B-E
- Source figure basename: figure_1_family_physicochemical_properties
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 15 directly referenced or locally packaged source-data file(s)
