#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ape)
  library(ggplot2)
  library(ggtree)
  library(patchwork)
  library(dplyr)
  library(tidyr)
  library(ggrepel)
})

options(stringsAsFactors = FALSE)

project_dir <- "asgrad_species_rep_mag_tree_gappyout"
tree_file <- file.path(project_dir, "trimmed_asgard_species_rep_mag_euk_mix_gappyout.treefile")
iqtree_file <- file.path(project_dir, "trimmed_asgard_species_rep_mag_euk_mix_gappyout.iqtree")
seq_meta_file <- file.path(project_dir, "asgard_species_rep_mag_actin_sequences.tsv")
tail_meta_file <- file.path("actin_tail_analysis", "seq_meta_with_tail_hmm386_410_euk_pssm_score.tsv")
tail_score_file <- file.path(
  "actin_tail_analysis",
  "tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv"
)
old_tree_file <- file.path(
  "genus_tree_LG_R9_gappyout",
  "trimmed_genus_resample_sequences_euk_bac_LG_R9_gappyout_thorough.treefile"
)
old_distance_file <- file.path(
  "genus_tree_LG_R9_gappyout",
  "plot_source_data",
  "asgard_sequence_mean_distance_to_eukaryotic_actin.tsv"
)

out_data <- file.path(project_dir, "plot_source_data")
out_fig <- file.path(project_dir, "figures")
dir.create(out_data, recursive = TRUE, showWarnings = FALSE)
dir.create(out_fig, recursive = TRUE, showWarnings = FALSE)

required <- c("ape", "ggplot2", "ggtree", "patchwork", "dplyr", "tidyr", "ggrepel")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Missing R packages: ", paste(missing, collapse = ", "))

theme_pub <- function(base_size = 7, base_family = "Arial") {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.text = element_text(colour = "#222222"),
      axis.title = element_text(size = base_size),
      strip.text = element_text(size = base_size, face = "bold"),
      legend.title = element_text(size = base_size - 0.1, face = "bold"),
      legend.text = element_text(size = base_size - 0.6),
      plot.title = element_text(size = base_size + 0.8, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.3, colour = "#4A4A4A"),
      plot.caption = element_text(size = base_size - 1.0, colour = "#555555", hjust = 0),
      panel.grid = element_blank()
    )
}
theme_set(theme_pub())

save_plot <- function(plot, stem, width_mm = 183, height_mm = 130, dpi = 450) {
  pdf_file <- file.path(out_fig, paste0(stem, ".pdf"))
  png_file <- file.path(out_fig, paste0(stem, "_preview.png"))
  ggsave(pdf_file, plot, width = width_mm, height = height_mm, units = "mm", device = cairo_pdf)
  ggsave(png_file, plot, width = width_mm, height = height_mm, units = "mm", dpi = dpi, bg = "white")
}

write_tsv <- function(x, name) {
  write.table(
    x, file.path(out_data, name), sep = "\t", quote = FALSE,
    row.names = FALSE, na = "NA"
  )
}

parse_support <- function(labels) {
  parts <- strsplit(ifelse(is.na(labels), "", labels), "/", fixed = TRUE)
  data.frame(
    SH_aLRT = vapply(parts, function(x) suppressWarnings(as.numeric(x[1])), numeric(1)),
    UFBoot = vapply(
      parts,
      function(x) if (length(x) > 1) suppressWarnings(as.numeric(x[2])) else NA_real_,
      numeric(1)
    )
  )
}

first_nonempty <- function(x) {
  x <- unique(x[!is.na(x) & x != ""])
  if (length(x)) x[1] else NA_character_
}

standardize_tail_class <- function(tail_class, tail_len, score) {
  out <- rep("short_or_missing", length(tail_len))
  enough <- is.finite(tail_len) & tail_len >= 10 & is.finite(score)
  out[enough & score >= -3.0] <- "high_euk_like"
  out[enough & score >= -3.8 & score < -3.0] <- "intermediate"
  out[enough & score < -3.8] <- "low_divergent"
  from_table <- !is.na(tail_class) & tail_class != ""
  out[from_table] <- tail_class[from_table]
  out[is.na(out) | out == ""] <- "short_or_missing"
  out
}

tree <- read.tree(tree_file)
tree_display <- tree
tree_display$edge.length <- sqrt(pmax(tree_display$edge.length, 0))

asgard_meta <- read.delim(seq_meta_file, check.names = FALSE, na.strings = c("", "NA"))
tail_meta <- read.delim(tail_meta_file, check.names = FALSE, na.strings = c("", "NA"))
tail_score <- read.delim(tail_score_file, check.names = FALSE, na.strings = c("", "NA"))

required_asgard <- c("seq", "mag_id", "actin_family_class", "s", "g", "f", "o", "c", "p", "d", "quality_checkm2")
if (length(setdiff(required_asgard, names(asgard_meta)))) {
  stop("Missing columns in species-representative metadata: ",
       paste(setdiff(required_asgard, names(asgard_meta)), collapse = ", "))
}
if (!all(c("seq", "tail_nogap_len", "tail_euk_pssm_score") %in% names(tail_meta))) {
  stop("Tail metadata lacks required seq/tail_nogap_len/tail_euk_pssm_score columns.")
}
if (!all(c("seq", "tail_euk_pssm_score_gap_penalty") %in% names(tail_score))) {
  stop("Tail score table lacks seq/tail_euk_pssm_score_gap_penalty.")
}

tail_score_small <- tail_score[, intersect(
  c("seq", "tail_class", "compare_group", "tail_euk_pssm_score_gap_penalty"),
  names(tail_score)
), drop = FALSE]
tail_join <- merge(
  tail_meta[, intersect(
    c("seq", "tail_nogap_len", "tail_aligned_len", "n_gap", "tail_euk_pssm_score"),
    names(tail_meta)
  ), drop = FALSE],
  tail_score_small,
  by = "seq", all.x = TRUE, sort = FALSE
)
names(tail_join)[names(tail_join) == "tail_euk_pssm_score"] <- "tail_score_no_gap"
names(tail_join)[names(tail_join) == "tail_euk_pssm_score_gap_penalty"] <- "tail_score_gap_penalty"

meta <- merge(asgard_meta, tail_join, by = "seq", all.x = TRUE, sort = FALSE)
meta$tail_score_gap_penalty <- suppressWarnings(as.numeric(meta$tail_score_gap_penalty))
meta$tail_score_no_gap <- suppressWarnings(as.numeric(meta$tail_score_no_gap))
meta$tail_nogap_len <- suppressWarnings(as.numeric(meta$tail_nogap_len))
meta$tail_class <- standardize_tail_class(
  if ("tail_class" %in% names(meta)) meta$tail_class else NA_character_,
  meta$tail_nogap_len,
  meta$tail_score_gap_penalty
)
meta$domain <- "Archaea"

euk_labels <- setdiff(tree$tip.label, meta$seq)
euk_meta <- data.frame(
  seq = euk_labels,
  mag_id = NA_character_,
  actin_family_class = "Eukaryota_actin",
  s = sub(".*\\|", "", euk_labels),
  g = NA_character_, f = NA_character_, o = NA_character_, c = "Eukaryota",
  p = "Eukaryota", d = "Eukaryota", quality_checkm2 = NA_character_,
  tail_nogap_len = NA_real_, tail_aligned_len = NA_real_, n_gap = NA_real_,
  tail_score_no_gap = NA_real_, tail_class = "Eukaryotic reference",
  compare_group = "Eukaryotic reference", tail_score_gap_penalty = NA_real_,
  domain = "Eukaryota",
  stringsAsFactors = FALSE
)

plot_meta <- bind_rows(
  meta[, intersect(names(euk_meta), names(meta)), drop = FALSE],
  euk_meta
)
plot_meta <- plot_meta[match(tree$tip.label, plot_meta$seq), , drop = FALSE]
if (anyNA(plot_meta$seq)) {
  missing_tips <- tree$tip.label[is.na(plot_meta$seq)]
  stop("Tree tips absent from metadata: ", paste(head(missing_tips, 20), collapse = ", "))
}

plot_meta$asgard_class <- ifelse(plot_meta$domain == "Eukaryota", "Eukaryotic reference", plot_meta$c)
plot_meta$tail_class_plot <- ifelse(
  plot_meta$domain == "Eukaryota", "Eukaryotic reference",
  ifelse(plot_meta$actin_family_class == "canonical Actin-like", plot_meta$tail_class, "non-canonical")
)
plot_meta$family_plot <- dplyr::case_when(
  plot_meta$actin_family_class == "canonical Actin-like" ~ "Canonical Actin-like",
  plot_meta$actin_family_class == "Crenactin-like / archaeal actin" ~ "Crenactin-like",
  plot_meta$actin_family_class == "MreB-like_C/ALP_N-related" ~ "MreB-C/ALP-N",
  plot_meta$actin_family_class == "Eukaryota_actin" ~ "Eukaryotic actin",
  TRUE ~ plot_meta$actin_family_class
)
plot_meta$domain_plot <- factor(plot_meta$domain, levels = c("Archaea", "Eukaryota"))

class_order <- c(
  "Lokiarchaeia", "Heimdallarchaeia", "Thorarchaeia", "Hermodarchaeia",
  "Njordarchaeia", "Jordiarchaeia", "Asgardarchaeia", "Baldrarchaeia",
  "Odinarchaeia", "Wukongarchaeia", "Atabeyarchaeia", "Sifarchaeia",
  "Eukaryotic reference"
)
class_order <- class_order[class_order %in% unique(plot_meta$asgard_class)]
plot_meta$asgard_class <- factor(plot_meta$asgard_class, levels = class_order)

class_palette <- c(
  "Lokiarchaeia" = "#33658A",
  "Heimdallarchaeia" = "#4F9B8F",
  "Thorarchaeia" = "#E08D3C",
  "Hermodarchaeia" = "#7B61A8",
  "Njordarchaeia" = "#C75C64",
  "Jordiarchaeia" = "#8C8C3E",
  "Asgardarchaeia" = "#5A7D9A",
  "Baldrarchaeia" = "#D6A64A",
  "Odinarchaeia" = "#9C6B4E",
  "Wukongarchaeia" = "#8E6A9E",
  "Atabeyarchaeia" = "#5C8F45",
  "Sifarchaeia" = "#6B6B6B",
  "Eukaryotic reference" = "#D73027"
)
tail_order <- c(
  "high_euk_like", "intermediate", "low_divergent", "short_or_missing",
  "non-canonical", "Eukaryotic reference"
)
tail_order <- tail_order[tail_order %in% unique(plot_meta$tail_class_plot)]
plot_meta$tail_class_plot <- factor(plot_meta$tail_class_plot, levels = tail_order)
tail_palette <- c(
  "high_euk_like" = "#D24B40",
  "intermediate" = "#E28E2C",
  "low_divergent" = "#7B61A8",
  "short_or_missing" = "#B8B8B8",
  "non-canonical" = "#5E6A71",
  "Eukaryotic reference" = "#222222"
)
family_palette <- c(
  "Canonical Actin-like" = "#4C78A8",
  "Crenactin-like" = "#4F9B8F",
  "MreB/Mbl-like" = "#8B6FA8",
  "MreB-C/ALP-N" = "#C77DA8",
  "FtsA/PilM-like" = "#777777",
  "Volactin" = "#E18D4F",
  "Salactin" = "#D6A64A",
  "Eukaryotic actin" = "#D73027"
)
family_order <- c(
  "Canonical Actin-like", "Crenactin-like", "MreB/Mbl-like",
  "MreB-C/ALP-N", "FtsA/PilM-like", "Volactin", "Salactin",
  "Eukaryotic actin"
)
family_order <- family_order[family_order %in% unique(plot_meta$family_plot)]
plot_meta$family_plot <- factor(plot_meta$family_plot, levels = family_order)

support <- parse_support(tree$node.label)
support$node <- seq.int(Ntip(tree) + 1L, Ntip(tree) + tree$Nnode)
support$high_support <- with(support, is.finite(SH_aLRT) & is.finite(UFBoot) & SH_aLRT >= 80 & UFBoot >= 95)

attach_tip_data <- function(p, colour_col) {
  idx <- match(p$data$label, plot_meta$seq)
  p$data$colour_group <- plot_meta[[colour_col]][idx]
  p$data$domain_plot <- plot_meta$domain_plot[idx]
  p$data$family_plot <- plot_meta$family_plot[idx]
  sidx <- match(p$data$node, support$node)
  p$data$high_support <- support$high_support[sidx]
  p$data$high_support[is.na(p$data$high_support)] <- FALSE
  p
}

make_tree_plot <- function(colour_col, palette, breaks, legend_title, title, subtitle) {
  p <- ggtree(tree_display, layout = "circular")
  for (i in seq_along(p$layers)) {
    p$layers[[i]]$aes_params$linewidth <- 0.15
    p$layers[[i]]$aes_params$colour <- "#777777"
  }
  p <- attach_tip_data(p, colour_col)
  p +
    geom_point2(
      aes(subset = isTip, colour = colour_group),
      shape = 16, size = 1.15, alpha = 0.9, stroke = 0.18
    ) +
    scale_colour_manual(values = palette, breaks = breaks, drop = FALSE, name = legend_title) +
    labs(
      title = title,
      subtitle = subtitle,
      caption = "Circular view uses square-root-transformed branch lengths for readability."
    ) +
    theme(
      plot.title = element_text(size = 8, face = "bold"),
      plot.subtitle = element_text(size = 6.5, colour = "#4A4A4A"),
      plot.caption = element_text(size = 5.5, colour = "#555555", hjust = 0),
      legend.position = "right",
      legend.title = element_text(size = 6.3, face = "bold"),
      legend.text = element_text(size = 5.7),
      legend.key.height = grid::unit(3.0, "mm"),
      plot.margin = margin(4, 8, 4, 4)
    ) +
    guides(
      colour = guide_legend(order = 1, override.aes = list(size = 2.4, alpha = 1))
    )
}

p_class_tree <- make_tree_plot(
  "asgard_class", class_palette, class_order, "Class",
  "Species-representative MAG actin tree: Asgard class view",
  "One actin-positive MAG per GTDB species; all actin copies from the selected MAGs are retained."
)
save_plot(p_class_tree, "figure_1_species_rep_tree_by_asgard_class", 183, 128)

p_tail_tree <- make_tree_plot(
  "tail_class_plot", tail_palette, tail_order, "Tail category",
  "Species-representative MAG actin tree: tail category view",
  "Tail category is assigned only to canonical Actin-like Asgard sequences; other archaeal actin families are grouped as non-canonical."
)
save_plot(p_tail_tree, "figure_2_species_rep_tree_by_tail_category", 183, 128)

p_family_tree <- make_tree_plot(
  "family_plot", family_palette, family_order, "Actin family",
  "Species-representative MAG actin tree: actin-family view",
  "Tips are coloured by actin-family assignment; eukaryotic references are retained as the outgroup-like reference set."
)
save_plot(p_family_tree, "figure_3_species_rep_tree_by_actin_family", 183, 128)

patristic <- cophenetic.phylo(tree)
asgard_labels <- plot_meta$seq[plot_meta$domain == "Archaea"]
euk_labels <- plot_meta$seq[plot_meta$domain == "Eukaryota"]
if (!length(asgard_labels) || !length(euk_labels)) stop("Could not identify Asgard or eukaryotic tips.")
asgard_to_euk <- patristic[asgard_labels, euk_labels, drop = FALSE]
nearest_index <- max.col(-asgard_to_euk, ties.method = "first")

distance_data <- data.frame(
  seq = rownames(asgard_to_euk),
  n_eukaryotic_reference_tips = ncol(asgard_to_euk),
  mean_distance_to_eukaryotic_actin = rowMeans(asgard_to_euk),
  median_distance_to_eukaryotic_actin = apply(asgard_to_euk, 1, median),
  min_distance_to_eukaryotic_actin = apply(asgard_to_euk, 1, min),
  max_distance_to_eukaryotic_actin = apply(asgard_to_euk, 1, max),
  nearest_eukaryotic_actin = colnames(asgard_to_euk)[nearest_index],
  stringsAsFactors = FALSE
)
distance_data <- merge(
  distance_data,
  meta[, c(
    "seq", "mag_id", "actin_family_class", "s", "g", "f", "o", "c", "p",
    "quality_checkm2", "tail_class", "compare_group", "tail_nogap_len",
    "tail_score_gap_penalty", "tail_score_no_gap"
  )],
  by = "seq", all.x = TRUE, sort = FALSE
)
distance_data$tail_class_plot <- ifelse(
  distance_data$actin_family_class == "canonical Actin-like",
  distance_data$tail_class,
  "non-canonical"
)
distance_data$tail_class_plot[is.na(distance_data$tail_class_plot) | distance_data$tail_class_plot == ""] <- "short_or_missing"
distance_data <- distance_data[order(distance_data$mean_distance_to_eukaryotic_actin), , drop = FALSE]
write_tsv(distance_data, "asgard_sequence_distance_to_eukaryotic_actin_species_rep_tree.tsv")

summarise_by <- function(data, group_col, group_type) {
  data %>%
    filter(!is.na(.data[[group_col]]), .data[[group_col]] != "") %>%
    group_by(group = .data[[group_col]]) %>%
    summarise(
      group_type = group_type,
      n_seq = n(),
      mean_of_mean_distance = mean(mean_distance_to_eukaryotic_actin),
      median_of_mean_distance = median(mean_distance_to_eukaryotic_actin),
      q1_mean_distance = unname(quantile(mean_distance_to_eukaryotic_actin, 0.25)),
      q3_mean_distance = unname(quantile(mean_distance_to_eukaryotic_actin, 0.75)),
      median_min_distance = median(min_distance_to_eukaryotic_actin),
      min_min_distance = min(min_distance_to_eukaryotic_actin),
      .groups = "drop"
    ) %>%
    arrange(median_of_mean_distance, group)
}

class_distance_summary <- summarise_by(distance_data, "c", "Asgard class")
family_distance_summary <- summarise_by(distance_data, "actin_family_class", "Actin family")
tail_distance_summary <- summarise_by(distance_data, "tail_class_plot", "Tail category")
write_tsv(bind_rows(class_distance_summary, family_distance_summary, tail_distance_summary),
          "asgard_to_eukaryotic_actin_distance_summary_species_rep_tree.tsv")

distance_long <- distance_data %>%
  select(seq, c, actin_family_class, tail_class_plot,
         mean_distance_to_eukaryotic_actin,
         median_distance_to_eukaryotic_actin,
         min_distance_to_eukaryotic_actin) %>%
  pivot_longer(
    cols = ends_with("distance_to_eukaryotic_actin"),
    names_to = "distance_metric",
    values_to = "distance"
  )
distance_long$distance_metric <- factor(
  distance_long$distance_metric,
  levels = c(
    "mean_distance_to_eukaryotic_actin",
    "median_distance_to_eukaryotic_actin",
    "min_distance_to_eukaryotic_actin"
  ),
  labels = c("Mean to 16 eukaryotic tips", "Median to 16 eukaryotic tips", "Nearest eukaryotic tip")
)
class_order_distance <- class_distance_summary$group
distance_long$c <- factor(distance_long$c, levels = rev(class_order_distance))

p_class_distance <- ggplot(distance_long, aes(distance, c)) +
  geom_boxplot(aes(fill = c), width = 0.55, outlier.shape = NA, linewidth = 0.34, alpha = 0.72) +
  geom_point(aes(fill = c), shape = 21, size = 0.7, stroke = 0.08, colour = "#333333",
             alpha = 0.55, position = position_jitter(height = 0.15, width = 0)) +
  facet_wrap(~distance_metric, scales = "free_x", nrow = 1) +
  scale_fill_manual(values = class_palette, guide = "none") +
  labs(
    title = "Asgard class-level patristic distance to eukaryotic actin",
    subtitle = "Each point is one Asgard actin sequence from the species-representative MAG tree.",
    x = "Patristic distance",
    y = "Asgard class"
  ) +
  theme_pub(6.8) +
  theme(strip.background = element_blank(), plot.margin = margin(5, 5, 5, 5))
save_plot(p_class_distance, "figure_3_asgard_class_distance_to_eukaryotic_actin", 183, 115)

collapse_mag_distance <- function(data, distance_col, metric_label) {
  data %>%
    filter(!is.na(mag_id), mag_id != "", is.finite(.data[[distance_col]])) %>%
    arrange(mag_id, .data[[distance_col]], seq) %>%
    group_by(mag_id) %>%
    slice(1) %>%
    ungroup() %>%
    mutate(
      selected_distance_metric = metric_label,
      mag_distance_to_eukaryotic_actin = .data[[distance_col]]
    )
}
mag_distance <- bind_rows(
  collapse_mag_distance(distance_data, "mean_distance_to_eukaryotic_actin", "Mean distance"),
  collapse_mag_distance(distance_data, "median_distance_to_eukaryotic_actin", "Median distance"),
  collapse_mag_distance(distance_data, "min_distance_to_eukaryotic_actin", "Nearest-tip distance")
)
write_tsv(mag_distance, "mag_level_min_copy_distance_to_eukaryotic_actin_species_rep_tree.tsv")

n_tip <- Ntip(tree)
root_node <- setdiff(unique(tree$edge[, 1]), unique(tree$edge[, 2]))
if (length(root_node) != 1) stop("Cannot identify a unique displayed root.")
root_node <- root_node[[1]]
branch_depth <- node.depth.edgelength(tree)
tree_height <- max(branch_depth[seq_len(n_tip)], na.rm = TRUE)
parent_map <- setNames(tree$edge[, 1], tree$edge[, 2])
edge_length_map <- setNames(tree$edge.length, tree$edge[, 2])
tip_parent <- as.integer(parent_map[as.character(seq_len(n_tip))])
tip_root <- data.frame(
  seq = tree$tip.label,
  root_to_tip_distance = branch_depth[seq_len(n_tip)],
  root_to_parent_distance = branch_depth[tip_parent],
  terminal_branch_length = as.numeric(edge_length_map[as.character(seq_len(n_tip))]),
  normalized_root_to_tip_distance = branch_depth[seq_len(n_tip)] / tree_height,
  stringsAsFactors = FALSE
)
tip_root <- merge(
  tip_root,
  meta[, c("seq", "mag_id", "actin_family_class", "c", "quality_checkm2", "tail_class", "tail_nogap_len", "tail_score_gap_penalty")],
  by = "seq", all.x = TRUE, sort = FALSE
)
write_tsv(tip_root, "sequence_root_distance_metrics_species_rep_tree.tsv")

root_metric_cols <- c("root_to_tip_distance", "root_to_parent_distance", "terminal_branch_length")
mag_root <- bind_rows(lapply(root_metric_cols, function(metric) {
  tip_root %>%
    filter(!is.na(mag_id), mag_id != "", is.finite(.data[[metric]])) %>%
    arrange(mag_id, .data[[metric]], seq) %>%
    group_by(mag_id) %>%
    slice(1) %>%
    ungroup() %>%
    mutate(root_metric = metric, mag_root_metric_value = .data[[metric]])
}))
mag_root$root_metric <- factor(
  mag_root$root_metric,
  levels = root_metric_cols,
  labels = c("Root-to-tip", "Root-to-parent", "Terminal branch")
)
write_tsv(mag_root, "mag_level_min_copy_root_distance_metrics_species_rep_tree.tsv")

root_summary <- mag_root %>%
  group_by(root_metric, c) %>%
  summarise(
    n_mag = n(),
    median = median(mag_root_metric_value),
    q1 = unname(quantile(mag_root_metric_value, 0.25)),
    q3 = unname(quantile(mag_root_metric_value, 0.75)),
    min = min(mag_root_metric_value),
    max = max(mag_root_metric_value),
    .groups = "drop"
  )
write_tsv(root_summary, "mag_level_root_distance_summary_by_class_species_rep_tree.tsv")

root_class_order <- root_summary %>%
  filter(root_metric == "Root-to-tip") %>%
  arrange(median, c) %>%
  pull(c)
mag_root$c <- factor(mag_root$c, levels = rev(root_class_order))

p_mag_root <- ggplot(mag_root, aes(mag_root_metric_value, c)) +
  geom_boxplot(aes(fill = c), width = 0.55, outlier.shape = NA, linewidth = 0.34, alpha = 0.72) +
  geom_point(aes(fill = c), shape = 21, size = 0.75, stroke = 0.08, colour = "#333333",
             alpha = 0.55, position = position_jitter(height = 0.15, width = 0)) +
  facet_wrap(~root_metric, scales = "free_x", nrow = 1) +
  scale_fill_manual(values = class_palette, guide = "none") +
  labs(
    title = "MAG-level distance from the displayed tree root",
    subtitle = "For each MAG and metric, the copy with the smallest value is retained. The IQ-TREE topology is unrooted; root-based values reflect the displayed Newick root.",
    x = "Branch-length distance",
    y = "Asgard class"
  ) +
  theme_pub(6.8) +
  theme(strip.background = element_blank(), plot.margin = margin(5, 5, 5, 5))
save_plot(p_mag_root, "figure_4_mag_level_root_distance_by_asgard_class", 183, 115)

multi_copy_meta <- meta %>%
  filter(!is.na(mag_id), mag_id != "", seq %in% rownames(patristic)) %>%
  group_by(mag_id) %>%
  filter(n() >= 2) %>%
  ungroup()

within_mag_copy_distance <- bind_rows(lapply(split(multi_copy_meta, multi_copy_meta$mag_id), function(z) {
  seqs <- z$seq
  dmat <- patristic[seqs, seqs, drop = FALSE]
  pair_idx <- which(upper.tri(dmat), arr.ind = TRUE)
  pair_dist <- dmat[pair_idx]
  data.frame(
    mag_id = z$mag_id[1],
    c = first_nonempty(z$c),
    s = first_nonempty(z$s),
    quality_checkm2 = first_nonempty(z$quality_checkm2),
    n_actin_copies_in_tree = length(seqs),
    n_pairwise_copy_distances = length(pair_dist),
    max_within_mag_copy_distance = max(pair_dist, na.rm = TRUE),
    median_within_mag_copy_distance = median(pair_dist, na.rm = TRUE),
    mean_within_mag_copy_distance = mean(pair_dist, na.rm = TRUE),
    closest_copy_pair_distance = min(pair_dist, na.rm = TRUE),
    longest_pair_seq_1 = rownames(dmat)[pair_idx[which.max(pair_dist), "row"]],
    longest_pair_seq_2 = colnames(dmat)[pair_idx[which.max(pair_dist), "col"]],
    stringsAsFactors = FALSE
  )
}))

within_mag_copy_distance <- within_mag_copy_distance %>%
  arrange(c, desc(max_within_mag_copy_distance), mag_id)
write_tsv(within_mag_copy_distance, "mag_level_within_copy_patristic_distance_species_rep_tree.tsv")

within_mag_summary <- within_mag_copy_distance %>%
  group_by(c) %>%
  summarise(
    n_multicopy_mag = n(),
    median_max_within_mag_copy_distance = median(max_within_mag_copy_distance),
    q1_max_within_mag_copy_distance = unname(quantile(max_within_mag_copy_distance, 0.25)),
    q3_max_within_mag_copy_distance = unname(quantile(max_within_mag_copy_distance, 0.75)),
    median_median_within_mag_copy_distance = median(median_within_mag_copy_distance),
    q1_median_within_mag_copy_distance = unname(quantile(median_within_mag_copy_distance, 0.25)),
    q3_median_within_mag_copy_distance = unname(quantile(median_within_mag_copy_distance, 0.75)),
    median_copy_number = median(n_actin_copies_in_tree),
    max_copy_number = max(n_actin_copies_in_tree),
    .groups = "drop"
  ) %>%
  arrange(median_max_within_mag_copy_distance, c)
write_tsv(within_mag_summary, "mag_level_within_copy_patristic_distance_summary_by_class.tsv")

within_mag_long <- within_mag_copy_distance %>%
  select(
    mag_id, c, n_actin_copies_in_tree,
    max_within_mag_copy_distance,
    median_within_mag_copy_distance
  ) %>%
  pivot_longer(
    cols = c(max_within_mag_copy_distance, median_within_mag_copy_distance),
    names_to = "within_mag_metric",
    values_to = "within_mag_copy_distance"
  )
within_mag_long$within_mag_metric <- factor(
  within_mag_long$within_mag_metric,
  levels = c("max_within_mag_copy_distance", "median_within_mag_copy_distance"),
  labels = c("Farthest copy pair", "Median copy-pair distance")
)
within_class_order <- within_mag_summary$c
within_mag_long$c <- factor(within_mag_long$c, levels = rev(within_class_order))

p_within_mag <- ggplot(within_mag_long, aes(within_mag_copy_distance, c)) +
  geom_boxplot(aes(fill = c), width = 0.56, outlier.shape = NA, linewidth = 0.34, alpha = 0.72) +
  geom_point(
    aes(fill = c, size = n_actin_copies_in_tree),
    shape = 21, stroke = 0.08, colour = "#333333", alpha = 0.58,
    position = position_jitter(height = 0.15, width = 0)
  ) +
  facet_wrap(~within_mag_metric, scales = "free_x", nrow = 1) +
  scale_fill_manual(values = class_palette, guide = "none") +
  scale_size_continuous(range = c(0.65, 2.5), breaks = c(2, 4, 8, 16), name = "Copies per MAG") +
  labs(
    title = "Within-MAG actin-copy divergence by Asgard class",
    subtitle = "Each point is one multi-copy MAG; distances are patristic distances among actin copies within the same MAG.",
    x = "Within-MAG copy-pair patristic distance",
    y = "Asgard class"
  ) +
  theme_pub(6.8) +
  theme(
    strip.background = element_blank(),
    legend.position = "right",
    plot.margin = margin(5, 5, 5, 5)
  )
save_plot(p_within_mag, "figure_7_within_mag_actin_copy_distance_by_asgard_class", 183, 115)

tail_distance_long <- distance_data %>%
  mutate(tail_class_plot = factor(tail_class_plot, levels = tail_order)) %>%
  select(seq, c, tail_class_plot, mean_distance_to_eukaryotic_actin, min_distance_to_eukaryotic_actin) %>%
  pivot_longer(
    cols = c(mean_distance_to_eukaryotic_actin, min_distance_to_eukaryotic_actin),
    names_to = "distance_metric",
    values_to = "distance"
  )
tail_distance_long$distance_metric <- factor(
  tail_distance_long$distance_metric,
  levels = c("mean_distance_to_eukaryotic_actin", "min_distance_to_eukaryotic_actin"),
  labels = c("Mean to eukaryotic tips", "Nearest eukaryotic tip")
)
write_tsv(tail_distance_long, "tail_category_sequence_distance_to_eukaryotic_actin_species_rep_tree.tsv")

p_tail_distance <- ggplot(tail_distance_long, aes(tail_class_plot, distance, fill = tail_class_plot)) +
  geom_boxplot(width = 0.58, outlier.shape = NA, linewidth = 0.34, alpha = 0.75) +
  geom_point(shape = 21, size = 0.7, stroke = 0.08, colour = "#333333", alpha = 0.55,
             position = position_jitter(width = 0.17, height = 0)) +
  facet_wrap(~distance_metric, scales = "free_y", nrow = 1) +
  scale_fill_manual(values = tail_palette, drop = FALSE, name = "Tail category") +
  labs(
    title = "Tail category association with distance to eukaryotic actin",
    subtitle = "Distances are calculated on the same species-representative MAG tree.",
    x = NULL,
    y = "Patristic distance"
  ) +
  theme_pub(6.8) +
  theme(
    axis.text.x = element_text(angle = 35, hjust = 1),
    strip.background = element_blank(),
    legend.position = "none"
  )
save_plot(p_tail_distance, "figure_5_tail_category_distance_to_eukaryotic_actin", 145, 105)

new_run_info <- {
  lines <- readLines(iqtree_file, warn = FALSE)
  input_line <- grep("^Input data:", lines, value = TRUE)[1]
  model_line <- grep("^Best-fit model according to BIC:", lines, value = TRUE)[1]
  logl_line <- grep("^Log-likelihood of the tree:", lines, value = TRUE)[1]
  data.frame(
    tree = "species_rep_MAG",
    n_sequences = as.integer(sub(".*Input data: ([0-9]+) sequences.*", "\\1", input_line)),
    n_sites = as.integer(sub(".*with ([0-9]+) amino-acid sites.*", "\\1", input_line)),
    model = sub("^Best-fit model according to BIC: ", "", model_line),
    log_likelihood = as.numeric(sub("^Log-likelihood of the tree: ([^ ]+).*", "\\1", logl_line)),
    stringsAsFactors = FALSE
  )
}
write_tsv(new_run_info, "species_rep_tree_iqtree_run_summary.tsv")

support_summary <- data.frame(
  tree = "species_rep_MAG",
  metric = c("SH-aLRT >= 80", "UFBoot >= 95", "Both thresholds"),
  count = c(
    sum(support$SH_aLRT >= 80, na.rm = TRUE),
    sum(support$UFBoot >= 95, na.rm = TRUE),
    sum(support$high_support, na.rm = TRUE)
  ),
  total_supported_nodes = sum(is.finite(support$SH_aLRT) & is.finite(support$UFBoot)),
  stringsAsFactors = FALSE
)
support_summary$proportion <- support_summary$count / support_summary$total_supported_nodes
write_tsv(support_summary, "species_rep_tree_support_summary.tsv")

old_tree <- read.tree(old_tree_file)
common_tips <- intersect(tree$tip.label, old_tree$tip.label)
if (length(common_tips) >= 4) {
  new_common <- keep.tip(tree, common_tips)
  old_common <- keep.tip(old_tree, common_tips)
  new_unrooted <- if (is.rooted(new_common)) unroot(new_common) else new_common
  old_unrooted <- if (is.rooted(old_common)) unroot(old_common) else old_common
  rf <- as.numeric(dist.topo(new_unrooted, old_unrooted, method = "PH85"))
  rf_max <- 2 * (length(common_tips) - 3)
  rf_table <- data.frame(
    comparison = "species_rep_MAG_tree_vs_genus_tree_LG_R9_gappyout",
    n_common_tips = length(common_tips),
    RF_distance = rf,
    RF_max = rf_max,
    normalized_RF = rf / rf_max,
    shared_internal_splits = length(common_tips) - 3 - rf / 2,
    stringsAsFactors = FALSE
  )
} else {
  rf_table <- data.frame(
    comparison = "species_rep_MAG_tree_vs_genus_tree_LG_R9_gappyout",
    n_common_tips = length(common_tips),
    RF_distance = NA_real_, RF_max = NA_real_, normalized_RF = NA_real_,
    shared_internal_splits = NA_real_,
    stringsAsFactors = FALSE
  )
}
write_tsv(rf_table, "species_rep_vs_genus_tree_common_tip_RF.tsv")

old_distance <- read.delim(old_distance_file, check.names = FALSE, na.strings = c("", "NA"))
old_cols <- c("seq", "mean_distance_to_eukaryotic_actin", "median_distance_to_eukaryotic_actin", "min_distance_to_eukaryotic_actin")
old_distance <- old_distance[, intersect(old_cols, names(old_distance)), drop = FALSE]
names(old_distance)[names(old_distance) != "seq"] <- paste0("old_", names(old_distance)[names(old_distance) != "seq"])
new_distance <- distance_data[, c("seq", "c", "actin_family_class", "tail_class_plot",
                                  "mean_distance_to_eukaryotic_actin",
                                  "median_distance_to_eukaryotic_actin",
                                  "min_distance_to_eukaryotic_actin")]
names(new_distance)[names(new_distance) %in% old_cols[-1]] <- paste0(
  "new_", names(new_distance)[names(new_distance) %in% old_cols[-1]]
)
distance_compare <- merge(old_distance, new_distance, by = "seq", all = FALSE, sort = FALSE)
if (nrow(distance_compare)) {
  distance_compare$delta_mean_distance_species_rep_minus_genus_tree <-
    distance_compare$new_mean_distance_to_eukaryotic_actin -
    distance_compare$old_mean_distance_to_eukaryotic_actin
  distance_compare$delta_min_distance_species_rep_minus_genus_tree <-
    distance_compare$new_min_distance_to_eukaryotic_actin -
    distance_compare$old_min_distance_to_eukaryotic_actin
}
write_tsv(distance_compare, "common_sequence_eukaryotic_distance_delta_species_rep_vs_genus_tree.tsv")

distance_delta_summary <- if (nrow(distance_compare)) {
  distance_compare %>%
    group_by(c) %>%
    summarise(
      n_common_seq = n(),
      spearman_mean_distance = suppressWarnings(cor(
        old_mean_distance_to_eukaryotic_actin,
        new_mean_distance_to_eukaryotic_actin,
        method = "spearman", use = "complete.obs"
      )),
      median_delta_mean_distance = median(delta_mean_distance_species_rep_minus_genus_tree, na.rm = TRUE),
      median_delta_min_distance = median(delta_min_distance_species_rep_minus_genus_tree, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    arrange(median_delta_mean_distance, c)
} else {
  data.frame()
}
write_tsv(distance_delta_summary, "common_sequence_distance_delta_summary_by_class.tsv")

if (nrow(distance_compare)) {
  p_delta_scatter <- ggplot(
    distance_compare,
    aes(old_mean_distance_to_eukaryotic_actin, new_mean_distance_to_eukaryotic_actin, colour = c)
  ) +
    geom_abline(slope = 1, intercept = 0, linewidth = 0.35, linetype = "dashed", colour = "#555555") +
    geom_point(size = 1.0, alpha = 0.72) +
    scale_colour_manual(values = class_palette, name = "Class") +
    coord_equal() +
    labs(
      title = "Common-tip distance shifts",
      subtitle = "Mean patristic distance to eukaryotic actin in old versus species-representative trees.",
      x = "Genus-tree LG+R9 gappyout distance",
      y = "Species-representative MAG tree distance"
    ) +
    theme_pub(6.8) +
    theme(legend.position = "right")

  delta_long <- distance_compare %>%
    select(seq, c, delta_mean_distance_species_rep_minus_genus_tree,
           delta_min_distance_species_rep_minus_genus_tree) %>%
    pivot_longer(starts_with("delta_"), names_to = "delta_metric", values_to = "delta")
  delta_long$delta_metric <- factor(
    delta_long$delta_metric,
    levels = c(
      "delta_mean_distance_species_rep_minus_genus_tree",
      "delta_min_distance_species_rep_minus_genus_tree"
    ),
    labels = c("Mean-distance shift", "Nearest-tip shift")
  )
  delta_order <- distance_delta_summary$c
  delta_long$c <- factor(delta_long$c, levels = rev(delta_order))
  p_delta_box <- ggplot(delta_long, aes(delta, c)) +
    geom_vline(xintercept = 0, linewidth = 0.3, linetype = "dashed", colour = "#555555") +
    geom_boxplot(aes(fill = c), width = 0.55, outlier.shape = NA, linewidth = 0.3, alpha = 0.72) +
    geom_point(aes(fill = c), shape = 21, size = 0.65, stroke = 0.08, colour = "#333333",
               alpha = 0.55, position = position_jitter(height = 0.13, width = 0)) +
    facet_wrap(~delta_metric, scales = "free_x", nrow = 1) +
    scale_fill_manual(values = class_palette, guide = "none") +
    labs(
      title = "Distance change by class",
      subtitle = paste0("Common tips: ", nrow(distance_compare), "; normalized RF: ",
                        ifelse(is.finite(rf_table$normalized_RF), sprintf("%.3f", rf_table$normalized_RF), "NA")),
      x = "Species-rep tree minus genus tree distance",
      y = "Asgard class"
    ) +
    theme_pub(6.8) +
    theme(strip.background = element_blank())

  p_compare <- p_delta_scatter / p_delta_box + plot_layout(heights = c(1.05, 1.15))
  save_plot(p_compare, "figure_6_species_rep_vs_genus_tree_common_tip_differences", 183, 185)
}

audit <- data.frame(
  item = c(
    "tree_tips",
    "asgard_tips",
    "eukaryotic_reference_tips",
    "metadata_matched_tips",
    "canonical_asgard_tips",
    "high_euk_like_asgard_tips",
    "intermediate_asgard_tips",
    "low_divergent_asgard_tips",
    "short_or_missing_asgard_tips",
    "noncanonical_asgard_tips",
    "common_tips_with_genus_tree"
  ),
  value = c(
    length(tree$tip.label),
    sum(plot_meta$domain == "Archaea"),
    sum(plot_meta$domain == "Eukaryota"),
    sum(!is.na(plot_meta$seq)),
    sum(plot_meta$actin_family_class == "canonical Actin-like" & plot_meta$domain == "Archaea"),
    sum(plot_meta$tail_class_plot == "high_euk_like", na.rm = TRUE),
    sum(plot_meta$tail_class_plot == "intermediate", na.rm = TRUE),
    sum(plot_meta$tail_class_plot == "low_divergent", na.rm = TRUE),
    sum(plot_meta$tail_class_plot == "short_or_missing", na.rm = TRUE),
    sum(plot_meta$tail_class_plot == "non-canonical", na.rm = TRUE),
    length(common_tips)
  ),
  stringsAsFactors = FALSE
)
write_tsv(audit, "analysis_audit_counts.tsv")

readme <- c(
  "# Species-representative MAG actin tree analysis (gappyout)",
  "",
  "This directory contains R-generated visualizations and source tables for the Asgard species-representative MAG actin tree inferred from the gappyout-trimmed alignment.",
  "",
  "## Scope",
  "",
  "- Input tree: `trimmed_asgard_species_rep_mag_euk_mix_gappyout.treefile`.",
  "- Sampling: one actin-positive MAG per GTDB species, retaining all actin sequences from the selected MAG, plus 16 eukaryotic actin references.",
  "- Tail categories follow the previous tail-analysis rule: length >= 10 and gap-penalized PSSM score >= -3.0 for `high_euk_like`, -3.8 to -3.0 for `intermediate`, < -3.8 for `low_divergent`; short or unscored tails are `short_or_missing`.",
  "",
  "## Main figures",
  "",
  "- `figures/figure_1_species_rep_tree_by_asgard_class.pdf`: circular tree coloured by Asgard class.",
  "- `figures/figure_2_species_rep_tree_by_tail_category.pdf`: circular tree coloured by tail category.",
  "- `figures/figure_3_species_rep_tree_by_actin_family.pdf`: circular tree coloured by actin family.",
  "- `figures/figure_3_asgard_class_distance_to_eukaryotic_actin.pdf`: class-level sequence distances to eukaryotic actin.",
  "- `figures/figure_4_mag_level_root_distance_by_asgard_class.pdf`: MAG-level root-distance metrics, retaining the closest copy per MAG for each metric.",
  "- `figures/figure_5_tail_category_distance_to_eukaryotic_actin.pdf`: tail-category distances to eukaryotic actin.",
  "- `figures/figure_6_species_rep_vs_genus_tree_common_tip_differences.pdf`: common-tip distance shifts relative to `genus_tree_LG_R9_gappyout`.",
  "- `figures/figure_7_within_mag_actin_copy_distance_by_asgard_class.pdf`: within-MAG actin-copy divergence by Asgard class.",
  "",
  "## Main source tables",
  "",
  "- `plot_source_data/asgard_sequence_distance_to_eukaryotic_actin_species_rep_tree.tsv`",
  "- `plot_source_data/asgard_to_eukaryotic_actin_distance_summary_species_rep_tree.tsv`",
  "- `plot_source_data/mag_level_min_copy_distance_to_eukaryotic_actin_species_rep_tree.tsv`",
  "- `plot_source_data/mag_level_min_copy_root_distance_metrics_species_rep_tree.tsv`",
  "- `plot_source_data/mag_level_within_copy_patristic_distance_species_rep_tree.tsv`",
  "- `plot_source_data/mag_level_within_copy_patristic_distance_summary_by_class.tsv`",
  "- `plot_source_data/species_rep_vs_genus_tree_common_tip_RF.tsv`",
  "- `plot_source_data/common_sequence_eukaryotic_distance_delta_species_rep_vs_genus_tree.tsv`",
  "- `plot_source_data/analysis_audit_counts.tsv`",
  "",
  "## Caveat",
  "",
  "The IQ-TREE topology is unrooted. Root-to-tip and root-to-parent summaries use the displayed Newick root and should be interpreted as tree-placement diagnostics, not as a rooted evolutionary polarity.",
  "",
  "## Reproduction",
  "",
  "Run from the project root:",
  "",
  "```bash",
  "Rscript asgrad_species_rep_mag_tree_gappyout/analyze_species_rep_mag_tree_gappyout.R",
  "```"
)
writeLines(readme, file.path(project_dir, "README_species_rep_mag_tree_analysis.md"))

message("Completed species-representative MAG tree analysis.")
message("Tree tips: ", length(tree$tip.label), "; Asgard: ", sum(plot_meta$domain == "Archaea"),
        "; eukaryotic references: ", sum(plot_meta$domain == "Eukaryota"),
        "; common tips with genus tree: ", length(common_tips))
