#!/usr/bin/env Rscript

# Replot the frozen gappyout species-representative tree with tail-category
# leaf points and an outer Asgard-class annotation ring. No topology, branch
# length input, tail-class rule, or sequence classification is altered.

required <- c("ape", "ggplot2", "ggtree", "ggnewscale", "dplyr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing R packages: ", paste(missing, collapse = ", "))
suppressPackageStartupMessages({ library(ape); library(ggplot2); library(ggtree); library(dplyr) })

project_dir <- "asgrad_species_rep_mag_tree_gappyout"
tree_file <- file.path(project_dir, "trimmed_asgard_species_rep_mag_euk_mix_gappyout.treefile")
meta_file <- file.path(project_dir, "asgard_species_rep_mag_actin_sequences.tsv")
tail_meta_file <- file.path("actin_tail_analysis", "seq_meta_with_tail_hmm386_410_euk_pssm_score.tsv")
tail_score_file <- file.path("actin_tail_analysis", "tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv")
out_dir <- file.path(project_dir, "figures")
source_dir <- file.path(project_dir, "plot_source_data")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

standardize_tail_class <- function(tail_class, tail_len, score) {
  out <- rep("short_or_missing", length(tail_len))
  enough <- is.finite(tail_len) & tail_len >= 10 & is.finite(score)
  out[enough & score >= -3.0] <- "high_euk_like"
  out[enough & score >= -3.8 & score < -3.0] <- "intermediate"
  out[enough & score < -3.8] <- "low_divergent"
  from_table <- !is.na(tail_class) & tail_class != ""
  out[from_table] <- tail_class[from_table]
  out[is.na(out) | out == ""] <- "short_or_missing"
  out
}

tree <- read.tree(tree_file)
tree_display <- tree
tree_display$edge.length <- sqrt(pmax(tree_display$edge.length, 0))
asgard_meta <- read.delim(meta_file, check.names = FALSE, stringsAsFactors = FALSE, na.strings = c("", "NA"))
tail_meta <- read.delim(tail_meta_file, check.names = FALSE, stringsAsFactors = FALSE, na.strings = c("", "NA"))
tail_score <- read.delim(tail_score_file, check.names = FALSE, stringsAsFactors = FALSE, na.strings = c("", "NA"))
if (!all(c("seq", "actin_family_class", "c") %in% names(asgard_meta))) stop("Required sequence metadata columns are absent.")
if (!all(c("seq", "tail_nogap_len") %in% names(tail_meta))) stop("Tail metadata lacks required columns.")
if (!all(c("seq", "tail_euk_pssm_score_gap_penalty", "tail_class") %in% names(tail_score))) stop("Tail-score metadata lacks required columns.")

tail_join <- merge(
  tail_meta[, c("seq", "tail_nogap_len"), drop = FALSE],
  tail_score[, c("seq", "tail_euk_pssm_score_gap_penalty", "tail_class"), drop = FALSE],
  by = "seq", all.x = TRUE, sort = FALSE
)
meta <- merge(asgard_meta[, c("seq", "actin_family_class", "c"), drop = FALSE], tail_join, by = "seq", all.x = TRUE, sort = FALSE)
meta$tail_nogap_len <- suppressWarnings(as.numeric(meta$tail_nogap_len))
meta$tail_euk_pssm_score_gap_penalty <- suppressWarnings(as.numeric(meta$tail_euk_pssm_score_gap_penalty))
meta$tail_class <- standardize_tail_class(meta$tail_class, meta$tail_nogap_len, meta$tail_euk_pssm_score_gap_penalty)

euk_labels <- setdiff(tree$tip.label, meta$seq)
euk_meta <- data.frame(
  seq = euk_labels, actin_family_class = "Eukaryota_actin", c = "Eukaryotic reference",
  tail_class = "Eukaryotic reference", stringsAsFactors = FALSE
)
meta <- bind_rows(meta %>% select(seq, actin_family_class, c, tail_class), euk_meta)
meta <- meta[match(tree$tip.label, meta$seq), , drop = FALSE]
if (anyNA(meta$seq)) stop("Some tree tips are absent from the sequence metadata.")

tail_order <- c("high_euk_like", "intermediate", "low_divergent", "short_or_missing", "non-canonical", "Eukaryotic reference")
tail_palette <- c(
  "high_euk_like" = "#2C7FB8",
  "intermediate" = "#E28E2C",
  "low_divergent" = "#7B61A8",
  "short_or_missing" = "#B8B8B8",
  "non-canonical" = "#FFFFFF",
  "Eukaryotic reference" = "#D73027"
)
tail_labels <- c(
  "high_euk_like" = "High euk-like",
  "intermediate" = "Intermediate",
  "low_divergent" = "Low/divergent",
  "short_or_missing" = "Short or missing",
  "non-canonical" = "Other actin families (not classified)",
  "Eukaryotic reference" = "Eukaryotic reference"
)
class_palette <- c(
  "Lokiarchaeia" = "#4F9B8F", "Heimdallarchaeia" = "#33658A", "Thorarchaeia" = "#E08D3C",
  "Hermodarchaeia" = "#7B61A8", "Njordarchaeia" = "#C75C64", "Jordiarchaeia" = "#8C8C3E",
  "Asgardarchaeia" = "#5A7D9A", "Baldrarchaeia" = "#D6A64A", "Odinarchaeia" = "#9C6B4E",
  "Wukongarchaeia" = "#8E6A9E", "Atabeyarchaeia" = "#5C8F45", "Sifarchaeia" = "#6B6B6B",
  "Eukaryotic reference" = "#D73027"
)
class_order <- names(class_palette)
family_palette <- c(
  "cALP" = "#2C7FB8", "dALP" = "#7B61A8", "MreB/Mbl-profile" = "#D95F02",
  "MreB_C/ALP_N-profile" = "#CC79A7", "FtsA/PilM-profile" = "#A6761D",
  "Salactin-like" = "#5AAE61", "Volactin-like" = "#C9A227",
  "Eukaryotic reference" = "#D73027"
)
family_order <- names(family_palette)
family_display <- recode(
  meta$actin_family_class,
  "canonical Actin-like" = "cALP",
  "Crenactin-like / archaeal actin" = "dALP",
  "MreB/Mbl-like" = "MreB/Mbl-profile",
  "MreB-like_C/ALP_N-related" = "MreB_C/ALP_N-profile",
  "FtsA/PilM-like" = "FtsA/PilM-profile",
  "Salactin" = "Salactin-like",
  "Volactin" = "Volactin-like",
  "Eukaryota_actin" = "Eukaryotic reference",
  .default = NA_character_
)
meta$tail_display <- ifelse(meta$actin_family_class == "canonical Actin-like", meta$tail_class, "non-canonical")
meta$tail_display[meta$actin_family_class == "Eukaryota_actin"] <- "Eukaryotic reference"
meta$tail_display <- factor(meta$tail_display, levels = tail_order)
meta$class_display <- factor(meta$c, levels = class_order)
meta$family_display <- factor(family_display, levels = family_order)
if (anyNA(meta$tail_display) || anyNA(meta$class_display) || anyNA(meta$family_display)) stop("Unexpected tail-category, actin-family, or Asgard-class label.")

p <- ggtree(tree_display, layout = "circular")
for (i in seq_along(p$layers)) {
  p$layers[[i]]$aes_params$linewidth <- 0.11
  p$layers[[i]]$aes_params$colour <- "#777777"
}
tip_match <- match(p$data$label, meta$seq)
p$data$tail_display <- meta$tail_display[tip_match]
p$data$class_display <- meta$class_display[tip_match]
p$data$family_display <- meta$family_display[tip_match]
tip_ring <- p$data[p$data$isTip, c("label", "x", "y", "tail_display", "family_display", "class_display"), drop = FALSE]
tree_radius <- max(tip_ring$x)
ring_gap <- tree_radius * 0.012
family_ring_width <- tree_radius * 0.026
class_ring_width <- tree_radius * 0.026
tip_ring$x_family_ring <- tree_radius + ring_gap + family_ring_width / 2
tip_ring$x_class_ring <- tree_radius + ring_gap + family_ring_width + ring_gap + class_ring_width / 2
write.table(
  tip_ring,
  file.path(source_dir, "figure_2_species_rep_tree_by_tail_category_class_outer_ring_tip_annotations.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

p_out <- p +
  geom_point2(
    aes(subset = isTip, fill = tail_display),
    shape = 21, size = 1.05, stroke = 0.22, colour = "#4B5358", alpha = 0.96
  ) +
  scale_fill_manual(
    values = tail_palette, breaks = tail_order, labels = tail_labels,
    drop = FALSE, name = "cALP tail state"
  ) +
  ggnewscale::new_scale_fill() +
  geom_tile(
    data = tip_ring, aes(x = x_family_ring, y = y, fill = family_display), inherit.aes = FALSE,
    width = family_ring_width, height = 1.02, linewidth = 0
  ) +
  scale_fill_manual(values = family_palette, breaks = family_order, drop = FALSE, name = "Middle ring: actin family/profile") +
  ggnewscale::new_scale_fill() +
  geom_tile(
    data = tip_ring, aes(x = x_class_ring, y = y, fill = class_display), inherit.aes = FALSE,
    width = class_ring_width, height = 1.02, linewidth = 0
  ) +
  scale_fill_manual(values = class_palette, breaks = class_order, drop = FALSE, name = "Outer ring: Asgard class") +
  labs(
    title = "Distribution of cALP tail states across an Asgard species-representative actin tree",
    subtitle = "Filled leaf points: cALP tail state; open points: other actin families; middle ring: actin family/profile; outer ring: GTDB class.",
    caption = "One actin-positive MAG per GTDB species key is represented, with all eligible actin-superfamily copies retained. Branch lengths are square-root transformed for display."
  ) +
  theme_void(base_family = "Arial") +
  theme(
    plot.title = element_text(size = 12, face = "bold"),
    plot.subtitle = element_text(size = 8.8, colour = "#444444"),
    plot.caption = element_text(size = 7.2, colour = "#444444", hjust = 0),
    legend.position = "right", legend.title = element_text(size = 8.5, face = "bold"),
    legend.text = element_text(size = 7.3), legend.key.height = grid::unit(3.4, "mm"),
    plot.margin = margin(7, 12, 7, 7)
  )

stem <- file.path(out_dir, "figure_2_species_rep_tree_by_tail_category")
ggsave(paste0(stem, ".pdf"), p_out, width = 260, height = 205, units = "mm", device = cairo_pdf)
ggsave(paste0(stem, "_preview.png"), p_out, width = 260, height = 205, units = "mm", dpi = 450, bg = "white")
message("Saved: ", normalizePath(paste0(stem, ".pdf"), winslash = "/"))
