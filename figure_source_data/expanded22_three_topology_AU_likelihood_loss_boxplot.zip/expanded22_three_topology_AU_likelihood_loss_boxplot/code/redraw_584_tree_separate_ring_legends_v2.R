options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(ggplot2)
  library(ggtree)
  library(ggnewscale)
  library(readr)
  library(ragg)
})

root <- ".."
audit_root <- file.path(root, "retention/actin_retention_evidence_audit_20260727")
input_root <- file.path(audit_root, "results/cALP_dALP_584_806_tree_inputs_20260807")
out_dir <- file.path(root, "manuscript_writing_20260801/figures/fig6_actin_retention/04_gene_tree_topology")

tree_file <- file.path(input_root, "remote_trees/584.gappyout.treefile")
raw_file <- file.path(input_root, "cALP_dALP_named_species_plus16euk_584.raw.fasta")
meta_file <- file.path(audit_root, "inputs/frozen_authoritative_6769/seq_meta_with_aa_seq.tsv")

read_ids <- function(path) {
  x <- readLines(path, warn = FALSE)
  sub("\\s+.*$", "", sub("^>", "", x[startsWith(x, ">")]))
}

tree <- read.tree(tree_file)
meta <- read_tsv(
  meta_file,
  show_col_types = FALSE,
  col_select = c(seq, p, c, actin_family_class)
) %>%
  mutate(
    Actin_profile = recode(
      actin_family_class,
      `canonical Actin-like` = "cALPs",
      `Crenactin-like / archaeal actin` = "dALPs",
      .default = "other"
    ),
    Phylum = sub("^p__", "", sub("^d__", "", p)),
    Class = sub("^c__", "", c)
  ) %>%
  select(seq, Actin_profile, Phylum, Class)

ann <- tibble(seq = read_ids(raw_file)) %>%
  left_join(meta, by = "seq") %>%
  mutate(
    Actin_profile = if_else(is.na(Actin_profile), "Eukaryotic reference", Actin_profile),
    Phylum = if_else(is.na(Phylum), "Eukaryota", Phylum),
    Class = if_else(is.na(Class), "Eukaryota", Class)
  )

stopifnot(setequal(tree$tip.label, ann$seq))
ann <- ann[match(tree$tip.label, ann$seq), ]

family_palette <- c(
  cALPs = "#4C78A8",
  dALPs = "#4F9B8F",
  `Eukaryotic reference` = "#C46A5A",
  other = "#BDBDBD"
)
phylum_levels <- sort(unique(ann$Phylum))
class_levels <- sort(unique(ann$Class))
phylum_palette <- setNames(hcl.colors(length(phylum_levels), "Set 2"), phylum_levels)
class_palette <- setNames(hcl.colors(length(class_levels), "Dark 3"), class_levels)

p <- ggtree(tree, layout = "circular", linewidth = 0.32, colour = "#666666")
p$data$Actin_profile <- ann$Actin_profile[match(p$data$label, ann$seq)]
tip_ring <- p$data[p$data$isTip, c("label", "x", "y"), drop = FALSE]
tip_ring$Phylum <- ann$Phylum[match(tip_ring$label, ann$seq)]
tip_ring$Class <- ann$Class[match(tip_ring$label, ann$seq)]
r <- max(tip_ring$x, na.rm = TRUE)
tip_ring$x_phylum <- r + 0.075 * r
tip_ring$x_class <- r + 0.125 * r

node_labels <- tree$node.label
if (is.null(node_labels)) node_labels <- rep("", tree$Nnode)
support_parts <- strsplit(ifelse(is.na(node_labels), "", node_labels), "/", fixed = TRUE)
sh <- vapply(support_parts, function(x) suppressWarnings(as.numeric(x[1])), numeric(1))
uf <- vapply(
  support_parts,
  function(x) if (length(x) > 1) suppressWarnings(as.numeric(x[2])) else NA_real_,
  numeric(1)
)
p$data$high_support <- FALSE
node_ids <- seq.int(Ntip(tree) + 1L, Ntip(tree) + tree$Nnode)
p$data$high_support[match(node_ids, p$data$node)] <-
  is.finite(sh) & is.finite(uf) & sh >= 80 & uf >= 95

p_ring <- p +
  geom_point2(
    aes(subset = isTip, colour = Actin_profile),
    size = 1.55,
    alpha = 0.98
  ) +
  geom_point(
    data = tip_ring,
    aes(x = x_phylum, y = y, fill = Phylum),
    inherit.aes = FALSE,
    shape = 21,
    size = 3.85,
    colour = "transparent",
    stroke = 0
  ) +
  scale_fill_manual(
    values = phylum_palette,
    name = "Inner ring: phylum",
    drop = FALSE,
    guide = guide_legend(order = 2, ncol = 2, byrow = FALSE)
  ) +
  new_scale_fill() +
  geom_point(
    data = tip_ring,
    aes(x = x_class, y = y, fill = Class),
    inherit.aes = FALSE,
    shape = 21,
    size = 3.85,
    colour = "transparent",
    stroke = 0
  ) +
  scale_fill_manual(
    values = class_palette,
    name = "Outer ring: class",
    drop = FALSE,
    guide = guide_legend(order = 3, ncol = 2, byrow = FALSE)
  ) +
  geom_point2(
    aes(subset = !isTip & high_support),
    shape = 21,
    size = 0.78,
    stroke = 0.08,
    colour = "white",
    fill = "black"
  ) +
  scale_colour_manual(
    values = family_palette,
    name = "Actin profile",
    drop = FALSE,
    guide = guide_legend(order = 1)
  ) +
  labs(
    title = "584-sequence cALP/dALP gene tree",
    subtitle = "Branch-length tree; tip symbols denote actin profile, with phylum and class shown by separate inner and outer rings",
    caption = "Unrooted Rich-LG tree; black nodes meet SH-aLRT >=80 and UFBoot >=95."
  ) +
  theme_void(base_family = "Arial") +
  theme(
    plot.title = element_text(size = 12.5, face = "bold", colour = "#18212B"),
    plot.subtitle = element_text(size = 9.0, colour = "#46515C"),
    plot.caption = element_text(size = 7.8, colour = "#4F5964", hjust = 0),
    legend.title = element_text(size = 8.6, face = "bold"),
    legend.text = element_text(size = 7.7),
    legend.key.height = grid::unit(3.3, "mm"),
    legend.key.width = grid::unit(3.3, "mm"),
    legend.spacing.y = grid::unit(1.5, "mm"),
    legend.position = "right",
    plot.margin = margin(8, 10, 8, 8)
  )

stem <- file.path(out_dir, "figure_1a_584_gappyout_branch_length_family_phylum_class_outer_rings_legend_v2")
ggsave(paste0(stem, ".pdf"), p_ring, width = 390, height = 310, units = "mm", device = cairo_pdf, bg = "white")
ggsave(paste0(stem, ".png"), p_ring, width = 390, height = 310, units = "mm", dpi = 300, device = ragg::agg_png, bg = "white")
write_tsv(ann, paste0(stem, "_tip_annotations.tsv"))

