from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "six_sister_MAG_pairs_retention_AU_source.tsv"
OUTBASE = HERE / "figure_six_sister_MAG_AU_likelihood_loss_boxplot_v1"

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "pdf.fonttype": 42,
        "font.size": 7,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.major.size": 0,
        "ytick.major.size": 3,
    }
)

df = pd.read_csv(SOURCE, sep="\t")
if len(df) != 6:
    raise ValueError(f"Expected 6 pre-specified sister-MAG pairs, found {len(df)}")

values = [
    np.zeros(len(df), dtype=float),
    df["terminal_duplication_deltaL"].to_numpy(float),
    df["crossed_deltaL"].to_numpy(float),
]
labels = [
    "Reciprocal paralog\nretention",
    "Terminal within-MAG\nduplication",
    "Crossed profile\npairing",
]
colors = ["#2A8C82", "#C96A55", "#7A7A7A"]

fig, ax = plt.subplots(figsize=(4.35, 3.25))
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

bp = ax.boxplot(
    values,
    positions=[1, 2, 3],
    widths=0.48,
    patch_artist=True,
    showfliers=False,
    whis=(0, 100),
    medianprops={"color": "#333333", "linewidth": 1.2},
    whiskerprops={"color": "#707070", "linewidth": 0.8},
    capprops={"color": "#707070", "linewidth": 0.8},
    boxprops={"edgecolor": "#707070", "linewidth": 0.8},
)
for patch, color in zip(bp["boxes"], colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.16)

# Deterministic horizontal offsets reveal all six observations without altering y values.
offsets = np.array([-0.115, -0.070, -0.025, 0.025, 0.070, 0.115])
for x, y, color in zip([1, 2, 3], values, colors):
    ax.scatter(
        x + offsets,
        y,
        s=30,
        facecolor=color,
        edgecolor="white",
        linewidth=0.55,
        alpha=0.94,
        zorder=4,
    )

ax.axhline(0, color="#222222", linewidth=0.75, zorder=0)
ax.set_xlim(0.52, 3.48)
ax.set_ylim(-28, 1010)
ax.set_xticks([1, 2, 3], labels)
ax.set_ylabel("Likelihood loss relative to the best topology (ΔlnL)")
ax.set_title(
    "Six sister-MAG tests favor reciprocal paralog retention",
    loc="left", fontsize=8.2, fontweight="bold", pad=12,
)

status = ["AU retained\n6/6", "AU rejected\n6/6", "AU rejected\n6/6"]
for x, txt, color in zip([1, 2, 3], status, colors):
    ax.text(x, 982, txt, ha="center", va="top", fontsize=6.4,
            fontweight="bold", color=color)

ax.text(
    0.0, -0.22,
    "Each point represents one pre-specified sister-MAG pair; AU decisions were made within each pair.",
    transform=ax.transAxes, ha="left", va="top", fontsize=5.6, color="#555555",
)
ax.tick_params(axis="both", labelsize=6.4)
ax.spines["left"].set_color("#333333")
ax.spines["bottom"].set_color("#333333")

plt.subplots_adjust(left=0.17, right=0.985, top=0.87, bottom=0.25)
fig.savefig(OUTBASE.with_suffix(".pdf"), facecolor="white")
fig.savefig(OUTBASE.with_suffix(".png"), dpi=400, facecolor="white")
plt.close(fig)

