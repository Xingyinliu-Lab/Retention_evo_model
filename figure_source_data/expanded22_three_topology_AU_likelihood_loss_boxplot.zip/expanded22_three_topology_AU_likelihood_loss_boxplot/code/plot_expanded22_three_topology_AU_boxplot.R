suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

root <- ".."
input <- file.path(root, "summary", "EXPANDED22_STRICT_AU_RESULTS.tsv")
figure_dir <- file.path(root, "figures")
source_dir <- file.path(root, "data", "figure_source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

dat <- read.delim(input, check.names = FALSE, stringsAsFactors = FALSE)

pair_order <- dat %>%
  transmute(
    pair_id,
    mean_alternative_loss =
      (retention_minus_terminal_logL + retention_minus_crossed_logL) / 2
  ) %>%
  arrange(mean_alternative_loss) %>%
  pull(pair_id)
offsets <- setNames(seq(-0.12, 0.12, length.out = length(pair_order)), pair_order)

plot_dat <- bind_rows(
  dat %>% transmute(
    pair_id, order, n_species_trees_exact_sisters,
    topology = "Reciprocal retention",
    log_likelihood = retention_logL,
    p_AU = retention_pAU
  ),
  dat %>% transmute(
    pair_id, order, n_species_trees_exact_sisters,
    topology = "Terminal MAG duplication",
    log_likelihood = terminal_logL,
    p_AU = terminal_pAU
  ),
  dat %>% transmute(
    pair_id, order, n_species_trees_exact_sisters,
    topology = "Crossed profile pairing",
    log_likelihood = crossed_logL,
    p_AU = crossed_pAU
  )
) %>%
  group_by(pair_id) %>%
  mutate(likelihood_loss = max(log_likelihood) - log_likelihood) %>%
  ungroup() %>%
  mutate(
    topology = factor(
      topology,
      levels = c(
        "Reciprocal retention",
        "Terminal MAG duplication",
        "Crossed profile pairing"
      )
    ),
    x_base = as.integer(topology),
    x_plot = x_base + unname(offsets[pair_id]),
    order = factor(order, levels = c("Sigynarchaeales", "Hodarchaeales")),
    AU_status = ifelse(p_AU >= 0.05, "Not rejected", "Rejected")
  )

write.table(
  plot_dat,
  file.path(
    source_dir,
    "fig_expanded22_three_topology_AU_likelihood_loss_boxplot_source_data.tsv"
  ),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)

order_cols <- c("Sigynarchaeales" = "#7A6AA8", "Hodarchaeales" = "#4F9C9A")

p <- ggplot(plot_dat, aes(x_base, likelihood_loss, group = topology)) +
  geom_hline(yintercept = 0, linewidth = 0.30, colour = "#666666") +
  geom_boxplot(
    width = 0.38, linewidth = 0.32, outlier.shape = NA,
    fill = "white", colour = "#777777"
  ) +
  geom_point(
    aes(x = x_plot, colour = order),
    shape = 16, size = 1.75, alpha = 0.88
  ) +
  annotate(
    "text", x = 1, y = 735, label = "AU retained\n22/22",
    size = 2.05, lineheight = 0.92, colour = "#3F3F3F"
  ) +
  annotate(
    "text", x = 2, y = 735, label = "AU rejected\n22/22",
    size = 2.05, lineheight = 0.92, colour = "#3F3F3F"
  ) +
  annotate(
    "text", x = 3, y = 735, label = "AU rejected\n22/22",
    size = 2.05, lineheight = 0.92, colour = "#3F3F3F"
  ) +
  scale_x_continuous(
    breaks = 1:3,
    labels = c(
      "Reciprocal\nretention",
      "Terminal MAG\nduplication",
      "Crossed profile\npairing"
    ),
    limits = c(0.68, 3.32)
  ) +
  scale_y_continuous(
    limits = c(0, 780), breaks = seq(0, 700, 100),
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_colour_manual(values = order_cols, drop = FALSE, name = NULL) +
  labs(
    title = "Reciprocal retention is the best-supported topology",
    x = NULL,
    y = "Likelihood loss relative to the best topology",
    caption = "Each point is one of 22 strict sister-MAG pairs. Lower values indicate better fit; AU significance is evaluated within each pair."
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "black"),
    axis.ticks = element_line(linewidth = 0.28, colour = "black"),
    axis.text.x = element_text(size = 6.3, lineheight = 0.92),
    axis.text.y = element_text(size = 6.3),
    axis.title.y = element_text(size = 7.0),
    plot.title = element_text(size = 8.1, face = "bold"),
    plot.caption = element_text(
      size = 5.3, colour = "#555555", hjust = 0,
      margin = margin(t = 4)
    ),
    legend.position = "top",
    legend.text = element_text(size = 5.8),
    legend.key.width = grid::unit(3.5, "mm"),
    plot.margin = margin(4, 6, 4, 5)
  ) +
  guides(colour = guide_legend(nrow = 1, override.aes = list(size = 1.9, alpha = 1)))

ggsave(
  file.path(figure_dir, "fig_expanded22_three_topology_AU_likelihood_loss_boxplot.pdf"),
  p, width = 135, height = 92, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_expanded22_three_topology_AU_likelihood_loss_boxplot.png"),
  p, width = 135, height = 92, units = "mm", dpi = 600, bg = "white"
)

