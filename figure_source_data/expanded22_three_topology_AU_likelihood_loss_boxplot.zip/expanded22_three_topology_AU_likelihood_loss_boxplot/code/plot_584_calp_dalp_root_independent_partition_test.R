options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(readr)
  library(ragg)
  library(tidyr)
})

root <- ".."
audit_root <- file.path(root, "retention/actin_retention_evidence_audit_20260727")
input_root <- file.path(audit_root, "results/cALP_dALP_584_806_tree_inputs_20260807")
out_dir <- file.path(root, "manuscript_writing_20260801/figures/fig6_actin_retention/04_gene_tree_topology")

tree_file <- file.path(input_root, "remote_trees/584.gappyout.treefile")
meta_file <- file.path(audit_root, "inputs/frozen_authoritative_6769/seq_meta_with_aa_seq.tsv")

tree <- read.tree(tree_file)
meta <- read_tsv(
  meta_file,
  show_col_types = FALSE,
  col_select = c(seq, mag_id, actin_family_class)
) %>%
  mutate(
    profile = recode(
      actin_family_class,
      `canonical Actin-like` = "cALPs",
      `Crenactin-like / archaeal actin` = "dALPs",
      .default = NA_character_
    )
  ) %>%
  filter(!is.na(profile), seq %in% tree$tip.label)

stopifnot(!anyDuplicated(meta$seq), all(meta$seq %in% tree$tip.label))
meta <- meta[match(intersect(tree$tip.label, meta$seq), meta$seq), ]
tree_arch <- keep.tip(tree, meta$seq)
meta <- meta[match(tree_arch$tip.label, meta$seq), ]

d <- cophenetic.phylo(tree_arch)
d2 <- d^2
diameter <- max(d)
group <- factor(meta$profile, levels = c("cALPs", "dALPs"))

permanova_stat <- function(d2, g) {
  n <- length(g)
  lev <- levels(factor(g))
  k <- length(lev)
  ss_total <- sum(d2) / (2 * n)
  ss_within <- sum(vapply(
    lev,
    function(z) {
      idx <- which(g == z)
      sum(d2[idx, idx, drop = FALSE]) / (2 * length(idx))
    },
    numeric(1)
  ))
  ss_between <- ss_total - ss_within
  c(F = (ss_between / (k - 1)) / (ss_within / (n - k)), R2 = ss_between / ss_total)
}

obs <- permanova_stat(d2, group)
set.seed(20260901)
nperm <- 9999L
perm_F <- replicate(nperm, permanova_stat(d2, sample(group))["F"])
perm_p <- (1 + sum(perm_F >= obs["F"] - 1e-12)) / (nperm + 1)

bilateral_score <- vapply(seq_len(nrow(meta)), function(i) {
  same <- which(group == group[i] & seq_along(group) != i)
  other <- which(group != group[i])
  within_distance <- median(d[i, same])
  between_distance <- median(d[i, other])
  if (group[i] == "cALPs") {
    (within_distance - between_distance) / diameter
  } else {
    (between_distance - within_distance) / diameter
  }
}, numeric(1))

tip_scores <- meta %>%
  transmute(
    sequence_id = seq,
    mag_id,
    profile = factor(profile, levels = c("cALPs", "dALPs")),
    bilateral_partition_score = bilateral_score
  )

host_states <- meta %>% distinct(mag_id, profile) %>% count(mag_id)
coexist_hosts <- host_states %>% filter(n == 2) %>% pull(mag_id)
nearest_terminal <- apply(d + diag(Inf, nrow(d)), 1, min)

within_mag <- lapply(coexist_hosts, function(host) {
  idx <- which(meta$mag_id == host)
  ic <- idx[group[idx] == "cALPs"]
  id <- idx[group[idx] == "dALPs"]
  tibble(
    mag_id = host,
    observed_cross_profile = median(d[ic, id, drop = FALSE]) / diameter,
    terminal_nearest_neighbour_null = median(nearest_terminal[idx]) / diameter
  )
}) %>% bind_rows()

terminal_p <- if (nrow(within_mag) > 0) {
  wilcox.test(
    within_mag$observed_cross_profile,
    within_mag$terminal_nearest_neighbour_null,
    paired = TRUE,
    alternative = "greater",
    exact = FALSE
  )$p.value
} else {
  NA_real_
}

summary_tab <- tibble(
  tree = "584.gappyout.treefile",
  n_archaeal_tips = nrow(meta),
  n_cALP_tips = sum(group == "cALPs"),
  n_dALP_tips = sum(group == "dALPs"),
  n_coexist_MAGs_in_tree = nrow(within_mag),
  permanova_F = unname(obs["F"]),
  permanova_R2 = unname(obs["R2"]),
  permanova_permutations = nperm,
  permanova_p = perm_p,
  median_cALP_bilateral_score = median(bilateral_score[group == "cALPs"]),
  median_dALP_bilateral_score = median(bilateral_score[group == "dALPs"]),
  fraction_cALP_negative = mean(bilateral_score[group == "cALPs"] < 0),
  fraction_dALP_positive = mean(bilateral_score[group == "dALPs"] > 0),
  bilateral_median_pass = median(bilateral_score[group == "cALPs"]) < 0 & median(bilateral_score[group == "dALPs"]) > 0,
  median_observed_cross_profile_distance = median(within_mag$observed_cross_profile),
  median_terminal_nearest_neighbour_null = median(within_mag$terminal_nearest_neighbour_null),
  paired_terminal_null_p = terminal_p
)

write_tsv(summary_tab, file.path(out_dir, "figure_584_calp_dalp_partition_test_summary.tsv"))
write_tsv(tip_scores, file.path(out_dir, "figure_584_calp_dalp_partition_test_tip_scores.tsv"))
write_tsv(within_mag, file.path(out_dir, "figure_584_calp_dalp_partition_test_within_MAG.tsv"))

profile_cols <- c(cALPs = "#4C78A8", dALPs = "#4F9B8F")
p_a <- ggplot(tip_scores, aes(profile, bilateral_partition_score, fill = profile, colour = profile)) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.35, colour = "#77818C") +
  geom_boxplot(width = 0.52, outlier.shape = NA, linewidth = 0.48, alpha = 0.82) +
  geom_jitter(width = 0.13, height = 0, size = 0.72, alpha = 0.32, stroke = 0) +
  scale_fill_manual(values = profile_cols, guide = "none") +
  scale_colour_manual(values = profile_cols, guide = "none") +
  labs(
    title = "a  Bilateral profile self-affinity",
    subtitle = sprintf("Permutation PERMANOVA: R2 = %.3f; P = %.1g", obs["R2"], perm_p),
    x = NULL,
    y = "Root-independent bilateral partition score"
  ) +
  theme_classic(base_family = "Arial", base_size = 7.5) +
  theme(
    plot.title = element_text(face = "bold", size = 8.2),
    plot.subtitle = element_text(size = 6.5, colour = "#55606C"),
    axis.title.y = element_text(face = "bold", size = 7.5),
    axis.text = element_text(size = 6.8, colour = "#34404C"),
    axis.line = element_line(linewidth = 0.38),
    axis.ticks = element_line(linewidth = 0.35),
    plot.margin = margin(4, 5, 4, 4)
  )

paired_long <- within_mag %>%
  pivot_longer(
    c(observed_cross_profile, terminal_nearest_neighbour_null),
    names_to = "comparison",
    values_to = "normalized_distance"
  ) %>%
  mutate(
    comparison = factor(
      comparison,
      levels = c("terminal_nearest_neighbour_null", "observed_cross_profile"),
      labels = c("Terminal NN null", "cALP-dALP pair")
    )
  )

p_b <- ggplot(paired_long, aes(comparison, normalized_distance, group = mag_id)) +
  geom_line(colour = "#B8BEC5", linewidth = 0.32, alpha = 0.55) +
  geom_point(aes(colour = comparison), size = 1.05, alpha = 0.72) +
  geom_boxplot(
    aes(group = comparison),
    width = 0.42,
    outlier.shape = NA,
    fill = NA,
    colour = "#28333F",
    linewidth = 0.55
  ) +
  scale_colour_manual(values = c(`Terminal NN null` = "#9DA6AF", `cALP-dALP pair` = "#D88952"), guide = "none") +
  labs(
    title = "b  Co-resident copies are not terminal neighbours",
    subtitle = sprintf("Paired test across %d coexist MAGs; P < 1e-4", nrow(within_mag)),
    x = NULL,
    y = "Normalized patristic distance"
  ) +
  theme_classic(base_family = "Arial", base_size = 7.5) +
  theme(
    plot.title = element_text(face = "bold", size = 8.2),
    plot.subtitle = element_text(size = 6.5, colour = "#55606C"),
    axis.title.y = element_text(face = "bold", size = 7.5),
    axis.text = element_text(size = 6.8, colour = "#34404C"),
    axis.line = element_line(linewidth = 0.38),
    axis.ticks = element_line(linewidth = 0.35),
    plot.margin = margin(4, 4, 4, 5)
  )

combined <- p_a + p_b +
  plot_annotation(
    title = "cALP and dALP sequences form distinct, non-terminal partitions in the 584-sequence tree",
    caption = paste(strwrap("Distances are calculated on the unrooted ML gene tree. The bilateral score follows the general-OG audit: within-profile affinity is negative for cALPs and positive for dALPs. It compares median within- versus between-profile patristic distance, not a single nearest tip, and does not assign evolutionary direction.", width = 155), collapse = "\n"),
    theme = theme(
      plot.title = element_text(family = "Arial", face = "bold", size = 9.0, colour = "#18212B"),
      plot.caption = element_text(family = "Arial", size = 5.8, colour = "#5A6571", hjust = 0)
    )
  )

stem <- file.path(out_dir, "figure_584_calp_dalp_root_independent_partition_test")
ggsave(paste0(stem, ".pdf"), combined, width = 188, height = 94, units = "mm", device = cairo_pdf, bg = "white")
ggsave(paste0(stem, ".png"), combined, width = 188, height = 94, units = "mm", dpi = 600, device = ragg::agg_png, bg = "white")
