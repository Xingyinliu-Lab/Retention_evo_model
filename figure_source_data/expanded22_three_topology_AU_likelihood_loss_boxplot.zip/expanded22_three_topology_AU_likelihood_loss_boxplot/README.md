# expanded22_three_topology_AU_likelihood_loss_boxplot

- Manuscript panel: Fig.5K
- Source figure basename: fig_expanded22_three_topology_AU_likelihood_loss_boxplot
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 4 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 13 directly referenced or locally packaged source-data file(s)
