suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(tidyr)
  library(ragg)
})

root <- ".."
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")

figure_contract <- list(
  core_conclusion = paste(
    "Delta KCF effects are concentrated in profilin-context templates, whereas",
    "Delta tail25 perturbs a broader set of partner contexts."
  ),
  archetype = "explicit-WT quantitative grid exported as separate figures",
  backend = "R",
  denominator = "126 matched templates per actin and state across six contexts",
  statistics = "descriptive boxplots only; templates are not biological replicates"
)

d0 <- read_tsv(
  file.path(source_dir, "effective_stage1_combined_13104_20260721.tsv"),
  show_col_types = FALSE
)
contexts <- read_tsv(
  "..",
  show_col_types = FALSE
) %>% distinct(pdb_id, context_final)

context_map <- c(
  monomer_handling_profilin = "Profilin",
  filament_motor_contractile_myosin_tropomyosin = "Myosin/tropomyosin",
  filament_remodeling_gelsolin = "Gelsolin",
  filament_end_capping = "Capping",
  filament_remodeling_cofilin_ADF = "Cofilin/ADF",
  nucleation_elongation_formin_WH2 = "Formin/WH2"
)
context_order <- unname(context_map)

d <- d0 %>%
  filter(grepl("AFSERVER_tail_mutant_EUK_(HUMAN_ACTB|RABBIT_ACTA1_8F8P)", candidate)) %>%
  mutate(
    organism_label = if_else(grepl("HUMAN_ACTB", candidate), "Human ACTB", "Rabbit ACTA1"),
    state = case_when(
      grepl("__WT$", candidate) ~ "WT",
      grepl("__DELTA_KCF$", candidate) ~ "Delta KCF",
      grepl("__DELTA_TAIL25$", candidate) ~ "Delta tail25",
      TRUE ~ NA_character_
    )
  ) %>%
  left_join(contexts, by = c("template" = "pdb_id")) %>%
  filter(context_final %in% names(context_map)) %>%
  mutate(
    context_label = unname(context_map[context_final]),
    context_label = factor(context_label, levels = context_order),
    organism_label = factor(organism_label, levels = c("Human ACTB", "Rabbit ACTA1")),
    state = factor(state, levels = c("WT", "Delta KCF", "Delta tail25"))
  )

expected_templates <- c(
  Profilin = 15L, `Myosin/tropomyosin` = 28L, Gelsolin = 36L, Capping = 22L,
  `Cofilin/ADF` = 11L, `Formin/WH2` = 14L
)
audit <- d %>%
  count(organism_label, state, context_label, name = "n_templates")
stopifnot(
  nrow(d) == 756L,
  n_distinct(d$template) == 126L,
  n_distinct(d$organism_label) == 2L,
  n_distinct(d$state) == 3L,
  n_distinct(d$context_label) == 6L,
  all(audit$n_templates == unname(expected_templates[as.character(audit$context_label)]))
)

write_tsv(d, file.path(source_dir, "fig_selected_context_wt_delta_kcf_tail25_boxplots_source.tsv"))
write_tsv(audit, file.path(source_dir, "fig_selected_context_wt_delta_kcf_tail25_boxplots_n_audit.tsv"))

metric_map <- tibble::tribble(
  ~metric, ~column, ~title, ~x_label, ~axis_transform,
  "contacts", "contacts_5A", "Interface contacts across partner contexts", "Interchain contacts within 5 A", "identity",
  "buried_area", "buried_surface_area_A2", "Buried interface area across partner contexts", "Buried surface area (A^2)", "identity",
  "prodigy_affinity", "prodigy_affinity", "Predicted affinity across partner contexts", "Predicted binding free energy (kcal mol^-1)", "identity",
  "minimum_distance", "minimum_interchain_distance_A", "Minimum interface distance across partner contexts", "Minimum interchain distance (A)", "identity",
  "foldx_interaction", "foldx_interaction_energy", "FoldX interaction energy across partner contexts", "FoldX interaction energy (kcal mol^-1)", "pseudo_log20",
  "clashes", "clashes_2A", "Steric clashes across partner contexts", "Interchain atom pairs within 2 A", "pseudo_log2"
)

palette <- c("WT" = "#C9CDD1", "Delta KCF" = "#D98C6B", "Delta tail25" = "#4C78A8")
point_palette <- c("WT" = "#72777C", "Delta KCF" = "#C96F4C", "Delta tail25" = "#356A9F")
context_display_levels <- paste0(
  context_order, "   n=", unname(expected_templates[context_order])
)

for (i in seq_len(nrow(metric_map))) {
  m <- metric_map[i, ]
  plot_data <- d %>%
    transmute(
      template, organism_label, context_final, context_label,
      state, value = .data[[m$column]]
    ) %>%
    filter(is.finite(value)) %>%
    mutate(
      state = factor(state, levels = c("WT", "Delta KCF", "Delta tail25")),
      context_display = factor(
        paste0(as.character(context_label), "   n=",
               unname(expected_templates[as.character(context_label)])),
        levels = rev(context_display_levels)
      ),
      metric = m$metric
    )

  export_data <- plot_data
  stopifnot(
    nrow(export_data) == 756L,
    n_distinct(export_data$template) == 126L
  )
  write_tsv(
    export_data,
    file.path(source_dir, paste0("fig_selected_context_boxplot_", m$metric, "_source.tsv"))
  )

  p <- ggplot(plot_data, aes(y = context_display, x = value, fill = state)) +
    annotate(
      "rect", xmin = -Inf, xmax = Inf,
      ymin = length(context_order) - 0.5, ymax = length(context_order) + 0.5,
      fill = "#F7EEE7", alpha = 0.72
    ) +
    geom_point(
      aes(group = state, colour = state), shape = 16, size = 0.92,
      alpha = 0.48,
      position = position_jitterdodge(
        jitter.width = 0, jitter.height = 0.055, dodge.width = 0.72
      ), show.legend = FALSE
    ) +
    geom_boxplot(
      width = 0.60, linewidth = 0.42, outlier.shape = NA, alpha = 0.82,
      position = position_dodge(width = 0.72), colour = "#303030",
      orientation = "y"
    ) +
    scale_fill_manual(
      values = palette, name = NULL,
      labels = c("WT" = "WT", "Delta KCF" = expression(Delta*KCF),
                 "Delta tail25" = expression(Delta*tail25))
    ) +
    scale_colour_manual(values = point_palette, guide = "none") +
    facet_wrap(~organism_label, nrow = 1) +
    labs(
      title = m$title,
      subtitle = "Matched structural templates; WT shown explicitly for direct comparison",
      x = m$x_label, y = NULL,
      caption = paste0(
        "Each point is one matched experimental-complex template.\n",
        "Boxes show median and IQR; whiskers extend to 1.5 x IQR.\n",
        "Templates are paired across states and are not biological replicates."
      )
    ) +
    theme_classic(base_size = 7.5, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "#222222"),
      axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
      axis.text = element_text(colour = "#222222"),
      axis.text.x = element_text(size = 6.8),
      axis.text.y = element_text(size = 7.1, hjust = 1),
      axis.title.x = element_text(size = 7.6, margin = margin(t = 5)),
      strip.background = element_blank(),
      strip.text = element_text(size = 8.0, face = "bold", margin = margin(b = 4)),
      legend.position = "top", legend.justification = "left",
      legend.text = element_text(size = 7.2),
      legend.key.width = unit(7, "mm"),
      panel.spacing.x = unit(10, "mm"),
      panel.grid.major.x = element_line(linewidth = 0.22, colour = "#E8E8E8"),
      panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(),
      plot.title = element_text(size = 9.2, face = "bold", margin = margin(b = 2)),
      plot.subtitle = element_text(size = 7.4, colour = "#555555", margin = margin(b = 6)),
      plot.caption = element_text(size = 6.2, colour = "#666666", hjust = 0,
                                  margin = margin(t = 6)),
      plot.margin = margin(7, 9, 7, 8)
    )

  if (m$axis_transform == "pseudo_log20") {
    p <- p + scale_x_continuous(
      trans = scales::pseudo_log_trans(sigma = 20),
      breaks = c(-30, 0, 30, 100, 200), minor_breaks = NULL
    )
  } else if (m$axis_transform == "pseudo_log2") {
    p <- p + scale_x_continuous(
      trans = scales::pseudo_log_trans(sigma = 2),
      breaks = c(0, 1, 5, 20, 50), minor_breaks = NULL
    )
  }

  stem <- file.path(figure_dir, paste0("fig_selected_context_boxplot_", m$metric))
  ggsave(paste0(stem, ".pdf"), p, device = grDevices::cairo_pdf,
         width = 165, height = 122, units = "mm", family = "Arial")
  ggsave(paste0(stem, ".png"), p, device = ragg::agg_png,
         width = 165, height = 122, units = "mm", dpi = 600, background = "white")
  stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
}

writeLines(
  c(
    "PASS", "backend=R", "rows=756", "unique_templates=126", "contexts=6",
    "states=3", "displayed_states=3", "actins=2", "figures=6",
    "independent_biological_replicates=no", "source_data_rows_per_figure=756",
    "display=absolute_values_with_explicit_WT",
    paste0("core_conclusion=", figure_contract$core_conclusion)
  ),
  file.path(figure_dir, "fig_selected_context_wt_delta_kcf_tail25_boxplots.QA.marker")
)
