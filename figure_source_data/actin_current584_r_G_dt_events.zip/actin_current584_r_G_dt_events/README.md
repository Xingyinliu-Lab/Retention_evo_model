# actin_current584_r_G_dt_events

- Manuscript panel: Supp.Fig.14B
- Source figure basename: fig_actin_current584_r_G_dt_events
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
