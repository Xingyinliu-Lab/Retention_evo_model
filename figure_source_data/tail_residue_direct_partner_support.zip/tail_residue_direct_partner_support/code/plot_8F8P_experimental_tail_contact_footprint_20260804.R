suppressPackageStartupMessages({
  library(ggplot2)
  library(readr)
  library(dplyr)
  library(scales)
  library(ragg)
})

input_file <- "../data/fig05_tail_residue_direct_partner_support_source.tsv"
figure_dir <- ".."
source_dir <- ".."
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

d <- read_tsv(input_file, show_col_types = FALSE) |>
  transmute(
    hmm_pos = as.integer(hmm_pos),
    tail_region,
    contact_class = recode(
      contact_type,
      "Non-actin protein contact" = "Non-actin protein",
      "Classical actin-chain contact" = "Actin-chain"
    ),
    n_pdb_with_contact = as.integer(n_pdb_direct_partner),
    structure_support_fraction = as.numeric(contact_fraction),
    denominator_pdb = 483L
  ) |>
  mutate(contact_class = factor(contact_class,
                                levels = c("Non-actin protein", "Actin-chain")))

stopifnot(nrow(d) == 50L, all(d$hmm_pos %in% 386:410))
write_tsv(d, file.path(source_dir,
                       "fig_8F8P_experimental_tail_contact_footprint_source.tsv"))

p <- ggplot(d, aes(hmm_pos, contact_class, fill = structure_support_fraction)) +
  geom_tile(width = 0.92, height = 0.72, colour = "white", linewidth = 0.25) +
  annotate("rect", xmin = 407.5, xmax = 410.5, ymin = 0.55, ymax = 2.45,
           fill = NA, colour = "#7C6E82", linewidth = 0.55) +
  annotate("text", x = 409, y = 2.62, label = "KCF", colour = "#675A6C",
           size = 3.1, fontface = "bold") +
  scale_fill_gradient(low = "#F5F7F8", high = "#557F99",
                      limits = c(0, 0.60), breaks = c(0, 0.2, 0.4, 0.6),
                      labels = percent_format(accuracy = 1),
                      name = "Structures with\ncontact") +
  scale_x_continuous(breaks = 386:410, limits = c(385.5, 410.5),
                     expand = expansion(mult = c(0, 0))) +
  coord_cartesian(ylim = c(0.5, 2.75), clip = "off") +
  labs(
    title = "Experimental PDB structures reveal recurrent actin-tail contacts",
    subtitle = "Residue-level contact support across 483 curated classical-actin PDB structures",
    x = "Profile-aligned actin position", y = NULL,
    caption = "Colour is the fraction of structures with a direct ≤5 Å contact. The outlined segment marks terminal KCF (positions 408–410)."
  ) +
  theme_classic(base_size = 9, base_family = "Arial") +
  theme(
    axis.line.y = element_line(linewidth = 0.35),
    axis.line.x = element_line(linewidth = 0.35),
    axis.ticks.y = element_blank(),
    axis.text.x = element_text(size = 7.3),
    axis.text.y = element_text(size = 8.5),
    axis.title.x = element_text(size = 9),
    plot.title = element_text(size = 12, face = "bold", margin = margin(b = 4)),
    plot.subtitle = element_text(size = 9.5, colour = "#555555", margin = margin(b = 12)),
    plot.caption = element_text(size = 7.5, colour = "#666666", hjust = 0,
                                margin = margin(t = 10)),
    legend.title = element_text(size = 8),
    legend.text = element_text(size = 7.5),
    legend.position = "bottom",
    legend.justification = "left",
    legend.box.just = "left",
    plot.margin = margin(14, 18, 10, 12)
  ) +
  guides(fill = guide_colourbar(direction = "horizontal", title.position = "top",
                                barwidth = grid::unit(55, "mm"),
                                barheight = grid::unit(3.5, "mm")))

stem <- file.path(figure_dir, "fig_8F8P_experimental_tail_contact_footprint")
ggsave(paste0(stem, ".pdf"), p, width = 183, height = 95,
       units = "mm", device = cairo_pdf, bg = "white")
ggsave(paste0(stem, ".png"), p, width = 183, height = 95,
       units = "mm", dpi = 600, device = ragg::agg_png, bg = "white")

writeLines(c(
  "PASS",
  "backend=R",
  "evidence=483_curated_classical_actin_PDB_structures",
  "contact_cutoff_A=5",
  "unit_of_analysis=PDB_structure",
  "not_MD_occupancy=true",
  "not_mutant_comparison=true"
), file.path(figure_dir, "fig_8F8P_experimental_tail_contact_footprint.QA.marker"))
