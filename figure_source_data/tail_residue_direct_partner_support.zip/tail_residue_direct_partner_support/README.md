# tail_residue_direct_partner_support

- Manuscript panel: Supp.Fig.7A
- Source figure basename: fig05_tail_residue_direct_partner_support
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 10 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 56 directly referenced or locally packaged source-data file(s)
