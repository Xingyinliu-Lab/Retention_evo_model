# 4_six_species_tree_state_clustering

- Manuscript panel: Supp.Fig.11C
- Source figure basename: fig_4_six_species_tree_state_clustering
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 16 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
