#!/usr/bin/env Rscript

# Publication-ready phylum-level actin-superfamily copy-number distribution
# Input: copy_number_distribution_by_phylum.tsv

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(tidyr)
  library(scales)
})

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
script_dir <- if (length(script_arg) == 1) {
  dirname(normalizePath(sub("^--file=", "", script_arg), winslash = "/"))
} else {
  normalizePath(getwd(), winslash = "/")
}

args <- commandArgs(trailingOnly = TRUE)
input_candidates <- c(
  file.path(script_dir, "copy_number_distribution_by_phylum.tsv"),
  file.path(dirname(script_dir), "copy_number_distribution_by_phylum.tsv"),
  file.path(dirname(script_dir), "data", "copy_number_distribution_by_phylum.tsv"),
  file.path(getwd(), "copy_number_distribution_by_phylum.tsv")
)

input_file <- if (length(args) >= 1) {
  normalizePath(args[1], winslash = "/", mustWork = TRUE)
} else {
  existing <- input_candidates[file.exists(input_candidates)]
  if (length(existing) == 0) {
    stop(
      "Cannot find copy_number_distribution_by_phylum.tsv. ",
      "Run from the table directory or provide the input file path."
    )
  }
  normalizePath(existing[1], winslash = "/")
}

output_root <- if (length(args) >= 2) {
  normalizePath(args[2], winslash = "/", mustWork = FALSE)
} else {
  dirname(input_file)
}

figure_dir <- file.path(output_root, "figures_gpt")
data_dir <- file.path(output_root, "plot_source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

COPY_NUMBER_CAP <- 4L
MIN_PHYLUM_N <- 10L
TOP_N_HEATMAP <- 25L

copy_levels <- c("1", "2", "3", ">=4")
copy_palette <- c(
  "1" = "#D9D9D9",
  "2" = "#9ECAE1",
  "3" = "#4292C6",
  ">=4" = "#084594"
)

fmt_int <- function(x) {
  format(x, big.mark = ",", scientific = FALSE, trim = TRUE)
}

fmt_pct <- function(x, digits = 1) {
  paste0(round(100 * x, digits), "%")
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size, colour = "black"),
      axis.text = element_text(size = base_size - 0.4, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = "black"),
      plot.title = element_text(size = base_size + 0.7, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.tag = element_text(size = 8, face = "bold"),
      plot.caption = element_text(
        size = base_size - 1.0,
        colour = "#4D4D4D",
        hjust = 0
      ),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 300) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      paste0(stem, ".pdf"),
      width = width_in,
      height = height_in,
      family = "sans"
    )
  } else {
    grDevices::pdf(
      paste0(stem, ".pdf"),
      width = width_in,
      height = height_in,
      family = "sans"
    )
  }
  print(plot)
  grDevices::dev.off()

  if (capabilities("cairo")) {
    grDevices::png(
      paste0(stem, "_preview.png"),
      width = width_in,
      height = height_in,
      units = "in",
      res = dpi,
      type = "cairo",
      bg = "white"
    )
  } else {
    grDevices::png(
      paste0(stem, "_preview.png"),
      width = width_in,
      height = height_in,
      units = "in",
      res = dpi,
      bg = "white"
    )
  }
  print(plot)
  grDevices::dev.off()
}

write_tsv_base <- function(x, file) {
  write.table(
    x,
    file,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    na = ""
  )
}

copy_group <- function(x) {
  label <- ifelse(
    x >= COPY_NUMBER_CAP,
    paste0(">=", COPY_NUMBER_CAP),
    as.character(x)
  )
  factor(label, levels = copy_levels)
}

required_columns <- c("p", "copy_number", "n_mags", "fraction_in_phylum")

copy_dist <- read.delim(
  input_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

missing_columns <- setdiff(required_columns, names(copy_dist))
if (length(missing_columns) > 0) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}

copy_dist <- copy_dist %>%
  mutate(
    p = trimws(as.character(p)),
    p = if_else(is.na(p) | p == "", "Unclassified", p),
    copy_number = as.integer(copy_number),
    n_mags = as.integer(n_mags),
    fraction_in_phylum = as.numeric(fraction_in_phylum),
    copy_group = copy_group(copy_number)
  )

if (any(is.na(copy_dist$copy_number) | copy_dist$copy_number < 1)) {
  stop("copy_number contains missing values or values below 1.")
}
if (any(is.na(copy_dist$n_mags) | copy_dist$n_mags < 0)) {
  stop("n_mags contains missing values or values below 0.")
}

write_tsv_base(
  copy_dist,
  file.path(data_dir, "copy_number_distribution_by_phylum_input_checked.tsv")
)

phylum_totals <- copy_dist %>%
  group_by(p) %>%
  summarise(total_mags = sum(n_mags), .groups = "drop")

plot_data <- copy_dist %>%
  group_by(p, copy_group) %>%
  summarise(n_mags = sum(n_mags), .groups = "drop") %>%
  complete(
    p,
    copy_group = factor(copy_levels, levels = copy_levels),
    fill = list(n_mags = 0L)
  ) %>%
  left_join(phylum_totals, by = "p") %>%
  mutate(
    fraction = if_else(total_mags > 0, n_mags / total_mags, NA_real_),
    copy_group = factor(copy_group, levels = copy_levels)
  )

phylum_summary <- plot_data %>%
  group_by(p) %>%
  summarise(
    total_mags = max(total_mags),
    copy1_fraction = sum(fraction[copy_group == "1"], na.rm = TRUE),
    multicopy_fraction = sum(fraction[copy_group %in% c("2", "3", ">=4")], na.rm = TRUE),
    highcopy_fraction = sum(fraction[copy_group %in% c("3", ">=4")], na.rm = TRUE),
    copy_ge4_fraction = sum(fraction[copy_group == ">=4"], na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(multicopy_fraction), desc(highcopy_fraction), desc(total_mags))

write_tsv_base(
  plot_data,
  file.path(data_dir, "phylum_copy_number_distribution_grouped_1_2_3_ge4.tsv")
)
write_tsv_base(
  phylum_summary,
  file.path(data_dir, "phylum_copy_number_distribution_summary.tsv")
)

# Figure 1: 100% stacked bar plot
selected_phyla <- phylum_summary %>%
  filter(total_mags >= MIN_PHYLUM_N)

if (nrow(selected_phyla) == 0) {
  selected_phyla <- phylum_summary %>%
    slice_head(n = min(12, nrow(phylum_summary)))
}

stacked_data <- plot_data %>%
  semi_join(selected_phyla, by = "p") %>%
  mutate(
    p = factor(p, levels = rev(selected_phyla$p)),
    label_n = paste0(p, " (n=", fmt_int(total_mags), ")")
  )

label_levels <- stacked_data %>%
  distinct(p, label_n) %>%
  arrange(p) %>%
  pull(label_n)

stacked_data <- stacked_data %>%
  mutate(label_n = factor(label_n, levels = label_levels))

p_stacked <- ggplot(
  stacked_data,
  aes(x = fraction, y = label_n, fill = copy_group)
) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.18) +
  scale_fill_manual(values = copy_palette, drop = FALSE) +
  scale_x_continuous(
    labels = percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(
    x = "Actin-positive MAGs (%)",
    y = NULL,
    fill = "Copy number",
    title = "Phylum-level copy-number distribution",
    subtitle = paste0(
      "Copy numbers were grouped as 1, 2, 3 and >=", COPY_NUMBER_CAP,
      "; phyla with >=", MIN_PHYLUM_N, " actin-positive MAGs are shown"
    ),
    caption = "Fractions were calculated within actin-positive MAGs in each phylum."
  ) +
  theme_nature() +
  theme(
    legend.position = "top",
    legend.justification = "left",
    legend.box.spacing = grid::unit(0, "pt"),
    axis.text.y = element_text(size = 6.2)
  )

stacked_height <- max(80, 32 + 5.2 * nrow(selected_phyla))
save_figure(
  p_stacked,
  file.path(figure_dir, "figure_1_phylum_copy_number_100pct_stacked_bar"),
  width_mm = 135,
  height_mm = stacked_height
)

write_tsv_base(
  stacked_data,
  file.path(data_dir, "figure_1_phylum_copy_number_100pct_stacked_bar_source_data.tsv")
)

# Figure 2: fraction heatmap
heatmap_phyla <- phylum_summary %>%
  slice_head(n = min(TOP_N_HEATMAP, nrow(phylum_summary)))

heatmap_data <- plot_data %>%
  semi_join(heatmap_phyla, by = "p") %>%
  mutate(
    p = factor(p, levels = rev(heatmap_phyla$p)),
    copy_group = factor(copy_group, levels = copy_levels)
  )

p_fraction_heatmap <- ggplot(
  heatmap_data,
  aes(x = copy_group, y = p, fill = fraction)
) +
  geom_tile(colour = "white", linewidth = 0.22) +
  geom_text(
    aes(label = if_else(fraction > 0, fmt_pct(fraction, digits = 0), "")),
    size = 1.85,
    colour = "black"
  ) +
  scale_fill_gradient(
    low = "#F7FBFF",
    high = "#084594",
    labels = percent_format(accuracy = 1),
    limits = c(0, 1)
  ) +
  labs(
    x = "Copy number per MAG",
    y = NULL,
    fill = "Fraction",
    title = "Phylum x copy-number fraction heatmap",
    subtitle = paste0("Top ", nrow(heatmap_phyla), " phyla ordered by multicopy fraction")
  ) +
  theme_nature() +
  theme(
    axis.text.y = element_text(size = 6.2),
    axis.ticks = element_blank(),
    axis.line = element_blank(),
    legend.position = "right"
  )

heatmap_height <- max(85, 32 + 5.2 * nrow(heatmap_phyla))
save_figure(
  p_fraction_heatmap,
  file.path(figure_dir, "figure_2_phylum_copy_number_fraction_heatmap"),
  width_mm = 105,
  height_mm = heatmap_height
)

write_tsv_base(
  heatmap_data,
  file.path(data_dir, "figure_2_phylum_copy_number_fraction_heatmap_source_data.tsv")
)

# Figure 3: absolute count heatmap
p_count_heatmap <- ggplot(
  heatmap_data,
  aes(x = copy_group, y = p, fill = n_mags)
) +
  geom_tile(colour = "white", linewidth = 0.22) +
  geom_text(
    aes(label = if_else(n_mags > 0, fmt_int(n_mags), "")),
    size = 1.85,
    colour = "black"
  ) +
  scale_fill_gradient(
    low = "#F7FBFF",
    high = "#084594",
    labels = comma
  ) +
  labs(
    x = "Copy number per MAG",
    y = NULL,
    fill = "MAGs",
    title = "Absolute MAG counts by phylum and copy number",
    subtitle = paste0("Top ", nrow(heatmap_phyla), " phyla ordered by multicopy fraction")
  ) +
  theme_nature() +
  theme(
    axis.text.y = element_text(size = 6.2),
    axis.ticks = element_blank(),
    axis.line = element_blank(),
    legend.position = "right"
  )

save_figure(
  p_count_heatmap,
  file.path(figure_dir, "figure_3_phylum_copy_number_absolute_count_heatmap"),
  width_mm = 105,
  height_mm = heatmap_height
)

write_tsv_base(
  heatmap_data,
  file.path(data_dir, "figure_3_phylum_copy_number_absolute_count_heatmap_source_data.tsv")
)

# Figure 4: compact overview
p_stacked_compact <- p_stacked +
  theme(
    legend.position = "top",
    plot.title = element_text(size = 7.7),
    plot.subtitle = element_blank(),
    plot.caption = element_blank()
  )

p_fraction_heatmap_compact <- p_fraction_heatmap +
  theme(
    plot.title = element_text(size = 7.7),
    plot.subtitle = element_blank()
  )

figure_overview <- p_stacked_compact | p_fraction_heatmap_compact
figure_overview <- figure_overview +
  plot_layout(widths = c(1.45, 1.00)) +
  plot_annotation(
    tag_levels = "a",
    title = "Phylum-level actin-superfamily copy-number distribution",
    caption = paste0(
      "Only actin-positive MAGs are included. Copy numbers >=", COPY_NUMBER_CAP,
      " are grouped as >=", COPY_NUMBER_CAP, "."
    )
  ) &
  theme_nature()

save_figure(
  figure_overview,
  file.path(figure_dir, "figure_4_phylum_copy_number_distribution_overview"),
  width_mm = 183,
  height_mm = max(stacked_height, heatmap_height, 110)
)

message("Completed phylum-level copy-number plotting.")
message("Input: ", normalizePath(input_file, winslash = "/"))
message("Figures: ", normalizePath(figure_dir, winslash = "/"))
message("Source data: ", normalizePath(data_dir, winslash = "/"))
