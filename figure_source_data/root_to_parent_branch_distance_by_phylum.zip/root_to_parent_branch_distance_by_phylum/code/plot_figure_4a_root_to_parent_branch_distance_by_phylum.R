#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(ggplot2))

input_file <- file.path(
  "genus_tree_LG_R9_gappyout", "plot_source_data",
  "tree_tip_attachment_metrics.tsv"
)
out_dir <- file.path("genus_tree_LG_R9_gappyout", "figures")
stem <- "figure_4a_root_to_parent_branch_distance_by_phylum"

d <- read.delim(
  input_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required <- c("label", "Phylum_plot", "root_to_parent_distance")
missing_cols <- setdiff(required, names(d))
if (length(missing_cols)) {
  stop("Missing columns: ", paste(missing_cols, collapse = ", "))
}

d$root_to_parent_distance <- suppressWarnings(
  as.numeric(d$root_to_parent_distance)
)
d <- d[
  nzchar(d$Phylum_plot) & is.finite(d$root_to_parent_distance),
  , drop = FALSE
]

phylum_levels <- unique(d$Phylum_plot)
phylum_base <- c(
  "Bacteria" = "#5B4636", "Eukaryota" = "#D73027",
  "Asgardarchaeota" = "#0072B2", "Thermoproteota" = "#D55E00",
  "Halobacteriota" = "#009E73", "Methanobacteriota" = "#CC79A7",
  "Nanoarchaeota" = "#E69F00", "Micrarchaeota" = "#56B4E9",
  "Hadarchaeota" = "#8C564B", "Hydrothermarchaeota" = "#9467BD",
  "Altiarchaeota" = "#2CA02C", "Iainarchaeota" = "#17BECF",
  "Aenigmatarchaeota" = "#BCBD22", "Undinarchaeota" = "#7F7F7F",
  "Thermoplasmatota" = "#F781BF", "Unclassified Archaea" = "#BDBDBD"
)
missing_phyla <- setdiff(phylum_levels, names(phylum_base))
if (length(missing_phyla)) {
  phylum_base <- c(
    phylum_base,
    setNames(grDevices::hcl.colors(length(missing_phyla), "Dark 3"), missing_phyla)
  )
}

medians <- tapply(
  d$root_to_parent_distance,
  d$Phylum_plot,
  median,
  na.rm = TRUE
)
d$Phylum_plot <- factor(d$Phylum_plot, levels = names(sort(medians)))

p <- ggplot(
  d,
  aes(
    x = root_to_parent_distance,
    y = Phylum_plot,
    colour = Phylum_plot
  )
) +
  geom_boxplot(
    width = 0.50,
    outlier.shape = NA,
    linewidth = 0.38,
    alpha = 0.24
  ) +
  geom_jitter(
    height = 0.14,
    width = 0,
    size = 0.65,
    alpha = 0.38
  ) +
  scale_colour_manual(values = phylum_base, guide = "none") +
  scale_x_continuous(expand = expansion(mult = c(0.015, 0.035))) +
  labs(
    title = "Displayed-tree attachment distance by phylum",
    subtitle = "Bacterial and eukaryotic sequences are each treated as one category.",
    x = "Root-to-parent branch distance",
    y = NULL,
    caption = "Distances are conditional on the displayed Newick root."
  ) +
  theme_classic(base_size = 7, base_family = "Arial") +
  theme(
    plot.title = element_text(size = 8.5, face = "bold", margin = margin(b = 2)),
    plot.subtitle = element_text(size = 6.5, colour = "#4D4D4D", margin = margin(b = 4)),
    plot.caption = element_text(size = 5.8, colour = "#555555", hjust = 0),
    axis.title.x = element_text(size = 7),
    axis.text = element_text(size = 6.2, colour = "#222222"),
    axis.text.y = element_text(margin = margin(r = 3)),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid.major.x = element_line(colour = "#E9EDF0", linewidth = 0.26),
    panel.grid.major.y = element_blank(),
    plot.margin = margin(5, 7, 4, 5)
  )

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
ggsave(
  file.path(out_dir, paste0(stem, ".pdf")),
  p,
  width = 125,
  height = 110,
  units = "mm",
  device = cairo_pdf
)
ggsave(
  file.path(out_dir, paste0(stem, "_preview.png")),
  p,
  width = 125,
  height = 110,
  units = "mm",
  dpi = 320,
  bg = "white"
)

message("Saved independent root-to-parent branch-distance panel: n=", nrow(d))
