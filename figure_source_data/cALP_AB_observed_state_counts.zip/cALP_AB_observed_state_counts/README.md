# cALP_AB_observed_state_counts

- Source figure: `fig_cALP_AB_observed_state_counts`
- Analysis basis: gappyout584 cALP A/B host states.
- Contents: final PDF/PNG, R plotting code and plotted MAG-state counts.
- Status: included; the former automated1-derived version is superseded.
- Packaging rule: files were copied; the analysis outputs were not moved.
