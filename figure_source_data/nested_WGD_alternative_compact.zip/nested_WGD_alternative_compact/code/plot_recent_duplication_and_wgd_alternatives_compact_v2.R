suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

# Figure contract
# 1) Local-duplication alternative: quantify how often the closest cALP/dALP
#    pair is demonstrably close on the same contig, including an all-copy
#    strict-clean sensitivity subset.
# 2) Simple recent genome-doubling alternative: retain all MAG-level points at
#    the two nested taxonomic scales and emphasize group medians and IQRs.
# Neither panel excludes ancient/fractionated genome-scale events or establishes
# a specific duplication mechanism.

retention_root <- ".."
pair_file <- file.path(retention_root, "data", "full342_cALP_dALP_closest_pair_context.tsv")
wgd_file <- file.path(retention_root, "data", "figure_source_data", "supp_S9_allOG_WGD_signature_map_source_data.tsv")
out_dir <- ".."

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

save_pdf_png <- function(plot, stem, width_mm, height_mm) {
  cairo_pdf(file.path(out_dir, paste0(stem, ".pdf")), width = width_mm / 25.4,
            height = height_mm / 25.4, family = "Arial")
  print(plot)
  dev.off()
  agg_png(file.path(out_dir, paste0(stem, ".png")), width = width_mm,
          height = height_mm, units = "mm", res = 450, background = "white")
  print(plot)
  dev.off()
}

# -----------------------------------------------------------------------------
# A. Local-duplication alternative: sequential count audit
# -----------------------------------------------------------------------------

pair_dat <- read_tsv(pair_file, show_col_types = FALSE)
stopifnot(nrow(pair_dat) == 342L)

local_summary <- bind_rows(
  pair_dat %>% mutate(analysis_set = "All coexist MAGs"),
  pair_dat %>% filter(all_profile_copies_strict_clean) %>%
    mutate(analysis_set = "All-copy strict-clean subset")
) %>%
  group_by(analysis_set) %>%
  summarise(
    total_MAGs = n(),
    same_contig = sum(pair_context != "different contigs"),
    same_contig_le20kb = sum(pair_context == "same contig, <=20 kb"),
    different_contigs = sum(pair_context == "different contigs"),
    .groups = "drop"
  ) %>%
  mutate(
    analysis_set = factor(
      analysis_set,
      levels = c("All-copy strict-clean subset", "All coexist MAGs")
    )
  )

stopifnot(
  local_summary$total_MAGs[local_summary$analysis_set == "All coexist MAGs"] == 342L,
  local_summary$same_contig[local_summary$analysis_set == "All coexist MAGs"] == 12L,
  local_summary$same_contig_le20kb[local_summary$analysis_set == "All coexist MAGs"] == 1L,
  local_summary$total_MAGs[local_summary$analysis_set == "All-copy strict-clean subset"] == 54L,
  local_summary$same_contig[local_summary$analysis_set == "All-copy strict-clean subset"] == 10L,
  local_summary$same_contig_le20kb[local_summary$analysis_set == "All-copy strict-clean subset"] == 0L
)

write_tsv(local_summary, file.path(out_dir, "fig_local_duplication_alternative_compact_v2_source_data.tsv"))

flow_dat <- local_summary %>%
  transmute(
    analysis_set,
    total_MAGs,
    same_contig,
    same_contig_le20kb,
    different_contigs,
    total_label = sprintf("%d\n100%%", total_MAGs),
    same_label = sprintf("%d\n%.1f%%", same_contig, 100 * same_contig / total_MAGs),
    close_label = sprintf("%d\n%.1f%%", same_contig_le20kb, 100 * same_contig_le20kb / total_MAGs)
  ) %>%
  mutate(y = if_else(analysis_set == "All coexist MAGs", 2, 1))

box_df <- bind_rows(
  flow_dat %>% transmute(analysis_set, y, stage = "Total coexist MAGs", x = 1, label = total_label),
  flow_dat %>% transmute(analysis_set, y, stage = "Closest pair on\nthe same contig", x = 2, label = same_label),
  flow_dat %>% transmute(analysis_set, y, stage = "Same-contig pair\nwithin 20 kb", x = 3, label = close_label)
) %>%
  mutate(
    stage = factor(stage, levels = c("Total coexist MAGs", "Closest pair on\nthe same contig", "Same-contig pair\nwithin 20 kb")),
    xmin = x - 0.35,
    xmax = x + 0.35,
    ymin = y - 0.27,
    ymax = y + 0.27
  )

stage_cols <- c(
  "Total coexist MAGs" = "#73879D",
  "Closest pair on\nthe same contig" = "#5FA69E",
  "Same-contig pair\nwithin 20 kb" = "#D88952"
)

p_local <- ggplot() +
  geom_segment(
    data = flow_dat,
    aes(x = 1.37, xend = 1.63, y = y, yend = y),
    linewidth = 0.55,
    colour = "#626E7A",
    arrow = grid::arrow(length = grid::unit(1.6, "mm"), type = "closed")
  ) +
  geom_segment(
    data = flow_dat,
    aes(x = 2.37, xend = 2.63, y = y, yend = y),
    linewidth = 0.55,
    colour = "#626E7A",
    arrow = grid::arrow(length = grid::unit(1.6, "mm"), type = "closed")
  ) +
  geom_rect(
    data = box_df,
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = stage),
    colour = "white",
    linewidth = 0.65
  ) +
  geom_text(
    data = box_df,
    aes(x = x, y = y + 0.01, label = label),
    family = "Arial",
    fontface = "bold",
    colour = "white",
    size = 3.0,
    lineheight = 0.90
  ) +
  geom_text(
    data = distinct(box_df, stage, x),
    aes(x = x, y = 2.48, label = as.character(stage)),
    family = "Arial",
    fontface = "bold",
    colour = "#28333F",
    size = 2.65,
    lineheight = 0.92
  ) +
  annotate("text", x = 0.18, y = 2, label = "All coexist\nMAGs", hjust = 0,
           family = "Arial", fontface = "bold", size = 2.55, colour = "#202A34") +
  annotate("text", x = 0.18, y = 1, label = "Strict-clean\nsensitivity subset", hjust = 0,
           family = "Arial", fontface = "bold", size = 2.55, colour = "#202A34") +
  annotate(
    "text", x = 1.84, y = 0.38,
    label = "Different-contig closest pairs: 330/342 and 44/54; physical separation is unresolved",
    family = "Arial", size = 2.55, colour = "#5A6571", hjust = 0.5
  ) +
  scale_fill_manual(values = stage_cols, guide = "none") +
  coord_cartesian(xlim = c(0.15, 3.45), ylim = c(0.18, 2.75), clip = "off") +
  labs(
    title = "Close same-contig cALP/dALP pairs are uncommon",
    subtitle = "Closest cross-profile pair per MAG; percentages use the row-specific MAG denominator"
  ) +
  theme_void(base_family = "Arial") +
  theme(
    plot.title = element_text(size = 8.2, face = "bold", colour = "#18212B", margin = margin(b = 1.5)),
    plot.subtitle = element_text(size = 6.1, colour = "#5A6572", margin = margin(b = 4)),
    plot.margin = margin(5, 5, 3, 5)
  )

save_pdf_png(p_local, "fig_local_duplication_alternative_compact_v2", 128, 68)

# -----------------------------------------------------------------------------
# B. Simple recent genome-doubling alternative: nested-scale scatter + summaries
# -----------------------------------------------------------------------------

wgd_dat <- read_tsv(wgd_file, show_col_types = FALSE) %>%
  mutate(
    dataset_label = recode(
      dataset,
      "Archaea1338" = "Archaea1338 (full archaeal scale)",
      "Asgard971" = "Asgard971 (nested subset)"
    ),
    dataset_label = factor(
      dataset_label,
      levels = c("Archaea1338 (full archaeal scale)", "Asgard971 (nested subset)")
    ),
    group = recode(group, "cALP+dALP coexist MAG" = "cALP+dALP coexist MAGs"),
    group = factor(group, levels = c("All other MAGs", "cALP+dALP coexist MAGs"))
  )

wgd_summary <- wgd_dat %>%
  group_by(dataset, dataset_label, group) %>%
  summarise(
    n_MAGs = n(),
    median_multicopy_fraction = median(multicopy_fraction),
    q25_multicopy_fraction = quantile(multicopy_fraction, 0.25),
    q75_multicopy_fraction = quantile(multicopy_fraction, 0.75),
    median_exact_two_share = median(exact_two_share_of_multicopy),
    q25_exact_two_share = quantile(exact_two_share_of_multicopy, 0.25),
    q75_exact_two_share = quantile(exact_two_share_of_multicopy, 0.75),
    .groups = "drop"
  )

write_tsv(wgd_summary, file.path(out_dir, "fig_nested_WGD_alternative_compact_v2_summary_source_data.tsv"))

group_cols <- c(
  "All other MAGs" = "#9AA2AA",
  "cALP+dALP coexist MAGs" = "#27776F"
)

arrow_dat <- distinct(wgd_dat, dataset_label) %>%
  mutate(x = 0.70, y = 0.555, xend = 0.90, yend = 0.875)

p_wgd <- ggplot() +
  geom_point(
    data = filter(wgd_dat, group == "All other MAGs"),
    aes(multicopy_fraction, exact_two_share_of_multicopy, colour = group),
    size = 0.65, alpha = 0.20
  ) +
  geom_point(
    data = filter(wgd_dat, group == "cALP+dALP coexist MAGs"),
    aes(multicopy_fraction, exact_two_share_of_multicopy, colour = group),
    size = 0.82, alpha = 0.50
  ) +
  geom_segment(
    data = arrow_dat,
    aes(x = x, y = y, xend = xend, yend = yend),
    inherit.aes = FALSE,
    colour = "#C0743E",
    linewidth = 0.45,
    arrow = grid::arrow(length = grid::unit(1.5, "mm"), type = "closed")
  ) +
  geom_text(
    data = arrow_dat,
    aes(x = x - 0.004, y = y - 0.015, label = "WGD-like direction"),
    inherit.aes = FALSE,
    family = "Arial", size = 2.35, colour = "#A25E31", hjust = 1
  ) +
  facet_wrap(~dataset_label, nrow = 1) +
  scale_colour_manual(values = group_cols, name = NULL) +
  guides(colour = guide_legend(override.aes = list(shape = 16, linetype = 0, size = 2.1, alpha = 1))) +
  scale_x_continuous(labels = percent_format(accuracy = 1), limits = c(0, 1.00),
                     breaks = seq(0, 1.00, 0.25), expand = expansion(mult = c(0.01, 0.01))) +
  scale_y_continuous(labels = percent_format(accuracy = 1), limits = c(0.48, 1.00),
                     breaks = c(0.50, 0.625, 0.75, 0.875, 1.00), expand = expansion(mult = c(0.01, 0.01))) +
  labs(
    title = "Coexist MAGs show more multicopy OGs but a lower exact-two share",
    subtitle = "Upper-right is the qualitative expectation for simple recent genome doubling",
    x = "Detected OGs that are multicopy",
    y = "Multicopy OGs that are exactly two-copy",
    caption = "Archaea1338 contains Asgard971; panels are nested taxonomic scales, not independent replications."
  ) +
  theme_classic(base_size = 7.0, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#303840"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#303840"),
    axis.text = element_text(size = 6.1, colour = "#4C5662"),
    axis.title = element_text(size = 6.7, colour = "#27313B"),
    strip.background = element_rect(fill = "#F3F5F7", colour = "#C6CDD5", linewidth = 0.35),
    strip.text = element_text(size = 6.6, face = "bold", colour = "#27313B", margin = margin(2.2, 2, 2.2, 2)),
    plot.title = element_text(size = 8.2, face = "bold", colour = "#18212B", margin = margin(b = 1.5)),
    plot.subtitle = element_text(size = 6.1, colour = "#5A6572", margin = margin(b = 4)),
    plot.caption = element_text(size = 5.5, colour = "#626D78", hjust = 0, margin = margin(t = 4)),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 6.0),
    legend.key.width = grid::unit(3.0, "mm"),
    panel.spacing = grid::unit(5.5, "mm"),
    plot.margin = margin(4, 5, 3, 4)
  )

save_pdf_png(p_wgd, "fig_nested_WGD_alternative_compact_v2", 178, 88)

message("Wrote compact alternative-explanation figures to: ", out_dir)
