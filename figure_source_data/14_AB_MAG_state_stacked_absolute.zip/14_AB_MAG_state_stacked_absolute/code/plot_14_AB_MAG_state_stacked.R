suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(stringr)
})

root <- ".."
source_file <- file.path(root, "tables", "Supplementary_Table_2_31_OG_sequence_MAG_lineage_details.tsv")
out_data <- file.path(root, "data", "AB_MAG_state_stacked_14_strong_supported")
out_fig <- file.path(root, "figures", "AB_MAG_state_stacked_14_strong_supported")
dir.create(out_data, recursive = TRUE, showWarnings = FALSE)
dir.create(out_fig, recursive = TRUE, showWarnings = FALSE)

all_cases <- read_tsv(source_file, show_col_types = FALSE)
stopifnot(nrow(all_cases) == 31L, !anyDuplicated(all_cases$og_id))

d <- all_cases %>%
  filter(evidence_class %in% c("strong", "supported"))

stopifnot(
  nrow(d) == 14L,
  sum(d$evidence_class == "strong") == 2L,
  sum(d$evidence_class == "supported") == 12L
)

# Use one fixed order for both figures: decreasing number of coexistence MAGs.
og_order <- d %>%
  arrange(desc(n_AB_coexist_MAG), desc(n_host_MAG), og_id) %>%
  pull(og_id)

labels_df <- d %>%
  mutate(
    function_short = str_trunc(functional_label, 32, ellipsis = "..."),
    axis_label = paste0(og_id, "\n", function_short)
  )
axis_labels <- setNames(labels_df$axis_label, labels_df$og_id)

counts <- d %>%
  transmute(
    og_id,
    evidence_class,
    `A-only` = n_A_only_MAG,
    `AB coexist` = n_AB_coexist_MAG,
    `B-only` = n_B_only_MAG
  ) %>%
  pivot_longer(
    cols = c(`A-only`, `AB coexist`, `B-only`),
    names_to = "state",
    values_to = "n_MAG"
  ) %>%
  mutate(
    og_id = factor(og_id, levels = og_order),
    state = factor(state, levels = c("A-only", "AB coexist", "B-only"))
  ) %>%
  group_by(og_id) %>%
  mutate(total_MAG = sum(n_MAG), fraction = n_MAG / total_MAG) %>%
  ungroup()

audit <- counts %>%
  group_by(og_id) %>%
  summarise(
    total_from_states = sum(n_MAG),
    coexist_from_states = n_MAG[state == "AB coexist"],
    .groups = "drop"
  ) %>%
  mutate(og_id = as.character(og_id)) %>%
  left_join(
    d %>% transmute(
      og_id,
      expected_total = n_host_MAG,
      expected_coexist = n_AB_coexist_MAG
    ),
    by = "og_id"
  ) %>%
  mutate(
    total_match = total_from_states == expected_total,
    coexist_match = coexist_from_states == expected_coexist
  )

stopifnot(all(audit$total_match), all(audit$coexist_match))

palette_state <- c(
  "A-only" = "#5F83A7",
  "AB coexist" = "#70A397",
  "B-only" = "#C57D5D"
)

theme_pub <- theme_classic(base_family = "Arial", base_size = 8) +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#202733"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#202733"),
    axis.text.x = element_text(
      angle = 52, hjust = 1, vjust = 1,
      size = 6.6, colour = "#28364A", lineheight = 0.90
    ),
    axis.text.y = element_text(size = 7.2, colour = "#28364A"),
    axis.title.x = element_blank(),
    axis.title.y = element_text(
      size = 8.8, face = "bold", colour = "#1C293C",
      margin = margin(r = 7)
    ),
    legend.position = "top",
    legend.justification = "center",
    legend.text = element_text(size = 7.2),
    legend.key.width = grid::unit(5, "mm"),
    legend.key.height = grid::unit(3.4, "mm"),
    panel.grid = element_blank(),
    plot.margin = margin(5, 6, 24, 7)
  )

p_absolute <- ggplot(counts, aes(x = og_id, y = n_MAG, fill = state)) +
  geom_col(width = 0.70, colour = "white", linewidth = 0.18) +
  scale_fill_manual(values = palette_state, name = NULL, drop = FALSE) +
  scale_x_discrete(labels = axis_labels, drop = FALSE) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.035))) +
  labs(y = "MAG count") +
  theme_pub

p_percent <- ggplot(counts, aes(x = og_id, y = fraction, fill = state)) +
  geom_col(width = 0.70, colour = "white", linewidth = 0.18) +
  scale_fill_manual(values = palette_state, name = NULL, drop = FALSE) +
  scale_x_discrete(labels = axis_labels, drop = FALSE) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(0, 1),
    breaks = seq(0, 1, 0.2),
    expand = c(0, 0)
  ) +
  labs(y = "MAG state composition (%)") +
  theme_pub

ggsave(
  file.path(out_fig, "fig_14_AB_MAG_state_stacked_absolute.pdf"),
  p_absolute, width = 235, height = 118, units = "mm",
  device = cairo_pdf, bg = "white"
)
ggsave(
  file.path(out_fig, "fig_14_AB_MAG_state_stacked_absolute.png"),
  p_absolute, width = 235, height = 118, units = "mm",
  dpi = 600, bg = "white"
)
ggsave(
  file.path(out_fig, "fig_14_AB_MAG_state_stacked_percent.pdf"),
  p_percent, width = 235, height = 118, units = "mm",
  device = cairo_pdf, bg = "white"
)
ggsave(
  file.path(out_fig, "fig_14_AB_MAG_state_stacked_percent.png"),
  p_percent, width = 235, height = 118, units = "mm",
  dpi = 600, bg = "white"
)

write_tsv(
  counts %>% arrange(og_id, state) %>% mutate(across(where(is.factor), as.character)),
  file.path(out_data, "fig_14_AB_MAG_state_stacked_counts.tsv")
)
write_tsv(
  tibble(x_position = seq_along(og_order), og_id = og_order),
  file.path(out_data, "fig_14_shared_OG_x_order.tsv")
)
write_tsv(
  labels_df %>% select(
    og_id, evidence_class, functional_label,
    functional_description, functional_confidence, axis_label
  ),
  file.path(out_data, "fig_14_AB_MAG_function_labels.tsv")
)
write_tsv(audit, file.path(out_data, "fig_14_AB_MAG_state_count_audit.tsv"))
writeLines(
  c(
    "status=PASS",
    "cases=14",
    "selection=evidence_class_in_strong_supported",
    "strong=2",
    "supported=12",
    "x_order=coexist_MAG_count_descending_then_total_MAG_descending_then_og_id",
    "states=A-only;AB coexist;B-only",
    paste0("total_counts_match=", all(audit$total_match)),
    paste0("coexist_counts_match=", all(audit$coexist_match))
  ),
  file.path(out_data, "AB_MAG_STATE_STACKED_14_COMPLETE.marker")
)
