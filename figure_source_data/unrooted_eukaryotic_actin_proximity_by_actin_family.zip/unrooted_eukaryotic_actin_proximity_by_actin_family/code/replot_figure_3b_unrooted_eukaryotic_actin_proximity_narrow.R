#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(ggplot2))

root <- ".."
data_file <- file.path(
  root, "genus_tree_LG_R9_gappyout", "plot_source_data",
  "figure_3b_unrooted_eukaryotic_actin_proximity_tip_data.tsv"
)
fig_dir <- file.path(root, "genus_tree_LG_R9_gappyout", "figures")
stem <- file.path(
  fig_dir,
  "figure_3b_unrooted_eukaryotic_actin_proximity_by_actin_family"
)

d <- read.delim(
  data_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)
required <- c(
  "label", "actin_family",
  "median_patristic_distance_to_eukaryotic_actin"
)
missing_cols <- setdiff(required, names(d))
if (length(missing_cols)) {
  stop("Missing columns: ", paste(missing_cols, collapse = ", "))
}

d$actin_family[d$actin_family == "MreB-C/ALP-N"] <- "MreB_C/ALP_N"
d$median_patristic_distance_to_eukaryotic_actin <- suppressWarnings(
  as.numeric(d$median_patristic_distance_to_eukaryotic_actin)
)
d <- d[
  nzchar(d$actin_family) &
    is.finite(d$median_patristic_distance_to_eukaryotic_actin),
  , drop = FALSE
]

family_colours <- c(
  "cALPs" = "#4C78A8",
  "dALPs" = "#4F9B8F",
  "Volactin" = "#E18D4F",
  "Salactin" = "#D6A64A",
  "MreB/Mbl-like" = "#8B6FA8",
  "MreB_C/ALP_N" = "#C77DA8",
  "FtsA/PilM-like" = "#777777",
  "Bacterial actin" = "#5B4636"
)

medians <- tapply(
  d$median_patristic_distance_to_eukaryotic_actin,
  d$actin_family,
  median,
  na.rm = TRUE
)
d$actin_family <- factor(d$actin_family, levels = names(sort(medians)))

p <- ggplot(
  d,
  aes(
    x = median_patristic_distance_to_eukaryotic_actin,
    y = actin_family,
    colour = actin_family
  )
) +
  geom_boxplot(
    width = 0.54,
    outlier.shape = NA,
    linewidth = 0.38,
    alpha = 0.22
  ) +
  geom_jitter(
    height = 0.15,
    width = 0,
    size = 0.70,
    alpha = 0.43
  ) +
  scale_colour_manual(values = family_colours, guide = "none") +
  scale_x_continuous(expand = expansion(mult = c(0.015, 0.03))) +
  labs(
    title = "Unrooted proximity to eukaryotic actin",
    subtitle = paste0(
      "Median patristic distance from each non-eukaryotic tip to ",
      "16 eukaryotic actin references."
    ),
    x = "Median patristic distance to eukaryotic actin",
    y = NULL,
    caption = paste0(
      "Shorter distances indicate closer placement in this tree; ",
      "points are individual sequences."
    )
  ) +
  theme_classic(base_size = 7, base_family = "Arial") +
  theme(
    plot.title = element_text(size = 8.8, face = "bold", margin = margin(b = 2)),
    plot.subtitle = element_text(size = 6.1, colour = "#4D4D4D", margin = margin(b = 4)),
    plot.caption = element_text(size = 5.6, colour = "#555555", hjust = 0),
    axis.title.x = element_text(size = 6.8),
    axis.text = element_text(size = 6.2, colour = "#222222"),
    axis.text.y = element_text(margin = margin(r = 3)),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid.major.x = element_line(colour = "#E9EDF0", linewidth = 0.26),
    panel.grid.major.y = element_blank(),
    plot.margin = margin(5, 6, 4, 5)
  )

ggsave(
  paste0(stem, ".pdf"),
  p,
  width = 125,
  height = 110,
  units = "mm",
  device = cairo_pdf
)
ggsave(
  paste0(stem, "_preview.png"),
  p,
  width = 125,
  height = 110,
  units = "mm",
  dpi = 320,
  bg = "white"
)

message("Saved narrow figure 3b from frozen tip-level source data: n=", nrow(d))
