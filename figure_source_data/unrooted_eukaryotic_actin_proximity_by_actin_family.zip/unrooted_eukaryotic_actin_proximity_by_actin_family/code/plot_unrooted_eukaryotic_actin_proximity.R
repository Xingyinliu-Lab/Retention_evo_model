#!/usr/bin/env Rscript

# Root-invariant placement diagnostic: median patristic distance from each
# non-eukaryotic tip to the 16 eukaryotic actin tips in the frozen genus tree.

required <- c("ape", "ggplot2")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing R packages: ", paste(missing, collapse = ", "))
suppressPackageStartupMessages({ library(ape); library(ggplot2) })

root <- ".."
tree_file <- file.path(root, "genus_tree_LG_R9_gappyout", "trimmed_genus_resample_sequences_euk_bac_LG_R9_gappyout_thorough.treefile")
meta_file <- file.path(root, "genus_tree", "meta.txt")
out_dir <- file.path(root, "genus_tree_LG_R9_gappyout")
fig_dir <- file.path(out_dir, "figures")
data_dir <- file.path(out_dir, "plot_source_data")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

tree <- read.tree(tree_file)
meta <- read.delim(meta_file, check.names = FALSE, stringsAsFactors = FALSE)
meta <- meta[match(tree$tip.label, meta$label), , drop = FALSE]
if (anyNA(meta$label)) stop("Some tree tips are absent from meta.txt.")

family_display_map <- c(
  "canonical Actin-like" = "cALPs",
  "Crenactin-like / archaeal actin" = "dALPs",
  "Volactin" = "Volactin", "Salactin" = "Salactin",
  "MreB/Mbl-like" = "MreB/Mbl-like", "MreB-like_C/ALP_N-related" = "MreB-C/ALP-N",
  "FtsA/PilM-like" = "FtsA/PilM-like", "Bacteria_actin" = "Bacterial actin"
)
family_colours <- c(
  "cALPs" = "#4C78A8", "dALPs" = "#4F9B8F", "Volactin" = "#E18D4F",
  "Salactin" = "#D6A64A", "MreB/Mbl-like" = "#8B6FA8", "MreB-C/ALP-N" = "#C77DA8",
  "FtsA/PilM-like" = "#777777", "Bacterial actin" = "#5B4636"
)

euk <- which(meta$actin_family_class == "Eukaryota_actin")
target <- which(meta$actin_family_class != "Eukaryota_actin")
if (length(euk) == 0L) stop("No eukaryotic actin tips found.")
distances <- cophenetic.phylo(tree)
tip_medians <- apply(distances[target, euk, drop = FALSE], 1L, median)
plot_data <- data.frame(
  label = meta$label[target],
  actin_family = unname(family_display_map[meta$actin_family_class[target]]),
  median_patristic_distance_to_eukaryotic_actin = as.numeric(tip_medians),
  n_eukaryotic_references = length(euk),
  stringsAsFactors = FALSE
)
plot_data$actin_family <- factor(plot_data$actin_family, levels = names(sort(tapply(
  plot_data$median_patristic_distance_to_eukaryotic_actin, plot_data$actin_family, median
))))
summary_data <- do.call(rbind, lapply(levels(plot_data$actin_family), function(x) {
  z <- plot_data$median_patristic_distance_to_eukaryotic_actin[plot_data$actin_family == x]
  data.frame(actin_family = x, n_tips = length(z), median = median(z), q1 = unname(quantile(z, 0.25)), q3 = unname(quantile(z, 0.75)))
}))
write.table(plot_data, file.path(data_dir, "figure_3b_unrooted_eukaryotic_actin_proximity_tip_data.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(summary_data, file.path(data_dir, "figure_3b_unrooted_eukaryotic_actin_proximity_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

p <- ggplot(plot_data, aes(x = median_patristic_distance_to_eukaryotic_actin, y = actin_family, colour = actin_family)) +
  geom_boxplot(width = 0.56, outlier.shape = NA, linewidth = 0.38, alpha = 0.22) +
  geom_jitter(height = 0.15, width = 0, size = 0.75, alpha = 0.45) +
  scale_colour_manual(values = family_colours, guide = "none") +
  labs(
    title = "Unrooted phylogenetic proximity to eukaryotic actin",
    subtitle = "For each non-eukaryotic tip: median patristic distance to 16 eukaryotic actin reference tips",
    x = "Median patristic distance to eukaryotic actin", y = NULL,
    caption = "Shorter distances indicate closer placement in this tree; boxes show medians and interquartile ranges, points are individual sequences."
  ) +
  theme_classic(base_size = 9, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 9), axis.text = element_text(size = 8, colour = "black"),
    plot.title = element_text(size = 11, face = "bold"), plot.subtitle = element_text(size = 8, colour = "#444444"),
    plot.caption = element_text(size = 7, colour = "#444444", hjust = 0), plot.margin = margin(6, 8, 6, 6)
  )

stem <- file.path(fig_dir, "figure_3b_unrooted_eukaryotic_actin_proximity_by_actin_family")
ggsave(paste0(stem, ".pdf"), p, width = 180, height = 110, units = "mm", device = cairo_pdf)
ggsave(paste0(stem, "_preview.png"), p, width = 180, height = 110, units = "mm", dpi = 300, bg = "white")
message("Saved: ", normalizePath(paste0(stem, ".pdf"), winslash = "/"))
