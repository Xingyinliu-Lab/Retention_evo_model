# 3b_unrooted_eukaryotic_actin_proximity_by_actin_family

- Manuscript panel: Supp.Fig.3B
- Source figure basename: figure_3b_unrooted_eukaryotic_actin_proximity_by_actin_family
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 2 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 4 directly referenced or locally packaged source-data file(s)
