#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(readr)
  library(ragg)
  library(stringr)
})

root <- ".."
data_dir <- file.path(root, "current_canonical_tail", "data")
figure_dir <- file.path(root, "current_canonical_tail", "figures")

all524 <- read_tsv(
  file.path(data_dir, "nonnetwork_positive_524_function_classification_20260826.tsv"),
  show_col_types = FALSE
)
axis_old <- read_tsv(
  file.path(data_dir, "fig_nonnetwork_pos_top100_gtdb_r226_axis_source.tsv"),
  show_col_types = FALSE
)

evidence_columns <- c(
  "functional_description_summary", "eggnog_top_preferred_names",
  "eggnog_top_descriptions", "eggnog_top_cog_categories",
  "eggnog_top_kegg_ko", "eggnog_top_kegg_pathway",
  "hmmscan_pfam_top_domains", "hmmscan_pfam_top_domain_desc",
  "hmmscan_pfam_best_domain", "hmmscan_pfam_best_domain_desc",
  "annotation_text"
)

refined <- all524 %>%
  rowwise() %>%
  mutate(
    secondary_annotation_evidence = str_to_lower(paste(
      coalesce(c_across(all_of(evidence_columns)), ""), collapse = " | "
    )),
    refinement_rule = case_when(
      functional_group_v2 != "unresolved_function" ~ "original_v2_assignment",
      str_detect(secondary_annotation_evidence, "roadblock/?lc7|roadblock lc7") ~
        "Roadblock/LC7 domain",
      str_detect(
        secondary_annotation_evidence,
        "ribonuclease iii|thump domain|d hh family|dhh family|recj|nura domain|rho termination factor|ribbon-helix-helix|double zinc ribbon|zinc-ribbon domain|non-smc mitotic condensation|ribosome biogenesis protein"
      ) ~ "information-processing domain",
      str_detect(
        secondary_annotation_evidence,
        "yip1 domain|oligosaccharyltransferase subunit 5|emc3/tmco1"
      ) ~ "membrane-system domain",
      str_detect(
        secondary_annotation_evidence,
        "pyridoxamine 5'-phosphate oxidase"
      ) ~ "metabolic enzyme domain",
      annotation_status == "unknown_or_no_hit" ~ "no eggNOG or clean-Pfam hit",
      TRUE ~ "annotation present but function remains nonspecific"
    ),
    refined_functional_group = case_when(
      functional_group_v2 != "unresolved_function" ~ functional_group_v2,
      refinement_rule == "Roadblock/LC7 domain" ~ "structural_scaffold",
      refinement_rule == "information-processing domain" ~ "information_processing",
      refinement_rule == "membrane-system domain" ~ "transport_membrane",
      refinement_rule == "metabolic enzyme domain" ~ "metabolism",
      refinement_rule == "no eggNOG or clean-Pfam hit" ~ "no_detectable_annotation",
      TRUE ~ "conserved_uncharacterized"
    ),
    refinement_confidence = case_when(
      functional_group_v2 != "unresolved_function" ~ "frozen_v2",
      refinement_rule %in% c("information-processing domain", "membrane-system domain",
                             "metabolic enzyme domain") ~ "moderate_high",
      refinement_rule == "Roadblock/LC7 domain" ~ "moderate",
      TRUE ~ "not_functionally_assigned"
    )
  ) %>%
  ungroup()

stopifnot(
  nrow(refined) == 524,
  n_distinct(refined$OG) == 524,
  sum(all524$functional_group_v2 == "unresolved_function") == 110,
  sum(refined$refined_functional_group == "no_detectable_annotation") == 68
)

fine_labels <- c(
  "information_processing" = "Genetic information processing",
  "no_detectable_annotation" = "No annotation detected",
  "conserved_uncharacterized" = "Conserved, function uncharacterized",
  "metabolism" = "Metabolism",
  "energy_redox" = "Energy and redox",
  "transport_membrane" = "Transport and membrane",
  "membrane_trafficking_remodeling_division" =
    "Membrane trafficking, remodeling and division",
  "cytoskeleton_cell_shape_motility" =
    "Cytoskeleton, cell shape and motility",
  "cell_surface_envelope_secretion" =
    "Cell surface, envelope and secretion",
  "protein_homeostasis" = "Protein homeostasis",
  "defense_mobile_genetic_elements" =
    "Defense and mobile genetic elements",
  "structural_scaffold" = "Structural scaffold",
  "signaling_regulation" = "Signaling and regulation"
)
broad_labels <- c(
  "information_processing" = "Nuclear-information regulation",
  "cytoskeleton_cell_shape_motility" = "Cytoskeletal-cellular architecture",
  "structural_scaffold" = "Cytoskeletal-cellular architecture",
  "membrane_trafficking_remodeling_division" = "Membrane-trafficking dynamics",
  "transport_membrane" = "Membrane-trafficking dynamics",
  "cell_surface_envelope_secretion" = "Membrane-trafficking dynamics",
  "signaling_regulation" = "Membrane-trafficking dynamics",
  "protein_homeostasis" = "Proteostasis-metabolism-stress",
  "metabolism" = "Proteostasis-metabolism-stress",
  "energy_redox" = "Proteostasis-metabolism-stress",
  "defense_mobile_genetic_elements" = "Proteostasis-metabolism-stress",
  "no_detectable_annotation" = "Unresolved / uncharacterized",
  "conserved_uncharacterized" = "Unresolved / uncharacterized"
)
broad_levels <- c(
  "Nuclear-information regulation",
  "Cytoskeletal-cellular architecture",
  "Membrane-trafficking dynamics",
  "Proteostasis-metabolism-stress",
  "Unresolved / uncharacterized"
)
broad_colors <- c(
  "Nuclear-information regulation" = "#B97A56",
  "Cytoskeletal-cellular architecture" = "#4F86B5",
  "Membrane-trafficking dynamics" = "#69A17A",
  "Proteostasis-metabolism-stress" = "#8B78AE",
  "Unresolved / uncharacterized" = "#9A9A9A"
)

refined <- refined %>%
  mutate(
    refined_fine_function = unname(fine_labels[refined_functional_group]),
    refined_broad_function = unname(broad_labels[refined_functional_group])
  )
stopifnot(!anyNA(refined$refined_fine_function), !anyNA(refined$refined_broad_function))

top100 <- refined %>% filter(nonnetwork_rank <= 100)
unresolved_audit <- refined %>%
  filter(functional_group_v2 == "unresolved_function") %>%
  select(
    OG, nonnetwork_rank, formal_integrated_rank, annotation_status,
    has_eggnog_annotation, has_hmmscan_pfam,
    functional_subgroup_v2, functional_description_summary,
    eggnog_top_preferred_names, eggnog_top_descriptions,
    hmmscan_pfam_best_domain, hmmscan_pfam_best_domain_desc,
    refinement_rule, refined_functional_group, refinement_confidence
  )

write_tsv(
  refined,
  file.path(data_dir, "nonnetwork_positive_524_function_classification_refined_20260826.tsv")
)
write_tsv(
  unresolved_audit,
  file.path(data_dir, "unresolved110_secondary_reclassification_audit_20260826.tsv")
)

count_source <- function(tbl, scope) {
  tbl %>%
    mutate(
      plot_function_group = if_else(
        refined_functional_group %in% c(
          "no_detectable_annotation", "conserved_uncharacterized"
        ),
        "Unresolved / uncharacterized",
        refined_fine_function
      )
    ) %>%
    count(plot_function_group, name = "og_n") %>%
    mutate(total_og_n = nrow(tbl), fraction = og_n / total_og_n, scope = scope) %>%
    arrange(plot_function_group == "Unresolved / uncharacterized", desc(og_n),
            plot_function_group)
}
top_counts <- count_source(top100, "Top 100 after network exclusion")
all_counts <- count_source(refined, "All 524 after network exclusion")
write_tsv(top_counts, file.path(data_dir, "fig_nonnetwork_pos_top100_function_counts_refined_source.tsv"))
write_tsv(all_counts, file.path(data_dir, "fig_nonnetwork_pos_all524_function_counts_refined_source.tsv"))

theme_pub <- theme_classic(base_size = 9, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#333333"),
    plot.title = element_text(size = 10.5, face = "bold"),
    plot.subtitle = element_text(size = 8.5, colour = "#555555"),
    plot.margin = margin(7, 9, 7, 7)
  )

plot_counts <- function(counts, title, output_stem) {
  display_order <- counts$plot_function_group
  pdat <- counts %>%
    mutate(plot_function_group = factor(
      plot_function_group, levels = rev(display_order)
    ))
  p <- ggplot(pdat, aes(og_n, plot_function_group)) +
    geom_col(width = 0.68, fill = "#5E87A6") +
    geom_text(
      aes(label = sprintf("%d (%.1f%%)", og_n, 100 * fraction)),
      hjust = -0.08, size = 2.7, family = "Arial", colour = "#333333"
    ) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.22)),
                       breaks = scales::pretty_breaks(n = 5)) +
    labs(
      x = "Number of positive OGs", y = NULL, title = title,
      subtitle = "Formal 91-OG actin-network set excluded; secondary annotation audit applied"
    ) + theme_pub
  ggsave(file.path(figure_dir, paste0(output_stem, ".pdf")), p,
         width = 178, height = 116, units = "mm", device = cairo_pdf)
  ggsave(file.path(figure_dir, paste0(output_stem, ".png")), p,
         width = 178, height = 116, units = "mm", dpi = 600, device = agg_png)
}

plot_counts(
  top_counts, "Refined functional composition of the top 100 non-network positive OGs",
  "fig_nonnetwork_pos_top100_function_class_counts_refined"
)
plot_counts(
  all_counts, "Refined functional composition of all 524 non-network positive OGs",
  "fig_nonnetwork_pos_all524_function_class_counts_refined"
)

axis_source <- axis_old %>%
  select(-any_of(c("broad_function", "fine_function", "y_base", "y_offset", "y_plot"))) %>%
  left_join(
    select(refined, OG, refined_functional_group, refined_fine_function,
           refined_broad_function, refinement_rule, refinement_confidence),
    by = "OG"
  ) %>%
  mutate(
    refined_broad_function = factor(refined_broad_function, levels = broad_levels),
    y_base = unname(setNames(5:1, broad_levels)[as.character(refined_broad_function)]),
    y_offset = ave(
      seq_along(OG), refined_broad_function, axis_position_shared,
      FUN = function(z) seq(-0.11, 0.11, length.out = length(z))
    ),
    y_plot = y_base + y_offset,
    label_text = if_else(
      is.na(functional_description_summary) | functional_description_summary == "",
      OG, paste0(OG, " | ", str_trunc(functional_description_summary, 34))
    )
  )

stopifnot(nrow(axis_source) == 100, n_distinct(axis_source$OG) == 100,
          !anyNA(axis_source$refined_broad_function))

labels <- axis_source %>%
  group_by(refined_broad_function) %>%
  arrange(formal_integrated_rank, OG, .by_group = TRUE) %>%
  slice_head(n = 3) %>%
  ungroup()
write_tsv(axis_source, file.path(data_dir, "fig_nonnetwork_pos_top100_gtdb_r226_axis_refined_source.tsv"))
write_tsv(labels, file.path(data_dir, "fig_nonnetwork_pos_top100_gtdb_r226_axis_refined_labels.tsv"))

p_axis <- ggplot(axis_source, aes(axis_position_shared, y_plot)) +
  geom_segment(
    aes(x = 0, xend = axis_position_shared, yend = y_plot,
        colour = refined_broad_function), linewidth = 0.45, alpha = 0.42
  ) +
  geom_point(aes(colour = refined_broad_function, size = n_mags_present), alpha = 0.82) +
  geom_point(data = labels, shape = 21, fill = "white", colour = "#202020",
             stroke = 0.55, size = 2.3) +
  geom_text_repel(
    data = labels, aes(label = label_text), family = "Arial", size = 2.2,
    colour = "#252525", min.segment.length = 0, segment.size = 0.25,
    box.padding = 0.24, point.padding = 0.16, max.overlaps = Inf, seed = 20260826
  ) +
  scale_colour_manual(values = broad_colors, drop = FALSE) +
  scale_size_continuous(range = c(1.4, 4.2), breaks = c(20, 100, 300, 600)) +
  scale_y_continuous(breaks = 5:1, labels = broad_levels, limits = c(0.55, 5.45)) +
  scale_x_continuous(
    limits = c(0, 1), breaks = c(0, 0.22, 0.50, 0.78, 1),
    labels = c("Shared stem", "Early", "Intermediate", "Late", "Tips"),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  labs(
    x = "GTDB r226 MRCA position on the shared archaeal axis", y = NULL,
    colour = "Compressed function", size = "MAGs present",
    title = "Phylogenetic distribution of the top 100 non-network positive OGs",
    subtitle = "Five compressed classes after secondary annotation audit"
  ) + theme_pub +
  theme(
    panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E2E2E2"),
    axis.line.y = element_blank(), axis.ticks.y = element_blank(),
    legend.position = "right"
  )

ggsave(
  file.path(figure_dir, "fig_nonnetwork_pos_top100_gtdb_r226_function_axis_five_classes_refined.pdf"),
  p_axis, width = 183, height = 126, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_nonnetwork_pos_top100_gtdb_r226_function_axis_five_classes_refined.png"),
  p_axis, width = 183, height = 126, units = "mm", dpi = 600, device = agg_png
)

audit_summary <- unresolved_audit %>%
  count(refinement_rule, refined_functional_group, refinement_confidence, name = "og_n") %>%
  arrange(desc(og_n), refinement_rule)
write_tsv(
  audit_summary,
  file.path(data_dir, "unresolved110_secondary_reclassification_summary_20260826.tsv")
)

message("original_unresolved_n=", nrow(unresolved_audit))
message("reassigned_to_known_group_n=", sum(
  unresolved_audit$refined_functional_group %in% c(
    "information_processing", "structural_scaffold", "transport_membrane", "metabolism"
  )
))
message("conserved_uncharacterized_n=", sum(
  unresolved_audit$refined_functional_group == "conserved_uncharacterized"
))
message("no_detectable_annotation_n=", sum(
  unresolved_audit$refined_functional_group == "no_detectable_annotation"
))
