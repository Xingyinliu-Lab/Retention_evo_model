#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(ragg)
})

root <- ".."
data_dir <- file.path(root, "current_canonical_tail", "data")
figure_dir <- file.path(root, "current_canonical_tail", "figures")
manuscript_dir <- paste0(
  "..",
  "fig8_actin_og"
)
source_path <- file.path(
  data_dir, "fig_nonnetwork_pos_top100_function_counts_refined_source.tsv"
)

counts <- read_tsv(source_path, show_col_types = FALSE) %>%
  mutate(
    plot_function_group = recode(
      plot_function_group,
      "Information processing" = "Genetic information processing"
    )
  )

stopifnot(
  nrow(counts) > 0,
  sum(counts$og_n) == 100,
  sum(counts$plot_function_group == "Genetic information processing") == 1
)
write_tsv(counts, source_path)

display_order <- counts$plot_function_group
pdat <- counts %>%
  mutate(
    plot_function_group = factor(
      plot_function_group, levels = rev(display_order)
    )
  )

p <- ggplot(pdat, aes(og_n, plot_function_group)) +
  geom_col(width = 0.68, fill = "#5E87A6") +
  geom_text(
    aes(label = sprintf("%d (%.1f%%)", og_n, 100 * fraction)),
    hjust = -0.08, size = 2.7, family = "Arial", colour = "#333333"
  ) +
  scale_x_continuous(
    expand = expansion(mult = c(0, 0.22)),
    breaks = scales::pretty_breaks(n = 5)
  ) +
  labs(
    x = "Number of positive OGs", y = NULL,
    title = "Refined functional composition of the top 100 non-network positive OGs",
    subtitle = "Formal 91-OG actin-network set excluded; secondary annotation audit applied"
  ) +
  theme_classic(base_size = 9, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#333333"),
    plot.title = element_text(size = 10.5, face = "bold"),
    plot.subtitle = element_text(size = 8.5, colour = "#555555"),
    plot.margin = margin(7, 9, 7, 7)
  )

stem <- file.path(
  figure_dir, "fig_nonnetwork_pos_top100_function_class_counts_refined"
)
ggsave(
  paste0(stem, ".pdf"), p,
  width = 178, height = 116, units = "mm", device = cairo_pdf
)
ggsave(
  paste0(stem, ".png"), p,
  width = 178, height = 116, units = "mm", dpi = 600,
  device = agg_png, bg = "white"
)
file.copy(paste0(stem, ".pdf"), manuscript_dir, overwrite = TRUE)
file.copy(paste0(stem, ".png"), manuscript_dir, overwrite = TRUE)

message("Updated display label only: Genetic information processing")
