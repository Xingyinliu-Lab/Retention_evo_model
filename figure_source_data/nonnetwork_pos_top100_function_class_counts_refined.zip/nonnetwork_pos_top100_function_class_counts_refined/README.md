# nonnetwork_pos_top100_function_class_counts_refined

- Manuscript panel: Fig.8B
- Source figure basename: fig_nonnetwork_pos_top100_function_class_counts_refined
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 3 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 16 directly referenced or locally packaged source-data file(s)
