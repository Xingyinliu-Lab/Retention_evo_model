# model_AIC_root_corrected_five_models_unit_topology_log_spacing

- Manuscript panel: Supp.Fig.11D
- Source figure basename: model_AIC_root_corrected_five_models_unit_topology_log_spacing
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 7 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 23 directly referenced or locally packaged source-data file(s)
