# mreb_alp_five_model_AIC_GTDB_unit_vs_source_branch_lengths_dual_axis

- Manuscript panel: Supp.Fig.12C
- Source figure basename: fig_mreb_alp_five_model_AIC_GTDB_unit_vs_source_branch_lengths_dual_axis
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 13 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 30 directly referenced or locally packaged source-data file(s)
