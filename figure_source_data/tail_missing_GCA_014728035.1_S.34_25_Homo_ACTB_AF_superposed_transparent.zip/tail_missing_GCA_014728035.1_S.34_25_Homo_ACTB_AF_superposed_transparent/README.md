# tail_missing_GCA_014728035.1_S.34_25_Homo_ACTB_AF_superposed_transparent

- Manuscript panel: Supp.Fig.6G
- Source figure basename: tail_missing_GCA_014728035.1_S.34_25_Homo_ACTB_AF_superposed_transparent
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 4 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 12 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
