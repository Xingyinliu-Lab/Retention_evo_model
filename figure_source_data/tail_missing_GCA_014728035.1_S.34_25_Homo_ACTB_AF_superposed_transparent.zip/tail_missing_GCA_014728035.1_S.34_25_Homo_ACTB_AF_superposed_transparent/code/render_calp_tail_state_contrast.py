"""Three individual cALP tail-state renderings in the B-panel fixed ACTB pose.

The structural superposition is display-only.  Tail state and score metadata
are copied from the frozen score table; no evolutionary direction is inferred.
"""
from math import acos, degrees, sqrt
from pathlib import Path
import csv
import json
import os
from pymol import cmd

ROOT = Path(r"..")
TAIL_ROOT = ROOT / "actin_tail_analysis"
AF_ROOT = ROOT / "complex_assess/data/alphafold_server_predicted_structure/downloaded"
OUT = TAIL_ROOT / "3Dstructure/pymol_cALP_tail_state_contrast"
OUT.mkdir(exist_ok=True)
SCORE_TSV = TAIL_ROOT / "tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv"
TAIL_META_TSV = TAIL_ROOT / "seq_meta_with_tail_hmm386_410.tsv"
POSE = ROOT / "8F8P/cif_vis/8VKH.cif"
ACTB_AF = TAIL_ROOT / "3Dstructure/Homo_actb_AF-P60709-F1-model_v6.cif"
transparent_bg = os.environ.get("PYMOL_TRANSPARENT_BG", "0") == "1"
actb_transparency = float(os.environ.get("ACTB_CARTOON_TRANSPARENCY", "0.70"))
render_tail_mapped = os.environ.get("RENDER_TAIL_MAPPED", "1") == "1"
render_only = os.environ.get("PYMOL_RENDER_ONLY", "0") == "1"
suffix = "_transparent" if transparent_bg else ""

CASES = [
    ("high_euk_like", "GCA_011364925.1_S.32_45", "fold_gca_011364925_1_s_32_45"),
    ("intermediate", "GCA_011364925.1_S.16_84", "fold_gca_011364925_1_s_16_84"),
    ("low_divergent", "GCA_011364925.1_S.90_9", "fold_gca_011364925_1_s_90_9"),
    ("tail_missing", "GCA_014728035.1_S.34_25", "fold_gca_014728035_1_s_34_25"),
]
MODEL_OVERRIDES = {
    "fold_gca_011364925_1_s_16_84": TAIL_ROOT / "3Dstructure/fold_gca_011364925_1_s_16_84_model_0.cif",
}

def centroid(selection):
    atoms = cmd.get_model(selection).atom
    return [sum(atom.coord[i] for atom in atoms) / len(atoms) for i in range(3)]

def define_style():
    cmd.set_color("ink", [0.071, 0.094, 0.133])
    cmd.set_color("actb_green", [0.20, 0.78, 0.47])
    cmd.set_color("tail_orange", [0.96, 0.40, 0.10])
    cmd.set_color("terminal_magenta", [0.90, 0.23, 0.53])
    cmd.set_color("query_tail_cyan", [0.32, 0.72, 0.85])
    for i in range(75):
        t = i / 74
        start, end = [0.298, 0.471, 0.659], [0.420, 0.620, 0.700]
        cmd.set_color(f"blue_{i:02d}", [start[k] * (1-t) + end[k] * t for k in range(3)])
    cmd.bg_color("ink")
    cmd.set("ray_opaque_background", 0 if transparent_bg else 1); cmd.set("orthoscopic", 0)
    cmd.set("ambient", 0.20); cmd.set("direct", 0.80); cmd.set("specular", 0.32)
    cmd.set("shininess", 40); cmd.set("ray_shadows", 1); cmd.set("ambient_occlusion_mode", 2)
    cmd.set("cartoon_fancy_helices", 1)

def apply_blue_gradient(obj):
    residues = sorted({int(atom.resi) for atom in cmd.get_model(obj).atom if atom.resi.lstrip("-").isdigit()})
    first, last = residues[0], residues[-1]
    for i in range(75):
        low = first + (last-first+1)*i//75
        high = first + (last-first+1)*(i+1)//75 - 1
        cmd.color(f"blue_{i:02d}", f"{obj} and resi {low}-{high}")

with SCORE_TSV.open(newline="", encoding="utf-8") as handle:
    score_rows = {row["seq"]: row for row in csv.DictReader(handle, delimiter="\t")}
with TAIL_META_TSV.open(newline="", encoding="utf-8") as handle:
    tail_meta_rows = {row["seq"]: row for row in csv.DictReader(handle, delimiter="\t")}

def query_tail_residue_selections(seq):
    """Map non-gap HMM386-410 residues to the model's sequence numbering."""
    row = tail_meta_rows[seq]
    aligned = row["tail_aligned"]
    nongap = aligned.replace("-", "")
    if not nongap:
        return "", "", ""
    start = row["aa_seq"].rfind(nongap)
    if start < 0:
        raise ValueError(f"C-terminal HMM sequence not found in {seq}")
    body, terminal, actual_positions = [], [], []
    residue = start + 1
    for hmm_position, character in enumerate(aligned, start=386):
        if character == "-":
            continue
        actual_positions.append(str(residue))
        (body if hmm_position <= 407 else terminal).append(str(residue))
        residue += 1
    return "+".join(body), "+".join(terminal), "+".join(actual_positions)

records = []
requested_state = os.environ.get("CALP_TAIL_STATE", "").strip()
for state, seq, stem in CASES:
    if requested_state and state != requested_state:
        continue
    model_dir = AF_ROOT / stem
    model_file = MODEL_OVERRIDES.get(stem, model_dir / f"{stem}_model_0.cif")
    confidence_file = model_dir / f"{stem}_summary_confidences_0.json"
    if confidence_file.exists():
        with confidence_file.open(encoding="utf-8") as handle:
            confidence = json.load(handle)
        ptm = confidence.get("ptm")
        confidence_source = str(confidence_file)
    else:
        ptm = "not_provided_with_CIF"
        confidence_source = "not_provided_with_CIF"
    row = score_rows[seq]

    cmd.reinitialize(); define_style()
    cmd.load(str(POSE), "pose_ref")
    cmd.load(str(ACTB_AF), "actb_af")
    cmd.load(str(model_file), "calp")
    cmd.align("actb_af", "pose_ref and chain E")
    cmd.super("calp", "actb_af")
    core = centroid("pose_ref and chain E and resi 1-340 and not hydro")
    tail = centroid("pose_ref and chain E and resi 351-375 and not hydro")
    vector = [tail[i] - core[i] for i in range(3)]
    norm = sqrt(sum(x*x for x in vector)); vector = [x/norm for x in vector]
    target = [-0.36, 0.20, 0.91]
    norm = sqrt(sum(x*x for x in target)); target = [x/norm for x in target]
    axis = [vector[1]*target[2]-vector[2]*target[1], vector[2]*target[0]-vector[0]*target[2], vector[0]*target[1]-vector[1]*target[0]]
    norm = sqrt(sum(x*x for x in axis)); axis = [x/norm for x in axis]
    angle = degrees(acos(max(-1.0, min(1.0, sum(vector[i]*target[i] for i in range(3))))))
    for obj in ("actb_af", "calp"):
        cmd.translate([-core[0], -core[1], -core[2]], obj, camera=0)
        cmd.rotate(axis, angle, obj, camera=0)
    cmd.dss("actb_af")
    mean_plddt = sum(atom.b for atom in cmd.get_model("calp and name CA").atom) / len(cmd.get_model("calp and name CA").atom)
    cmd.hide("everything")
    cmd.show("cartoon", "actb_af"); cmd.color("actb_green", "actb_af")
    cmd.set("cartoon_transparency", actb_transparency, "actb_af")
    cmd.color("tail_orange", "actb_af and resi 351-372")
    cmd.color("terminal_magenta", "actb_af and resi 373-375")
    cmd.show("cartoon", "calp"); apply_blue_gradient("calp")
    cmd.zoom("actb_af or calp", 6)
    output = OUT / f"{state}_{seq}_Homo_ACTB_AF_superposed{suffix}.png"
    cmd.ray(2400, 1800); cmd.png(str(output), dpi=300)
    body_residues, terminal_residues, all_tail_residues = query_tail_residue_selections(seq)
    mapped_output = ""
    if render_tail_mapped:
        if body_residues:
            cmd.color("query_tail_cyan", f"calp and resi {body_residues}")
        if terminal_residues:
            cmd.color("terminal_magenta", f"calp and resi {terminal_residues}")
        mapped_output = OUT / f"{state}_{seq}_Homo_ACTB_AF_superposed_tail_mapped{suffix}.png"
        cmd.ray(2400, 1800); cmd.png(str(mapped_output), dpi=300)
    records.append({
        "state": state, "seq": seq, "mag_id": row["mag_id"], "actin_family_class_frozen": row["actin_family_class"],
        "tail_class": row["tail_class"], "tail_aligned_HMM386_410": row["tail_aligned"],
        "tail_coverage_positions_25": f"{row['tail_nogap_len']}/25", "tail_coverage_fraction": float(row["tail_nogap_len"])/25,
        "tail_euk_pssm_score_gap_penalty": row["tail_euk_pssm_score_gap_penalty"], "af_model": str(model_file),
        "af_mean_pLDDT_CA": mean_plddt, "af_pTM": ptm, "render_png": str(output),
        "render_tail_mapped_png": str(mapped_output), "query_tail_mapped_model_residues": all_tail_residues,
        "tail_score_source": str(SCORE_TSV), "confidence_source": confidence_source,
        "visual_alignment": "PyMOL super to Homo ACTB-AF, then shared 8F8P fixed-pose transform; display only",
    })

if not render_only:
    metadata_tsv = OUT / "cALP_tail_state_representative_metadata.tsv"
    existing = {}
    if metadata_tsv.exists():
        with metadata_tsv.open(newline="", encoding="utf-8") as handle:
            first_line = handle.readline()
            handle.seek(0)
            existing_delimiter = "\t" if "\t" in first_line else ","
            existing = {row["state"]: row for row in csv.DictReader(handle, delimiter=existing_delimiter)}
    for record in records:
        existing[record["state"]] = record
    fieldnames = []
    for record in list(existing.values()) + records:
        for key in record:
            if key not in fieldnames:
                fieldnames.append(key)
    with metadata_tsv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader(); writer.writerows(existing[key] for key, _, _ in CASES if key in existing)
cmd.quit()
