"""Render remaining cALP tail-only close-ups in the approved high-state style."""
from math import acos, degrees, sqrt
from pathlib import Path
import os
from pymol import cmd

ROOT = Path(r"..")
TAIL = ROOT / "actin_tail_analysis"
AFROOT = ROOT / "complex_assess/data/alphafold_server_predicted_structure/downloaded"
POSE = ROOT / "8F8P/cif_vis/8VKH.cif"
ACTB = TAIL / "3Dstructure/Homo_actb_AF-P60709-F1-model_v6.cif"
OUT = TAIL / "3Dstructure/pymol_cALP_tail_state_contrast"
transparent_bg = os.environ.get("PYMOL_TRANSPARENT_BG", "0") == "1"
actb_transparency = float(os.environ.get("ACTB_CARTOON_TRANSPARENCY", "0.70"))
suffix = "_transparent" if transparent_bg else ""
CASES = {
    "intermediate": ("GCA_011364925.1_S.16_84", TAIL / "3Dstructure/fold_gca_011364925_1_s_16_84_model_0.cif"),
    "low_divergent": ("GCA_011364925.1_S.90_9", AFROOT / "fold_gca_011364925_1_s_90_9/fold_gca_011364925_1_s_90_9_model_0.cif"),
    "tail_missing": ("GCA_014728035.1_S.34_25", AFROOT / "fold_gca_014728035_1_s_34_25/fold_gca_014728035_1_s_34_25_model_0.cif"),
}

def centroid(selection):
    atoms = cmd.get_model(selection).atom
    return [sum(atom.coord[i] for atom in atoms) / len(atoms) for i in range(3)]

state = os.environ["CALP_TAIL_STATE"]
seq, model = CASES[state]
cmd.reinitialize()
cmd.set_color("ink", [0.071, 0.094, 0.133]); cmd.set_color("actb_green", [0.20, 0.78, 0.47])
cmd.set_color("query_blue", [0.298, 0.471, 0.659]); cmd.set_color("tail_orange", [0.96, 0.40, 0.10])
cmd.set_color("terminal_magenta", [0.90, 0.23, 0.53]); cmd.bg_color("ink")
cmd.set("ray_opaque_background", 0 if transparent_bg else 1); cmd.set("orthoscopic", 0); cmd.set("ambient", 0.20)
cmd.set("direct", 0.80); cmd.set("specular", 0.32); cmd.set("shininess", 40)
cmd.set("ray_shadows", 1); cmd.set("ambient_occlusion_mode", 2); cmd.set("cartoon_fancy_helices", 1)
cmd.load(str(POSE), "pose_ref"); cmd.load(str(ACTB), "actb_af"); cmd.load(str(model), "calp")
cmd.align("actb_af", "pose_ref and chain E"); cmd.super("calp", "actb_af")
core = centroid("pose_ref and chain E and resi 1-340 and not hydro")
tail = centroid("pose_ref and chain E and resi 351-375 and not hydro")
vector = [tail[i] - core[i] for i in range(3)]; norm = sqrt(sum(x*x for x in vector)); vector = [x/norm for x in vector]
target = [-0.36, 0.20, 0.91]; norm = sqrt(sum(x*x for x in target)); target = [x/norm for x in target]
axis = [vector[1]*target[2]-vector[2]*target[1], vector[2]*target[0]-vector[0]*target[2], vector[0]*target[1]-vector[1]*target[0]]
norm = sqrt(sum(x*x for x in axis)); axis = [x/norm for x in axis]
angle = degrees(acos(max(-1.0, min(1.0, sum(vector[i]*target[i] for i in range(3))))))
for obj in ("actb_af", "calp"):
    cmd.translate([-core[0], -core[1], -core[2]], obj, camera=0); cmd.rotate(axis, angle, obj, camera=0)
cmd.dss("actb_af")
residues = [int(a.resi) for a in cmd.get_model("calp and name CA").atom if a.resi.lstrip("-").isdigit()]
qstart, qend = max(residues)-49, max(residues)
cmd.hide("everything")
cmd.show("cartoon", "actb_af and resi 326-375"); cmd.color("actb_green", "actb_af and resi 326-375")
cmd.set("cartoon_transparency", actb_transparency, "actb_af and resi 326-375")
cmd.color("tail_orange", "actb_af and resi 351-372"); cmd.color("terminal_magenta", "actb_af and resi 373-375")
cmd.show("cartoon", f"calp and resi {qstart}-{qend}"); cmd.color("query_blue", f"calp and resi {qstart}-{qend}")
cmd.zoom(f"(actb_af and resi 326-375) or (calp and resi {qstart}-{qend})", 1)
cmd.ray(2400, 1800)
cmd.png(str(OUT / f"{state}_{seq}_tail_closeup_last50{suffix}.png"), dpi=300)
cmd.quit()
