"""Append GTDB taxonomy for the three rendered cALP representatives."""
from pathlib import Path
import csv

OUT = Path(r"..")
METADATA = OUT / "cALP_tail_state_representative_metadata.tsv"
TAXON_SOURCE = Path(r"../data/seq_meta_with_aa_seq.tsv")

with TAXON_SOURCE.open(newline="", encoding="utf-8") as handle:
    taxonomy = {row["seq"]: row for row in csv.DictReader(handle, delimiter="\t")}
with METADATA.open(newline="", encoding="utf-8") as handle:
    records = list(csv.DictReader(handle, delimiter="\t"))

taxon_fields = ["gtdb_species", "gtdb_genus", "gtdb_family", "gtdb_order", "gtdb_class", "gtdb_phylum", "mag_quality_checkm2", "taxonomy_source"]
for record in records:
    taxon = taxonomy[record["seq"]]
    record.update({
        "gtdb_species": taxon["s"], "gtdb_genus": taxon["g"], "gtdb_family": taxon["f"],
        "gtdb_order": taxon["o"], "gtdb_class": taxon["c"], "gtdb_phylum": taxon["p"],
        "mag_quality_checkm2": taxon["quality_checkm2"], "taxonomy_source": str(TAXON_SOURCE),
    })
fieldnames = list(records[0].keys())
with METADATA.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
    writer.writeheader(); writer.writerows(records)
