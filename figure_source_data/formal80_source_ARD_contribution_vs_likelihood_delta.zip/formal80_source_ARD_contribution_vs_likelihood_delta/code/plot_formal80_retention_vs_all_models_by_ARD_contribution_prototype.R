suppressPackageStartupMessages({
  library(ggplot2)
  library(readr)
  library(dplyr)
  library(tidyr)
  library(scales)
})

root <- ".."
fit_file <- "../data/ALL_221_unit_five_model_fit_GTDB.tsv"
scatter_file <- file.path(root, "data", "formal80_ARD_threshold_scatter_20260828.tsv")
out_dir <- file.path(root, "retention_vs_all_models_prototype_20260902")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

scatter <- read_tsv(scatter_file, show_col_types = FALSE) %>%
  filter(branch_scale == "unit_topology") %>%
  select(og_id, ARD_retention_contribution_ratio, final_class)

fits <- read_tsv(fit_file, show_col_types = FALSE) %>%
  mutate(og_id = sub("^archaea1338__", "", case_id)) %>%
  filter(og_id %in% scatter$og_id) %>%
  select(og_id, model, log_likelihood, success)

stopifnot(nrow(scatter) == 80L, n_distinct(scatter$og_id) == 80L)
stopifnot(nrow(fits) == 400L, all(toupper(fits$success) == "TRUE"))

wide <- fits %>%
  select(-success) %>%
  pivot_wider(names_from = model, values_from = log_likelihood)

plot_data <- wide %>%
  transmute(
    og_id,
    `ARD unrestricted` = adjacency_coexist_middle - ARD_unrestricted,
    `A-middle adjacency` = adjacency_coexist_middle - adjacency_A_middle,
    `B-middle adjacency` = adjacency_coexist_middle - adjacency_B_middle,
    `Ancestral coexistence` = adjacency_coexist_middle - ancestral_coexistence_strict
  ) %>%
  pivot_longer(-og_id, names_to = "comparator", values_to = "retention_minus_comparator_logL") %>%
  left_join(scatter, by = "og_id") %>%
  mutate(
    comparator = factor(
      comparator,
      levels = c("ARD unrestricted", "A-middle adjacency", "B-middle adjacency", "Ancestral coexistence")
    ),
    final_class = factor(final_class, levels = c("strong", "supported", "compatible", "fail"))
  )

stopifnot(nrow(plot_data) == 320L, !anyNA(plot_data))

class_cols <- c(
  strong = "#C95858",
  supported = "#2C8C82",
  compatible = "#C89A3D",
  fail = "#BFC4CA"
)
class_shapes <- c(strong = 21, supported = 22, compatible = 24, fail = 21)

p <- ggplot(
  plot_data,
  aes(
    x = ARD_retention_contribution_ratio,
    y = retention_minus_comparator_logL,
    fill = final_class,
    shape = final_class
  )
) +
  geom_hline(yintercept = 0, linewidth = 0.38, colour = "#333333") +
  geom_vline(xintercept = 0.75, linetype = "22", linewidth = 0.45, colour = "#2C8C82") +
  geom_vline(xintercept = 0.90, linetype = "42", linewidth = 0.45, colour = "#C95858") +
  geom_point(size = 1.85, stroke = 0.32, colour = "white", alpha = 0.94) +
  facet_wrap(~comparator, ncol = 2, scales = "free_y") +
  scale_fill_manual(values = class_cols, drop = FALSE) +
  scale_shape_manual(values = class_shapes, drop = FALSE) +
  scale_x_continuous(
    limits = c(0, 1.015), breaks = seq(0, 1, 0.25),
    labels = percent_format(accuracy = 1),
    expand = expansion(mult = c(0.015, 0.02))
  ) +
  labs(
    title = "Retention-model support across four comparator models",
    subtitle = "Formal80, unit-topology scale; each facet contains the same 80 OGs",
    x = "ARD transitions mediated by the coexistence state",
    y = expression(log*L[retention] - log*L[comparator]),
    fill = NULL, shape = NULL
  ) +
  guides(
    fill = guide_legend(override.aes = list(shape = unname(class_shapes), colour = "white")),
    shape = "none"
  ) +
  theme_classic(base_family = "Arial", base_size = 8.2) +
  theme(
    plot.title = element_text(face = "bold", size = 9.4),
    plot.subtitle = element_text(size = 7.4, colour = "#555555", margin = margin(b = 6)),
    strip.background = element_rect(fill = "#F2F4F6", colour = NA),
    strip.text = element_text(face = "bold", size = 7.8, margin = margin(3, 3, 3, 3)),
    axis.title = element_text(size = 8.0),
    axis.text = element_text(size = 7.0, colour = "#333333"),
    axis.line = element_line(linewidth = 0.38, colour = "#333333"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#333333"),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 7.2),
    panel.spacing = unit(7, "pt"),
    plot.margin = margin(6, 7, 6, 6)
  )

pdf_file <- file.path(out_dir, "fig_formal80_unit_ARD_contribution_vs_retention_minus_all_models_prototype.pdf")
png_file <- file.path(out_dir, "fig_formal80_unit_ARD_contribution_vs_retention_minus_all_models_prototype.png")

ggsave(pdf_file, p, width = 178, height = 145, units = "mm", device = cairo_pdf, bg = "white")
ggsave(png_file, p, width = 178, height = 145, units = "mm", dpi = 450, bg = "white")

write_tsv(
  plot_data %>% mutate(across(where(is.factor), as.character)),
  file.path(out_dir, "fig_formal80_unit_ARD_contribution_vs_retention_minus_all_models_source.tsv")
)
write_tsv(
  plot_data %>%
    group_by(comparator) %>%
    summarise(
      n = n(), min = min(retention_minus_comparator_logL),
      median = median(retention_minus_comparator_logL),
      max = max(retention_minus_comparator_logL), .groups = "drop"
    ),
  file.path(out_dir, "comparator_range_QA.tsv")
)
