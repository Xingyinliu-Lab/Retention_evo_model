suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4) {
  stop("Usage: Rscript plot_selected14_per_OG_five_model_and_ARD.R fits.tsv ard.tsv annotations.tsv output_root")
}
fits_path <- args[[1]]
ard_path <- args[[2]]
annotations_path <- args[[3]]
out_root <- args[[4]]
figure_root <- file.path(out_root, "figures")
source_root <- file.path(out_root, "source_data")
dir.create(figure_root, recursive = TRUE, showWarnings = FALSE)
dir.create(source_root, recursive = TRUE, showWarnings = FALSE)

fits <- read_tsv(fits_path, show_col_types = FALSE)
ard <- read_tsv(ard_path, show_col_types = FALSE)
annotations <- read_tsv(annotations_path, show_col_types = FALSE) %>%
  select(og_id, functional_label, functional_description, functional_confidence)

case_index <- fits %>%
  distinct(og_id, final_class) %>%
  left_join(annotations, by = "og_id") %>%
  arrange(factor(final_class, levels = c("strong", "supported")), og_id)
stopifnot(nrow(case_index) == 14, all(!is.na(case_index$functional_label)))
write_tsv(case_index, file.path(out_root, "CASE_INDEX.tsv"))

model_levels <- c("ARD unrestricted", "Sequential\nretention", "B-middle\nadjacency",
                  "A-middle\nadjacency", "Ancestral coexist\n(strict)")
scale_levels <- c("Unit topology", "Source branch lengths")
scale_cols <- c("Unit topology" = "#777777", "Source branch lengths" = "#4F857D")

theme_pub <- function() {
  theme_classic(base_size = 7.2, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.30, colour = "black"),
      axis.ticks = element_line(linewidth = 0.28, colour = "black"),
      axis.text.x = element_text(size = 5.8, lineheight = 0.92),
      axis.text.y = element_text(size = 6.2),
      plot.title = element_text(size = 7.8, face = "bold"),
      plot.subtitle = element_text(size = 5.9, colour = "#4D4D4D"),
      plot.caption = element_text(size = 5.1, colour = "#555555", hjust = 0,
                                  margin = margin(t = 4)),
      legend.position = "top", legend.text = element_text(size = 5.9),
      legend.key.width = grid::unit(4.3, "mm"),
      plot.margin = margin(4, 7, 4, 7)
    )
}

for (cid in case_index$og_id) {
  meta <- filter(case_index, og_id == cid)
  title_text <- paste0(cid, " | ", meta$functional_label)
  subtitle_text <- paste0(meta$functional_description, " | ", meta$final_class)
  case_fig_dir <- file.path(figure_root, cid)
  case_src_dir <- file.path(source_root, cid)
  dir.create(case_fig_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(case_src_dir, recursive = TRUE, showWarnings = FALSE)

  fit <- fits %>% filter(og_id == cid) %>% mutate(
    branch_scale_label = recode(branch_scale,
      unit_topology = "Unit topology",
      source_branch_lengths = "Source branch lengths"),
    model_label = recode(model,
      ARD_unrestricted = "ARD unrestricted",
      adjacency_coexist_middle = "Sequential\nretention",
      adjacency_B_middle = "B-middle\nadjacency",
      adjacency_A_middle = "A-middle\nadjacency",
      ancestral_coexistence_strict = "Ancestral coexist\n(strict)"),
    model_label = factor(model_label, levels = model_levels),
    branch_scale_label = factor(branch_scale_label, levels = scale_levels),
    label = sprintf("%.1f", delta_AIC)
  )
  stopifnot(nrow(fit) == 10, all(toupper(fit$success) == "TRUE"), all(is.finite(fit$delta_AIC)))
  unit_max <- max(fit$delta_AIC[fit$branch_scale_label == "Unit topology"])
  source_max <- max(fit$delta_AIC[fit$branch_scale_label == "Source branch lengths"])
  unit_max <- max(unit_max, 1e-8)
  source_max <- max(source_max, 1e-8)
  scale_factor <- source_max / unit_max
  fit <- fit %>% mutate(y_plot = if_else(branch_scale_label == "Source branch lengths",
                                          delta_AIC / scale_factor, delta_AIC))
  write_tsv(fit, file.path(case_src_dir, paste0(cid, "_five_model_unit_source.tsv")))

  p_fit <- ggplot(fit, aes(model_label, y_plot, fill = branch_scale_label)) +
    geom_col(position = position_dodge(width = 0.74), width = 0.64) +
    geom_text(aes(label = label), position = position_dodge(width = 0.74),
              vjust = -0.42, size = 1.82, family = "Arial", colour = "#303030") +
    scale_fill_manual(values = scale_cols, name = NULL) +
    scale_y_continuous(
      name = expression("Unit-topology "*Delta*"AIC"),
      limits = c(0, unit_max * 1.18), breaks = scales::pretty_breaks(5),
      expand = expansion(mult = c(0, 0)),
      sec.axis = sec_axis(~ . * scale_factor,
                          name = expression("Source branch-length "*Delta*"AIC"),
                          breaks = scales::pretty_breaks(5)(c(0, source_max)))
    ) +
    labs(title = title_text, subtitle = subtitle_text, x = NULL,
         caption = "GTDB r226; composition-corrected root priors. Labels show raw delta-AIC values.") +
    theme_pub() +
    theme(axis.text.y.left = element_text(colour = scale_cols[["Unit topology"]]),
          axis.text.y.right = element_text(colour = scale_cols[["Source branch lengths"]]),
          axis.title.y.left = element_text(colour = scale_cols[["Unit topology"]]),
          axis.title.y.right = element_text(colour = scale_cols[["Source branch lengths"]]))

  fit_stem <- file.path(case_fig_dir, paste0(cid, "_five_model_AIC_unit_vs_source_dual_axis"))
  ggsave(paste0(fit_stem, ".pdf"), p_fit, width = 150, height = 98, units = "mm", device = cairo_pdf)
  ggsave(paste0(fit_stem, ".png"), p_fit, width = 150, height = 98, units = "mm", dpi = 400, bg = "white")

  ard_case <- ard %>% filter(og_id == cid) %>%
    transmute(
      branch_scale_label = recode(branch_scale,
        unit_topology = "Unit topology",
        source_branch_lengths = "Source branch lengths"),
      `Coexist-mediated` = 100 * coexist_mediated_fraction,
      `Direct endpoint transition` = 100 * direct_endpoint_fraction
    ) %>%
    pivot_longer(-branch_scale_label, names_to = "route", values_to = "percent") %>%
    mutate(route = factor(route, levels = c("Coexist-mediated", "Direct endpoint transition")),
           branch_scale_label = factor(branch_scale_label, levels = scale_levels),
           label = sprintf("%.1f%%", percent))
  stopifnot(nrow(ard_case) == 4, all(is.finite(ard_case$percent)))
  write_tsv(ard_case, file.path(case_src_dir, paste0(cid, "_ARD_unit_source.tsv")))

  p_ard <- ggplot(ard_case, aes(route, percent, fill = branch_scale_label)) +
    geom_col(position = position_dodge(width = 0.72), width = 0.62) +
    geom_text(aes(label = label), position = position_dodge(width = 0.72),
              vjust = -0.42, size = 2.10, family = "Arial", colour = "#303030") +
    scale_fill_manual(values = scale_cols, name = NULL) +
    scale_x_discrete(labels = c("Coexist-mediated", "Direct endpoint\ntransition")) +
    scale_y_continuous(limits = c(0, 104), breaks = seq(0, 100, 20),
                       labels = function(x) paste0(x, "%"), expand = expansion(mult = c(0, 0))) +
    labs(title = title_text, subtitle = subtitle_text, x = NULL,
         y = "Share of inferred ARD transitions",
         caption = "GTDB r226; fixed-Q stochastic-history posterior means on two branch scales.") +
    theme_pub()

  ard_stem <- file.path(case_fig_dir, paste0(cid, "_ARD_contribution_unit_vs_source"))
  ggsave(paste0(ard_stem, ".pdf"), p_ard, width = 112, height = 92, units = "mm", device = cairo_pdf)
  ggsave(paste0(ard_stem, ".png"), p_ard, width = 112, height = 92, units = "mm", dpi = 400, bg = "white")
}

pdfs <- list.files(figure_root, pattern = "\\.pdf$", recursive = TRUE, full.names = TRUE)
pngs <- list.files(figure_root, pattern = "\\.png$", recursive = TRUE, full.names = TRUE)
stopifnot(length(pdfs) == 28, length(pngs) == 28)
writeLines(c("status=complete", "backend=R", "n_cases=14", "n_pdf=28", "n_png=28",
             "branch_scales=unit_topology,source_branch_lengths"),
           file.path(out_root, "FIGURES_COMPLETE.marker"))
