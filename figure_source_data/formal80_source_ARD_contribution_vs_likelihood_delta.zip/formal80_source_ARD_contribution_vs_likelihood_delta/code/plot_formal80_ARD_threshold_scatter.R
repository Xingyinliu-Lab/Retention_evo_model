suppressPackageStartupMessages({
  library(ggplot2)
  library(readr)
  library(dplyr)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("Usage: Rscript plot_formal80_ARD_threshold_scatter.R input.tsv output_dir")
input <- args[[1]]
outdir <- args[[2]]
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

d <- read_tsv(input, show_col_types = FALSE) %>%
  mutate(
    final_class = factor(final_class, levels = c("strong", "supported", "compatible", "fail")),
    branch_scale = factor(branch_scale, levels = c("unit_topology", "source_branch_lengths"))
  )

stopifnot(nrow(d) == 160, n_distinct(d$og_id) == 80)

cols <- c(strong = "#C9493A", supported = "#287D8E", compatible = "#D79A2B", fail = "#B8BDC5")
shapes <- c(strong = 21, supported = 22, compatible = 24, fail = 21)

make_plot <- function(dd, title, filename) {
  # Draw fail/compatible cases first and strong cases last so overlapping
  # high-contribution points cannot obscure the two strong cases.
  dd <- dd %>% arrange(desc(final_class))
  p <- ggplot(dd, aes(x = ARD_retention_contribution_ratio,
                      y = ARD_minus_retention_delta_logL,
                      fill = final_class, shape = final_class)) +
    annotate("rect", xmin = 0.75, xmax = 0.90, ymin = -Inf, ymax = Inf,
             fill = "#287D8E", alpha = 0.045) +
    annotate("rect", xmin = 0.90, xmax = Inf, ymin = -Inf, ymax = Inf,
             fill = "#C9493A", alpha = 0.045) +
    geom_hline(yintercept = 0, linewidth = 0.45, colour = "#252525") +
    geom_vline(xintercept = c(0.75, 0.90), linetype = c("22", "42"),
               linewidth = 0.55, colour = c("#287D8E", "#C9493A")) +
    annotate("text", x = 0.75, y = Inf, label = "75%", vjust = 1.35, hjust = 1.15,
             size = 2.35, family = "Arial", colour = "#287D8E") +
    annotate("text", x = 0.90, y = Inf, label = "90%", vjust = 1.35, hjust = 1.15,
             size = 2.35, family = "Arial", colour = "#C9493A") +
    geom_point(size = 2.05, stroke = 0.38, colour = "white", alpha = 0.95) +
    scale_fill_manual(values = cols, drop = FALSE) +
    scale_shape_manual(values = shapes, drop = FALSE) +
    scale_x_continuous(limits = c(0, 1.015), breaks = seq(0, 1, 0.25),
                       labels = percent_format(accuracy = 1), expand = expansion(mult = c(0.015, 0.02))) +
    labs(
      title = title,
      x = "ARD transitions mediated by the coexistence state",
      y = expression(Delta*log*L == log*L[ARD] - log*L[sequential~retention]),
      fill = NULL, shape = NULL
    ) +
    guides(fill = guide_legend(override.aes = list(shape = unname(shapes), colour = "white")),
           shape = "none") +
    theme_classic(base_family = "Arial", base_size = 8.5) +
    theme(
      plot.title = element_text(face = "bold", size = 9.5, margin = margin(b = 7)),
      axis.title = element_text(size = 8.5),
      axis.text = element_text(size = 7.5, colour = "#333333"),
      axis.line = element_line(linewidth = 0.45, colour = "#333333"),
      axis.ticks = element_line(linewidth = 0.4, colour = "#333333"),
      legend.position = "top",
      legend.justification = "left",
      legend.text = element_text(size = 7.5),
      legend.key.width = unit(9, "pt"),
      legend.spacing.x = unit(2, "pt"),
      plot.margin = margin(7, 8, 7, 7)
    )
  ggsave(file.path(outdir, paste0(filename, ".pdf")), p, width = 4.25, height = 3.55, units = "in", device = cairo_pdf)
  ggsave(file.path(outdir, paste0(filename, ".png")), p, width = 4.25, height = 3.55, units = "in", dpi = 320, bg = "white")
}

make_plot(filter(d, branch_scale == "unit_topology"),
          "Unit-topology model scale",
          "fig_formal80_unit_ARD_contribution_vs_likelihood_delta")
make_plot(filter(d, branch_scale == "source_branch_lengths"),
          "Source-branch-length model scale",
          "fig_formal80_source_ARD_contribution_vs_likelihood_delta")

summary <- d %>%
  group_by(branch_scale, final_class) %>%
  summarise(n = n(), median_ratio = median(ARD_retention_contribution_ratio),
            median_delta_logL = median(ARD_minus_retention_delta_logL), .groups = "drop")
write_tsv(summary, file.path(dirname(input), "formal80_threshold_scatter_summary.tsv"))

threshold_summary <- d %>%
  mutate(ratio_bin = cut(ARD_retention_contribution_ratio,
                         breaks = c(-Inf, 0.75, 0.90, Inf), right = FALSE,
                         labels = c("<0.75", "0.75-<0.90", ">=0.90"))) %>%
  group_by(branch_scale, ratio_bin) %>%
  summarise(n = n(),
            median_delta_logL = median(ARD_minus_retention_delta_logL),
            q25_delta_logL = quantile(ARD_minus_retention_delta_logL, 0.25),
            q75_delta_logL = quantile(ARD_minus_retention_delta_logL, 0.75),
            .groups = "drop")
write_tsv(threshold_summary, file.path(dirname(input), "formal80_ARD_threshold_bin_summary.tsv"))

cor_summary <- d %>%
  group_by(branch_scale) %>%
  group_modify(~{
    z <- suppressWarnings(cor.test(.x$ARD_retention_contribution_ratio,
                                   .x$ARD_minus_retention_delta_logL,
                                   method = "spearman", exact = FALSE))
    tibble(spearman_rho = unname(z$estimate), p_value = z$p.value, n = nrow(.x))
  }) %>% ungroup()
write_tsv(cor_summary, file.path(dirname(input), "formal80_ARD_threshold_spearman.tsv"))

threshold_tests <- bind_rows(lapply(levels(d$branch_scale), function(bs) {
  x <- filter(d, branch_scale == bs)
  bind_rows(lapply(c(0.75, 0.90), function(thr) {
    low <- x$ARD_minus_retention_delta_logL[x$ARD_retention_contribution_ratio < thr]
    high <- x$ARD_minus_retention_delta_logL[x$ARD_retention_contribution_ratio >= thr]
    wt <- suppressWarnings(wilcox.test(high, low, alternative = "less", exact = FALSE))
    tibble(branch_scale = bs, threshold = thr, n_below = length(low), n_at_or_above = length(high),
           median_below = median(low), median_at_or_above = median(high), p_one_sided = wt$p.value)
  }))
}))
write_tsv(threshold_tests, file.path(dirname(input), "formal80_ARD_threshold_wilcoxon.tsv"))
