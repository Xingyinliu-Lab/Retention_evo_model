suppressPackageStartupMessages({
  library(ggplot2)
  library(readr)
  library(dplyr)
  library(tidyr)
  library(scales)
})

root <- ".."
unit_file <- "../data/ALL_221_unit_five_model_fit_GTDB.tsv"
source_file <- "../data/ALL_221_source_branch_five_model_fit_GTDB.tsv"
class_file <- file.path(root, "data", "formal80_ARD_threshold_scatter_20260828.tsv")
out_dir <- file.path(root, "five_model_deltaAIC_matrix_prototype_20260902")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

class_index <- read_tsv(class_file, show_col_types = FALSE) %>%
  distinct(og_id, final_class) %>%
  filter(final_class %in% c("strong", "supported"))
stopifnot(nrow(class_index) == 14L)

contribution <- read_tsv(class_file, show_col_types = FALSE) %>%
  filter(og_id %in% class_index$og_id) %>%
  select(og_id, branch_scale, ARD_retention_contribution_ratio)
stopifnot(nrow(contribution) == 28L)

read_fit <- function(path) {
  read_tsv(path, show_col_types = FALSE) %>%
    mutate(og_id = sub("^archaea1338__", "", case_id)) %>%
    filter(og_id %in% class_index$og_id) %>%
    select(og_id, branch_scale, model, log_likelihood, AIC, delta_AIC, success)
}

fits <- bind_rows(read_fit(unit_file), read_fit(source_file)) %>%
  left_join(class_index, by = "og_id")

stopifnot(nrow(fits) == 140L, all(toupper(fits$success) == "TRUE"))

model_levels <- c(
  "ARD_unrestricted", "adjacency_coexist_middle", "adjacency_A_middle",
  "adjacency_B_middle", "ancestral_coexistence_strict"
)
model_labels <- c(
  "ARD", "Retention", "A-middle", "B-middle", "Ancestral"
)
scale_levels <- c("unit_topology", "source_branch_lengths")

row_order <- fits %>%
  filter(model == "adjacency_coexist_middle") %>%
  group_by(og_id, final_class) %>%
  summarise(retention_delta_AIC = max(delta_AIC), .groups = "drop") %>%
  mutate(class_rank = match(final_class, c("strong", "supported", "compatible", "fail"))) %>%
  arrange(class_rank, retention_delta_AIC, og_id) %>%
  pull(og_id)

row_index <- tibble(
  og_id = row_order,
  y = rev(seq_along(row_order))
) %>%
  left_join(class_index, by = "og_id")

plot_data <- fits %>%
  left_join(row_index %>% select(og_id, y), by = "og_id") %>%
  mutate(
    model = factor(model, levels = model_levels, labels = model_labels),
    branch_scale = factor(branch_scale, levels = scale_levels),
    model_index = as.integer(model),
    scale_index = as.integer(branch_scale),
    x = model_index + if_else(scale_index == 1L, 0, 7),
    delta_AIC_capped = pmin(delta_AIC, 20),
    is_best = delta_AIC < 1e-8,
    final_class = factor(final_class, levels = c("strong", "supported"))
  )

class_strip <- row_index %>%
  mutate(final_class = factor(final_class, levels = c("strong", "supported")))

contribution_data <- contribution %>%
  left_join(row_index %>% select(og_id, y), by = "og_id") %>%
  mutate(
    branch_scale = factor(branch_scale, levels = scale_levels),
    x = if_else(branch_scale == "unit_topology", 6.15, 13.15),
    contribution_label = percent(ARD_retention_contribution_ratio, accuracy = 1)
  )

class_boundaries <- class_strip %>%
  group_by(final_class) %>%
  summarise(ymin = min(y) - 0.5, .groups = "drop") %>%
  filter(ymin > 0.5)

label_rows <- class_strip

class_cols <- c(
  strong = "#C95858",
  supported = "#2C8C82",
  compatible = "#C89A3D",
  fail = "#BFC4CA"
)

x_breaks <- c(1:5, 6.15, 8:12, 13.15)
x_labels <- c(model_labels, "ARD\npath %", model_labels, "ARD\npath %")

p <- ggplot(plot_data, aes(x = x, y = y)) +
  geom_tile(aes(fill = delta_AIC_capped), width = 0.82, height = 0.82) +
  geom_tile(
    data = contribution_data,
    aes(x = x, y = y), inherit.aes = FALSE,
    width = 0.78, height = 0.82,
    fill = "#F3EFE4", colour = "#D3C9AE", linewidth = 0.22
  ) +
  geom_text(
    data = contribution_data,
    aes(x = x, y = y, label = contribution_label), inherit.aes = FALSE,
    family = "Arial", fontface = "bold", size = 2.15, colour = "#5D543F"
  ) +
  geom_point(
    data = filter(plot_data, is_best),
    shape = 21, size = 0.95, stroke = 0.20,
    fill = "#24323B", colour = "#24323B"
  ) +
  geom_point(
    data = class_strip,
    aes(x = 0.12, y = y, colour = final_class),
    inherit.aes = FALSE, shape = 15, size = 2.15
  ) +
  geom_hline(
    data = class_boundaries, aes(yintercept = ymin),
    inherit.aes = FALSE, linewidth = 0.42, colour = "#858C92"
  ) +
  geom_vline(xintercept = 7.15, linewidth = 0.55, colour = "#59636D") +
  annotate("text", x = 3.6, y = 16.0, label = "Unit topology", fontface = "bold", size = 2.65) +
  annotate("text", x = 10.6, y = 16.0, label = "Source branch lengths", fontface = "bold", size = 2.65) +
  scale_fill_gradientn(
    colours = c("#F5F4EF", "#DCE5E2", "#ABC6C4", "#63999F", "#236E79"),
    values = rescale(c(0, 2, 6, 12, 20)),
    limits = c(0, 20), oob = squish,
    name = expression(Delta*"AIC from best"),
    breaks = c(0, 2, 6, 12, 20),
    labels = c("0", "2", "6", "12", expression(">="*20))
  ) +
  scale_colour_manual(values = class_cols, drop = TRUE, name = "Gate class") +
  scale_x_continuous(
    breaks = x_breaks, labels = x_labels,
    limits = c(-0.05, 13.65), expand = c(0, 0)
  ) +
  scale_y_continuous(
    breaks = label_rows$y, labels = label_rows$og_id,
    limits = c(0.2, 16.7), expand = c(0, 0)
  ) +
  labs(
    title = "Five-model evidence profiles across 14 strong or supported OGs",
    subtitle = "Rows are ordered by gate class and retention-model support; dark dots mark the minimum-AIC model within each scale",
    x = NULL, y = NULL
  ) +
  guides(
    fill = guide_colourbar(order = 1, barwidth = grid::unit(33, "mm"), barheight = grid::unit(3.2, "mm")),
    colour = guide_legend(order = 2, override.aes = list(shape = 15, size = 3.2))
  ) +
  theme_classic(base_family = "Arial", base_size = 8) +
  theme(
    plot.title = element_text(face = "bold", size = 9.6),
    plot.subtitle = element_text(size = 7.3, colour = "#555555", margin = margin(b = 7)),
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(size = 7.0, angle = 38, hjust = 1, colour = "#2F3740"),
    axis.text.y = element_text(size = 7.0, colour = "#2F3740"),
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.title = element_text(size = 7.0, face = "bold"),
    legend.text = element_text(size = 6.7),
    panel.grid = element_blank(),
    plot.margin = margin(7, 8, 6, 7)
  )

pdf_file <- file.path(out_dir, "fig_formal80_five_model_deltaAIC_matrix_prototype.pdf")
png_file <- file.path(out_dir, "fig_formal80_five_model_deltaAIC_matrix_prototype.png")

ggsave(pdf_file, p, width = 183, height = 112, units = "mm", device = cairo_pdf, bg = "white")
ggsave(png_file, p, width = 183, height = 112, units = "mm", dpi = 450, bg = "white")

write_tsv(
  plot_data %>%
    transmute(
      og_id, final_class = as.character(final_class), branch_scale = as.character(branch_scale),
      model = as.character(model), log_likelihood, AIC, delta_AIC, is_best, y, x
    ),
  file.path(out_dir, "fig_formal80_five_model_deltaAIC_matrix_source.tsv")
)

write_tsv(
  contribution_data %>%
    transmute(
      og_id, branch_scale = as.character(branch_scale),
      ARD_retention_contribution_ratio, contribution_label, y, x
    ),
  file.path(out_dir, "fig_formal80_ARD_contribution_matrix_source.tsv")
)

write_tsv(
  plot_data %>%
    group_by(branch_scale, model) %>%
    summarise(
      n = n(), n_best = sum(is_best), median_delta_AIC = median(delta_AIC),
      .groups = "drop"
    ),
  file.path(out_dir, "five_model_summary_QA.tsv")
)
