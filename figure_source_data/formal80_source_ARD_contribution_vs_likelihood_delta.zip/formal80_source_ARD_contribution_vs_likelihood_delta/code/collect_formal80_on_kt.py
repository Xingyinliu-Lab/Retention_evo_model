#!/usr/bin/env python3
"""Collect the frozen 80-case formal five-model/ARD evidence on kt."""
from __future__ import annotations

import csv
from pathlib import Path


OLD = Path("..")
NEW = Path("..")
LATE = Path("..")
OUT = Path("../data/formal80_ARD_threshold_scatter_20260828.tsv")
OUT_FITS = Path("../data/formal80_selected14_five_model_fits_20260828.tsv")
OUT_ARD = Path("../data/formal80_selected14_ARD_contribution_20260828.tsv")
RAW_FITS = []
RAW_ARD = []


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def evaluate(fits, ard):
    by_model = {row["model"]: row for row in fits}
    retention = by_model["adjacency_coexist_middle"]
    unrestricted = by_model["ARD_unrestricted"]
    other = max(
        (row for name, row in by_model.items() if name not in {"ARD_unrestricted", "adjacency_coexist_middle"}),
        key=lambda row: float(row["log_likelihood"]),
    )
    ll_ret = float(retention["log_likelihood"])
    ll_ard = float(unrestricted["log_likelihood"])
    margin = ll_ret - float(other["log_likelihood"])
    fraction = float(ard["coexist_mediated_fraction"])
    return {
        "retention_log_likelihood": ll_ret,
        "ARD_log_likelihood": ll_ard,
        "ARD_minus_retention_delta_logL": ll_ard - ll_ret,
        "retention_minus_best_other_restricted_logL": margin,
        "ARD_retention_contribution_ratio": fraction,
        "pass75": margin >= -1e-6 and fraction >= 0.75,
        "strong90": margin >= -1e-6 and fraction >= 0.90,
    }


def add_case(rows, og, origin, unit_fit, unit_ard, source_fit_rows, source_ard):
    unit_fit_rows = read_tsv(unit_fit)
    unit_ard_row = read_tsv(unit_ard)[0]
    unit = evaluate(unit_fit_rows, unit_ard_row)
    source = evaluate(source_fit_rows, source_ard)
    final_class = (
        "strong" if unit["strong90"] and source["strong90"]
        else "supported" if unit["pass75"] and source["pass75"]
        else "compatible" if unit["pass75"] or source["pass75"]
        else "fail"
    )
    if final_class in {"strong", "supported"}:
        for scale, fit_rows in (("unit_topology", unit_fit_rows),
                                ("source_branch_lengths", source_fit_rows)):
            for row in fit_rows:
                RAW_FITS.append({
                    "og_id": og, "origin_set": origin, "final_class": final_class,
                    "branch_scale": scale, "model": row["model"],
                    "log_likelihood": row["log_likelihood"], "AIC": row["AIC"],
                    "delta_AIC": row["delta_AIC"], "success": row["success"],
                })
        for scale, row in (("unit_topology", unit_ard_row),
                           ("source_branch_lengths", source_ard)):
            RAW_ARD.append({
                "og_id": og, "origin_set": origin, "final_class": final_class,
                "branch_scale": scale,
                "coexist_mediated_mean": row["coexist_mediated_mean"],
                "direct_endpoint_mean": row["direct_endpoint_mean"],
                "coexist_mediated_fraction": row["coexist_mediated_fraction"],
                "direct_endpoint_fraction": row["direct_endpoint_fraction"],
                "expected_total": row["expected_total"],
            })
    n_hosts = int(next(iter(read_tsv(unit_fit)))["n_hosts"])
    for scale, values in (("unit_topology", unit), ("source_branch_lengths", source)):
        rows.append({
            "og_id": og,
            "origin_set": origin,
            "branch_scale": scale,
            "n_hosts": n_hosts,
            "retention_log_likelihood": values["retention_log_likelihood"],
            "ARD_log_likelihood": values["ARD_log_likelihood"],
            "ARD_minus_retention_delta_logL": values["ARD_minus_retention_delta_logL"],
            "ARD_minus_retention_delta_logL_per_host": values["ARD_minus_retention_delta_logL"] / n_hosts,
            "retention_minus_best_other_restricted_logL": values["retention_minus_best_other_restricted_logL"],
            "ARD_retention_contribution_ratio": values["ARD_retention_contribution_ratio"],
            "scale_pass75": str(values["pass75"]).upper(),
            "scale_strong90": str(values["strong90"]).upper(),
            "final_class": final_class,
        })


def main():
    rows = []

    old_source_fit = read_tsv(OLD / "results/source_branch_length_validation/five_model_fit_GTDB_source_branch_lengths.tsv")
    old_source_ard = {r["case_id"]: r for r in read_tsv(OLD / "results/source_branch_length_validation/ARD_contribution_GTDB_source_branch_lengths.tsv")}
    old_source_by_case = {}
    for row in old_source_fit:
        old_source_by_case.setdefault(row["case_id"], []).append(row)
    for case in sorted((OLD / "cases").iterdir()):
        if not case.is_dir():
            continue
        cid = case.name
        og = cid.split("__", 1)[-1]
        add_case(rows, og, "existing_formal40", case / "results/five_model_fit_GTDB.tsv",
                 case / "results/ARD_transition_contribution_GTDB.tsv",
                 old_source_by_case[cid], old_source_ard[cid])

    for case in sorted((NEW / "cases").iterdir()):
        gate = case / "downstream_gate_v2"
        if not (gate / "final_results/FORMAL_V2_DUAL_SCALE_GATE_COMPLETE.marker").exists():
            continue
        cid = f"archaea1338__{case.name}"
        source_fit = read_tsv(gate / "results/source_branch_length_validation/five_model_fit_GTDB_source_branch_lengths.tsv")
        source_ard = {r["case_id"]: r for r in read_tsv(gate / "results/source_branch_length_validation/ARD_contribution_GTDB_source_branch_lengths.tsv")}
        source_by_case = {}
        for row in source_fit:
            source_by_case.setdefault(row["case_id"], []).append(row)
        unit_case = gate / "cases" / cid
        add_case(rows, case.name, "new_formal39", unit_case / "results/five_model_fit_GTDB.tsv",
                 unit_case / "results/ARD_transition_contribution_GTDB.tsv",
                 source_by_case[cid], source_ard[cid])

    late_cid = "archaea1338__OG0000323"
    late_source_fit = read_tsv(LATE / "results/source_branch_length_validation/five_model_fit_GTDB_source_branch_lengths.tsv")
    late_source_ard = {r["case_id"]: r for r in read_tsv(LATE / "results/source_branch_length_validation/ARD_contribution_GTDB_source_branch_lengths.tsv")}
    late_by_case = {}
    for row in late_source_fit:
        late_by_case.setdefault(row["case_id"], []).append(row)
    add_case(rows, "OG0000323", "late_formal1", LATE / "results/five_model_fit_GTDB.tsv",
             LATE / "results/ARD_transition_contribution_GTDB.tsv",
             late_by_case[late_cid], late_source_ard[late_cid])

    ogs = {row["og_id"] for row in rows}
    assert len(rows) == 160, len(rows)
    assert len(ogs) == 80, len(ogs)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    selected = {row["og_id"] for row in RAW_FITS}
    assert len(selected) == 14, len(selected)
    assert len(RAW_FITS) == 140, len(RAW_FITS)
    assert len(RAW_ARD) == 28, len(RAW_ARD)
    for path, data in ((OUT_FITS, RAW_FITS), (OUT_ARD, RAW_ARD)):
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(data[0]), delimiter="\t", lineterminator="\n")
            writer.writeheader()
            writer.writerows(data)
    print(f"rows={len(rows)} cases={len(ogs)} selected={len(selected)} output={OUT}")


if __name__ == "__main__":
    main()
