"""Render Homo ACTB-AF alone using the exact pose and ray settings of panel B."""

from math import acos, degrees, sqrt
import os
from pathlib import Path

from pymol import cmd


root = Path(r"..")
pose_ref = Path(r"..")
transparent_bg = os.environ.get("PYMOL_TRANSPARENT_BG", "0") == "1"
actb_transparency = float(os.environ.get("ACTB_CARTOON_TRANSPARENCY", "0.70"))
output_name = os.environ.get(
    "PYMOL_OUTPUT_NAME",
    (
        "Homo_ACTB_AF_only_fixedpose_matching_B_transparent.png"
        if transparent_bg
        else "Homo_ACTB_AF_only_fixedpose_matching_B.png"
    ),
)
out = (
    root
    / "pymol_profile_family_atlas_fixedpose"
    / output_name
)


def centroid(selection):
    atoms = cmd.get_model(selection).atom
    return [sum(atom.coord[i] for atom in atoms) / len(atoms) for i in range(3)]


cmd.reinitialize()
cmd.set_color("ink", [0.071, 0.094, 0.133])
cmd.set_color("actb_green", [0.20, 0.78, 0.47])
cmd.set_color("tail_orange", [0.96, 0.40, 0.10])
cmd.set_color("terminal_magenta", [0.90, 0.23, 0.53])
cmd.bg_color("white" if transparent_bg else "ink")
cmd.set("ray_opaque_background", 0 if transparent_bg else 1)
cmd.set("orthoscopic", 0)
cmd.set("ambient", 0.20)
cmd.set("direct", 0.80)
cmd.set("specular", 0.32)
cmd.set("shininess", 40)
cmd.set("ray_shadows", 1)
cmd.set("ambient_occlusion_mode", 2)
cmd.set("cartoon_fancy_helices", 1)
cmd.set("stick_radius", 0.18)

cmd.load(str(pose_ref), "pose_ref")
cmd.load(str(root / "Homo_actb_AF-P60709-F1-model_v6.cif"), "actb_af")

# Load the B-panel cALP only as a hidden framing helper so the camera extent is
# identical to the existing overlay. It is deleted before rendering.
cmd.load(str(root / "fold_GCA_054384275.1_S.8_46_model_0.cif"), "calp_frame")
cmd.align("actb_af", "pose_ref and chain E")
cmd.align("calp_frame", "actb_af")

core = centroid("pose_ref and chain E and resi 1-340 and not hydro")
tail = centroid("pose_ref and chain E and resi 351-375 and not hydro")
vector = [tail[i] - core[i] for i in range(3)]
norm = sqrt(sum(value * value for value in vector))
vector = [value / norm for value in vector]
target = [-0.36, 0.20, 0.91]
target_norm = sqrt(sum(value * value for value in target))
target = [value / target_norm for value in target]
axis = [
    vector[1] * target[2] - vector[2] * target[1],
    vector[2] * target[0] - vector[0] * target[2],
    vector[0] * target[1] - vector[1] * target[0],
]
axis_norm = sqrt(sum(value * value for value in axis))
axis = [value / axis_norm for value in axis]
angle = degrees(
    acos(max(-1, min(1, sum(vector[i] * target[i] for i in range(3)))))
)

for obj in ("actb_af", "calp_frame"):
    cmd.translate([-core[0], -core[1], -core[2]], obj, camera=0)
    cmd.rotate(axis, angle, obj, camera=0)

cmd.dss("actb_af")
cmd.hide("everything")
cmd.show("cartoon", "actb_af")
cmd.color("actb_green", "actb_af")
cmd.set("cartoon_transparency", actb_transparency, "actb_af")
cmd.color("tail_orange", "actb_af and resi 351-372")
cmd.color("terminal_magenta", "actb_af and resi 373-375")

# Match the existing B-panel camera exactly, then remove the helper object.
cmd.zoom("actb_af or calp_frame", 6)
cmd.delete("calp_frame")
cmd.ray(2400, 1800)
cmd.png(str(out), dpi=300)
cmd.sync()
cmd.quit()
