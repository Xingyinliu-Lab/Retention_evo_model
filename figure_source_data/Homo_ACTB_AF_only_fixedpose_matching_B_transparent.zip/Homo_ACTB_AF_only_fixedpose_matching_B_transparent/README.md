# Homo_ACTB_AF_only_fixedpose_matching_B_transparent

- Manuscript panel: Fig.2A
- Source figure basename: Homo_ACTB_AF_only_fixedpose_matching_B_transparent
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)
