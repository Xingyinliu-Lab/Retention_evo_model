# 5_coexist_MAG_phylogenetic_composition_full2606_pie

- Manuscript panel: Fig.4F
- Source figure basename: fig_5_coexist_MAG_phylogenetic_composition_full2606_pie
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 6 directly referenced or locally packaged source-data file(s)
