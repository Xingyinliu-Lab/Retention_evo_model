suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

root <- ".."
state_file <- "../data/full2606_MAG_states.tsv"
placement_file <- "../data/mapped_584.tsv"
figure_dir <- file.path(root, "figures")
source_dir <- file.path(root, "data", "figure_source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

# Figure contract: show the phylogenetic breadth of full-universe MAG-level
# cALP+dALP coexistence. Asgardarchaeota is resolved to class; non-Asgard
# lineages remain at phylum level. This is descriptive, not directional.
states <- read.delim(state_file, check.names = FALSE, stringsAsFactors = FALSE)
placement <- read.delim(placement_file, check.names = FALSE, stringsAsFactors = FALSE)
if (nrow(placement) != 2606L || !all(c("seq", "mag_id", "profile", "branch_label") %in% names(placement))) {
  stop("Frozen expanded 584-placement input failed its dimension/column audit.")
}

plot_dat <- states %>%
  filter(state == "coexist") %>%
  transmute(
    category = ifelse(phylum == "Asgardarchaeota", class, phylum),
    resolution = ifelse(phylum == "Asgardarchaeota", "Asgard class", "Non-Asgard phylum")
  ) %>%
  count(category, resolution, name = "n_MAGs") %>%
  arrange(desc(n_MAGs)) %>%
  mutate(
    proportion = n_MAGs / sum(n_MAGs),
    label = paste0(category, " (", n_MAGs, "; ", sprintf("%.1f", 100 * proportion), "%)"),
    ymax = cumsum(n_MAGs),
    ymin = lag(ymax, default = 0),
    label_y = (ymin + ymax) / 2,
    label_inside = ifelse(n_MAGs >= 30, paste0(category, "\n", n_MAGs), "")
  )

stopifnot(sum(plot_dat$n_MAGs) == 342L)
write.table(
  plot_dat,
  file.path(source_dir, "fig_5_coexist_MAG_phylogenetic_composition_full2606_pie_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)

palette <- c(
  "Lokiarchaeia" = "#C77C84",
  "Heimdallarchaeia" = "#5E91AD",
  "Thermoproteota" = "#D7A24D",
  "Hermodarchaeia" = "#8879A7",
  "Njordarchaeia" = "#77A28F",
  "Thorarchaeia" = "#A86F85",
  "Jordiarchaeia" = "#829C61",
  "Wukongarchaeia" = "#B8A55E"
)

p <- ggplot(plot_dat, aes(x = 1, y = n_MAGs, fill = category)) +
  geom_col(width = 1, colour = NA) +
  geom_text(
    aes(y = label_y, label = label_inside),
    colour = "white", size = 2.7, family = "Arial", fontface = "bold",
    lineheight = 0.9
  ) +
  coord_polar(theta = "y", start = 0, direction = -1, clip = "off") +
  scale_fill_manual(values = palette, breaks = plot_dat$category, labels = plot_dat$label, name = NULL) +
  labs(
    title = "cALP+dALP coexistence spans archaeal lineages",
    subtitle = "342 coexist MAGs in the expanded 584-reference placement universe",
    caption = "Asgardarchaeota is shown at class level; non-Asgard lineages at phylum level. MAG-level profile states; n = 342 coexist MAGs."
  ) +
  theme_void(base_size = 7.2, base_family = "Arial") +
  theme(
    plot.title = element_text(size = 8.4, face = "bold", hjust = 0),
    plot.subtitle = element_text(size = 6.2, colour = "#555555", hjust = 0, margin = margin(b = 2)),
    plot.caption = element_text(size = 5.2, colour = "#555555", hjust = 0, margin = margin(t = 4)),
    legend.position = "right",
    legend.text = element_text(size = 5.8),
    legend.key.height = grid::unit(3.8, "mm"),
    legend.key.width = grid::unit(3.8, "mm"),
    plot.margin = margin(4, 8, 4, 4)
  )

ggsave(
  file.path(figure_dir, "fig_5_coexist_MAG_phylogenetic_composition_full2606_pie.pdf"),
  p, width = 150, height = 94, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_5_coexist_MAG_phylogenetic_composition_full2606_pie.png"),
  p, width = 150, height = 94, units = "mm", dpi = 600, bg = "white"
)
