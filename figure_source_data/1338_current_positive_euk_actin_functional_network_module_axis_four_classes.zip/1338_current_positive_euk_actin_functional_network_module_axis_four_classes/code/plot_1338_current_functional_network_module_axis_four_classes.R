#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(readr)
  library(ragg)
  library(stringr)
})

root <- ".."
current_dir <- file.path(root, "current_canonical_tail")
data_dir <- file.path(current_dir, "data")
figure_dir <- file.path(current_dir, "figures")

source <- read_tsv(
  file.path(data_dir, "fig19_1338_current_network_events_on_gtdb_axis_source.tsv"),
  show_col_types = FALSE
)
module_coverage <- read_tsv(
  file.path(data_dir, "fig19_1338_current_network_module_mrca_coverage.tsv"),
  show_col_types = FALSE
)
shared_axis_key <- read_tsv(
  file.path(
    file.path(
      root, "archive_pre0719_root_20260724", "visualization_rebuild_20260718",
      "current_canonical_tail", "data", "kt_gtdb_r226_key_phylum_mrca_map_20260718"
    ),
    "gtdb_r226_key_phylum_mrca_map_summary.tsv"
  ),
  show_col_types = FALSE
) %>%
  arrange(x_log_plot, desc(n_gtdb_reference_tips), p) %>%
  mutate(
    interval_start_raw = c(
      max(0, x_log_plot[1] - (x_log_plot[2] - x_log_plot[1]) / 2),
      head((x_log_plot + lead(x_log_plot)) / 2, -1)
    ),
    interval_end_raw = c(
      head((x_log_plot + lead(x_log_plot)) / 2, -1),
      min(1, x_log_plot[n()] + (x_log_plot[n()] - x_log_plot[n() - 1]) / 2)
    )
  )

window_start_raw <- min(shared_axis_key$interval_start_raw)
window_end_raw <- max(shared_axis_key$interval_end_raw)
display_left <- 0.22
display_right <- 0.78
expand_shared_axis <- function(x) {
  ifelse(
    x <= window_start_raw,
    display_left * x / window_start_raw,
    ifelse(
      x <= window_end_raw,
      display_left + (display_right - display_left) *
        (x - window_start_raw) / (window_end_raw - window_start_raw),
      display_right + (1 - display_right) *
        (x - window_end_raw) / (1 - window_end_raw)
    )
  )
}
original_depth_breaks <- c(0, 0.01, 0.025, 0.05, 0.10, 0.15, 0.20, 0.30, 0.50, 1)
log_depth_breaks <- log1p(99 * original_depth_breaks) / log(100)
display_depth_breaks <- expand_shared_axis(log_depth_breaks)

stopifnot(
  nrow(source) == 91,
  n_distinct(source$OG) == 91,
  all(source$mrca_available),
  all(source$mapped_mag_fraction == 1),
  all(source$unresolved_taxon_lineage_n == 0),
  all(source$direct_actin_superfamily_excluded)
)

category_levels <- c(
  "Nuclear-information regulation",
  "Cytoskeletal-cellular architecture",
  "Membrane-trafficking dynamics",
  "Proteostasis-metabolism-stress"
)
category_y <- setNames(c(4, 3, 2, 1), category_levels)
category_colors <- c(
  "Nuclear-information regulation" = "#C57A3E",
  "Cytoskeletal-cellular architecture" = "#3479B9",
  "Membrane-trafficking dynamics" = "#6B9F4A",
  "Proteostasis-metabolism-stress" = "#8A67B8"
)
module_category <- c(
  "Actin/cytoskeletal machinery" = "Cytoskeletal-cellular architecture",
  "ESCRT/Cdv membrane abscission" =
    "Membrane-trafficking dynamics",
  "Vesicle trafficking small GTPases" =
    "Membrane-trafficking dynamics",
  "Membrane remodeling/endocytosis" =
    "Membrane-trafficking dynamics",
  "Trafficking/secretion" =
    "Membrane-trafficking dynamics",
  "Folding/chaperone systems" = "Proteostasis-metabolism-stress",
  "Proteolysis/ubiquitin systems" = "Proteostasis-metabolism-stress",
  "Chromatin/genome organization" = "Nuclear-information regulation",
  "Motility/motor systems" = "Cytoskeletal-cellular architecture",
  "Repeat/coiled-coil scaffolds" =
    "Cytoskeletal-cellular architecture"
)
module_offsets <- c(
  "Actin/cytoskeletal machinery" = 0,
  "ESCRT/Cdv membrane abscission" = 0.16,
  "Vesicle trafficking small GTPases" = 0.05,
  "Membrane remodeling/endocytosis" = -0.06,
  "Trafficking/secretion" = -0.17,
  "Folding/chaperone systems" = 0.08,
  "Proteolysis/ubiquitin systems" = -0.08,
  "Chromatin/genome organization" = 0,
  "Motility/motor systems" = 0.07,
  "Repeat/coiled-coil scaffolds" = -0.07
)

plot_source <- source %>%
  arrange(OG) %>%
  mutate(
    functional_category = unname(module_category[network_module]),
    functional_category = factor(functional_category, levels = category_levels),
    category_y = unname(category_y[as.character(functional_category)]),
    module_offset = unname(module_offsets[network_module]),
    y_plot = category_y + module_offset,
    association_evidence_rank = rank(
      -association_priority_log10,
      ties.method = "first",
      na.last = "keep"
    ),
    topology_evidence_rank = if_else(
      max_primary_shared_tips >= 20 & !is.na(best_primary_topology_similarity),
      rank(-if_else(
        max_primary_shared_tips >= 20,
        best_primary_topology_similarity,
        NA_real_
      ), ties.method = "first", na.last = "keep"),
      NA_integer_
    ),
    association_top20 = association_evidence_rank <= 20,
    topology_top20 = !is.na(topology_evidence_rank) & topology_evidence_rank <= 20,
    strong_evidence_class = case_when(
      association_top20 & topology_top20 ~ "Top 20 association + topology",
      association_top20 ~ "Top 20 association",
      topology_top20 ~ "Top 20 topology",
      TRUE ~ "Standard current-network OG"
    ),
    axis_position_shared = expand_shared_axis(axis_position_log_expanded),
    compact_function = str_trim(str_extract(functional_description_summary, "[^|]+$")),
    compact_function = if_else(
      is.na(compact_function) | compact_function == "",
      str_replace_all(functional_subgroup_v2, "_", " "),
      compact_function
    ),
    short_gene = str_remove(
      str_extract(coalesce(eggnog_top_preferred_names, ""), "^[^;]+"),
      ":\\d+$"
    ),
    short_gene = if_else(
      is.na(short_gene) | short_gene %in% c("", "map", "NA"),
      coalesce(hmmscan_pfam_best_domain, compact_function),
      short_gene
    ),
    short_gene = if_else(
      nchar(short_gene) > 18,
      coalesce(hmmscan_pfam_best_domain, OG),
      short_gene
    ),
    module_specific_annotation_support = case_when(
      network_module == "ESCRT/Cdv membrane abscission" ~
        str_detect(compact_function, regex("snf7|escrt|vps", ignore_case = TRUE)),
      network_module == "Vesicle trafficking small GTPases" ~
        str_detect(
          compact_function,
          regex(
            "ras family|rab subfamily|adp-ribosylation factor|gtr1/raga|\\barf[0-9]",
            ignore_case = TRUE
          )
        ),
      network_module == "Motility/motor systems" ~
        str_detect(
          compact_function,
          regex(
            "dynein|kinesin|myosin|dynactin|roadblock/lc7|motor",
            ignore_case = TRUE
          )
        ),
      TRUE ~ TRUE
    )
  ) %>%
  group_by(functional_category) %>%
  mutate(
    zero_axis_n = sum(axis_position_shared == 0),
    zero_axis_rank = if_else(
      axis_position_shared == 0,
      cumsum(axis_position_shared == 0),
      NA_integer_
    ),
    axis_position_display = if_else(
      axis_position_shared == 0,
      0.003 + (zero_axis_rank - 1) * 0.0012,
      axis_position_shared
    )
  ) %>%
  ungroup()

available <- plot_source %>%
  filter(mrca_available, !is.na(functional_category))

stopifnot(
  all(is.finite(available$axis_position_shared)),
  all(available$axis_position_shared >= 0),
  all(available$axis_position_shared <= 1)
)

representatives <- available %>%
  arrange(
    network_module,
    desc(module_specific_annotation_support),
    mrca_depth_norm,
    formal_integrated_rank,
    desc(n_mags_present),
    OG
  ) %>%
  group_by(network_module) %>%
  slice_head(n = 1) %>%
  ungroup() %>%
  mutate(
    label_offset_y = case_when(
      network_module == "Actin/cytoskeletal machinery" ~ 0.40,
      network_module == "Vesicle trafficking small GTPases" ~ 0.25,
      network_module == "ESCRT/Cdv membrane abscission" ~ -0.34,
      network_module == "Trafficking/secretion" ~ 0.54,
      network_module == "Folding/chaperone systems" ~ -0.31,
      network_module == "Proteolysis/ubiquitin systems" ~ 0.27,
      network_module == "Motility/motor systems" ~ 0.28,
      network_module == "Repeat/coiled-coil scaffolds" ~ -0.39,
      TRUE ~ 0.30
    ),
    label_offset_x = case_when(
      network_module == "Vesicle trafficking small GTPases" ~ -0.055,
      network_module == "ESCRT/Cdv membrane abscission" ~ -0.03,
      network_module == "Trafficking/secretion" ~ 0.065,
      network_module == "Folding/chaperone systems" ~ 0.03,
      network_module == "Proteolysis/ubiquitin systems" ~ -0.02,
      network_module == "Motility/motor systems" ~ -0.03,
      network_module == "Repeat/coiled-coil scaffolds" ~ 0.02,
      TRUE ~ 0.015
    ),
    label_y = category_y + label_offset_y,
    label_x = pmax(0.04, pmin(0.96, axis_position_shared + label_offset_x)),
    label = short_gene
  )

label_source <- available %>%
  mutate(
    module_earliest_representative = OG %in% representatives$OG,
    label_reason = case_when(
      module_earliest_representative & association_top20 & topology_top20 ~
        "module representative + association top 20 + topology top 20",
      module_earliest_representative & association_top20 ~
        "module representative + association top 20",
      module_earliest_representative & topology_top20 ~
        "module representative + topology top 20",
      module_earliest_representative ~ "module representative",
      association_top20 & topology_top20 ~
        "association top 20 + topology top 20",
      association_top20 ~ "association top 20",
      topology_top20 ~ "topology top 20",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(label_reason)) %>%
  mutate(label = short_gene)

pending_by_category <- module_coverage %>%
  mutate(
    functional_category = unname(module_category[network_module]),
    category_y = unname(category_y[functional_category])
  ) %>%
  group_by(functional_category, category_y) %>%
  summarise(
    pending_og_n = sum(mrca_missing_n),
    pending_modules = paste(
      network_module[mrca_missing_n > 0],
      collapse = "; "
    ),
    .groups = "drop"
  ) %>%
  filter(pending_og_n > 0) %>%
  mutate(
    pending_label = paste0(
      "MRCA pending: ", pending_og_n, " OG",
      if_else(pending_og_n == 1, "", "s")
    )
  )

audit <- tibble(
  metric = c(
    "current_network_og_n",
    "mrca_available_og_n",
    "mrca_missing_og_n",
    "functional_category_n",
    "zero_axis_og_n",
    "represented_functional_category_n",
    "current_module_n",
    "represented_module_n",
    "association_top20_n_revised91",
    "topology_top20_n_revised91",
    "both_top20_n_revised91",
    "labeled_union_n",
    "all_association_top20_labeled",
    "all_topology_top20_labeled",
    "shared_axis_display_left",
    "shared_axis_display_right",
    "figure_width_in",
    "figure_height_in",
    "direct_actin_superfamily_og_n",
    "gtdb_release",
    "figure_status"
  ),
  value = c(
    n_distinct(plot_source$OG),
    n_distinct(available$OG),
    sum(!plot_source$mrca_available),
    length(category_levels),
    sum(plot_source$axis_position_shared == 0),
    n_distinct(available$functional_category),
    n_distinct(plot_source$network_module),
    n_distinct(available$network_module),
    sum(plot_source$association_top20),
    sum(plot_source$topology_top20),
    sum(plot_source$association_top20 & plot_source$topology_top20),
    n_distinct(label_source$OG),
    all(plot_source$OG[plot_source$association_top20] %in% label_source$OG),
    all(plot_source$OG[plot_source$topology_top20] %in% label_source$OG),
    display_left,
    display_right,
      16.0,
      6.8,
    sum(!plot_source$direct_actin_superfamily_excluded),
    "r226",
    "revised_formal_network_91_strict_taxon_mrca_r226_four_functional_classes"
  )
)

write_tsv(
  plot_source,
  file.path(
    data_dir,
    "fig20_1338_current_positive_functional_network_module_axis_four_classes_source.tsv"
  )
)
write_tsv(
  representatives,
  file.path(
    data_dir,
    "fig20_1338_current_functional_network_module_axis_four_classes_representatives.tsv"
  )
)
write_tsv(
  label_source,
  file.path(
    data_dir,
    "fig20_1338_current_functional_network_module_axis_four_classes_label_selection.tsv"
  )
)
write_tsv(
  pending_by_category,
  file.path(
    data_dir,
    "fig20_1338_current_functional_network_module_axis_four_classes_pending_mrca.tsv"
  )
)
write_tsv(
  audit,
  file.path(
    data_dir,
    "fig20_1338_current_functional_network_module_axis_four_classes_audit.tsv"
  )
)

font_family <- "Arial"
dark <- "#273444"
outline_shapes <- c(
  "Top 20 association" = 22,
  "Top 20 topology" = 23,
  "Top 20 association + topology" = 8
)

p <- ggplot(available, aes(x = axis_position_shared, y = y_plot)) +
  annotate(
    "rect", xmin = 0, xmax = display_left, ymin = -Inf, ymax = Inf,
    fill = "#F3F4F6", alpha = 0.55
  ) +
  annotate(
    "rect", xmin = display_left, xmax = display_right, ymin = -Inf, ymax = Inf,
    fill = "#E8EEF5", alpha = 0.42
  ) +
  annotate(
    "rect", xmin = display_right, xmax = 1, ymin = -Inf, ymax = Inf,
    fill = "#F3F4F6", alpha = 0.55
  ) +
  geom_hline(
    yintercept = unname(category_y),
    linewidth = 0.4,
    colour = "#D2D6DC"
  ) +
  geom_point(
    aes(
      x = axis_position_display,
      fill = functional_category,
      size = n_mags_present_gene_count
    ),
    shape = 21,
    colour = "white",
    stroke = 0.25,
    alpha = 0.25
  ) +
  geom_point(
    data = representatives,
    aes(x = axis_position_display, fill = functional_category),
    shape = 21,
    size = 4.8,
    colour = "white",
    stroke = 0.5,
    alpha = 1,
    show.legend = FALSE
  ) +
  geom_point(
    data = filter(
      available,
      strong_evidence_class != "Standard current-network OG"
    ),
    aes(
      x = axis_position_display,
      shape = strong_evidence_class
    ),
    size = 3.5,
    fill = NA,
    colour = "#111111",
    stroke = 0.72
  ) +
  geom_text_repel(
    data = label_source,
    aes(
      x = axis_position_display,
      y = y_plot,
      label = label,
      colour = functional_category
    ),
    family = font_family,
    size = 2.05,
    lineheight = 0.9,
    min.segment.length = 0,
    segment.size = 0.2,
    box.padding = 0.18,
    point.padding = 0.06,
    force = 2,
    force_pull = 0.25,
    direction = "both",
    max.time = 5,
    max.iter = 50000,
    max.overlaps = Inf,
    seed = 20,
    show.legend = FALSE
  ) +
  annotate(
    "text", x = display_left / 2, y = 4.48,
    label = "shared archaeal stem", family = font_family,
    size = 2.35, colour = "#667085"
  ) +
  annotate(
    "text", x = (display_left + display_right) / 2, y = 4.48,
    label = "phylum MRCA window", family = font_family,
    size = 2.35, colour = "#465166"
  ) +
  annotate(
    "text", x = (display_right + 1) / 2, y = 4.48,
    label = "within-phylum diversification to tips", family = font_family,
    size = 2.35, colour = "#667085"
  ) +
  geom_text(
    data = pending_by_category,
    aes(
      x = 0.995,
      y = category_y - 0.31,
      label = pending_label
    ),
    inherit.aes = FALSE,
    family = font_family,
    size = 2.25,
    hjust = 1,
    colour = "#7A8493"
  ) +
  scale_y_continuous(
    breaks = unname(category_y),
    labels = names(category_y),
    limits = c(0.48, 4.55),
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_x_continuous(
    limits = c(-0.015, 1.015),
    breaks = display_depth_breaks,
    labels = c("0", "0.01", "0.025", "0.05", "0.1", "0.15", "0.2", "0.3", "0.5", "1"),
    expand = expansion(mult = 0)
  ) +
  scale_fill_manual(values = category_colors, guide = "none") +
  scale_colour_manual(values = category_colors, guide = "none") +
  scale_shape_manual(
    values = outline_shapes,
    breaks = names(outline_shapes),
    name = "Current evidence strength"
  ) +
  scale_size_continuous(
    range = c(1.5, 4.3),
    breaks = c(25, 50, 100, 200),
    name = "MAGs carrying OG"
  ) +
  guides(
    shape = guide_legend(
      order = 1,
      override.aes = list(fill = NA, colour = "#111111", size = 3.2)
    ),
    size = guide_legend(
      order = 2,
      override.aes = list(
        shape = 21,
        fill = "#AAB4C0",
        colour = "white",
        alpha = 0.85
      )
    )
  ) +
  labs(
    title = "Four broad functional classes across the GTDB r226 actin-network axis",
    subtitle = paste0(
      "Auditable MRCA positions for ", n_distinct(available$OG),
      "/91 curated non-direct canonical/tail positives; four-class recoding; outlines mark top-20 evidence"
    ),
    x = "shared GTDB r226 root-to-MRCA display axis (0–1)",
    y = NULL,
    caption = paste0(
      "Labels: module representatives and association/topology top-20 OGs; ",
      "text shows short gene/domain names only.\n",
      "All 91 retained OGs passed GTDB r226 mapping and MRCA audit; 32 candidates are deferred."
    )
  ) +
  theme_classic(base_size = 8.1, base_family = font_family) +
  theme(
    axis.line.y = element_blank(),
    axis.line.x = element_line(linewidth = 0.7, colour = "#8A8A8A"),
    axis.ticks = element_blank(),
    axis.text.y = element_text(
      face = "bold",
      size = 7.7,
      colour = "#3A424D",
      margin = margin(r = 10)
    ),
    axis.text.x = element_text(size = 7.8, colour = "#555555"),
    axis.title.x = element_text(size = 8.5, margin = margin(t = 6)),
    plot.title = element_text(face = "bold", size = 10.2, colour = "#111111"),
    plot.subtitle = element_text(size = 8.2, colour = "#5D6675"),
    plot.caption = element_text(size = 6.7, colour = "#667085", hjust = 0),
    legend.position = "inside",
    legend.position.inside = c(0.865, 0.61),
    legend.justification = c(0, 0.5),
    legend.box = "vertical",
    legend.box.spacing = grid::unit(1.5, "pt"),
    legend.background = element_rect(
      fill = scales::alpha("white", 0.88),
      colour = NA
    ),
    legend.margin = margin(3, 4, 3, 4),
    legend.key.height = grid::unit(10, "pt"),
    legend.title = element_text(face = "bold", size = 7.3),
    legend.text = element_text(size = 6.7),
    panel.grid = element_blank(),
    plot.margin = margin(22, 16, 12, 10)
  ) +
  coord_cartesian(clip = "off")

stem <- file.path(
  figure_dir,
    "fig20_1338_current_positive_euk_actin_functional_network_module_axis_four_classes"
)

grDevices::cairo_pdf(
  paste0(stem, ".pdf"),
  width = 16.0,
  height = 6.8,
  family = font_family
)
print(p)
grDevices::dev.off()

ragg::agg_png(
  paste0(stem, ".png"),
  width = 16.0,
  height = 6.8,
  units = "in",
  res = 600,
  background = "white"
)
print(p)
grDevices::dev.off()

message(
  "Saved Fig. 20 with ",
  n_distinct(available$OG),
  "/91 positioned OGs across ",
  n_distinct(available$network_module),
  "/10 modules"
)
