# 1338_current_positive_euk_actin_functional_network_module_axis_four_classes

- Manuscript panel: Fig.8A-part3
- Source figure basename: fig20_1338_current_positive_euk_actin_functional_network_module_axis_four_classes
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 14 directly referenced or locally packaged source-data file(s)
