suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(ragg)
})

root <- ".."
source_dir <- file.path(root, "source_data")
figure_dir <- file.path(root, "figures")
fig3_dir <- ".."

dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(fig3_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read_tsv(
  file.path(source_dir, "effective_stage1_combined_13104_20260721.tsv"),
  show_col_types = FALSE
)
context_map <- read_tsv(
  file.path(source_dir, "delta_kcf_fullscreen_template_context_audit.tsv"),
  show_col_types = FALSE
) %>%
  distinct(template, context_final)

ids <- c(
  ACTB_WT = "AFSERVER_tail_mutant_EUK_HUMAN_ACTB__WT",
  ACTB_DKCF = "AFSERVER_tail_mutant_EUK_HUMAN_ACTB__DELTA_KCF",
  ACTA1_WT = "AFSERVER_tail_mutant_EUK_RABBIT_ACTA1_8F8P__WT",
  ACTA1_DKCF = "AFSERVER_tail_mutant_EUK_RABBIT_ACTA1_8F8P__DELTA_KCF",
  Drosophila = "LEGACY_dro_act_AF-P02572-F1-model_v6",
  Yeast = "LEGACY_yeast_act_AF-P60010-F1-model_v6",
  Symbiodinium = "LEGACY_Symbiodinium_act_AF-A0A1Q9CGX8-F1-model_v6",
  Tetrahymena = "AFSERVER_tail_mutant_EUK_TETRAHYMENA_ACTIN__WT_NATURAL_NON_KCF",
  Giardia = "LEGACY_Giardia_act_AF-A0A132NN04-F1-model_v6"
)

metric_defs <- tibble::tribble(
  ~metric, ~metric_label, ~adverse_direction,
  "contacts_5A", "Contacts reduced", "lower",
  "buried_surface_area_A2", "Buried area reduced", "lower",
  "prodigy_affinity", "PRODIGY affinity weakened", "higher",
  "minimum_interchain_distance_A", "Minimum distance increased", "higher",
  "foldx_interaction_energy", "FoldX interaction weakened", "higher",
  "clashes_2A", "Clashes increased", "higher"
)
metric_order <- metric_defs$metric_label

stopifnot(
  nrow(raw) == 13104L,
  n_distinct(raw$candidate) == 84L,
  n_distinct(raw$template) == 156L,
  nrow(context_map) == 156L,
  all(ids %in% raw$candidate)
)

selected <- raw %>%
  filter(candidate %in% ids) %>%
  mutate(state_key = names(ids)[match(candidate, ids)])
stopifnot(all((selected %>% count(state_key))$n == 156L))

wide <- selected %>%
  select(state_key, template, all_of(metric_defs$metric)) %>%
  pivot_longer(all_of(metric_defs$metric), names_to = "metric", values_to = "value") %>%
  left_join(metric_defs, by = "metric") %>%
  select(-metric_label, -adverse_direction) %>%
  pivot_wider(names_from = state_key, values_from = value)

natural_specs <- tibble::tribble(
  ~state_key, ~candidate_label, ~terminal_class, ~reference_key,
  "ACTA1_WT", "Rabbit ACTA1 (KCF)", "Natural KCF-bearing", "ACTB_WT",
  "Drosophila", "Drosophila ACT2 (KCF)", "Natural KCF-bearing", "ACTB_WT",
  "Yeast", "Yeast actin (KCF)", "Natural KCF-bearing", "ACTB_WT",
  "Symbiodinium", "Symbiodinium actin (KCF)", "Natural KCF-bearing", "ACTB_WT",
  "Tetrahymena", "Tetrahymena actin (RKVLF)", "Natural non-KCF", "ACTB_WT",
  "Giardia", "Giardia actin (RRF)", "Natural non-KCF", "ACTB_WT"
)

natural_detail <- bind_rows(lapply(seq_len(nrow(natural_specs)), function(i) {
  s <- natural_specs[i, ]
  wide %>%
    transmute(
      template, metric,
      state_key = s$state_key,
      candidate_label = s$candidate_label,
      terminal_class = s$terminal_class,
      reference_label = "Human ACTB (KCF)",
      candidate_value = .data[[s$state_key]],
      reference_value = .data[[s$reference_key]]
    )
})) %>%
  left_join(metric_defs, by = "metric") %>%
  mutate(
    delta_vs_reference = candidate_value - reference_value,
    supports_weaker_interface = case_when(
      adverse_direction == "lower" ~ candidate_value < reference_value,
      adverse_direction == "higher" ~ candidate_value > reference_value,
      TRUE ~ NA
    )
  )

natural_summary <- natural_detail %>%
  group_by(state_key, candidate_label, terminal_class, metric, metric_label) %>%
  summarise(
    n_templates = sum(!is.na(supports_weaker_interface)),
    n_support = sum(supports_weaker_interface, na.rm = TRUE),
    proportion_support = n_support / n_templates,
    median_delta = median(delta_vs_reference, na.rm = TRUE),
    .groups = "drop"
  )

stopifnot(
  nrow(natural_detail) == 6L * 156L * 6L,
  nrow(natural_summary) == 36L,
  all(natural_summary$n_templates == 156L)
)

write_tsv(natural_detail, file.path(
  source_dir, "fig_natural_kcf_non_kcf_static_metric_support_template_source.tsv"
))
write_tsv(natural_summary, file.path(
  source_dir, "fig_natural_kcf_non_kcf_static_metric_support_summary_source.tsv"
))

candidate_levels <- natural_specs$candidate_label
offsets <- setNames(c(0.31, 0.19, 0.07, -0.07, -0.19, -0.31), candidate_levels)
palette <- c(
  "Rabbit ACTA1 (KCF)" = "#A9C7DD",
  "Drosophila ACT2 (KCF)" = "#86AEC9",
  "Yeast actin (KCF)" = "#6F98B5",
  "Symbiodinium actin (KCF)" = "#547F9D",
  "Tetrahymena actin (RKVLF)" = "#D7A267",
  "Giardia actin (RRF)" = "#A98AAE"
)
shapes <- c(21, 22, 23, 24, 25, 21)
names(shapes) <- candidate_levels

plot_metric <- natural_summary %>%
  mutate(
    candidate_label = factor(candidate_label, levels = candidate_levels),
    y_base = match(metric_label, rev(metric_order)),
    y = y_base + offsets[as.character(candidate_label)],
    label = paste0(n_support, "/", n_templates),
    label_x = proportion_support + if_else(proportion_support > 0.88, -0.018, 0.018),
    label_hjust = if_else(proportion_support > 0.88, 1, 0)
  )

p_metric <- ggplot(plot_metric, aes(x = proportion_support, y = y)) +
  geom_hline(yintercept = seq_along(metric_order), linewidth = 0.23, colour = "#E8E8E8") +
  geom_point(
    aes(fill = candidate_label, shape = candidate_label),
    size = 2.85, stroke = 0.4, colour = "#333333"
  ) +
  geom_text(
    aes(x = label_x, label = label, colour = candidate_label, hjust = label_hjust),
    size = 1.75, fontface = "bold", show.legend = FALSE
  ) +
  scale_fill_manual(values = palette, name = "Natural actin and terminal state") +
  scale_colour_manual(values = palette) +
  scale_shape_manual(values = shapes, name = "Natural actin and terminal state") +
  guides(
    fill = guide_legend(ncol = 2, byrow = TRUE),
    shape = guide_legend(ncol = 2, byrow = TRUE)
  ) +
  scale_x_continuous(
    labels = scales::label_percent(accuracy = 1), breaks = seq(0, 1, 0.2),
    limits = c(-0.02, 1.04), expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    breaks = seq_along(metric_order), labels = rev(metric_order),
    limits = c(0.5, 6.5), expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Natural non-KCF actins do not phenocopy a single\nuniform interface-loss state",
    subtitle = "Six natural actins compared template-by-template with Human ACTB across 156 experimental complexes",
    x = "Templates in which the natural actin scores weaker than Human ACTB", y = NULL,
    caption = paste(
      "Labels show n/156. Blue symbols are natural KCF-bearing actins; orange and violet are natural non-KCF actins.\n",
      "These are whole-sequence offsets, not isolated terminal-motif effects; templates are structural contexts, not biological replicates."
    )
  ) +
  theme_classic(base_size = 8.0, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#222222"),
    axis.text.y = element_text(size = 7.2),
    legend.position = "top", legend.justification = "left", legend.box = "vertical",
    legend.key.width = grid::unit(4.5, "mm"), legend.key.height = grid::unit(4.0, "mm"),
    legend.title = element_text(size = 7.0, face = "bold"),
    legend.text = element_text(size = 6.7),
    plot.title = element_text(size = 9.4, face = "bold"),
    plot.subtitle = element_text(size = 7.8, colour = "#4D4D4D"),
    plot.caption = element_text(size = 6.6, colour = "#666666", hjust = 0),
    panel.grid = element_blank(),
    plot.margin = margin(8, 12, 8, 8)
  )

stem_metric <- file.path(figure_dir, "fig_natural_kcf_non_kcf_static_metric_support")
ggsave(paste0(stem_metric, ".pdf"), p_metric, device = grDevices::cairo_pdf,
       width = 175, height = 145, units = "mm", family = "Arial")
ggsave(paste0(stem_metric, ".png"), p_metric, device = ragg::agg_png,
       width = 175, height = 145, units = "mm", dpi = 600, background = "white")

comparison_specs <- tibble::tribble(
  ~comparison_key, ~candidate_key, ~reference_key, ~comparison_label, ~comparison_class,
  "ACTB_DKCF", "ACTB_DKCF", "ACTB_WT", "Human ACTB Delta KCF", "Artificial deletion",
  "ACTA1_DKCF", "ACTA1_DKCF", "ACTA1_WT", "Rabbit ACTA1 Delta KCF", "Artificial deletion",
  "Tetrahymena", "Tetrahymena", "ACTB_WT", "Tetrahymena RKVLF", "Natural non-KCF",
  "Giardia", "Giardia", "ACTB_WT", "Giardia RRF", "Natural non-KCF"
)

context_detail <- bind_rows(lapply(seq_len(nrow(comparison_specs)), function(i) {
  s <- comparison_specs[i, ]
  wide %>%
    transmute(
      template, metric,
      comparison_key = s$comparison_key,
      comparison_label = s$comparison_label,
      comparison_class = s$comparison_class,
      candidate_value = .data[[s$candidate_key]],
      reference_value = .data[[s$reference_key]]
    )
})) %>%
  left_join(metric_defs, by = "metric") %>%
  mutate(
    supports_weaker_interface = case_when(
      adverse_direction == "lower" ~ candidate_value < reference_value,
      adverse_direction == "higher" ~ candidate_value > reference_value,
      TRUE ~ NA
    )
  ) %>%
  filter(metric != "minimum_interchain_distance_A") %>%
  select(template, comparison_key, comparison_label, comparison_class,
         metric, supports_weaker_interface) %>%
  pivot_wider(names_from = metric, values_from = supports_weaker_interface) %>%
  mutate(
    support_count = rowSums(across(all_of(c(
      "contacts_5A", "buried_surface_area_A2", "prodigy_affinity",
      "foldx_interaction_energy", "clashes_2A"
    ))), na.rm = TRUE),
    n_metrics_available = rowSums(!is.na(across(all_of(c(
      "contacts_5A", "buried_surface_area_A2", "prodigy_affinity",
      "foldx_interaction_energy", "clashes_2A"
    ))))),
    consensus_loss = support_count >= 3L
  ) %>%
  left_join(context_map, by = "template")

context_summary <- context_detail %>%
  group_by(comparison_key, comparison_label, comparison_class, context_final) %>%
  summarise(
    n_templates = n(),
    n_consensus = sum(consensus_loss),
    fraction_consensus = n_consensus / n_templates,
    .groups = "drop"
  )

context_order <- context_summary %>%
  group_by(context_final) %>%
  summarise(
    non_kcf_mean = mean(fraction_consensus[comparison_class == "Natural non-KCF"]),
    artificial_mean = mean(fraction_consensus[comparison_class == "Artificial deletion"]),
    natural_minus_artificial = non_kcf_mean - artificial_mean,
    .groups = "drop"
  ) %>%
  arrange(natural_minus_artificial, context_final) %>%
  mutate(y_base = row_number())

stopifnot(
  nrow(context_detail) == 4L * 156L,
  all(context_detail$n_metrics_available == 5L),
  n_distinct(context_summary$context_final) == 18L,
  nrow(context_summary) == 72L
)

write_tsv(context_detail, file.path(
  source_dir, "fig_artificial_vs_natural_non_kcf_partner_context_template_source.tsv"
))
write_tsv(context_summary, file.path(
  source_dir, "fig_artificial_vs_natural_non_kcf_partner_context_source.tsv"
))
write_tsv(context_order, file.path(
  source_dir, "fig_artificial_vs_natural_non_kcf_partner_context_order_source.tsv"
))

comparison_levels <- comparison_specs$comparison_label
context_palette <- c(
  "Human ACTB Delta KCF" = "#D3B17A",
  "Rabbit ACTA1 Delta KCF" = "#B98D55",
  "Tetrahymena RKVLF" = "#76A9A1",
  "Giardia RRF" = "#9B86A5"
)
context_shapes <- c(21, 24, 22, 23)
names(context_shapes) <- comparison_levels
context_offsets <- setNames(c(0.27, 0.09, -0.09, -0.27), comparison_levels)

plot_context <- context_summary %>%
  left_join(context_order %>% select(context_final, y_base), by = "context_final") %>%
  mutate(
    comparison_label = factor(comparison_label, levels = comparison_levels),
    y = y_base + context_offsets[as.character(comparison_label)],
    label = paste0(n_consensus, "/", n_templates),
    label_x = fraction_consensus + if_else(fraction_consensus > 0.90, -0.018, 0.018),
    label_hjust = if_else(fraction_consensus > 0.90, 1, 0)
  )

context_labels <- context_order %>%
  transmute(y_base, label = gsub("_", " ", context_final))

p_context <- ggplot(plot_context, aes(x = fraction_consensus, y = y)) +
  geom_hline(yintercept = context_order$y_base, linewidth = 0.22, colour = "#E8E8E8") +
  geom_point(
    aes(fill = comparison_label, shape = comparison_label),
    size = 2.75, stroke = 0.42, colour = "#2D2D2D"
  ) +
  geom_text(
    aes(x = label_x, label = label, colour = comparison_label, hjust = label_hjust),
    size = 1.85, fontface = "bold", show.legend = FALSE
  ) +
  scale_fill_manual(values = context_palette, name = "Comparison") +
  scale_colour_manual(values = context_palette) +
  scale_shape_manual(values = context_shapes, name = "Comparison") +
  guides(
    fill = guide_legend(ncol = 2, byrow = TRUE),
    shape = guide_legend(ncol = 2, byrow = TRUE)
  ) +
  scale_x_continuous(
    labels = scales::label_percent(accuracy = 1), breaks = seq(0, 1, 0.2),
    limits = c(-0.05, 1.05), expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    breaks = context_labels$y_base, labels = context_labels$label,
    limits = c(0.55, 18.45), expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Artificial KCF deletion and natural non-KCF actins show\ndistinct partner-context responses",
    subtitle = "Matched static replacement across the same 156 experimental templates",
    x = "Templates with at least 3 of 5 metrics supporting interface loss", y = NULL,
    caption = paste0(
      "Labels show n/N within each refined context. Delta-KCF states use their matched WT;\n",
      "natural non-KCF actins use Human ACTB as reference. Natural-sequence comparisons include\n",
      "whole-sequence divergence and cannot isolate the causal effect of the terminal motif."
    )
  ) +
  theme_classic(base_size = 8.0, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
    axis.text = element_text(colour = "#222222"),
    axis.text.y = element_text(size = 6.6),
    legend.position = "top", legend.justification = "left", legend.box = "vertical",
    legend.key.width = grid::unit(4.5, "mm"), legend.key.height = grid::unit(4.0, "mm"),
    legend.title = element_text(size = 7.0, face = "bold"),
    legend.text = element_text(size = 6.9),
    plot.title = element_text(size = 9.3, face = "bold"),
    plot.subtitle = element_text(size = 7.8, colour = "#4D4D4D"),
    plot.caption = element_text(size = 6.6, colour = "#666666", hjust = 0),
    panel.grid = element_blank(),
    plot.margin = margin(8, 12, 8, 8)
  )

stem_context <- file.path(figure_dir, "fig_artificial_vs_natural_non_kcf_partner_context_consensus")
ggsave(paste0(stem_context, ".pdf"), p_context, device = grDevices::cairo_pdf,
       width = 180, height = 205, units = "mm", family = "Arial")
ggsave(paste0(stem_context, ".png"), p_context, device = ragg::agg_png,
       width = 180, height = 205, units = "mm", dpi = 600, background = "white")

stopifnot(all(file.info(c(
  paste0(stem_metric, c(".pdf", ".png")),
  paste0(stem_context, c(".pdf", ".png"))
))$size > 10000))

writeLines(c(
  "PASS", "backend=R", "templates=156", "metrics=6",
  "natural_actins=6", "kcf_bearing_natural=4", "non_kcf_natural=2",
  "reference=Human_ACTB_KCF", "whole_sequence_confound_explicit=yes",
  "independent_biological_replicates=no"
), paste0(stem_metric, ".QA.marker"))

writeLines(c(
  "PASS", "backend=R", "templates=156", "contexts=18", "metrics_for_consensus=5",
  "artificial_delta_kcf_comparisons=2", "natural_non_kcf_comparisons=2",
  "matched_wt_for_delta_kcf=yes", "natural_reference=Human_ACTB_KCF",
  "whole_sequence_confound_explicit=yes", "independent_biological_replicates=no"
), paste0(stem_context, ".QA.marker"))

file.copy(paste0(stem_metric, ".pdf"), file.path(fig3_dir, basename(paste0(stem_metric, ".pdf"))), overwrite = TRUE)
file.copy(paste0(stem_context, ".pdf"), file.path(fig3_dir, basename(paste0(stem_context, ".pdf"))), overwrite = TRUE)

cat(sprintf(
  "metric_rows=%d context_rows=%d templates=%d contexts=%d\n",
  nrow(natural_summary), nrow(context_summary), n_distinct(raw$template),
  n_distinct(context_summary$context_final)
))
