# artificial_vs_natural_non_kcf_partner_context_consensus

- Manuscript panel: Supp.Fig.7D
- Source figure basename: fig_artificial_vs_natural_non_kcf_partner_context_consensus
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 7 directly referenced or locally packaged source-data file(s)
