# asgard_current_positive_negative_function_contrast_two_panel

- Manuscript panel: Supp.Fig.15C
- Source figure basename: fig17_asgard_current_positive_negative_function_contrast_two_panel
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 16 directly referenced or locally packaged source-data file(s)
