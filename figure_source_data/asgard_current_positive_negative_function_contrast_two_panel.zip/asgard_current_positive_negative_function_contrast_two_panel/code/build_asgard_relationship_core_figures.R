#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(purrr)
  library(ragg)
  library(readr)
  library(scales)
  library(stringr)
  library(tidyr)
})

args <- commandArgs(trailingOnly = TRUE)
viz_root <- if (length(args) >= 1L) {
  normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
} else {
  ".."
}
# The Asgard visualization root is the final output root; do not create a nested rebuild directory.
out_root <- viz_root
base_viz_root <- if (basename(viz_root) == "relationship_figure_rebuild_20260723") dirname(viz_root) else viz_root
data_dir <- file.path(out_root, "data")
figure_dir <- file.path(out_root, "figures")
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

formal_dir <- paste0(
  "..",
  "relationship_rebuild_20260719/data/formal_integrated_relationship_20260723"
)
annotation_file <- paste0(
  "..",
  "four_new_strategy_functional_reclassification_v2_20260718/",
  "four_group_og_functional_classification_v2.tsv"
)
network_file <- file.path(
  base_viz_root, "data", "asgard_positive_network_module_formal_selection.tsv"
)

font_family <- "Arial"
blue <- "#2F6FA3"
orange <- "#C9823F"
teal <- "#2A9D8F"
grey <- "#B9C0C9"
dark <- "#243247"
grid_colour <- "#E4E9F0"

theme_asgard <- function(base_size = 8.2) {
  theme_classic(base_size = base_size, base_family = font_family) +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = dark),
      axis.ticks = element_line(linewidth = 0.35, colour = dark),
      axis.text = element_text(colour = "#273548"),
      plot.title = element_text(face = "bold", size = base_size + 1.4),
      plot.subtitle = element_text(size = base_size, colour = "#53627A"),
      plot.caption = element_text(size = base_size - 1.15, colour = "#65748A", hjust = 0),
      legend.title = element_text(face = "bold"),
      panel.grid.major = element_line(linewidth = 0.25, colour = grid_colour),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 13, 8, 9)
    )
}

save_pair <- function(plot, stem, width_mm, height_mm, dpi = 600) {
  grDevices::cairo_pdf(
    file.path(figure_dir, paste0(stem, ".pdf")),
    width = width_mm / 25.4,
    height = height_mm / 25.4,
    family = font_family
  )
  print(plot)
  grDevices::dev.off()
  ragg::agg_png(
    file.path(figure_dir, paste0(stem, ".png")),
    width = width_mm,
    height = height_mm,
    units = "mm",
    res = dpi,
    background = "white"
  )
  print(plot)
  grDevices::dev.off()
}

first_item <- function(x) {
  str_remove(str_extract(coalesce(x, ""), "^[^;]+"), ":\\d+$")
}

functional_display <- function(x) {
  str_to_sentence(str_replace_all(coalesce(x, "unresolved_function"), "_", " "))
}

biological_group <- function(group, subgroup) {
  case_when(
    group == "information_processing" & subgroup %in% c(
      "DNA_replication_repair_COG", "DNA_replication_repair_recombination"
    ) ~ "DNA replication, recombination and repair",
    group == "information_processing" & subgroup == "RNA_processing_modification" ~
      "RNA processing and modification",
    group == "information_processing" & subgroup %in% c(
      "transcription_COG", "transcription_regulation"
    ) ~ "Transcription and transcriptional regulation",
    group == "information_processing" & subgroup %in% c(
      "translation_ribosome", "translation_ribosome_COG"
    ) ~ "Translation and ribosome biogenesis",
    group == "information_processing" & subgroup == "chromatin_genome_organization" ~
      "Chromatin and genome organization",
    TRUE ~ functional_display(group)
  )
}

positive <- read_tsv(
  file.path(formal_dir, "asgard_positive_formal_integrated_ranked.tsv"),
  show_col_types = FALSE
)
negative <- read_tsv(
  file.path(formal_dir, "asgard_negative_frozen_ranked_no_formal_tree.tsv"),
  show_col_types = FALSE
)
annotation <- read_tsv(annotation_file, show_col_types = FALSE) %>%
  filter(dataset == "asgard971_denovo") %>%
  select(
    OG, selection_set_annotation = selection_set,
    annotation_detected, eggnog_top_preferred_names, eggnog_top_descriptions,
    hmmscan_pfam_best_domain, hmmscan_pfam_best_domain_desc,
    annotation_text_shared
  )

stopifnot(
  nrow(positive) == 693,
  n_distinct(positive$OG) == 693,
  nrow(negative) == 600,
  n_distinct(negative$OG) == 600,
  nrow(annotation) == 1293,
  n_distinct(annotation$OG) == 1293,
  length(intersect(positive$OG, negative$OG)) == 0,
  all(!positive$direct_actin_superfamily),
  all(positive$direct_actin_superfamily_excluded == FALSE),
  all(negative$direct_actin_superfamily_excluded == FALSE)
)

positive <- positive %>%
  inner_join(annotation, by = "OG") %>%
  mutate(
    association_set = "positive",
    association_priority_log10 = log10(canonical_tail_priority_score),
    biological_function_group = biological_group(
      functional_group_v2, functional_subgroup_v2
    )
  )
negative <- negative %>%
  inner_join(annotation, by = "OG") %>%
  mutate(
    association_set = "negative",
    biological_function_group = biological_group(
      functional_group_v2, functional_subgroup_v2
    )
  )
stopifnot(nrow(positive) == 693, nrow(negative) == 600)

all_ogs <- bind_rows(
  positive %>% transmute(
    OG, association_set, formal_integrated_rank, n_mags_present,
    functional_group_v2, functional_subgroup_v2,
    biological_function_group, annotation_detected,
    eggnog_top_preferred_names, eggnog_top_descriptions,
    hmmscan_pfam_best_domain, hmmscan_pfam_best_domain_desc,
    direct_actin_superfamily = FALSE
  ),
  negative %>% transmute(
    OG, association_set, formal_integrated_rank, n_mags_present,
    functional_group_v2, functional_subgroup_v2,
    biological_function_group, annotation_detected,
    eggnog_top_preferred_names, eggnog_top_descriptions,
    hmmscan_pfam_best_domain, hmmscan_pfam_best_domain_desc,
    direct_actin_superfamily = FALSE
  )
)

# Fig03: functional-group prevalence and direction.
group_counts <- all_ogs %>%
  filter(functional_group_v2 != "unresolved_function") %>%
  count(functional_group_v2, association_set, name = "n") %>%
  complete(functional_group_v2, association_set = c("positive", "negative"), fill = list(n = 0)) %>%
  pivot_wider(names_from = association_set, values_from = n) %>%
  rename(positive_count = positive, negative_count = negative) %>%
  mutate(
    positive_total = 693L,
    negative_total = 600L,
    positive_fraction = positive_count / positive_total,
    negative_fraction = negative_count / negative_total,
    odds_ratio = pmap_dbl(
      list(positive_count, negative_count),
      function(pos, neg) {
        unname(fisher.test(matrix(c(pos, 693 - pos, neg, 600 - neg), nrow = 2, byrow = TRUE))$estimate)
      }
    ),
    fisher_pvalue = pmap_dbl(
      list(positive_count, negative_count),
      function(pos, neg) {
        fisher.test(matrix(c(pos, 693 - pos, neg, 600 - neg), nrow = 2, byrow = TRUE))$p.value
      }
    ),
    fisher_qvalue_bh = p.adjust(fisher_pvalue, method = "BH"),
    log2_odds_ratio_pseudocount = log2(
      ((positive_count + 0.5) / (693 - positive_count + 0.5)) /
        ((negative_count + 0.5) / (600 - negative_count + 0.5))
    ),
    direction = if_else(log2_odds_ratio_pseudocount >= 0, "positive_enriched", "negative_enriched"),
    functional_label = functional_display(functional_group_v2),
    significant = fisher_qvalue_bh < 0.05
  ) %>%
  arrange(log2_odds_ratio_pseudocount) %>%
  mutate(functional_label = factor(functional_label, levels = functional_label))
write_tsv(group_counts, file.path(data_dir, "fig03_asgard_positive_negative_functional_contrast_v2.tsv"))

prevalence_long <- bind_rows(
  transmute(group_counts, functional_label, set = "Positive (n=693)", fraction = positive_fraction),
  transmute(group_counts, functional_label, set = "Negative (n=600)", fraction = negative_fraction)
)
p03a <- ggplot(group_counts, aes(y = functional_label)) +
  geom_segment(aes(x = positive_fraction, xend = negative_fraction, yend = functional_label), colour = "#C8D2E1", linewidth = 0.85) +
  geom_point(data = prevalence_long, aes(x = fraction, colour = set), size = 2.8) +
  scale_x_continuous(labels = label_percent(accuracy = 1), expand = expansion(mult = c(0.03, 0.10))) +
  scale_colour_manual(values = c("Positive (n=693)" = blue, "Negative (n=600)" = orange)) +
  labs(x = "OGs in functional group", y = NULL, colour = NULL, title = "Group prevalence") +
  theme_asgard(8) +
  theme(plot.title = element_text(size = 10.5), legend.position = c(0.72, 0.08), legend.background = element_rect(fill = alpha("white", 0.9), colour = NA), panel.grid.major.y = element_blank(), axis.text.y = element_text(size = 7.4))
p03b <- ggplot(group_counts, aes(x = log2_odds_ratio_pseudocount, y = functional_label)) +
  geom_vline(xintercept = 0, colour = "#687B98", linewidth = 0.55) +
  geom_segment(aes(x = 0, xend = log2_odds_ratio_pseudocount, yend = functional_label, colour = direction), linewidth = 0.75, alpha = 0.65) +
  geom_point(aes(colour = direction, alpha = significant), size = 2.8) +
  geom_text(data = filter(group_counts, significant), aes(label = paste0("q=", formatC(fisher_qvalue_bh, format = "g", digits = 2))), family = font_family, size = 2.3, colour = "#344054", nudge_y = 0.22, show.legend = FALSE) +
  scale_colour_manual(values = c(positive_enriched = blue, negative_enriched = orange)) +
  scale_alpha_manual(values = c(`TRUE` = 1, `FALSE` = 0.35)) +
  scale_x_continuous(expand = expansion(mult = c(0.12, 0.18))) +
  labs(x = "log2 odds ratio: positive vs negative", y = NULL, title = "Direction and BH-adjusted support") +
  theme_asgard(8) +
  theme(plot.title = element_text(size = 10.5), axis.text.y = element_blank(), panel.grid.major.y = element_blank(), legend.position = "none")
fig03 <- (p03a + p03b + plot_layout(widths = c(1.45, 1))) +
  plot_annotation(
    title = "Asgard positive-negative functional-group contrast",
    subtitle = "Frozen canonical/tail sets: 693 non-direct positive OGs versus 600 frozen negative OGs"
  )
save_pair(fig03, "fig03_asgard_positive_negative_functional_group_contrast_v2", 230, 128)

# Fig04: formal topology against association strength, stratified by fixed Asgard tiers.
fig04_source <- positive %>%
  mutate(
    topology_comparable = !is.na(formal_best_topology_similarity) & formal_max_shared_tips >= 4,
    tier_display = recode(
      canonical_tail_tier,
      "T1_both_broad" = "T1: both, broad Asgard",
      "T2_both_lineage_biased" = "T2: both, lineage-biased",
      "T2_canonical_broad" = "T2: canonical, broad Asgard",
      "T3_canonical_lineage_biased" = "T3: canonical, lineage-biased",
      "T4_tail_only" = "T4: tail-only"
    )
  )
x_unique <- sort(unique(fig04_source$association_priority_log10))
gap_table <- tibble(left = head(x_unique, -1), right = tail(x_unique, -1), gap = diff(x_unique)) %>%
  slice_max(gap, n = 4, with_ties = FALSE) %>% arrange(left) %>%
  mutate(boundary = (left + right) / 2)
band_levels <- paste0("Band ", 1:5)
fig04_source <- fig04_source %>%
  mutate(x_axis_band = cut(association_priority_log10, breaks = c(-Inf, gap_table$boundary, Inf), labels = band_levels, ordered_result = TRUE))
fig04_bands <- fig04_source %>%
  group_by(x_axis_band) %>%
  summarise(
    og_n = n(), x_min = min(association_priority_log10), x_max = max(association_priority_log10),
    tier_composition = paste(sort(unique(canonical_tail_tier)), collapse = ";"),
    .groups = "drop"
  ) %>%
  mutate(label_x = (x_min + x_max) / 2, band_label = paste0(x_axis_band, "\n(n=", og_n, ")"))
fig04_labels <- fig04_source %>%
  group_by(x_axis_band) %>%
  slice_max(formal_integrated_priority_score, n = 3, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(plot_label = paste0(OG, "\n", str_replace_all(functional_subgroup_v2, "_", " ")))
write_tsv(fig04_source, file.path(data_dir, "fig04_asgard_evidence_tier_within_tier_strength_source.tsv"))
write_tsv(gap_table, file.path(data_dir, "fig04_asgard_x_axis_four_natural_gaps.tsv"))
write_tsv(fig04_bands, file.path(data_dir, "fig04_asgard_x_axis_five_band_audit.tsv"))
write_tsv(fig04_labels, file.path(data_dir, "fig04_asgard_top3_ogs_per_x_axis_band_labels.tsv"))
fig04_tier_levels <- c("T1: both, broad Asgard", "T2: both, lineage-biased", "T2: canonical, broad Asgard", "T3: canonical, lineage-biased", "T4: tail-only")
tier_palette <- c("#2F6B9A", "#D9A62E", "#7E6BB3", "#4F9D69", "#B06F46")
names(tier_palette) <- fig04_tier_levels
p04 <- ggplot(filter(fig04_source, topology_comparable), aes(x = association_priority_log10, y = formal_best_topology_similarity, fill = factor(tier_display, levels = fig04_tier_levels), size = formal_max_shared_tips)) +
  geom_vline(data = gap_table, aes(xintercept = boundary), inherit.aes = FALSE, linetype = "dashed", colour = "#B6C0CF", linewidth = 0.45) +
  geom_hline(yintercept = c(0.4, 0.5), linetype = c("dashed", "dotted"), colour = "#8B9AAF", linewidth = 0.45) +
  geom_point(shape = 21, colour = "white", stroke = 0.3, alpha = 0.85) +
  geom_point(data = filter(fig04_labels, topology_comparable), aes(x = association_priority_log10, y = formal_best_topology_similarity), inherit.aes = FALSE, shape = 21, fill = NA, colour = "#172033", stroke = 0.9, size = 3.6, show.legend = FALSE) +
  geom_text_repel(data = filter(fig04_labels, topology_comparable), aes(label = plot_label), family = font_family, fontface = "bold", size = 2.05, colour = "#172033", seed = 971, force = 6, max.overlaps = Inf, box.padding = 0.32, point.padding = 0.26, min.segment.length = 0, segment.colour = "#5B6779", show.legend = FALSE) +
  geom_text(data = fig04_bands, aes(x = label_x, y = 1.07, label = band_label), inherit.aes = FALSE, family = font_family, fontface = "bold", size = 2.45, colour = "#334155", lineheight = 0.95) +
  scale_fill_manual(values = tier_palette, name = "Frozen Asgard evidence tier") +
  scale_size_continuous(range = c(1.6, 5.1), breaks = pretty_breaks(n = 4), name = "Shared tips") +
  coord_cartesian(ylim = c(0, 1.1), clip = "off") +
  labs(title = "Association-strength composition bands and formal actin-tree similarity", subtitle = "Five bands use the four largest observed gaps on the frozen Asgard association-priority axis", x = "Canonical/tail association priority, log10 scale", y = "Best formal topology similarity (1 - normalized RF)", caption = str_wrap("Points without a comparable formal topology result are retained in the source TSV but omitted from the scatter. Black rings label the top three integrated OGs per x-axis band.", 150)) +
  theme_asgard(8.2) + theme(legend.position = "right")
save_pair(p04, "fig04_asgard_evidence_tier_within_tier_strength_vs_topology", 230, 146)

# Fig06: five specifically annotated representatives per association direction.
specific_annotated <- function(x) {
  x %>% filter(annotation_detected, functional_group_v2 != "unresolved_function")
}
pos_rep <- specific_annotated(positive) %>%
  arrange(formal_integrated_rank, OG) %>% slice_head(n = 5) %>%
  mutate(within_set_evidence = percent_rank(formal_integrated_priority_score) * 100)
neg_rep <- specific_annotated(negative) %>%
  arrange(formal_integrated_rank, OG) %>% slice_head(n = 5) %>%
  mutate(within_set_evidence = -percent_rank(canonical_tail_negative_score) * 100)
fig06_source <- bind_rows(pos_rep, neg_rep) %>%
  mutate(
    association_set = factor(association_set, levels = c("positive", "negative")),
    og_label = factor(paste0(OG, " [", association_set, "]"), levels = rev(paste0(OG, " [", association_set, "]"))),
    preferred_name_short = first_item(eggnog_top_preferred_names),
    preferred_name_short = if_else(is.na(preferred_name_short) | preferred_name_short %in% c("", "NA", "map"), coalesce(hmmscan_pfam_best_domain, functional_subgroup_v2), preferred_name_short),
    description_short = first_item(eggnog_top_descriptions),
    description_short = if_else(is.na(description_short) | description_short == "", coalesce(hmmscan_pfam_best_domain_desc, functional_description_summary), description_short),
    annotation_label = paste0(preferred_name_short, "\n", str_trunc(description_short, 56)),
    lineage_label = if_else(association_set == "positive", lineage_scope, best_lineage_status)
  ) %>%
  arrange(association_set, formal_integrated_rank)
stopifnot(nrow(fig06_source) == 10, sum(fig06_source$association_set == "positive") == 5, sum(fig06_source$association_set == "negative") == 5)
write_tsv(fig06_source, file.path(data_dir, "fig06_asgard_representative_5pos_5neg_integrated_evidence_source.tsv"))
write_tsv(tibble(check = c("displayed_og_n", "positive_n", "negative_n", "direct_actin_n", "no_annotation_n"), value = c(nrow(fig06_source), 5, 5, sum(fig06_source$direct_actin_superfamily), sum(!fig06_source$annotation_detected))), file.path(data_dir, "fig06_asgard_representative_selection_audit.tsv"))
p06a <- ggplot(fig06_source, aes(y = og_label, x = within_set_evidence, colour = association_set)) +
  geom_vline(xintercept = 0, colour = "#718096", linewidth = 0.55) +
  geom_segment(aes(x = 0, xend = within_set_evidence, yend = og_label), linewidth = 0.75, alpha = 0.65) +
  geom_point(aes(size = n_mags_present), alpha = 0.9) +
  scale_colour_manual(values = c(positive = blue, negative = orange)) +
  scale_size_continuous(trans = "sqrt", range = c(2.8, 6.2), name = "Supporting MAGs") +
  labs(x = "Within-set association evidence percentile (negative left)", y = NULL, title = "Association direction", colour = NULL) +
  theme_asgard(7.7) + theme(panel.grid.major.y = element_blank(), legend.position = "bottom")
p06b <- ggplot(fig06_source, aes(y = og_label)) +
  geom_vline(xintercept = c(0.4, 0.5), linetype = c("dashed", "dotted"), colour = "#93A4BC") +
  geom_point(data = filter(fig06_source, association_set == "positive", !is.na(formal_best_topology_similarity)), aes(x = formal_best_topology_similarity, size = formal_max_shared_tips), shape = 21, fill = blue, colour = "#172033", stroke = 0.55) +
  geom_text(data = filter(fig06_source, association_set == "negative"), aes(x = 0.27, label = "not required"), family = font_family, size = 2.5, colour = "#7A8699") +
  scale_x_continuous(limits = c(0.2, 1.02), breaks = c(0.2, 0.4, 0.6, 0.8, 1)) +
  scale_y_discrete(limits = levels(fig06_source$og_label), drop = FALSE) +
  scale_size_continuous(range = c(2.7, 5.6), name = "Shared tips") +
  labs(x = "Formal topology similarity", y = NULL, title = "Formal-tree evidence") +
  theme_asgard(7.7) + theme(axis.text.y = element_blank(), panel.grid.major.y = element_blank(), legend.position = "bottom")
p06c <- ggplot(fig06_source, aes(y = og_label, x = 0)) +
  geom_text(aes(label = annotation_label, colour = association_set), hjust = 0, family = font_family, size = 2.15, lineheight = 0.93, show.legend = FALSE) +
  scale_colour_manual(values = c(positive = blue, negative = orange)) +
  scale_y_discrete(limits = levels(fig06_source$og_label), drop = FALSE) +
  coord_cartesian(xlim = c(0, 1), clip = "off") +
  labs(x = NULL, y = NULL, title = "Dominant functional annotation") +
  theme_void(base_family = font_family) + theme(plot.title = element_text(face = "bold", size = 9.1, colour = dark), plot.margin = margin(8, 50, 8, 4))
fig06 <- ((p06a + p06b + p06c) + plot_layout(widths = c(1.10, 0.98, 1.78), guides = "collect") +
  plot_annotation(title = "Representative Asgard positive and negative OGs", subtitle = "Five specifically annotated OGs per frozen set; formal topology is required only for positive OGs", caption = str_wrap("Association-evidence percentiles are calculated within each frozen set and are shown on opposite sides only for visual direction. Functional annotation is interpretive and does not modify ranks.", 170))) &
  theme(legend.position = "bottom")
save_pair(fig06, "fig06_asgard_representative_5pos_5neg_integrated_evidence", 270, 154)

# Fig14 and Fig17: biological functional-group contrast, with information processing split.
bio_counts <- all_ogs %>%
  count(biological_function_group, association_set, name = "n") %>%
  complete(biological_function_group, association_set = c("positive", "negative"), fill = list(n = 0)) %>%
  pivot_wider(names_from = association_set, values_from = n) %>%
  rename(positive_count = positive, negative_count = negative) %>%
  mutate(
    positive_total = 693L, negative_total = 600L,
    positive_fraction = positive_count / positive_total,
    negative_fraction = negative_count / negative_total,
    fraction_difference = positive_fraction - negative_fraction,
    percentage_point_difference = 100 * fraction_difference,
    fisher_pvalue = pmap_dbl(list(positive_count, negative_count), function(pos, neg) fisher.test(matrix(c(pos, 693-pos, neg, 600-neg), nrow = 2, byrow = TRUE))$p.value),
    fisher_qvalue_bh = p.adjust(fisher_pvalue, method = "BH"),
    log2_odds_ratio_pseudocount = log2(((positive_count + 0.5)/(693-positive_count+0.5))/((negative_count+0.5)/(600-negative_count+0.5))),
    direction = if_else(fraction_difference >= 0, "Positive-enriched", "Negative-enriched"),
    count_label = paste0("+", positive_count, " / -", negative_count, if_else(fisher_qvalue_bh < 0.05, " *", ""))
  ) %>%
  filter(biological_function_group != "Unresolved function") %>%
  arrange(percentage_point_difference) %>%
  mutate(group_display = factor(biological_function_group, levels = biological_function_group))
write_tsv(bio_counts, file.path(data_dir, "fig14_asgard_current_pos_neg_function_overlap_contrast_source.tsv"))
p14 <- ggplot(bio_counts, aes(x = percentage_point_difference, y = group_display, fill = direction)) +
  geom_col(width = 0.68, alpha = 0.94) + geom_vline(xintercept = 0, linewidth = 0.4, colour = "#596579") +
  geom_text(aes(x = percentage_point_difference + if_else(percentage_point_difference >= 0, 0.34, -0.34), label = count_label, hjust = if_else(percentage_point_difference >= 0, 0, 1)), family = font_family, size = 2.2, colour = "#1F2937") +
  scale_fill_manual(values = c("Positive-enriched" = blue, "Negative-enriched" = orange), guide = "none") +
  scale_x_continuous(breaks = pretty_breaks(n = 7), expand = expansion(mult = c(0.25, 0.25))) +
  labs(title = "Asgard positive versus negative functional overlap and contrast", subtitle = "Canonical/tail strategy: 693 non-direct positive OGs versus 600 frozen negative OGs", x = "Positive fraction - negative fraction (percentage points)", y = NULL, caption = "Bars right: positive-enriched; bars left: negative-enriched. Labels show +positive / -negative OG counts; * BH FDR < 0.05.") +
  theme_asgard(7.9) + theme(panel.grid.major.y = element_blank(), axis.text.y = element_text(size = 7.1))
save_pair(p14, "fig14_asgard_current_pos_neg_function_overlap_contrast", 183, 134)

fig17_source <- bio_counts %>%
  mutate(
    significance = case_when(
      fisher_qvalue_bh < 0.05 & log2_odds_ratio_pseudocount > 0 ~ "Positive-enriched, BH FDR < 0.05",
      fisher_qvalue_bh < 0.05 & log2_odds_ratio_pseudocount < 0 ~ "Negative-enriched, BH FDR < 0.05",
      TRUE ~ "Not BH-significant"
    ),
    combined_count = positive_count + negative_count,
    functional_group_display = group_display
  )
write_tsv(fig17_source, file.path(data_dir, "fig17_asgard_current_pos_neg_function_contrast_two_panel_source.tsv"))
fraction_source <- fig17_source %>%
  select(functional_group_display, `Positive: 693 OGs` = positive_fraction, `Negative: 600 OGs` = negative_fraction) %>%
  pivot_longer(cols = c(`Positive: 693 OGs`, `Negative: 600 OGs`), names_to = "selection_set", values_to = "fraction") %>%
  mutate(signed_fraction = if_else(selection_set == "Negative: 600 OGs", -fraction, fraction))
panel_a <- ggplot(fraction_source, aes(x = signed_fraction, y = functional_group_display, fill = selection_set)) +
  geom_col(width = 0.67, alpha = 0.94) + geom_vline(xintercept = 0, linewidth = 0.4, colour = "#596579") +
  scale_fill_manual(values = c("Negative: 600 OGs" = orange, "Positive: 693 OGs" = blue), guide = "none") +
  scale_x_continuous(labels = function(x) percent(abs(x), accuracy = 1), expand = expansion(mult = c(0.02, 0.02))) +
  labs(title = "a  Functional composition", subtitle = "Negative left; positive right", x = "Fraction of frozen set", y = NULL) +
  theme_asgard(7.3) + theme(panel.grid.major.y = element_blank(), axis.text.y = element_text(size = 6.5))
panel_b <- ggplot(fig17_source, aes(x = log2_odds_ratio_pseudocount, y = functional_group_display)) +
  geom_vline(xintercept = 0, linewidth = 0.4, linetype = "dashed", colour = "#596579") +
  geom_segment(aes(x = 0, xend = log2_odds_ratio_pseudocount, yend = functional_group_display), linewidth = 0.45, colour = "#C4CAD2") +
  geom_point(aes(size = combined_count, fill = significance), shape = 21, colour = "white", stroke = 0.35, alpha = 0.96) +
  scale_fill_manual(values = c("Positive-enriched, BH FDR < 0.05" = blue, "Negative-enriched, BH FDR < 0.05" = orange, "Not BH-significant" = grey), name = NULL) +
  scale_size_continuous(range = c(2.3, 7), guide = "none") +
  labs(title = "b  Positive versus negative contrast", subtitle = "Two-sided Fisher tests; BH correction", x = "log2 odds ratio (positive versus negative)", y = NULL) +
  theme_asgard(7.3) + theme(panel.grid.major.y = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank(), legend.position = "bottom", legend.text = element_text(size = 6.0))
fig17 <- (panel_a | panel_b) + plot_layout(widths = c(1.12, 1)) +
  plot_annotation(title = "Asgard functional composition and positive-negative contrast", subtitle = "Frozen canonical/tail strategy and functional classification v2", caption = str_wrap("Positive set: 693 non-direct OGs; negative set: 600 frozen OGs; point size = total OG count. Functional annotation is interpretive and does not contribute to association ranking.", 150))
save_pair(fig17, "fig17_asgard_current_positive_negative_function_contrast_two_panel", 220, 142)

# Fig18: Asgard-specific formal network candidates in evidence space.
network <- read_tsv(network_file, show_col_types = FALSE) %>%
  select(OG, network_module = revised_network_module, network_relevance_tier) %>%
  filter(!is.na(network_module))
stopifnot(nrow(network) == 86, n_distinct(network$OG) == 86)
fig18_source <- positive %>%
  select(OG, formal_integrated_rank, association_priority_log10, formal_best_topology_similarity, formal_max_shared_tips, n_mags_present, functional_subgroup_v2, functional_description_summary) %>%
  left_join(network, by = "OG") %>%
  mutate(
    point_class = case_when(
      network_relevance_tier == "Tier 1: direct network machinery" ~ "Tier 1 network-related",
      network_relevance_tier == "Tier 2: supporting network context" ~ "Tier 2 network context",
      TRUE ~ "Other non-direct positive OG"
    ),
    point_class = factor(point_class, levels = c("Other non-direct positive OG", "Tier 2 network context", "Tier 1 network-related")),
    compact_function = str_trim(str_extract(functional_description_summary, "[^|]+$")),
    compact_function = if_else(is.na(compact_function) | compact_function == "", str_replace_all(functional_subgroup_v2, "_", " "), compact_function)
  )
tier1_topology <- fig18_source %>%
  filter(point_class == "Tier 1 network-related", formal_max_shared_tips >= 20, !is.na(formal_best_topology_similarity), formal_integrated_rank > 10) %>%
  arrange(desc(formal_best_topology_similarity), formal_integrated_rank, OG) %>% slice_head(n = 5) %>%
  transmute(OG, label_reason = "Tier 1 topology top5 with >=20 shared tips")
label_ogs <- bind_rows(
  fig18_source %>% filter(formal_integrated_rank <= 10) %>% transmute(OG, label_reason = "Asgard formal integrated top10"),
  tier1_topology
) %>% distinct(OG, .keep_all = TRUE) %>%
  left_join(fig18_source %>% select(OG, compact_function), by = "OG") %>%
  mutate(label = paste0(OG, "\n", str_trunc(compact_function, width = 24)))
fig18_source <- fig18_source %>% left_join(label_ogs %>% select(OG, label_reason, label), by = "OG")
write_tsv(fig18_source, file.path(data_dir, "fig18_asgard_current_non_direct_network_evidence_space_source.tsv"))
write_tsv(label_ogs, file.path(data_dir, "fig18_asgard_current_non_direct_network_evidence_space_labels.tsv"))
p18 <- ggplot(filter(fig18_source, !is.na(formal_best_topology_similarity)), aes(x = association_priority_log10, y = formal_best_topology_similarity)) +
  geom_hline(yintercept = c(0.4, 0.5), linewidth = 0.35, linetype = c("dashed", "dotted"), colour = "#8292A8") +
  geom_point(aes(fill = point_class, size = n_mags_present), shape = 21, colour = "white", stroke = 0.25, alpha = 0.82) +
  geom_point(data = filter(fig18_source, !is.na(label_reason), !is.na(formal_best_topology_similarity)), aes(size = n_mags_present), shape = 21, fill = NA, colour = "#1F2937", stroke = 0.65, show.legend = FALSE) +
  geom_text_repel(data = filter(fig18_source, !is.na(label_reason), !is.na(formal_best_topology_similarity)), aes(label = label), family = font_family, size = 2.05, lineheight = 0.9, colour = "#263448", min.segment.length = 0, segment.size = 0.25, segment.colour = "#64748B", box.padding = 0.35, point.padding = 0.25, max.overlaps = Inf, seed = 18) +
  scale_fill_manual(values = c("Other non-direct positive OG" = grey, "Tier 2 network context" = teal, "Tier 1 network-related" = blue), name = "Asgard-specific functional-network candidates") +
  scale_size_continuous(range = c(1.4, 6.6), name = "MAG coverage") +
  labs(title = "Asgard non-direct positive OGs in association-tree evidence space", subtitle = "Direct actin-superfamily OGs excluded; annotation-supported formal network candidates: 86 of 693 positive OGs", x = "Canonical/tail association priority (log10 scale)", y = "Best canonical actin-reference topology similarity (1 - normalized RF)", caption = "Black outlines mark the Asgard formal integrated top10 and five Tier 1 topology candidates with at least 20 shared tips. Functional labels do not contribute to ranking.") +
  theme_asgard(7.9) + theme(legend.position = "right")
save_pair(p18, "fig18_asgard_current_non_direct_positive_network_evidence_space", 190, 134)

# Fig24: specific information-processing OGs, selected independently within set and class.
info_levels <- c("DNA replication, recombination and repair", "Translation and ribosome biogenesis", "Transcription and transcriptional regulation", "RNA processing and modification")
fig24_source <- all_ogs %>%
  filter(biological_function_group %in% info_levels, annotation_detected) %>%
  mutate(
    gene = first_item(eggnog_top_preferred_names),
    gene = if_else(is.na(gene) | gene %in% c("", "NA", "map"), hmmscan_pfam_best_domain, gene),
    gene = if_else(is.na(gene) | gene == "", "unresolved", gene),
    gene = str_trunc(gene, 18),
    set = recode(association_set, positive = "Canonical/tail positive", negative = "Frozen negative")
  ) %>%
  filter(gene != "unresolved") %>%
  group_by(biological_function_group, set) %>%
  arrange(formal_integrated_rank, desc(n_mags_present), OG, .by_group = TRUE) %>%
  slice_head(n = 4) %>%
  ungroup() %>%
  mutate(biological_function_group = factor(biological_function_group, levels = info_levels), label = paste0(OG, " | ", gene)) %>%
  group_by(biological_function_group, set) %>%
  mutate(y = if_else(set == "Canonical/tail positive", seq(0.72, 0.93, length.out = n()), seq(0.28, 0.07, length.out = n()))) %>%
  ungroup()
stopifnot(nrow(fig24_source) >= 16)
write_tsv(fig24_source, file.path(data_dir, "fig24_asgard_information_processing_specific_og_selection.tsv"))
x_max_24 <- ceiling(max(fig24_source$n_mags_present) / 100) * 100
p24 <- ggplot(fig24_source, aes(n_mags_present, y, colour = set)) +
  geom_hline(yintercept = 0.5, linewidth = 0.4, colour = "#D0D5DD") +
  geom_segment(aes(xend = n_mags_present, yend = 0.5), linewidth = 0.5, alpha = 0.45) +
  geom_point(size = 3.0) +
  geom_text_repel(aes(label = label), family = font_family, size = 2.3, direction = "both", box.padding = 0.22, point.padding = 0.13, min.segment.length = 0, max.overlaps = Inf, seed = 24, show.legend = FALSE) +
  facet_wrap(~biological_function_group, ncol = 2) +
  scale_colour_manual(values = c("Canonical/tail positive" = blue, "Frozen negative" = orange), name = NULL) +
  scale_x_continuous(limits = c(0, x_max_24), breaks = pretty_breaks(n = 5), expand = expansion(mult = c(0.01, 0.02))) +
  scale_y_continuous(limits = c(-0.02, 1.02), breaks = NULL) +
  labs(title = "Specific Asgard information-processing OGs underlying positive-negative contrasts", subtitle = "Four strongest specifically annotated OGs per information class and frozen set; blue = canonical/tail positive, orange = frozen negative", x = "MAGs carrying the OG (out of 971)", y = NULL, caption = "Labels show OG and dominant gene/domain annotation. This exploratory representative view is not an ancestral gain/loss or replacement reconstruction.") +
  theme_asgard(7.8) + theme(axis.line.y = element_blank(), axis.ticks.y = element_blank(), axis.text.y = element_blank(), axis.text.x = element_text(size = 7.0), strip.background = element_blank(), strip.text = element_text(face = "bold", size = 7.8), legend.position = "top", legend.justification = "left", panel.spacing = grid::unit(1.0, "lines")) + coord_cartesian(clip = "off")
save_pair(p24, "fig24_asgard_information_processing_specific_ogs", 210, 150)

summary_audit <- tibble(
  check = c(
    "positive_og_n", "negative_og_n", "positive_direct_actin_n",
    "negative_direct_actin_excluded_flag_true_n", "fig04_topology_comparable_n",
    "fig06_representative_n", "fig18_network_candidate_n", "fig24_selected_og_n",
    "fig03_function_group_n", "fig14_biological_group_n"
  ),
  value = c(
    nrow(positive), nrow(negative), sum(positive$direct_actin_superfamily),
    sum(negative$direct_actin_superfamily_excluded), sum(fig04_source$topology_comparable),
    nrow(fig06_source), nrow(network), nrow(fig24_source), nrow(group_counts), nrow(bio_counts)
  )
)
write_tsv(summary_audit, file.path(data_dir, "asgard_relationship_core_figure_audit.tsv"))
message("Asgard core figures saved: fig03 fig04 fig06 fig14 fig17 fig18 fig24")
