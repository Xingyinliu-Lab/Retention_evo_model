# SPNOTE1_6769_actin_superfamily_selection_and_classification_simplified

- Manuscript panel: Fig.1C
- Source figure basename: SPNOTE1_6769_actin_superfamily_selection_and_classification_simplified_v2
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 3 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)
