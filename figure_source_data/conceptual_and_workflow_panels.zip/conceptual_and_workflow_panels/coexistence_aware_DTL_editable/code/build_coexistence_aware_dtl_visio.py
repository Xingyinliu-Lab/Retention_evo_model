from pathlib import Path
import shutil

import win32com.client as win32


OUT = Path(r"..")
WORK = OUT / "visio_rebuild_coexistence_dtl"
SOURCE = OUT / "ChatGPT Image Aug 18, 2026, 07_47_13 AM.png"
STAGED_SOURCE = WORK / "source" / SOURCE.name
VSDX = OUT / "coexistence_aware_DTL_editable_v1.vsdx"
PNG = OUT / "coexistence_aware_DTL_editable_v1_preview.png"

W, H = 15.0, 10.0
WHITE = "RGB(255,255,255)"
INK = "RGB(20,24,31)"
NAVY = "RGB(17,39,83)"
TREE = "RGB(104,117,136)"
BLUE = "RGB(62,104,153)"
BLUE_DARK = "RGB(34,72,116)"
BLUE_PALE = "RGB(246,249,253)"
GREEN = "RGB(44,112,42)"
GREEN_DARK = "RGB(31,84,30)"
GREEN_PALE = "RGB(246,251,243)"
ORANGE = "RGB(238,104,0)"
PURPLE = "RGB(91,60,181)"
RED = "RGB(207,26,24)"
GRAY = "RGB(125,130,137)"
LIGHT_GRAY = "RGB(211,214,218)"


def set_cell(shape, cell, formula):
    try:
        shape.CellsU(cell).FormulaU = formula
    except Exception:
        pass


def style(shape, fill=WHITE, line=INK, weight=0.8, transparency=0):
    set_cell(shape, "FillForegnd", fill)
    set_cell(shape, "FillPattern", "1")
    set_cell(shape, "FillForegndTrans", str(transparency))
    set_cell(shape, "LineColor", line)
    set_cell(shape, "LineWeight", f"{weight} pt")
    set_cell(shape, "LinePattern", "1")


def rect(page, x, y, w, h, fill=WHITE, line=INK, weight=0.8, radius=0.0, transparency=0):
    s = page.DrawRectangle(x, H - y - h, x + w, H - y)
    style(s, fill, line, weight, transparency)
    if radius:
        set_cell(s, "Rounding", f"{radius} in")
    return s


def oval(page, x, y, w, h, fill=WHITE, line=INK, weight=0.8):
    s = page.DrawOval(x, H - y - h, x + w, H - y)
    style(s, fill, line, weight)
    return s


def text(page, value, x, y, w, h, size=9.5, color=INK, bold=False, align=0, italic=False):
    s = rect(page, x, y, w, h, WHITE, WHITE, 0)
    set_cell(s, "FillPattern", "0")
    set_cell(s, "LinePattern", "0")
    s.Text = value
    set_cell(s, "Char.Font", 'FONT("Arial")')
    set_cell(s, "Char.Color", color)
    set_cell(s, "Char.Size", f"{size} pt")
    char_style = (1 if bold else 0) + (2 if italic else 0)
    set_cell(s, "Char.Style", str(char_style))
    set_cell(s, "Para.HorzAlign", str(align))
    set_cell(s, "VerticalAlign", "0")
    set_cell(s, "TxtMarginLeft", "0.02 in")
    set_cell(s, "TxtMarginRight", "0.02 in")
    set_cell(s, "TxtMarginTop", "0.01 in")
    set_cell(s, "TxtMarginBottom", "0.01 in")
    return s


def line(page, x1, y1, x2, y2, color=INK, weight=0.9, arrow=False, dash=False):
    s = page.DrawLine(x1, H - y1, x2, H - y2)
    set_cell(s, "LineColor", color)
    set_cell(s, "LineWeight", f"{weight} pt")
    set_cell(s, "LinePattern", "2" if dash else "1")
    if arrow:
        set_cell(s, "EndArrow", "13")
        set_cell(s, "EndArrowSize", "2")
    return s


def polygon(page, points, fill, outline, weight=0.65):
    pts = list(points)
    if pts[0] != pts[-1]:
        pts.append(pts[0])
    values = []
    for x, y in pts:
        values.extend([float(x), float(H - y)])
    try:
        s = page.DrawPolyline(values, 0.0)
    except TypeError:
        s = page.DrawPolyline(values)
    style(s, fill, outline, weight)
    return s


def orf(page, cx, cy, color=BLUE, outline=BLUE_DARK, width=0.34, height=0.13):
    """Short editable directional ORF symbol, replacing ambiguous gene dots."""
    x0 = cx - width / 2
    body_end = cx + width * 0.10
    tip = cx + width / 2
    pts = [
        (x0, cy - height * 0.34),
        (body_end, cy - height * 0.34),
        (body_end, cy - height * 0.50),
        (tip, cy),
        (body_end, cy + height * 0.50),
        (body_end, cy + height * 0.34),
        (x0, cy + height * 0.34),
    ]
    polygon(page, pts, color, outline, 0.55)


def state_box(page, x, y, copies, state=None, dashed=False, modern=False):
    w, h = 0.90, 0.58
    s = rect(page, x, y, w, h, BLUE_PALE if state != "C" else GREEN_PALE,
             BLUE_DARK if state != "C" else GREEN_DARK, 0.75, 0.10)
    if dashed:
        set_cell(s, "LinePattern", "2")
        set_cell(s, "LineColor", GRAY)
        set_cell(s, "FillForegnd", WHITE)
    if state:
        text(page, state, x + 0.08, y + 0.15, 0.22, 0.25, 12, GREEN_DARK if state == "C" else NAVY, True, 1)
        centers = [x + 0.58] if copies == 1 else [x + 0.51, x + 0.73]
    else:
        centers = [x + 0.45] if copies == 1 else [x + 0.34, x + 0.60]
    for cx in centers:
        orf(page, cx, y + 0.29, GREEN if state == "C" else BLUE,
            GREEN_DARK if state == "C" else BLUE_DARK, 0.22, 0.10)
    return s


def mini_state_key(page, x, y, state):
    fill = GREEN_PALE if state == "C" else BLUE_PALE
    edge = GREEN_DARK if state == "C" else BLUE_DARK
    rect(page, x, y, 0.25, 0.36, fill, edge, 0.70, 0.06)
    text(page, state, x + 0.025, y + 0.08, 0.20, 0.20, 10.0, edge, True, 1)


def event_arrow(page, x1, y, x2, color, label, detail, label_x=None, detail_x=None, detail_y=None):
    line(page, x1, y, x2, y, color, 1.5, True)
    lx = label_x if label_x is not None else x1 + 0.10
    text(page, label, lx, y - 0.27, 1.10, 0.22, 10.5, color, False)
    dx = detail_x if detail_x is not None else lx
    dy = detail_y if detail_y is not None else y + 0.13
    text(page, detail, dx, dy, 1.30, 0.55, 8.1, INK, False)


def species_tree(page, x, y0, tip_ys):
    # Rectangular ancestral species tree with four observed tips.
    trunk_x = x
    inner_x = x + 0.34
    tip_x = x + 0.72
    line(page, trunk_x, tip_ys[0], trunk_x, tip_ys[-1], TREE, 1.65)
    line(page, trunk_x, (tip_ys[0] + tip_ys[1]) / 2, inner_x, (tip_ys[0] + tip_ys[1]) / 2, TREE, 1.65)
    line(page, inner_x, tip_ys[0], inner_x, tip_ys[1], TREE, 1.65)
    line(page, inner_x, tip_ys[0], tip_x, tip_ys[0], TREE, 1.65)
    line(page, inner_x, tip_ys[1], tip_x, tip_ys[1], TREE, 1.65)
    second_inner = x + 0.34
    line(page, trunk_x, (tip_ys[1] + tip_ys[2]) / 2, second_inner, (tip_ys[1] + tip_ys[2]) / 2, TREE, 1.65)
    line(page, second_inner, tip_ys[2], second_inner, tip_ys[3], TREE, 1.65)
    line(page, second_inner, tip_ys[2], tip_x, tip_ys[2], TREE, 1.65)
    line(page, trunk_x, tip_ys[3], tip_x, tip_ys[3], TREE, 1.65)


def panel_a(page):
    text(page, "A", 0.18, 0.15, 0.34, 0.35, 20, INK, True, 1)
    text(page, "Conventional ALE / DTL", 0.58, 0.15, 3.10, 0.34, 16.5, INK, True)
    text(page, "Gene-family evolution modeled by independent lineages\nwith Duplication, Transfer and Loss events", 0.59, 0.53, 5.55, 0.52, 10.7, INK)

    text(page, "Species tree\n(ancestral)", 0.48, 1.27, 1.10, 0.45, 10.2, NAVY, True, 1)
    text(page, "Ancestral gene states", 2.02, 1.27, 1.65, 0.25, 10.2, NAVY, True, 1)
    text(page, "Modern gene states\n(observed)", 4.75, 1.27, 1.45, 0.45, 10.2, NAVY, True, 1)

    ys = [2.30, 3.55, 4.80, 5.95]
    species_tree(page, 0.20, 2.30, ys)
    for label, y in zip("ABCD", ys):
        text(page, label, 1.39, y - 0.16, 0.25, 0.28, 11.5, INK, False, 1)
        line(page, 1.65, y, 2.24, y, GRAY, 0.95, False, True)
        line(page, 3.15, y, 4.77, y, GRAY, 0.95, False, True)

    state_box(page, 2.28, ys[0] - 0.29, 1, dashed=True)
    state_box(page, 2.28, ys[1] - 0.29, 1, dashed=True)
    state_box(page, 2.28, ys[2] - 0.29, 2, dashed=True)
    state_box(page, 2.28, ys[3] - 0.29, 2, dashed=True)
    state_box(page, 4.80, ys[0] - 0.29, 2, modern=True)
    state_box(page, 4.80, ys[1] - 0.29, 1, modern=True)
    state_box(page, 4.80, ys[2] - 0.29, 2, modern=True)
    state_box(page, 4.80, ys[3] - 0.29, 1, modern=True)

    # Transfer arc rendered as a polyline to remain fully editable.
    line(page, 3.16, ys[1], 3.58, ys[1], PURPLE, 1.5)
    line(page, 3.58, ys[1], 4.18, ys[0] + 0.48, PURPLE, 1.5)
    line(page, 4.18, ys[0] + 0.48, 4.80, ys[0] + 0.05, PURPLE, 1.5, True)
    text(page, "T", 3.88, ys[0] + 0.42, 0.25, 0.22, 11.0, PURPLE, True, 1)
    text(page, "T", 5.90, ys[0] + 0.12, 0.24, 0.22, 11.0, PURPLE, True, 1)
    text(page, "transfer\nintroduces an\nextra copy", 5.92, ys[0] + 0.42, 1.02, 0.66, 8.0, INK)

    event_arrow(page, 3.18, ys[2], 4.80, ORANGE, "D", "duplication\ncreates an\nextra copy", 3.83, 5.92, ys[2] + 0.16)
    event_arrow(page, 3.18, ys[3], 4.80, RED, "L", "loss removes\none copy", 3.83, 5.92, ys[3] + 0.16)

    rect(page, 0.30, 6.72, 6.10, 0.82, BLUE_PALE, TREE, 0.70, 0.10)
    text(page,
         "Modern patterns arise from combinations of D (duplication), T (transfer), and L (loss).\n"
         "Lineages evolve independently after events.\n"
         "Histories are compared and parameters estimated by maximum likelihood.",
         0.44, 6.84, 5.82, 0.60, 8.9, NAVY)

    rect(page, 0.20, 7.78, 6.47, 0.46, WHITE, LIGHT_GRAY, 0.65, 0.08)
    oval(page, 0.39, 7.88, 0.24, 0.24, ORANGE, ORANGE, 0.4)
    text(page, "D", 0.42, 7.91, 0.18, 0.16, 9.2, WHITE, True, 1)
    text(page, "Duplication", 0.69, 7.89, 0.88, 0.22, 8.6, INK)
    oval(page, 1.78, 7.88, 0.24, 0.24, PURPLE, PURPLE, 0.4)
    text(page, "T", 1.81, 7.91, 0.18, 0.16, 9.2, WHITE, True, 1)
    text(page, "Transfer", 2.08, 7.89, 0.70, 0.22, 8.6, INK)
    oval(page, 2.94, 7.88, 0.24, 0.24, RED, RED, 0.4)
    text(page, "L", 2.97, 7.91, 0.18, 0.16, 9.2, WHITE, True, 1)
    text(page, "Loss", 3.25, 7.89, 0.48, 0.22, 8.6, INK)
    orf(page, 4.02, 8.00, BLUE, BLUE_DARK, 0.22, 0.10)
    text(page, "Single-copy", 4.20, 7.89, 0.85, 0.22, 8.6, INK)
    orf(page, 5.30, 8.00, BLUE, BLUE_DARK, 0.20, 0.09)
    orf(page, 5.55, 8.00, BLUE, BLUE_DARK, 0.20, 0.09)
    text(page, "Two copies", 5.70, 7.89, 0.83, 0.22, 8.6, INK)


def panel_b(page):
    text(page, "B", 7.18, 0.15, 0.34, 0.35, 20, INK, True, 1)
    text(page, "Coexistence-aware DTL", 7.61, 0.15, 3.20, 0.34, 16.5, INK, True)
    text(page, "Adds an explicit host copy-state and a persistence parameter\nfor coexistence across consecutive lineages", 7.62, 0.53, 5.50, 0.52, 10.7, INK)

    text(page, "Species tree\n(ancestral)", 7.50, 1.27, 1.12, 0.45, 10.2, NAVY, True, 1)
    text(page, "Host copy-state (gene-family history)", 8.87, 1.27, 2.60, 0.25, 10.2, NAVY, True, 1)
    text(page, "Modern states\n(observed)", 11.86, 1.27, 1.24, 0.45, 10.2, NAVY, True, 1)

    ys = [2.30, 3.55, 4.80, 5.95]
    species_tree(page, 7.24, 2.30, ys)
    for label, y in zip("ABCD", ys):
        text(page, label, 8.43, y - 0.16, 0.25, 0.28, 11.5, INK, False, 1)
        line(page, 8.70, y, 9.02, y, GRAY, 0.95, False, True)

    state_box(page, 9.05, ys[0] - 0.29, 1, "S")
    state_box(page, 9.05, ys[1] - 0.29, 1, "S")
    state_box(page, 9.05, ys[2] - 0.29, 2, "C")
    state_box(page, 9.05, ys[3] - 0.29, 2, "C")
    state_box(page, 11.77, ys[0] - 0.29, 2, "C")
    state_box(page, 11.77, ys[1] - 0.29, 1, "S")
    state_box(page, 11.77, ys[2] - 0.29, 1, "S")
    state_box(page, 11.77, ys[3] - 0.29, 2, "C")

    event_arrow(page, 10.00, ys[0], 11.68, ORANGE, "D/gain", "duplication\ngenerates an\nextra copy", 10.22, 10.22, ys[0] + 0.12)
    line(page, 11.65, ys[0] + 0.47, 11.26, ys[0] + 0.65, PURPLE, 1.25)
    line(page, 11.26, ys[0] + 0.65, 10.92, ys[1] - 0.45, PURPLE, 1.25, True, True)
    text(page, "T/gain", 10.48, ys[1] - 0.48, 0.62, 0.20, 9.7, PURPLE)
    text(page, "transfer (optional)\nintroduces an\nextra copy", 10.70, ys[1] - 0.28, 1.15, 0.58, 7.9, INK)

    event_arrow(page, 10.00, ys[2], 11.68, RED, "L/resolution", "loss removes\none copy", 10.20, 10.20, ys[2] + 0.14)

    # Editable persistence highlight: pale broad band behind green arrow.
    line(page, 10.00, ys[3], 11.68, ys[3], "RGB(218,235,205)", 14.0)
    line(page, 10.00, ys[3], 11.68, ys[3], GREEN_DARK, 1.5, True)
    text(page, "persistent\ncoexistence (C → C)\nacross consecutive\nlineages", 10.32, ys[3] - 0.45, 1.22, 0.83, 8.4, INK, False, 1)

    # Right legend.
    rect(page, 13.10, 1.98, 1.60, 4.58, WHITE, LIGHT_GRAY, 0.65, 0.10)
    line(page, 13.28, 2.28, 13.55, 2.28, ORANGE, 1.6, True)
    text(page, "D/gain", 13.64, 2.17, 0.82, 0.22, 9.2, ORANGE)
    text(page, "duplication or\nother gain event", 13.64, 2.44, 0.90, 0.43, 7.8, INK)
    line(page, 13.28, 3.10, 13.55, 3.10, PURPLE, 1.6, True, True)
    text(page, "T/gain", 13.64, 2.99, 0.82, 0.22, 9.2, PURPLE)
    text(page, "transfer (optional)\nas gain source", 13.64, 3.26, 0.90, 0.43, 7.8, INK)
    line(page, 13.28, 3.92, 13.55, 3.92, RED, 1.6, True)
    text(page, "L/resolution", 13.64, 3.81, 0.92, 0.22, 9.2, RED)
    text(page, "loss or resolution", 13.64, 4.08, 0.90, 0.28, 7.8, INK)
    mini_state_key(page, 13.28, 4.56, "S")
    text(page, "single-copy\n(single copy)", 13.63, 4.57, 0.92, 0.43, 7.8, INK)
    mini_state_key(page, 13.28, 5.12, "C")
    text(page, "coexistence\n(multiple copies)", 13.63, 5.13, 0.94, 0.43, 7.8, INK)
    line(page, 13.28, 6.00, 13.55, 6.00, "RGB(218,235,205)", 13.0)
    text(page, "persistent coexistence\nacross branches (C → C)", 13.64, 5.83, 0.90, 0.50, 7.6, INK)

    rect(page, 7.80, 6.74, 5.02, 1.38, GREEN_PALE, GREEN_DARK, 0.70, 0.10)
    text(page, "r", 7.99, 6.87, 0.20, 0.22, 10.2, GREEN_DARK, True, 1, True)
    text(page, "= persistence odds multiplier for C → C", 8.18, 6.87, 3.72, 0.24, 9.1, INK)
    text(page,
         "r > 1 increases the tendency that a coexistence state continues across\n"
         "adjacent lineages; r = 1 reduces to no additional persistence.\n"
         "r is a model parameter, not a biological constant and does not imply\n"
         "directional ancestry.",
         7.99, 7.13, 4.58, 0.82, 8.2, INK)


def bottom_summary(page):
    rect(page, 0.30, 8.52, 14.05, 1.15, WHITE, TREE, 0.75, 0.10)
    line(page, 7.08, 8.70, 7.08, 9.50, LIGHT_GRAY, 0.75)
    text(page, "Conventional ALE / DTL", 2.18, 8.73, 2.50, 0.27, 12.4, BLUE_DARK, True, 1)
    text(page,
         "Multicopy lineages can persist, but each copy follows independent DTL dynamics.\n"
         "Persistent coexistence is not explicitly modeled.",
         0.67, 9.08, 5.98, 0.48, 9.1, INK)
    text(page, "Coexistence-aware DTL", 9.25, 8.73, 2.48, 0.27, 12.4, "RGB(105,145,42)", True, 1)
    text(page,
         "Multicopy patterns can arise from: (i) D or T creating/gaining extra copies,\n"
         "(ii) persistent coexistence (C → C) across lineages, or (iii) loss/resolution (C → S).\n"
         "Coexistence persistence is explicitly parameterized by r.",
         7.48, 9.03, 6.45, 0.60, 8.8, INK)


def main():
    WORK.mkdir(parents=True, exist_ok=True)
    STAGED_SOURCE.parent.mkdir(parents=True, exist_ok=True)
    if not STAGED_SOURCE.exists():
        shutil.copy2(SOURCE, STAGED_SOURCE)

    app = win32.Dispatch("Visio.Application")
    app.Visible = False
    doc = app.Documents.Add("")
    try:
        page = doc.Pages.Item(1)
        page.PageSheet.CellsU("PageWidth").FormulaU = f"{W} in"
        page.PageSheet.CellsU("PageHeight").FormulaU = f"{H} in"
        bg = rect(page, 0, 0, W, H, WHITE, WHITE, 0)
        bg.SendToBack()
        line(page, 6.93, 0.20, 6.93, 8.28, LIGHT_GRAY, 0.75)
        panel_a(page)
        panel_b(page)
        bottom_summary(page)

        for path in (VSDX, PNG):
            if path.exists():
                path.unlink()
        doc.SaveAs(str(VSDX))
        page.Export(str(PNG))
    finally:
        doc.Close()
        app.Quit()


if __name__ == "__main__":
    main()
