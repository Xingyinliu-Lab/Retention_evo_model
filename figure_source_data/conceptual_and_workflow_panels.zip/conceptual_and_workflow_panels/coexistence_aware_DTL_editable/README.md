# coexistence_aware_DTL_editable

- Manuscript panel: Fig.7B
- Source figure basename: coexistence_aware_DTL_editable_v1
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)
