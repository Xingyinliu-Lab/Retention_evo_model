suppressPackageStartupMessages(library(png))

source_file <- ".."
source_dir <- dirname(source_file)
manuscript_dir <- ".."

transparent_name <- "retention_model_v1_clean_textless_transparent_white_matte.png"
white_name <- "retention_model_v1_clean_textless_white_background.png"

x <- readPNG(source_file, native = FALSE)
stopifnot(length(dim(x)) == 3L, dim(x)[3] == 4L)

alpha <- x[, , 4]

# Preserve alpha and visible pixels, but assign white RGB to fully transparent
# pixels so applications that inspect the hidden RGB do not show a black matte.
transparent_white_matte <- x
fully_transparent <- alpha == 0
for (channel in 1:3) {
  layer <- transparent_white_matte[, , channel]
  layer[fully_transparent] <- 1
  transparent_white_matte[, , channel] <- layer
}

# Exact white-background composite for applications that do not handle PNG
# alpha reliably.
white_background <- array(1, dim = c(dim(x)[1], dim(x)[2], 3L))
for (channel in 1:3) {
  white_background[, , channel] <- x[, , channel] * alpha + (1 - alpha)
}

writePNG(transparent_white_matte, file.path(source_dir, transparent_name))
writePNG(white_background, file.path(source_dir, white_name))

dir.create(manuscript_dir, recursive = TRUE, showWarnings = FALSE)
file.copy(
  file.path(source_dir, transparent_name),
  file.path(manuscript_dir, transparent_name),
  overwrite = TRUE
)
file.copy(
  file.path(source_dir, white_name),
  file.path(manuscript_dir, white_name),
  overwrite = TRUE
)

# Encoding audit.
check_transparent <- readPNG(file.path(source_dir, transparent_name), native = FALSE)
check_white <- readPNG(file.path(source_dir, white_name), native = FALSE)
stopifnot(all(check_transparent[, , 1][fully_transparent] == 1))
stopifnot(all(check_transparent[, , 2][fully_transparent] == 1))
stopifnot(all(check_transparent[, , 3][fully_transparent] == 1))
stopifnot(dim(check_white)[3] == 3L)
