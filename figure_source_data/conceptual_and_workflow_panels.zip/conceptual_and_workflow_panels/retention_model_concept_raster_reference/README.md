# retention_model_concept_raster_reference

- Manuscript panel: Fig.4G
- Source figure basename: retention_model_concept_raster_reference_v1
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)
