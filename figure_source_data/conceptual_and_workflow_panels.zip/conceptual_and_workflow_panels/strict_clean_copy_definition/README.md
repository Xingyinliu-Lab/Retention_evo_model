# strict_clean_copy_definition

- Manuscript panel: Fig.5A
- Source figure basename: fig_strict_clean_copy_definition
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 1 directly referenced or locally packaged source-data file(s)
