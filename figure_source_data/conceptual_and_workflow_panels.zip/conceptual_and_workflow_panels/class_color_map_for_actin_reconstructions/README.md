# class_color_map_for_actin_reconstructions

- Manuscript panel: Supp.Fig.14A
- Source figure basename: class_color_map_for_actin_reconstructions
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 0 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)

## Targeted provenance completion
