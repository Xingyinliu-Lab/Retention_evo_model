from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon, Wedge


OUTDIR = Path(__file__).resolve().parent
OUTBASE = OUTDIR / "eight_to_five_model_framework_preview_v1"

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "pdf.fonttype": 42,
        "font.size": 7,
        "axes.linewidth": 0.8,
    }
)

# Manuscript-consistent restrained palette.
COL_D = "#3B8C7A"       # dALP
COL_C = "#4E79A7"       # cALP
COL_LINE = "#374151"
COL_MUTED = "#6B7280"
COL_LIGHT = "#E5E7EB"
COL_PANEL_A = "#F7F7F7"
COL_PANEL_B = "#F4F8FB"


def rounded_box(ax, x, y, w, h, *, fc="white", ec=COL_LIGHT, lw=0.8, radius=0.08, z=1):
    p = FancyBboxPatch(
        (x, y), w, h,
        boxstyle=f"round,pad=0.02,rounding_size={radius}",
        facecolor=fc, edgecolor=ec, linewidth=lw, zorder=z,
    )
    ax.add_patch(p)
    return p


def state_node(ax, x, y, state, r=0.16, alpha=1.0, label=True, z=5):
    if state == "D":
        ax.add_patch(Wedge((x, y), r, 0, 360, fc=COL_D, ec=COL_LINE, lw=0.75, alpha=alpha, zorder=z))
        color = "white"
    elif state == "C":
        ax.add_patch(Wedge((x, y), r, 0, 360, fc=COL_C, ec=COL_LINE, lw=0.75, alpha=alpha, zorder=z))
        color = "white"
    else:
        ax.add_patch(Wedge((x, y), r, 90, 270, fc=COL_D, ec="none", alpha=alpha, zorder=z))
        ax.add_patch(Wedge((x, y), r, -90, 90, fc=COL_C, ec="none", alpha=alpha, zorder=z))
        ax.add_patch(Wedge((x, y), r, 0, 360, fc="none", ec=COL_LINE, lw=0.75, alpha=alpha, zorder=z + 0.1))
        color = "white"
    if label:
        ax.text(x, y - 0.002, state, ha="center", va="center", fontsize=6.4,
                fontweight="bold", color=color, alpha=alpha, zorder=z + 1)


def bidirectional(ax, x1, y1, x2, y2, *, color=COL_LINE, alpha=1.0, lw=0.9, z=3):
    arrow = FancyArrowPatch(
        (x1, y1), (x2, y2), arrowstyle="<->", mutation_scale=7,
        color=color, linewidth=lw, alpha=alpha, shrinkA=8, shrinkB=8, zorder=z,
    )
    ax.add_patch(arrow)


def directed(ax, x1, y1, x2, y2, *, color=COL_LINE, alpha=1.0, lw=0.9, z=3):
    arrow = FancyArrowPatch(
        (x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=7,
        color=color, linewidth=lw, alpha=alpha, shrinkA=8, shrinkB=8, zorder=z,
    )
    ax.add_patch(arrow)


def root_marker(ax, x, y, *, muted=False):
    color = "#4B5563" if muted else "#111827"
    tri = Polygon([[x, y], [x - 0.055, y + 0.075], [x + 0.055, y + 0.075]],
                  closed=True, fc=color, ec="none", zorder=7)
    ax.add_patch(tri)
    ax.text(x, y + 0.105, "root", ha="center", va="bottom", fontsize=4.7,
            color=color, fontweight="bold", zorder=8)


def draw_chain(ax, x, y, order, *, spacing=0.62, muted=False, root_index=None, r=0.14):
    alpha = 0.84 if muted else 1.0
    xs = [x + (i - 1) * spacing for i in range(3)]
    for i in range(2):
        bidirectional(ax, xs[i], y, xs[i + 1], y, color=COL_MUTED if muted else COL_LINE,
                      alpha=alpha, lw=0.8 if muted else 0.95)
    for xx, state in zip(xs, order):
        state_node(ax, xx, y, state, r=r, alpha=alpha)
    if root_index is not None:
        root_marker(ax, xs[root_index], y + r + 0.035, muted=muted)
    return xs


def draw_strict(ax, cx, cy, *, muted=False, scale=1.0):
    alpha = 0.84 if muted else 1.0
    top = (cx, cy + 0.28 * scale)
    left = (cx - 0.42 * scale, cy - 0.25 * scale)
    right = (cx + 0.42 * scale, cy - 0.25 * scale)
    directed(ax, *top, *left, color=COL_MUTED if muted else COL_LINE, alpha=alpha)
    directed(ax, *top, *right, color=COL_MUTED if muted else COL_LINE, alpha=alpha)
    state_node(ax, *top, "X", r=0.14 * scale, alpha=alpha)
    state_node(ax, *left, "D", r=0.14 * scale, alpha=alpha)
    state_node(ax, *right, "C", r=0.14 * scale, alpha=alpha)
    root_marker(ax, top[0], top[1] + 0.14 * scale + 0.035, muted=muted)


def draw_ard(ax, cx, cy, *, muted=False, scale=1.0):
    alpha = 0.84 if muted else 1.0
    top = (cx, cy + 0.29 * scale)
    left = (cx - 0.42 * scale, cy - 0.24 * scale)
    right = (cx + 0.42 * scale, cy - 0.24 * scale)
    color = COL_MUTED if muted else COL_LINE
    bidirectional(ax, *top, *left, color=color, alpha=alpha)
    bidirectional(ax, *top, *right, color=color, alpha=alpha)
    bidirectional(ax, *left, *right, color=color, alpha=alpha)
    state_node(ax, *top, "X", r=0.14 * scale, alpha=alpha)
    state_node(ax, *left, "D", r=0.14 * scale, alpha=alpha)
    state_node(ax, *right, "C", r=0.14 * scale, alpha=alpha)


def historical_pair(ax, x0, y0, w, title, rows):
    rounded_box(ax, x0, y0, w, 2.08, fc="white", ec="#D1D5DB", lw=0.75, radius=0.06)
    ax.text(x0 + w / 2, y0 + 1.91, title, ha="center", va="center",
            fontsize=7.25, fontweight="bold", color="#374151")
    for j, (hist_label, order, root_index) in enumerate(rows):
        yy = y0 + 1.36 - j * 0.82
        ax.text(x0 + w / 2, yy + 0.26, hist_label, ha="center", va="center",
                fontsize=5.7, color="#4B5563")
        draw_chain(ax, x0 + w / 2, yy - 0.02, order, spacing=0.57, muted=True,
                   root_index=root_index, r=0.125)


def formal_card(ax, x0, y0, w, title, draw_fn, footer1, footer2=""):
    rounded_box(ax, x0, y0, w, 1.92, fc="white", ec="#9CA3AF", lw=0.95, radius=0.08)
    ax.text(x0 + w / 2, y0 + 1.70, title, ha="center", va="center",
            fontsize=7.35, fontweight="bold", color="#111827")
    draw_fn()
    ax.text(x0 + w / 2, y0 + 0.34, footer1, ha="center", va="center",
            fontsize=5.55, color="#374151")
    if footer2:
        ax.text(x0 + w / 2, y0 + 0.16, footer2, ha="center", va="center",
                fontsize=5.35, color="#6B7280")


fig, ax = plt.subplots(figsize=(14.8, 7.0))
ax.set_xlim(0, 14.8)
ax.set_ylim(0, 7.0)
ax.axis("off")
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

# Panel fields.
rounded_box(ax, 0.18, 3.55, 14.44, 3.05, fc=COL_PANEL_A, ec="#D1D5DB", lw=0.8, radius=0.10, z=0)
rounded_box(ax, 0.18, 0.30, 14.44, 2.82, fc=COL_PANEL_B, ec="#BFCAD6", lw=0.8, radius=0.10, z=0)

ax.text(0.38, 6.40, "A", fontsize=9.5, fontweight="bold", va="center")
ax.text(0.66, 6.40, "Historical fixed-root formulations", fontsize=9.0,
        fontweight="bold", va="center", color="#374151")
ax.text(4.10, 6.40, "development only; not used as the final formal analysis",
        fontsize=6.0, va="center", color=COL_MUTED)

ax.text(0.38, 2.91, "B", fontsize=9.5, fontweight="bold", va="center")
ax.text(0.66, 2.91, "Final composition-corrected five-model framework",
        fontsize=9.0, fontweight="bold", va="center", color="#111827")

# State legend.
legend_y = 6.08
legend_xs = [9.10, 11.00, 13.00]
for xx, state, label in zip(legend_xs, ["D", "X", "C"],
                            ["dALP-only", "cALP+dALP coexist", "cALP-only"]):
    state_node(ax, xx, legend_y, state, r=0.105)
    ax.text(xx + 0.16, legend_y, label, ha="left", va="center", fontsize=5.8, color="#374151")

# Five aligned columns.
left = 0.42
gap = 0.14
widths = [2.70, 2.70, 2.70, 2.70, 2.70]
xs = [left]
for i in range(1, 5):
    xs.append(xs[-1] + widths[i - 1] + gap)

# Historical model pairs.
historical_pair(
    ax, xs[0], 3.78, widths[0], "Coexist-middle formulations",
    [
        ("Historical label: dALP → coexist → cALP", ["D", "X", "C"], 0),
        ("Historical label: cALP → coexist → dALP", ["C", "X", "D"], 0),
    ],
)
historical_pair(
    ax, xs[1], 3.78, widths[1], "cALP-middle formulations",
    [
        ("Historical label: dALP → cALP → coexist", ["D", "C", "X"], 0),
        ("Historical label: coexist → cALP → dALP", ["X", "C", "D"], 0),
    ],
)
historical_pair(
    ax, xs[2], 3.78, widths[2], "dALP-middle formulations",
    [
        ("Historical label: cALP → dALP → coexist", ["C", "D", "X"], 0),
        ("Historical label: coexist → dALP → cALP", ["X", "D", "C"], 0),
    ],
)

# Historical strict and ARD models.
for col, title in [(3, "Ancestral coexist divergence"), (4, "ARD unrestricted")]:
    rounded_box(ax, xs[col], 3.78, widths[col], 2.08, fc="white", ec="#D1D5DB", lw=0.75, radius=0.06)
    ax.text(xs[col] + widths[col] / 2, 5.69, title, ha="center", va="center",
            fontsize=7.0, fontweight="bold", color="#4B5563")
if True:
    draw_strict(ax, xs[3] + widths[3] / 2, 4.72, muted=True, scale=0.9)
    ax.text(xs[3] + widths[3] / 2, 4.04, "fixed coexist root · two outward rates",
            ha="center", va="center", fontsize=5.4, color=COL_MUTED)
    draw_ard(ax, xs[4] + widths[4] / 2, 4.72, muted=True, scale=0.9)
    ax.text(xs[4] + widths[4] / 2, 4.04, "stationary(Q) root · six free rates",
            ha="center", va="center", fontsize=5.4, color=COL_MUTED)

# Mapping arrows and exact refit logic.
for i in range(5):
    directed(ax, xs[i] + widths[i] / 2, 3.76, xs[i] + widths[i] / 2, 3.18,
             color="#6B7280", lw=0.85)
for i in range(3):
    ax.text(xs[i] + widths[i] / 2, 3.47,
            "same adjacency · remove fixed root · re-fit",
            ha="center", va="center", fontsize=5.1, color="#4B5563")
ax.text(xs[3] + widths[3] / 2, 3.47, "retained as fixed-root model",
        ha="center", va="center", fontsize=5.1, color="#4B5563")
ax.text(xs[4] + widths[4] / 2, 3.47, "retained as unrestricted model",
        ha="center", va="center", fontsize=5.1, color="#4B5563")

# Formal model cards.
y_card = 0.58
formal_card(
    ax, xs[0], y_card, widths[0], "Sequential retention",
    lambda: draw_chain(ax, xs[0] + widths[0] / 2, 1.55, ["D", "X", "C"], spacing=0.66, r=0.15),
    "stationary(Q) root · k = 4",
    "no direct D↔C transition",
)
formal_card(
    ax, xs[1], y_card, widths[1], "cALP-middle adjacency",
    lambda: draw_chain(ax, xs[1] + widths[1] / 2, 1.55, ["D", "C", "X"], spacing=0.66, r=0.15),
    "stationary(Q) root · k = 4",
)
formal_card(
    ax, xs[2], y_card, widths[2], "dALP-middle adjacency",
    lambda: draw_chain(ax, xs[2] + widths[2] / 2, 1.55, ["C", "D", "X"], spacing=0.66, r=0.15),
    "stationary(Q) root · k = 4",
)
formal_card(
    ax, xs[3], y_card, widths[3], "Ancestral coexist divergence",
    lambda: draw_strict(ax, xs[3] + widths[3] / 2, 1.48, scale=0.82),
    "root fixed to coexist · k = 2",
    "single-profile states are absorbing",
)
formal_card(
    ax, xs[4], y_card, widths[4], "ARD unrestricted",
    lambda: draw_ard(ax, xs[4] + widths[4] / 2, 1.48, scale=0.82),
    "stationary(Q) root · k = 6",
    "all six directional rates free",
)

# One concise grammar note, not a results/footer panel.
ax.text(
    7.40, 0.36,
    "↔ denotes two independently fitted directional rates; paired historical likelihoods were not averaged.",
    ha="center", va="center", fontsize=5.55, color="#4B5563",
)

plt.subplots_adjust(left=0.008, right=0.992, top=0.992, bottom=0.018)
fig.savefig(OUTBASE.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
fig.savefig(OUTBASE.with_suffix(".png"), dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)


# A-only export requested for the manuscript: historical eight-model definitions.
A_ONLY_BASE = OUTDIR / "historical_eight_fixed_root_formulations_only_v2"
fig, ax = plt.subplots(figsize=(14.8, 3.45))
ax.set_xlim(0, 14.8)
ax.set_ylim(0, 3.45)
ax.axis("off")
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

rounded_box(ax, 0.18, 0.16, 14.44, 3.09, fc="#F8F9FA", ec="#C9CED6", lw=0.85, radius=0.10, z=0)
ax.text(0.38, 3.06, "A", fontsize=10.0, fontweight="bold", va="center")
ax.text(0.66, 3.06, "Historical fixed-root formulations", fontsize=9.2,
        fontweight="bold", va="center", color="#374151")
ax.text(4.10, 3.06, "historical eight-model framework",
        fontsize=6.2, va="center", color="#6B7280")

legend_y = 2.90
legend_xs = [9.10, 11.00, 13.00]
for xx, state, label in zip(legend_xs, ["D", "X", "C"],
                            ["dALP-only", "cALP+dALP coexist", "cALP-only"]):
    state_node(ax, xx, legend_y, state, r=0.11)
    ax.text(xx + 0.17, legend_y, label, ha="left", va="center", fontsize=6.0, color="#374151")

historical_pair(
    ax, xs[0], 0.44, widths[0], "Coexist-middle formulations",
    [
        ("dALP → coexist → cALP", ["D", "X", "C"], 0),
        ("cALP → coexist → dALP", ["C", "X", "D"], 0),
    ],
)
historical_pair(
    ax, xs[1], 0.44, widths[1], "cALP-middle formulations",
    [
        ("dALP → cALP → coexist", ["D", "C", "X"], 0),
        ("coexist → cALP → dALP", ["X", "C", "D"], 0),
    ],
)
historical_pair(
    ax, xs[2], 0.44, widths[2], "dALP-middle formulations",
    [
        ("cALP → dALP → coexist", ["C", "D", "X"], 0),
        ("coexist → dALP → cALP", ["X", "D", "C"], 0),
    ],
)

for col, title in [(3, "Ancestral coexist divergence"), (4, "ARD unrestricted")]:
    rounded_box(ax, xs[col], 0.44, widths[col], 2.08, fc="white", ec="#C7CDD5", lw=0.8, radius=0.06)
    ax.text(xs[col] + widths[col] / 2, 2.35, title, ha="center", va="center",
            fontsize=7.25, fontweight="bold", color="#374151")
draw_strict(ax, xs[3] + widths[3] / 2, 1.38, muted=True, scale=0.94)
ax.text(xs[3] + widths[3] / 2, 0.68, "fixed coexist root · two outward rates",
        ha="center", va="center", fontsize=5.65, color="#4B5563")
draw_ard(ax, xs[4] + widths[4] / 2, 1.38, muted=True, scale=0.94)
ax.text(xs[4] + widths[4] / 2, 0.68, "stationary(Q) root · six free rates",
        ha="center", va="center", fontsize=5.65, color="#4B5563")

ax.text(7.40, 0.27,
        "↔ denotes two independently fitted directional rates; arrows in historical model names encode fixed-root/order formulations.",
        ha="center", va="center", fontsize=5.65, color="#4B5563")

plt.subplots_adjust(left=0.008, right=0.992, top=0.992, bottom=0.018)
fig.savefig(A_ONLY_BASE.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
fig.savefig(A_ONLY_BASE.with_suffix(".png"), dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
