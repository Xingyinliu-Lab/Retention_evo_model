# historical_eight_fixed_root_formulations_only

- Manuscript panel: Fig.5H
- Source figure basename: historical_eight_fixed_root_formulations_only_v2
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)
