# archaea1338_OG_retention_screening_flowchart_compact

- Manuscript panel: Fig.6A
- Source figure basename: archaea1338_OG_retention_screening_flowchart_compact
- Package type: diagram
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 3 final figure asset(s)
- code/: 0 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 0 directly referenced or locally packaged source-data file(s)
