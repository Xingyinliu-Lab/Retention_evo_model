# 1_full6769_profile_state_counts_by_MAG_quality_stacked

- Manuscript panel: Fig.4E
- Source figure basename: fig_1_full6769_profile_state_counts_by_MAG_quality_stacked
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 16 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 1 directly referenced or locally packaged source-data file(s)
