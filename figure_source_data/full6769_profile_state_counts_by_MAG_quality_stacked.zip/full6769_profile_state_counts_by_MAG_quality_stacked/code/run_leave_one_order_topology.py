#!/usr/bin/env python3
"""Leave-one-order-out topology sensitivity for the profile-state audit."""

from __future__ import annotations

import csv
from collections import Counter

import numpy as np
from Bio import Phylo

from run_profile_retention_four_tree_audit import (
    DATA, RESULTS, TREE_SPECS, STATE_CODE, STATE_LEVELS, restrict_tree,
    nested_topology, sankoff, graph_nearest_sets, nearest_agreement, write_tsv,
)


def main():
    with (DATA / "frozen_584_MAG_profile_states.tsv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    state = {x["mag_id"]: x["state"] for x in rows}
    order = {x["mag_id"]: x["order"] for x in rows}
    rng = np.random.default_rng(20260808)
    unordered = [[0 if i == j else 1 for j in range(3)] for i in range(3)]
    ordered = [[abs(i - j) for j in range(3)] for i in range(3)]
    out = []
    for tree_name, spec in TREE_SPECS.items():
        full = Phylo.read(str(spec["path"]), "newick")
        mapped = restrict_tree(full, state)
        mapped_tips = {x.name for x in mapped.get_terminals()}
        order_counts = Counter(order[x] for x in mapped_tips)
        targets = ["NONE"] + [x for x, n in sorted(order_counts.items()) if n >= 5]
        for omitted in targets:
            keep = {x: state[x] for x in mapped_tips if omitted == "NONE" or order[x] != omitted}
            tree = restrict_tree(mapped, keep)
            topology = nested_topology(tree)
            states = {x: STATE_CODE[keep[x]] for x in keep}
            nearest = graph_nearest_sets(topology)
            obs_near = nearest_agreement(nearest, states)
            obs_unordered = sankoff(topology, states, unordered)
            obs_ordered = sankoff(topology, states, ordered)
            labels = list(states)
            values = np.array([states[x] for x in labels])
            perm_unordered, perm_near = [], []
            for _ in range(199):
                shuffled = rng.permutation(values)
                perm = dict(zip(labels, shuffled.tolist()))
                perm_unordered.append(sankoff(topology, perm, unordered))
                perm_near.append(nearest_agreement(nearest, perm))
            counts = Counter(keep.values())
            out.append({
                "tree": tree_name,
                "left_out_order": omitted,
                "left_out_n": 0 if omitted == "NONE" else order_counts[omitted],
                "remaining_MAGs": len(keep),
                "n_dALP_only": counts["dALP-only"],
                "n_coexist": counts["coexist"],
                "n_cALP_only": counts["cALP-only"],
                "coexist_remaining_orders": len({order[x] for x in keep if keep[x] == "coexist"}),
                "unordered_min_changes": obs_unordered,
                "ordered_min_step_score": obs_ordered,
                "unordered_permutation_p_low": (1 + sum(x <= obs_unordered for x in perm_unordered)) / 200,
                "nearest_same_state_fraction": obs_near,
                "nearest_permutation_p_high": (1 + sum(x >= obs_near for x in perm_near)) / 200,
            })
    write_tsv(RESULTS / "leave_one_order_out_topology.tsv", out)
    print(f"rows={len(out)}")


if __name__ == "__main__":
    main()
