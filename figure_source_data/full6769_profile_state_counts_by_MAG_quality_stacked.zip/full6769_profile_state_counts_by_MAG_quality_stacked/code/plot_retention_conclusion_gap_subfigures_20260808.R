suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
})

base_dir <- ".."
results_dir <- file.path(base_dir, "results")
evidence_results <- ".."
data_dir <- file.path(base_dir, "data", "three_model_figures")
figure_dir <- file.path(base_dir, "figures", "three_model_validation")
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

theme_pub <- function(base_size = 7.2) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.text = element_text(colour = "#222222"),
      plot.title = element_text(face = "bold", size = base_size + 1.0, margin = margin(b = 3)),
      plot.subtitle = element_text(size = base_size - 0.5, colour = "#444444", margin = margin(b = 6)),
      plot.margin = margin(6, 8, 5, 6),
      legend.title = element_text(face = "bold", size = base_size - 0.4),
      legend.text = element_text(size = base_size - 0.7),
      legend.key.height = unit(3.5, "mm"),
      panel.grid = element_blank()
    )
}

save_plot <- function(plot, stem, width_mm, height_mm, dpi = 450) {
  ggsave(
    file.path(figure_dir, paste0(stem, ".pdf")), plot,
    width = width_mm, height = height_mm, units = "mm",
    device = grDevices::cairo_pdf, family = "Arial", bg = "white"
  )
  ggsave(
    file.path(figure_dir, paste0(stem, ".png")), plot,
    width = width_mm, height = height_mm, units = "mm",
    device = ragg::agg_png, dpi = dpi, bg = "white"
  )
}

# Figure 6: all directly paired coexist MAGs are not terminally close.
pairs <- read.delim(
  file.path(results_dir, "gene_tree_584_coexist_MAG_pairs.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
stopifnot(nrow(pairs) == 107L, sum(pairs$exact_terminal_cherry == "TRUE") == 0L)
distance_long <- pairs %>%
  select(mag_id, order, within_MAG_min_cALP_dALP_distance, same_order_between_MAG_median_distance) %>%
  pivot_longer(
    cols = c(within_MAG_min_cALP_dALP_distance, same_order_between_MAG_median_distance),
    names_to = "comparison", values_to = "patristic_distance"
  ) %>%
  mutate(
    comparison = recode(
      comparison,
      within_MAG_min_cALP_dALP_distance = "Within-MAG cALP–dALP",
      same_order_between_MAG_median_distance = "Between-MAG same-order control"
    ),
    comparison = factor(
      comparison,
      levels = c("Within-MAG cALP–dALP", "Between-MAG same-order control")
    )
  )
distance_test <- wilcox.test(
  pairs$within_MAG_min_cALP_dALP_distance,
  pairs$same_order_between_MAG_median_distance,
  paired = TRUE, exact = FALSE
)
write.table(
  distance_long,
  file.path(data_dir, "fig_6_all_coexist_MAG_profile_distance_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)
p6 <- ggplot(distance_long, aes(comparison, patristic_distance, group = mag_id)) +
  geom_line(colour = "#B8B8B8", linewidth = 0.25, alpha = 0.28) +
  geom_point(aes(colour = comparison), size = 1.25, alpha = 0.62) +
  geom_boxplot(
    aes(group = comparison), width = 0.28, outlier.shape = NA,
    fill = NA, colour = "black", linewidth = 0.55
  ) +
  scale_colour_manual(
    values = c(
      "Within-MAG cALP–dALP" = "#D98C3F",
      "Between-MAG same-order control" = "#4C78A8"
    ), guide = "none"
  ) +
  labs(
    title = "Coexisting cALP/dALP copies are not products of recent terminal duplication",
    subtitle = sprintf(
      "107 paired MAGs; paired Wilcoxon P = %.3g; 0/107 terminal cherries in the 584 tree",
      distance_test$p.value
    ),
    x = NULL, y = "Patristic distance in the 584-gappyout gene tree"
  ) +
  theme_pub() +
  theme(axis.text.x = element_text(size = 6.4))
save_plot(p6, "fig_6_all_coexist_MAG_profile_distance", 125, 98)

# Figure 3b: full state-model comparison, including unrestricted histories.
models <- read.delim(
  file.path(results_dir, "directional_model_comparison.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
) %>%
  mutate(
    model_label = recode(
      model,
      ARD_unrestricted = "Unrestricted ARD",
      retention_sequential_endpoint_root_best = "Sequential retention",
      retention_adjacent_reversible = "Adjacent-state reversible",
      divergent_from_ancestral_coexist_strict = "Strict ancestral coexist"
    ),
    tree_label = recode(
      tree,
      asgard971_addcore = "Asgard971",
      archaea1338_addcore = "Archaea1338",
      gtdb_r226_expanded = "GTDB r226"
    ),
    branch_label = recode(
      branch_scale,
      unit_topology = "unit topology",
      source_branch_lengths = "source branches"
    ),
    analysis = paste0(tree_label, " — ", branch_label)
  )
analysis_levels <- c(
  "GTDB r226 — source branches", "GTDB r226 — unit topology",
  "Asgard971 — source branches", "Asgard971 — unit topology",
  "Archaea1338 — source branches", "Archaea1338 — unit topology"
)
models$analysis <- factor(models$analysis, levels = analysis_levels)
models$model_label <- factor(
  models$model_label,
  levels = c("Unrestricted ARD", "Adjacent-state reversible", "Sequential retention", "Strict ancestral coexist")
)
models$tree_label <- factor(
  models$tree_label,
  levels = c("Archaea1338", "Asgard971", "GTDB r226")
)
models$branch_label <- factor(
  models$branch_label,
  levels = c("unit topology", "source branches")
)
models <- models %>%
  mutate(
    model_x = as.integer(model_label),
    x_plot = model_x + if_else(branch_label == "unit topology", -0.075, 0.075),
    delta_label = if_else(delta_AIC < 10, sprintf("%.1f", delta_AIC), sprintf("%.0f", delta_AIC))
  )
write.table(
  models,
  file.path(data_dir, "fig_3b_full_state_model_AIC_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)
branch_cols <- c(
  "unit topology" = "#4477AA",
  "source branches" = "#CC6677"
)
p3b <- ggplot(models, aes(x_plot, delta_AIC, colour = branch_label, shape = branch_label)) +
  geom_hline(yintercept = 0, linewidth = 0.4, colour = "#666666", linetype = "22") +
  geom_line(aes(group = branch_label), linewidth = 0.62, alpha = 0.82) +
  geom_point(size = 2.35, stroke = 0.35) +
  geom_text(
    aes(label = delta_label), vjust = -0.72, size = 2.15,
    colour = "#222222", show.legend = FALSE
  ) +
  facet_wrap(~tree_label, ncol = 1, scales = "free_y") +
  scale_x_continuous(
    breaks = 1:4,
    labels = c(
      "Unrestricted\nARD", "Adjacent-state\nreversible",
      "Sequential\nretention", "Ancestral coexist\n(strict)"
    ),
    limits = c(0.72, 4.28)
  ) +
  scale_y_continuous(
    trans = pseudo_log_trans(base = 10, sigma = 1),
    breaks = c(0, 2, 10, 30, 100, 300),
    labels = c("0", "2", "10", "30", "100", "300"),
    expand = expansion(mult = c(0.03, 0.16))
  ) +
  scale_colour_manual(values = branch_cols, name = NULL) +
  scale_shape_manual(values = c("unit topology" = 16, "source branches" = 17), name = NULL) +
  labs(
    title = "All fitted state models show dataset-specific support",
    subtitle = "Exact values are delta AIC within each species-tree and branch-scale analysis; 0 denotes the best fit",
    x = NULL, y = expression(Delta*"AIC from the best model")
  ) +
  theme_pub() +
  theme(
    legend.position = "top",
    legend.justification = "left",
    axis.text.x = element_text(size = 6.2, lineheight = 0.92),
    strip.text = element_text(size = 7.4, face = "bold"),
    panel.spacing.y = unit(4.2, "mm")
  ) +
  guides(colour = guide_legend(override.aes = list(linewidth = 0.8)))
save_plot(p3b, "fig_3b_full_state_model_AIC_comparison", 142, 152)

# Figure 7: assembly-context evidence for coexist MAGs.
assembly <- read.delim(
  file.path(results_dir, "coexist_584_MAG_assembly_context.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
) %>%
  mutate(
    n_profile_copies = n_cALP_full_context + n_dALP_full_context,
    n_strict_copies = strict_cALP + strict_dALP,
    strict_copy_fraction = n_strict_copies / n_profile_copies,
    quality_checkm2 = factor(quality_checkm2, levels = c("HQ", "MQ")),
    all_clean = ifelse(all_cALP_dALP_copies_strict_clean == "TRUE", "All copies strict-clean", "At least one copy below strict gate")
  )
stopifnot(nrow(assembly) == 117L, sum(assembly$all_cALP_dALP_copies_strict_clean == "TRUE") == 27L)
write.table(
  assembly,
  file.path(data_dir, "fig_7_coexist_MAG_assembly_context_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)
quality_counts <- assembly %>%
  group_by(quality_checkm2) %>%
  summarise(n = n(), n_all_clean = sum(all_cALP_dALP_copies_strict_clean == "TRUE"), .groups = "drop") %>%
  mutate(label = paste0(n_all_clean, "/", n, " all-copy clean"))
p7 <- ggplot(assembly, aes(quality_checkm2, strict_copy_fraction)) +
  geom_violin(fill = "#D9E7EC", colour = "#6B8994", linewidth = 0.4, width = 0.75, trim = TRUE) +
  geom_boxplot(width = 0.22, outlier.shape = NA, fill = "white", linewidth = 0.45) +
  geom_jitter(
    aes(shape = all_clean, colour = all_clean),
    width = 0.12, height = 0, size = 1.25, alpha = 0.72
  ) +
  geom_text(
    data = quality_counts, aes(x = quality_checkm2, y = 1.08, label = label),
    inherit.aes = FALSE, size = 2.35, family = "Arial"
  ) +
  scale_colour_manual(
    values = c("All copies strict-clean" = "#2A9D8F", "At least one copy below strict gate" = "#8C8C8C"),
    name = NULL
  ) +
  scale_shape_manual(
    values = c("All copies strict-clean" = 16, "At least one copy below strict gate" = 1),
    name = NULL
  ) +
  scale_y_continuous(limits = c(0, 1.13), breaks = seq(0, 1, 0.25), expand = expansion(mult = c(0, 0))) +
  labs(
    title = "Strict-clean assembly contexts support genuine cALP/dALP coexistence cases",
    subtitle = "27/117 MAGs pass the strict gate for every profile copy; raw-read depth is unavailable and is not inferred",
    x = "CheckM2 MAG quality", y = "Fraction of profile copies passing the strict context gate"
  ) +
  theme_pub() +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(nrow = 2), shape = guide_legend(nrow = 2))
save_plot(p7, "fig_7_coexist_MAG_assembly_context", 130, 99)

# Figure 8: legacy combined-focus ALE context for global-history boundaries.
ale_summary <- read.delim(
  file.path(evidence_results, "ale_run_summary.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
ale_branches <- read.delim(
  file.path(evidence_results, "ale_species_branch_events.tsv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
event_data <- bind_rows(
  ale_branches %>% filter(branch_type == "S_internal_branch") %>% summarise(
    branch_type = "Internal branches",
    Duplication = sum(duplication_support_ge_0_5 == "true"),
    Transfer = sum(transfer_support_ge_0_5 == "true"),
    Loss = sum(loss_support_ge_0_5 == "true")
  ),
  ale_branches %>% filter(branch_type == "S_terminal_branch") %>% summarise(
    branch_type = "Terminal branches",
    Duplication = sum(duplication_support_ge_0_5 == "true"),
    Transfer = sum(transfer_support_ge_0_5 == "true"),
    Loss = sum(loss_support_ge_0_5 == "true")
  )
) %>%
  pivot_longer(c(Duplication, Transfer, Loss), names_to = "event", values_to = "n_branches")
expected_totals <- c(
  Duplication = as.numeric(ale_summary$value[ale_summary$metric == "expected_duplications_total"]),
  Transfer = as.numeric(ale_summary$value[ale_summary$metric == "expected_transfers_total"]),
  Loss = as.numeric(ale_summary$value[ale_summary$metric == "expected_losses_total"])
)
event_data$event <- factor(event_data$event, levels = c("Duplication", "Transfer", "Loss"))
event_data$branch_type <- factor(event_data$branch_type, levels = c("Internal branches", "Terminal branches"))
write.table(
  event_data,
  file.path(data_dir, "fig_8_legacy_ALE_DTL_context_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)
total_labels <- data.frame(
  event = factor(names(expected_totals), levels = c("Duplication", "Transfer", "Loss")),
  label = paste0("expected total = ", sprintf("%.2f", expected_totals)),
  y = c(4.0, 10.0, 2.0)
)
p8 <- ggplot(event_data, aes(event, n_branches, fill = branch_type)) +
  geom_col(position = position_dodge(width = 0.68), width = 0.62, colour = "black", linewidth = 0.3) +
  geom_text(
    aes(label = n_branches), position = position_dodge(width = 0.68),
    vjust = -0.45, size = 2.45, family = "Arial"
  ) +
  geom_text(
    data = total_labels, aes(event, y, label = label), inherit.aes = FALSE,
    size = 2.25, colour = "#444444", family = "Arial"
  ) +
  scale_fill_manual(
    values = c("Internal branches" = "#4C78A8", "Terminal branches" = "#D6D6D6"),
    name = NULL
  ) +
  scale_y_continuous(breaks = 0:10, limits = c(0, 11), expand = expansion(mult = c(0, 0))) +
  labs(
    title = "Reconciliation supports a complex DTL context\nrather than one stable deep duplication",
    subtitle = "Legacy combined-focus ALE; branches with event expectation ≥0.5\nNo internal duplication reaches the threshold",
    x = NULL, y = "Species-tree branches"
  ) +
  theme_pub() +
  theme(legend.position = "top")
save_plot(p8, "fig_8_legacy_ALE_DTL_context", 125, 92)

writeLines(
  c(
    "status=complete",
    "backend=R",
    "new_independent_subfigures=4",
    "formats=PDF,PNG",
    "composite_figure=false"
  ),
  file.path(base_dir, "RETENTION_CONCLUSION_GAP_SUBFIGURES_COMPLETE.marker")
)
