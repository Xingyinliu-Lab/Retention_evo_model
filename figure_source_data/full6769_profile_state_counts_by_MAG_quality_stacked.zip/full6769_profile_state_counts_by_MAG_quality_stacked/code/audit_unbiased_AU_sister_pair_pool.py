#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from collections import defaultdict
from itertools import combinations
from pathlib import Path

from Bio import Phylo

BASE = Path(r"..")
DATA = BASE / "data"
RESULTS = BASE / "results"
STATE = DATA / "frozen_584_MAG_profile_states.tsv"
SEQ = DATA / "frozen_584_sequence_profiles.tsv"
ASSEMBLY = RESULTS / "coexist_584_MAG_assembly_context.tsv"
DONE = RESULTS / "CORE_PROFILE_RETENTION_AU_CASES.tsv"
TREES = {
    "asgard971_addcore": Path(r".."),
    "asgard971_astral89": Path(r".."),
    "archaea1338_addcore": Path(r".."),
    "archaea1338_denovo": Path(r".."),
    "archaea1338_astral64": Path(r".."),
    "gtdb_r226": Path(r".."),
}


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        yield from csv.DictReader(handle, delimiter="\t")


def norm(name):
    return name.split("_", 1)[1] if name.startswith(("GB_", "RS_")) else name


state_rows = {x["mag_id"]: x for x in rows(STATE)}
direct = {m for m, x in state_rows.items() if x["selected_584_state"] == "coexist"}
seqs = defaultdict(lambda: defaultdict(list))
for x in rows(SEQ):
    if x["mag_id"] in direct:
        seqs[x["mag_id"]][x["profile"]].append(x["seq"])
assembly = {x["mag_id"]: x for x in rows(ASSEMBLY)}
done = {tuple(sorted((x["mag_a"], x["mag_b"]))) for x in rows(DONE)}

pair_trees = defaultdict(set)
for tree_id, path in TREES.items():
    tree = Phylo.read(str(path), "newick")
    for node in tree.get_nonterminals(order="preorder"):
        children = node.clades
        if len(children) != 2 or not all(x.is_terminal() for x in children):
            continue
        pair = tuple(sorted(norm(x.name) for x in children))
        if set(pair) <= direct:
            pair_trees[pair].add(tree_id)

out_rows = []
for (a, b), supported in sorted(pair_trees.items()):
    x = state_rows[a]
    same_order = x["order"] == state_rows[b]["order"]
    out_rows.append({
        "mag_a": a,
        "mag_b": b,
        "class": x["class"],
        "order": x["order"] if same_order else x["order"] + ";" + state_rows[b]["order"],
        "quality_a": x["quality_checkm2"],
        "quality_b": state_rows[b]["quality_checkm2"],
        "n_species_trees_exact_sisters": len(supported),
        "species_trees": ";".join(sorted(supported)),
        "n_cALP_a": len(seqs[a]["cALP"]),
        "n_dALP_a": len(seqs[a]["dALP"]),
        "n_cALP_b": len(seqs[b]["cALP"]),
        "n_dALP_b": len(seqs[b]["dALP"]),
        "strict_clean_a": assembly.get(a, {}).get("all_cALP_dALP_copies_strict_clean", "NA"),
        "strict_clean_b": assembly.get(b, {}).get("all_cALP_dALP_copies_strict_clean", "NA"),
        "already_AU_complete": str((a, b) in done).upper(),
        "unbiased_primary_eligible": str(len(supported) >= 2).upper(),
        "cALP_sequences_a": ";".join(sorted(seqs[a]["cALP"])),
        "dALP_sequences_a": ";".join(sorted(seqs[a]["dALP"])),
        "cALP_sequences_b": ";".join(sorted(seqs[b]["cALP"])),
        "dALP_sequences_b": ";".join(sorted(seqs[b]["dALP"])),
    })

out_rows.sort(key=lambda x: (
    x["unbiased_primary_eligible"] != "TRUE",
    x["order"] == "Sigynarchaeales",
    x["already_AU_complete"] == "TRUE",
    -int(x["n_species_trees_exact_sisters"]),
    x["mag_a"], x["mag_b"],
))
out = RESULTS / "AU_UNBIASED_SISTER_PAIR_POOL.tsv"
with out.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(out_rows[0]), delimiter="\t", lineterminator="\n")
    writer.writeheader(); writer.writerows(out_rows)

eligible = [x for x in out_rows if x["unbiased_primary_eligible"] == "TRUE"]
summary = {
    "direct_584_coexist_MAGs": len(direct),
    "species_tree_sister_pairs_union": len(out_rows),
    "pairs_sister_in_at_least_2_trees": len(eligible),
    "eligible_unique_MAGs": len({x[k] for x in eligible for k in ("mag_a", "mag_b")}),
    "eligible_already_AU_complete": sum(x["already_AU_complete"] == "TRUE" for x in eligible),
    "eligible_remaining": sum(x["already_AU_complete"] == "FALSE" for x in eligible),
    "eligible_non_Sigyn": sum(x["order"] != "Sigynarchaeales" for x in eligible),
    "eligible_orders": sorted({x["order"] for x in eligible}),
}
(RESULTS / "AU_UNBIASED_SISTER_PAIR_POOL_SUMMARY.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(summary, ensure_ascii=False))
