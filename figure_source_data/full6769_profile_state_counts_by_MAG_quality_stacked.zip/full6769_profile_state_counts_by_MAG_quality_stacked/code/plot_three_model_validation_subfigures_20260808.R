suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(scales)
})

base_dir <- ".."
results_dir <- file.path(base_dir, "results")
data_dir <- file.path(base_dir, "data", "three_model_figures")
figure_dir <- file.path(base_dir, "figures", "three_model_validation")
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

theme_pub <- function(base_size = 8.5) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.4, colour = "black"),
      axis.ticks = element_line(linewidth = 0.4, colour = "black"),
      axis.text = element_text(colour = "black"),
      plot.title = element_text(face = "bold", size = base_size + 1.5, margin = margin(b = 5)),
      plot.subtitle = element_text(size = base_size, colour = "#333333", margin = margin(b = 7)),
      plot.margin = margin(8, 12, 8, 8),
      legend.title = element_blank(),
      legend.key.height = unit(3.5, "mm"),
      panel.grid = element_blank()
    )
}

save_plot <- function(plot, stem, width_mm, height_mm, dpi = 420) {
  ggsave(
    filename = file.path(figure_dir, paste0(stem, ".pdf")),
    plot = plot, width = width_mm, height = height_mm, units = "mm",
    device = grDevices::cairo_pdf, family = "Arial", bg = "white"
  )
  ggsave(
    filename = file.path(figure_dir, paste0(stem, ".png")),
    plot = plot, width = width_mm, height = height_mm, units = "mm",
    device = ragg::agg_png, dpi = dpi, bg = "white"
  )
}

state_cols <- c(
  "dALP-only" = "#4F9B8F",
  "coexist" = "#8B78A8",
  "cALP-only" = "#4C78A8"
)

# Subfigure 1: observed MAG states.
state_counts <- data.frame(
  state = factor(c("dALP-only", "coexist", "cALP-only"),
                 levels = c("dALP-only", "coexist", "cALP-only")),
  n_MAG = c(232L, 117L, 112L),
  n_orders = c(NA_integer_, 13L, NA_integer_),
  n_classes = c(NA_integer_, 10L, NA_integer_)
)
write.table(state_counts, file.path(data_dir, "source_state_counts.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
p1 <- ggplot(state_counts, aes(state, n_MAG, fill = state)) +
  geom_col(width = 0.62, colour = "black", linewidth = 0.35) +
  geom_text(aes(label = n_MAG), vjust = -0.45, size = 3.1, family = "Arial") +
  annotate("text", x = 2, y = 94, label = "13 orders\n10 classes",
           family = "Arial", size = 2.7, lineheight = 0.95) +
  scale_fill_manual(values = state_cols, guide = "none") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.10))) +
  labs(
    title = "A stable coexistence state occurs across archaeal lineages",
    subtitle = "Full frozen-6769 profiles for the 461 represented MAGs\n39 coexist MAGs across 12 orders remain after removing Sigynarchaeales",
    x = NULL, y = "MAGs"
  ) +
  theme_pub()
save_plot(p1, "fig_1_observed_profile_state_counts", 118, 88)
if (identical(Sys.getenv("PLOT_ONLY_FIG1"), "1")) quit(save = "no", status = 0)

# Subfigure 2: AU topology discrimination in four sister-MAG pairs.
au <- read.delim(file.path(results_dir, "CORE_PROFILE_RETENTION_AU_CASES.tsv"),
                 check.names = FALSE, stringsAsFactors = FALSE)
short_id <- c("Pair 1", "Pair 2", "Pair 3", "Pair 4")
au_long <- bind_rows(
  data.frame(pair = short_id, model = "Retention", delta_logL = 0,
             p_AU = au$retention_pAU),
  data.frame(pair = short_id, model = "Terminal duplication", delta_logL = au$terminal_duplication_deltaL,
             p_AU = au$terminal_duplication_pAU),
  data.frame(pair = short_id, model = "Crossed pairing", delta_logL = au$crossed_deltaL,
             p_AU = au$crossed_pAU)
) %>%
  mutate(model = factor(model, levels = c("Retention", "Terminal duplication", "Crossed pairing")))
write.table(au_long, file.path(data_dir, "source_four_pair_AU_likelihood_loss.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
pair_cols <- c("Pair 1" = "#355C9A", "Pair 2" = "#2A9D8F", "Pair 3" = "#C06C54", "Pair 4" = "#7B6D9C")
p2 <- ggplot(au_long, aes(model, delta_logL, group = pair, colour = pair)) +
  geom_line(linewidth = 0.65, alpha = 0.82) +
  geom_point(size = 2.35) +
  scale_colour_manual(values = pair_cols) +
  scale_y_continuous(expand = expansion(mult = c(0.01, 0.08))) +
  labs(
    title = "Sister-MAG topology tests reject recent terminal duplication",
    subtitle = "Retention p-AU = 0.999–1.000\nBoth alternative constraints are rejected in all four pairs",
    x = NULL, y = expression(Delta*"log-likelihood relative to retention")
  ) +
  theme_pub() +
  theme(legend.position = "top", axis.text.x = element_text(size = 7.7))
save_plot(p2, "fig_2_four_pair_AU_likelihood_loss", 128, 92)

# Subfigure 3: direction-marginalized M2 versus strict M3.
models <- read.delim(file.path(results_dir, "directional_model_comparison.tsv"),
                     check.names = FALSE, stringsAsFactors = FALSE)
keep <- models %>%
  filter(model %in% c("retention_sequential_endpoint_root_best",
                      "divergent_from_ancestral_coexist_strict")) %>%
  select(tree, branch_scale, model, AIC) %>%
  tidyr::pivot_wider(names_from = model, values_from = AIC) %>%
  mutate(
    delta_AIC_M3_minus_M2 = divergent_from_ancestral_coexist_strict - retention_sequential_endpoint_root_best,
    tree_label = recode(tree,
                        "asgard971_addcore" = "Asgard971",
                        "archaea1338_addcore" = "Archaea1338",
                        "gtdb_r226_expanded" = "GTDB r226"),
    scale_label = recode(branch_scale,
                         "unit_topology" = "Unit topology",
                         "source_branch_lengths" = "Source branches")
  )
write.table(keep, file.path(data_dir, "source_M2_vs_M3_delta_AIC.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
p3 <- ggplot(keep, aes(tree_label, delta_AIC_M3_minus_M2, colour = scale_label, shape = scale_label)) +
  geom_hline(yintercept = 0, linetype = "dashed", colour = "#777777", linewidth = 0.4) +
  geom_point(size = 2.8, position = position_dodge(width = 0.35)) +
  geom_text(aes(label = sprintf("%.1f", delta_AIC_M3_minus_M2)),
            position = position_dodge(width = 0.35), vjust = -0.85,
            size = 2.55, family = "Arial", show.legend = FALSE) +
  scale_colour_manual(values = c("Unit topology" = "#4C78A8", "Source branches" = "#E28E2C")) +
  scale_shape_manual(values = c("Unit topology" = 16, "Source branches" = 17)) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.14))) +
  labs(
    title = "Retention is favoured over strict ancestral-coexist resolution",
    subtitle = "Positive values favour M2\nEndpoint identity is marginalized; no cALP/dALP direction is assigned",
    x = NULL, y = expression(Delta*"AIC (M3 ancestral coexist - M2 retention)")
  ) +
  theme_pub() +
  theme(legend.position = "top")
save_plot(p3, "fig_3_M2_vs_M3_delta_AIC", 126, 92)

# Subfigure 4: six-tree robustness of state clustering.
topo <- read.delim(file.path(results_dir, "species_tree_profile_state_topology.tsv"),
                   check.names = FALSE, stringsAsFactors = FALSE) %>%
  mutate(
    random_same_state = (
      n_dALP_only * (n_dALP_only - 1) +
        n_coexist * (n_coexist - 1) +
        n_cALP_only * (n_cALP_only - 1)
    ) / (mapped_MAGs * (mapped_MAGs - 1)),
    tree_label = recode(tree,
      "asgard971_addcore" = "Asgard971 add-core",
      "asgard971_astral89" = "Asgard971 ASTRAL89",
      "archaea1338_addcore" = "Archaea1338 add-core",
      "archaea1338_denovo" = "Archaea1338 de novo",
      "archaea1338_astral64" = "Archaea1338 ASTRAL64",
      "gtdb_r226_expanded" = "GTDB r226"
    )
  )
topo$tree_label <- factor(topo$tree_label, levels = rev(topo$tree_label))
write.table(topo, file.path(data_dir, "source_six_tree_state_clustering.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
topo_long <- bind_rows(
  topo %>% transmute(tree, tree_label, group = "Random", same_state_fraction = random_same_state),
  topo %>% transmute(tree, tree_label, group = "Observed", same_state_fraction = nearest_same_state_fraction)
) %>%
  mutate(group = factor(group, levels = c("Random", "Observed")))
tree_levels <- c(
  "asgard971_addcore", "asgard971_astral89", "archaea1338_addcore",
  "archaea1338_denovo", "archaea1338_astral64", "gtdb_r226_expanded"
)
tree_names <- c(
  "asgard971_addcore" = "Asgard971 add-core",
  "asgard971_astral89" = "Asgard971 ASTRAL89",
  "archaea1338_addcore" = "Archaea1338 add-core",
  "archaea1338_denovo" = "Archaea1338 de novo",
  "archaea1338_astral64" = "Archaea1338 ASTRAL64",
  "gtdb_r226_expanded" = "GTDB r226"
)
tree_offsets <- setNames(seq(-0.105, 0.105, length.out = length(tree_levels)), tree_levels)
topo_long <- topo_long %>%
  mutate(
    x_base = as.integer(group),
    x_plot = x_base + unname(tree_offsets[tree]),
    tree_display = factor(tree_names[tree], levels = unname(tree_names[tree_levels]))
  )
write.table(topo_long, file.path(data_dir, "source_six_tree_state_clustering_boxplot.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

p4 <- ggplot(topo_long, aes(y = same_state_fraction)) +
  geom_boxplot(
    aes(x = x_base, group = group, fill = group), width = 0.42, outlier.shape = NA,
    linewidth = 0.45, colour = "#4B4548", alpha = 0.86
  ) +
  geom_line(
    aes(x = x_plot, group = tree_display, colour = tree_display),
    linewidth = 0.45, alpha = 0.42
  ) +
  geom_point(
    aes(x = x_plot, colour = tree_display, shape = tree_display),
    size = 2.5, stroke = 0.65
  ) +
  annotate("segment", x = 1, xend = 2, y = 0.925, yend = 0.925, linewidth = 0.4) +
  annotate("segment", x = 1, xend = 1, y = 0.912, yend = 0.925, linewidth = 0.4) +
  annotate("segment", x = 2, xend = 2, y = 0.912, yend = 0.925, linewidth = 0.4) +
  annotate("text", x = 1.5, y = 0.938,
           label = "Label permutation P < 0.001 in each tree",
           family = "Arial", size = 2.65) +
  scale_fill_manual(values = c("Random" = "#E7E3E1", "Observed" = "#CBBBC1"), guide = "none") +
  scale_colour_manual(
    values = c("#4C78A8", "#93B7CF", "#C66A4A", "#D9A45D", "#5E927F", "#7D6A91"),
    name = "Species tree"
  ) +
  scale_shape_manual(
    values = c(16, 17, 15, 18, 8, 3),
    name = "Species tree"
  ) +
  scale_x_continuous(breaks = c(1, 2), labels = c("Random", "Observed"), limits = c(0.62, 2.38)) +
  scale_y_continuous(limits = c(0.28, 0.97), breaks = seq(0.3, 0.9, 0.1),
                     expand = expansion(mult = c(0.01, 0.01))) +
  labs(
    title = "Profile states cluster beyond random expectation",
    subtitle = "Each point is one species-tree reconstruction; lines connect matched values",
    x = NULL, y = "Nearest-neighbour same-state fraction"
  ) +
  theme_pub() +
  theme(
    legend.position = "bottom",
    legend.title = element_text(size = 6.0, face = "bold"),
    legend.text = element_text(size = 5.5),
    legend.key.width = unit(5, "mm"),
    legend.key.height = unit(3.5, "mm"),
    axis.text.x = element_text(size = 7.2, face = "bold"),
    plot.margin = margin(6, 8, 5, 6)
  ) +
  guides(
    colour = guide_legend(
      ncol = 2, byrow = TRUE,
      override.aes = list(alpha = 1, linewidth = 0.7, shape = c(16, 17, 15, 18, 8, 3))
    ),
    shape = "none"
  )
save_plot(p4, "fig_4_six_species_tree_state_clustering", 125, 104)

# Subfigure 5: leave-Sigyn lineage control.
loo <- read.delim(file.path(results_dir, "leave_one_order_out_topology.tsv"),
                  check.names = FALSE, stringsAsFactors = FALSE) %>%
  filter(left_out_order == "Sigynarchaeales") %>%
  mutate(
    dataset = case_when(
      grepl("^asgard971", tree) ~ "Asgard971",
      grepl("^archaea1338", tree) ~ "Archaea1338",
      TRUE ~ "GTDB r226"
    )
  ) %>%
  group_by(dataset) %>%
  summarise(
    coexist_after = first(n_coexist),
    orders_after = first(coexist_remaining_orders),
    .groups = "drop"
  )
before <- data.frame(dataset = c("Asgard971", "Archaea1338", "GTDB r226"),
                     coexist_before = c(112L, 33L, 117L))
loo_plot <- left_join(before, loo, by = "dataset") %>%
  tidyr::pivot_longer(c(coexist_before, coexist_after), names_to = "condition", values_to = "n_coexist") %>%
  mutate(condition = recode(condition,
                            "coexist_before" = "All orders",
                            "coexist_after" = "Without Sigynarchaeales"))
write.table(loo_plot, file.path(data_dir, "source_leave_Sigyn_coexistence.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
p5 <- ggplot(loo_plot, aes(condition, n_coexist, group = dataset, colour = dataset)) +
  geom_line(linewidth = 0.7) +
  geom_point(size = 2.5) +
  geom_text(data = loo_plot %>% filter(condition == "Without Sigynarchaeales"),
            aes(label = paste0(n_coexist, " MAGs; ", orders_after, " orders")),
            hjust = -0.08, size = 2.45, family = "Arial", show.legend = FALSE) +
  scale_colour_manual(values = c("Asgard971" = "#3F7CAC", "Archaea1338" = "#8E6C9F", "GTDB r226" = "#2A9D8F")) +
  scale_y_continuous(expand = expansion(mult = c(0.03, 0.08))) +
  scale_x_discrete(expand = expansion(add = c(0.15, 0.72))) +
  labs(
    title = "Coexistence persists after removing Sigynarchaeales",
    subtitle = "The retention-compatible state is not produced by one dominant order",
    x = NULL, y = "Coexist MAGs"
  ) +
  theme_pub() +
  theme(legend.position = "top")
save_plot(p5, "fig_5_leave_Sigyn_coexistence", 126, 91)

writeLines(c(
  "status=complete",
  "backend=R",
  "outputs=5_independent_PDF_plus_PNG",
  "composite_figure=false",
  "direction_used_for_retention_call=false"
), file.path(base_dir, "THREE_MODEL_SUBFIGURES_COMPLETE.marker"))
