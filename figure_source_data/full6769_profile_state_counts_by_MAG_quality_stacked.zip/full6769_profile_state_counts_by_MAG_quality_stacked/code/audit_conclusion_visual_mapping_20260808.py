#!/usr/bin/env python3
"""Strictly verify that every actin-retention manuscript conclusion maps to nonempty visuals and source data."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAP = ROOT / "results" / "ACTIN_RETENTION_CONCLUSION_TO_FIGURE_MAP_20260808.tsv"
FIGURES = ROOT / "figures" / "three_model_validation"
DATA = ROOT / "data" / "three_model_figures"
DELIVERY = ROOT / "results" / "THREE_MODEL_FIGURE_DELIVERY_AUDIT.tsv"
OUT = ROOT / "results" / "ACTIN_RETENTION_CONCLUSION_VISUAL_COMPLETENESS_AUDIT.tsv"


def nonempty(path: Path) -> bool:
    return path.is_file() and path.stat().st_size > 0


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def split_files(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def main() -> None:
    rows = list(csv.DictReader(MAP.open(encoding="utf-8"), delimiter="\t"))
    delivery = list(csv.DictReader(DELIVERY.open(encoding="utf-8"), delimiter="\t"))
    delivered_pdf = {row["pdf"] for row in delivery if row["final_status"] == "PASS"}
    audits: list[dict[str, str]] = []
    for row in rows:
        primary = split_files(row["primary_visual"])
        secondary = split_files(row["secondary_visual"])
        sources = [] if row["conclusion_id"] == "FINAL" else split_files(row["source_data"])
        visual_files = primary + secondary
        visual_exists = all(nonempty(FIGURES / name) for name in visual_files)
        pdfs_in_delivery = all(name in delivered_pdf for name in visual_files)
        png_exists = all(nonempty(FIGURES / name.replace(".pdf", ".png")) for name in visual_files)
        source_exists = all(nonempty(DATA / name) for name in sources)
        primary_exists = bool(primary) and all(nonempty(FIGURES / name) for name in primary)
        status = primary_exists and visual_exists and pdfs_in_delivery and png_exists and source_exists
        audits.append(
            {
                "conclusion_id": row["conclusion_id"],
                "level": row["level"],
                "primary_visual_nonempty": str(primary_exists).upper(),
                "all_mapped_visuals_nonempty": str(visual_exists).upper(),
                "all_PDFs_in_delivery_PASS": str(pdfs_in_delivery).upper(),
                "all_PNG_previews_nonempty": str(png_exists).upper(),
                "all_source_data_nonempty": str(source_exists).upper(),
                "final_visual_support_status": "PASS" if status else "FAIL",
                "primary_visual_sha256": ";".join(sha256(FIGURES / name) for name in primary if nonempty(FIGURES / name)),
            }
        )
    with OUT.open("w", encoding="utf-8", newline="\n") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(audits[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(audits)
    failed = [row["conclusion_id"] for row in audits if row["final_visual_support_status"] != "PASS"]
    if failed:
        raise RuntimeError(f"visual-support audit failed: {failed}")
    (ROOT / "ACTIN_RETENTION_CONCLUSION_VISUAL_RECOVERY_COMPLETE.marker").write_text(
        "status=COMPLETE\n"
        "scope=actin_only_retention\n"
        f"conclusions_mapped={len(rows)}\n"
        f"conclusions_visual_audit_PASS={len(audits)}\n"
        "independent_visuals_total=10\n"
        "new_visuals=4\n"
        "backend=R\n"
        "formats=PDF,PNG\n"
        "every_manuscript_conclusion_has_visual_support=true\n"
        "direction_required=false\n",
        encoding="utf-8",
        newline="\n",
    )


if __name__ == "__main__":
    main()
