#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

from Bio import Phylo

BASE = Path(r"..")
RESULTS = BASE / "results"
DATA = BASE / "data"
META = Path(r"..")
ASSEMBLY = Path(r"..")
TREE_DIR = Path(r"..")
TREES = {
    "584_automated1": TREE_DIR / "584.treefile",
    "584_gappyout": TREE_DIR / "584.gappyout.treefile",
    "806_automated1": TREE_DIR / "806.treefile",
    "806_gappyout": TREE_DIR / "806.gappyout.treefile",
}
PROFILE = {
    "canonical Actin-like": "cALP",
    "Crenactin-like / archaeal actin": "dALP",
}


def read_tsv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        yield from csv.DictReader(handle, delimiter="\t")


def write_tsv(path: Path, rows):
    rows = list(rows)
    if not rows:
        raise ValueError(f"No rows for {path}")
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


seq_meta = {}
for row in read_tsv(META):
    profile = PROFILE.get(row["actin_family_class"])
    if profile:
        seq_meta[row["seq"]] = {
            "mag_id": row["mag_id"],
            "profile": profile,
            "order": row["o"],
        }

tree_rows = []
direct_coexist_by_tree = {}
for tree_id, path in TREES.items():
    tree = Phylo.read(str(path), "newick")
    tips = [x for x in tree.get_terminals() if x.name in seq_meta]
    tip_names = {x.name for x in tips}
    by_mag = defaultdict(lambda: defaultdict(list))
    for tip in tips:
        row = seq_meta[tip.name]
        by_mag[row["mag_id"]][row["profile"]].append(tip.name)
    coexist = {m for m, pp in by_mag.items() if pp["cALP"] and pp["dALP"]}
    direct_coexist_by_tree[tree_id] = coexist

    parent = {}
    for node in tree.find_clades(order="preorder"):
        for child in node.clades:
            parent[id(child)] = node
    tip_obj = {x.name: x for x in tips}
    any_terminal_cherry = 0
    for mag in coexist:
        found = False
        for c in by_mag[mag]["cALP"]:
            for d in by_mag[mag]["dALP"]:
                pc = parent.get(id(tip_obj[c]))
                pd = parent.get(id(tip_obj[d]))
                if pc is not None and pc is pd and len(pc.clades) == 2 and all(x.is_terminal() for x in pc.clades):
                    found = True
                    break
            if found:
                break
        any_terminal_cherry += int(found)

    pure = {}
    for profile in ("cALP", "dALP"):
        best_n, best_support = 0, "NA"
        for node in tree.get_nonterminals(order="postorder"):
            desc = [x.name for x in node.get_terminals() if x.name in tip_names]
            if len(desc) <= best_n:
                continue
            profiles = {seq_meta[x]["profile"] for x in desc}
            if profiles == {profile}:
                best_n = len(desc)
                best_support = node.confidence if node.confidence is not None else (node.name or "NA")
        pure[profile] = (best_n, best_support)

    tree_rows.append({
        "tree": tree_id,
        "total_tips": len(tree.get_terminals()),
        "archaeal_profile_tips": len(tips),
        "direct_coexist_MAGs": len(coexist),
        "same_MAG_cALP_dALP_terminal_cherry_MAGs": any_terminal_cherry,
        "terminal_cherry_fraction": any_terminal_cherry / len(coexist) if coexist else "NA",
        "largest_pure_cALP_clade_tips": pure["cALP"][0],
        "largest_pure_cALP_clade_support": pure["cALP"][1],
        "largest_pure_dALP_clade_tips": pure["dALP"][0],
        "largest_pure_dALP_clade_support": pure["dALP"][1],
    })

write_tsv(RESULTS / "four_gene_tree_profile_sensitivity.tsv", tree_rows)

mag_state = {row["mag_id"]: row for row in read_tsv(DATA / "frozen_584_MAG_profile_states.tsv")}
coexist_full = {m for m, row in mag_state.items() if row["state"] == "coexist"}
coexist_direct_584 = direct_coexist_by_tree["584_gappyout"]
genes = defaultdict(list)
for row in read_tsv(ASSEMBLY):
    if row["mag_id"] not in coexist_full or row["actin_family_class"] not in PROFILE:
        continue
    try:
        strict = (
            row["partial"] == "00"
            and float(row["edge_distance_bp"]) >= 5000
            and float(row["local20kb_tnf_cosine_to_genome"]) >= 0.95
        )
    except (ValueError, TypeError):
        strict = False
    genes[row["mag_id"]].append((row, strict))

assembly_rows = []
for mag in sorted(coexist_full):
    gg = genes.get(mag, [])
    counts = Counter(PROFILE[x[0]["actin_family_class"]] for x in gg)
    strict_counts = Counter(PROFILE[x[0]["actin_family_class"]] for x in gg if x[1])
    all_strict = bool(gg) and all(x[1] for x in gg) and counts["cALP"] > 0 and counts["dALP"] > 0
    assembly_rows.append({
        "mag_id": mag,
        "in_584_direct_pair_set": str(mag in coexist_direct_584).upper(),
        "quality_checkm2": mag_state[mag]["quality_checkm2"],
        "n_cALP_full_context": counts["cALP"],
        "n_dALP_full_context": counts["dALP"],
        "strict_cALP": strict_counts["cALP"],
        "strict_dALP": strict_counts["dALP"],
        "all_cALP_dALP_copies_strict_clean": str(all_strict).upper(),
        "assembly_context_rows_found": str(bool(gg)).upper(),
    })
write_tsv(RESULTS / "coexist_584_MAG_assembly_context.tsv", assembly_rows)

summary = {
    "full_frozen_coexist_MAGs": len(coexist_full),
    "direct_584_coexist_MAGs": len(coexist_direct_584),
    "assembly_rows_found_MAGs": sum(x["assembly_context_rows_found"] == "TRUE" for x in assembly_rows),
    "all_profile_copies_strict_clean_MAGs": sum(x["all_cALP_dALP_copies_strict_clean"] == "TRUE" for x in assembly_rows),
    "direct_584_all_profile_copies_strict_clean_MAGs": sum(
        x["in_584_direct_pair_set"] == "TRUE" and x["all_cALP_dALP_copies_strict_clean"] == "TRUE"
        for x in assembly_rows
    ),
    "tree_sensitivity": tree_rows,
}
(RESULTS / "four_tree_and_coexist_assembly_summary.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(summary, ensure_ascii=False))
