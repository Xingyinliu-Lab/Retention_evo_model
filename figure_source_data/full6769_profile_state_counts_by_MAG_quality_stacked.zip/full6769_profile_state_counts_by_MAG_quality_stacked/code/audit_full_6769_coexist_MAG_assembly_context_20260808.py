#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(r"..")
META = Path(r"..")
ASSEMBLY = Path(r"..")
RESULTS = BASE / "results"
DATA = BASE / "data" / "full_6769_coexist_assembly_audit"
WORK = BASE / "work_records"

PROFILE = {
    "canonical Actin-like": "cALP",
    "Crenactin-like / archaeal actin": "dALP",
}


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"No rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def to_float(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


RESULTS.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)
WORK.mkdir(parents=True, exist_ok=True)

meta_rows = read_tsv(META)
if len(meta_rows) != 6769:
    raise SystemExit(f"Frozen metadata must contain 6769 sequences; observed {len(meta_rows)}")
if len({row["seq"] for row in meta_rows}) != len(meta_rows):
    raise SystemExit("Frozen metadata contains duplicate sequence IDs")

meta_by_seq = {row["seq"]: row for row in meta_rows}
profiles_by_mag: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
for row in meta_rows:
    profile = PROFILE.get(row["actin_family_class"])
    if profile:
        profiles_by_mag[row["mag_id"]][profile].append(row["seq"])

coexist = {
    mag: profiles for mag, profiles in profiles_by_mag.items()
    if profiles["cALP"] and profiles["dALP"]
}
if len(coexist) != 342:
    raise SystemExit(f"Frozen full-set coexist MAG count changed: expected 342, observed {len(coexist)}")

assembly_rows = read_tsv(ASSEMBLY)
if len({row["seq"] for row in assembly_rows}) != len(assembly_rows):
    raise SystemExit("Assembly-context table contains duplicate sequence IDs")
assembly_by_seq = {row["seq"]: row for row in assembly_rows}

copy_rows: list[dict[str, object]] = []
mag_rows: list[dict[str, object]] = []
order_counts: Counter[tuple[str, str]] = Counter()
quality_counts: Counter[tuple[str, str]] = Counter()
failure_copy_counts: Counter[str] = Counter()
failure_mag_sets: dict[str, set[str]] = defaultdict(set)

for mag in sorted(coexist):
    profile_sequences = coexist[mag]
    all_sequences = sorted(profile_sequences["cALP"] + profile_sequences["dALP"])
    first_meta = meta_by_seq[all_sequences[0]]
    taxonomy_fields = ("d", "p", "c", "o", "f", "g", "s", "quality_checkm2")
    for field in taxonomy_fields:
        values = {meta_by_seq[seq][field] for seq in all_sequences}
        if len(values) != 1:
            raise SystemExit(f"Inconsistent {field} within MAG {mag}: {sorted(values)}")

    strict_by_profile = Counter()
    failure_by_reason = Counter()
    context_found = 0
    for profile in ("cALP", "dALP"):
        for seq in sorted(profile_sequences[profile]):
            row = assembly_by_seq.get(seq)
            reasons: list[str] = []
            if row is None:
                reasons.append("missing_assembly_context")
                partial = edge_distance = local_tnf = contig = source_partition = "NA"
            else:
                context_found += 1
                partial = row["partial"]
                edge_distance = row["edge_distance_bp"]
                local_tnf = row["local20kb_tnf_cosine_to_genome"]
                contig = row["contig"]
                source_partition = row["source_partition"]
                if partial != "00":
                    reasons.append("partial_gene")
                edge = to_float(edge_distance)
                if edge is None:
                    reasons.append("edge_metric_missing")
                elif edge < 5000:
                    reasons.append("contig_edge_lt5kb")
                tnf = to_float(local_tnf)
                if tnf is None:
                    reasons.append("TNF_metric_missing")
                elif tnf < 0.95:
                    reasons.append("local_TNF_lt0.95")

            strict = not reasons
            if strict:
                strict_by_profile[profile] += 1
            else:
                for reason in reasons:
                    failure_copy_counts[reason] += 1
                    failure_by_reason[reason] += 1
                    failure_mag_sets[reason].add(mag)
            copy_rows.append({
                "mag_id": mag,
                "seq": seq,
                "profile": profile,
                "quality_checkm2": first_meta["quality_checkm2"],
                "phylum": first_meta["p"],
                "class": first_meta["c"],
                "order": first_meta["o"],
                "assembly_context_found": str(row is not None).upper(),
                "strict_clean": str(strict).upper(),
                "failure_reasons": ";".join(reasons) if reasons else "PASS",
                "partial": partial,
                "edge_distance_bp": edge_distance,
                "local20kb_tnf_cosine_to_genome": local_tnf,
                "contig": contig,
                "source_partition": source_partition,
            })

    n_calp = len(profile_sequences["cALP"])
    n_dalp = len(profile_sequences["dALP"])
    n_total = n_calp + n_dalp
    n_strict = strict_by_profile["cALP"] + strict_by_profile["dALP"]
    clean_pair = strict_by_profile["cALP"] > 0 and strict_by_profile["dALP"] > 0
    all_copy_clean = context_found == n_total and n_strict == n_total
    if all_copy_clean:
        evidence_tier = "ALL_COPIES_STRICT_CLEAN"
    elif clean_pair:
        evidence_tier = "AT_LEAST_ONE_STRICT_COPY_PER_PROFILE"
    elif n_strict > 0:
        evidence_tier = "STRICT_COPY_IN_ONE_PROFILE_ONLY"
    else:
        evidence_tier = "NO_STRICT_COPY"

    order_name = first_meta["o"] or "Unclassified order"
    quality = first_meta["quality_checkm2"] or "NA"
    order_counts[(order_name, "total")] += 1
    order_counts[(order_name, "clean_pair")] += int(clean_pair)
    order_counts[(order_name, "all_copy_clean")] += int(all_copy_clean)
    quality_counts[(quality, "total")] += 1
    quality_counts[(quality, "clean_pair")] += int(clean_pair)
    quality_counts[(quality, "all_copy_clean")] += int(all_copy_clean)

    mag_rows.append({
        "mag_id": mag,
        "quality_checkm2": quality,
        "domain": first_meta["d"],
        "phylum": first_meta["p"],
        "class": first_meta["c"],
        "order": order_name,
        "family": first_meta["f"],
        "genus": first_meta["g"],
        "species": first_meta["s"],
        "n_cALP": n_calp,
        "n_dALP": n_dalp,
        "n_profile_copies": n_total,
        "assembly_context_copies_found": context_found,
        "strict_cALP": strict_by_profile["cALP"],
        "strict_dALP": strict_by_profile["dALP"],
        "n_strict_copies": n_strict,
        "strict_copy_fraction": f"{n_strict / n_total:.6f}",
        "at_least_one_strict_copy_per_profile": str(clean_pair).upper(),
        "all_profile_copies_strict_clean": str(all_copy_clean).upper(),
        "evidence_tier": evidence_tier,
        "failed_partial_copies": failure_by_reason["partial_gene"],
        "failed_edge_lt5kb_copies": failure_by_reason["contig_edge_lt5kb"],
        "failed_TNF_lt0.95_copies": failure_by_reason["local_TNF_lt0.95"],
        "failed_missing_context_or_metric_copies": (
            failure_by_reason["missing_assembly_context"]
            + failure_by_reason["edge_metric_missing"]
            + failure_by_reason["TNF_metric_missing"]
        ),
    })

total_copies = len(copy_rows)
strict_copies = sum(row["strict_clean"] == "TRUE" for row in copy_rows)
clean_pair_mags = sum(row["at_least_one_strict_copy_per_profile"] == "TRUE" for row in mag_rows)
all_clean_mags = sum(row["all_profile_copies_strict_clean"] == "TRUE" for row in mag_rows)
mapped_copies = sum(row["assembly_context_found"] == "TRUE" for row in copy_rows)
non_sigyn_pair = sum(
    row["order"] != "Sigynarchaeales" and row["at_least_one_strict_copy_per_profile"] == "TRUE"
    for row in mag_rows
)
non_sigyn_all = sum(
    row["order"] != "Sigynarchaeales" and row["all_profile_copies_strict_clean"] == "TRUE"
    for row in mag_rows
)

summary_metrics = [
    ("frozen_authoritative_sequences", len(meta_rows)),
    ("full_coexist_MAGs", len(mag_rows)),
    ("full_coexist_profile_copies", total_copies),
    ("assembly_context_copies_found", mapped_copies),
    ("strict_clean_copies", strict_copies),
    ("strict_clean_copy_fraction", f"{strict_copies / total_copies:.6f}"),
    ("MAGs_with_at_least_one_strict_cALP_and_dALP", clean_pair_mags),
    ("MAGs_with_all_profile_copies_strict_clean", all_clean_mags),
    ("non_Sigyn_clean_pair_MAGs", non_sigyn_pair),
    ("non_Sigyn_all_copy_clean_MAGs", non_sigyn_all),
    ("MAGs_with_edge_lt5kb_failure", len(failure_mag_sets["contig_edge_lt5kb"])),
    ("MAGs_with_partial_gene_failure", len(failure_mag_sets["partial_gene"])),
    ("MAGs_with_TNF_lt0.95_failure", len(failure_mag_sets["local_TNF_lt0.95"])),
    ("copies_with_edge_lt5kb_failure", failure_copy_counts["contig_edge_lt5kb"]),
    ("copies_with_partial_gene_failure", failure_copy_counts["partial_gene"]),
    ("copies_with_TNF_lt0.95_failure", failure_copy_counts["local_TNF_lt0.95"]),
]

order_rows = []
for order_name in sorted({key[0] for key in order_counts}):
    total = order_counts[(order_name, "total")]
    pair = order_counts[(order_name, "clean_pair")]
    all_clean = order_counts[(order_name, "all_copy_clean")]
    order_rows.append({
        "order": order_name,
        "coexist_MAGs": total,
        "clean_pair_MAGs": pair,
        "all_copy_clean_MAGs": all_clean,
        "clean_pair_fraction": f"{pair / total:.6f}",
        "all_copy_clean_fraction": f"{all_clean / total:.6f}",
    })

quality_rows = []
for quality in sorted({key[0] for key in quality_counts}):
    total = quality_counts[(quality, "total")]
    pair = quality_counts[(quality, "clean_pair")]
    all_clean = quality_counts[(quality, "all_copy_clean")]
    quality_rows.append({
        "quality_checkm2": quality,
        "coexist_MAGs": total,
        "clean_pair_MAGs": pair,
        "all_copy_clean_MAGs": all_clean,
        "clean_pair_fraction": f"{pair / total:.6f}",
        "all_copy_clean_fraction": f"{all_clean / total:.6f}",
    })

mag_out = RESULTS / "full_6769_coexist_MAG_assembly_context_20260808.tsv"
copy_out = DATA / "full_6769_coexist_copy_assembly_context_20260808.tsv"
summary_out = RESULTS / "full_6769_coexist_assembly_summary_20260808.tsv"
order_out = DATA / "full_6769_coexist_assembly_by_order_20260808.tsv"
quality_out = DATA / "full_6769_coexist_assembly_by_quality_20260808.tsv"
manifest_out = RESULTS / "full_6769_coexist_assembly_input_manifest_20260808.tsv"

write_tsv(mag_out, mag_rows)
write_tsv(copy_out, copy_rows)
write_tsv(summary_out, [{"metric": key, "value": value} for key, value in summary_metrics])
write_tsv(order_out, order_rows)
write_tsv(quality_out, quality_rows)
write_tsv(manifest_out, [
    {"input": "frozen_6769_sequence_metadata", "path": str(META), "rows": len(meta_rows), "bytes": META.stat().st_size, "sha256": sha256(META)},
    {"input": "full_multicopy_assembly_context", "path": str(ASSEMBLY), "rows": len(assembly_rows), "bytes": ASSEMBLY.stat().st_size, "sha256": sha256(ASSEMBLY)},
])

summary_json = {
    "scope": "all cALP+dALP coexist MAGs in the frozen authoritative 6769-sequence universe",
    "strict_gate": "partial=00 AND edge_distance_bp>=5000 AND local20kb_tnf_cosine_to_genome>=0.95",
    "metrics": {key: value for key, value in summary_metrics},
    "quality": quality_rows,
    "orders": order_rows,
    "interpretation_boundary": (
        "Failure of the strict gate is uncertainty, not evidence of assembly artefact. "
        "No BAM/FASTQ-based read-depth, linkage, strain-separation or re-binning test is available."
    ),
}
(RESULTS / "full_6769_coexist_assembly_summary_20260808.json").write_text(
    json.dumps(summary_json, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)

report = f"""# 冻结6769全集 cALP+dALP coexist MAG 组装上下文审计

## 冻结范围与门槛

- 唯一序列宇宙：冻结的 6,769 条已鉴定 actin 序列，不新增 HMM/tblastn 搜索。
- 全量 coexist 定义：同一 MAG 至少含 1 条 cALP 和 1 条 dALP。
- strict-clean 拷贝定义：`partial=00`、距 contig edge 至少 5 kb、局部20-kb TNF与MAG背景 cosine至少0.95。
- 不使用不可得的 BAM/FASTQ，不推断 read-depth parity、strain separation 或 read-pair linkage。

## 全量结果

- 共识别 **{len(mag_rows)} 个 coexist MAG、{total_copies} 条 cALP/dALP profile拷贝**；{mapped_copies}/{total_copies} 条均找到组装上下文。
- **{strict_copies}/{total_copies}** 条拷贝通过 strict-clean。
- **{clean_pair_mags}/{len(mag_rows)}** 个 MAG 至少各有 1 条 strict-clean cALP 与 dALP，可直接支持同MAG clean coexist。
- **{all_clean_mags}/{len(mag_rows)}** 个 MAG 的全部 cALP/dALP 拷贝均 strict-clean，是最强证据层。
- clean-pair 证据不限于 Sigynarchaeales：非Sigyn为 **{non_sigyn_pair}** 个；all-copy-clean 非Sigyn为 **{non_sigyn_all}** 个。
- HQ：{quality_counts[("HQ", "clean_pair")]}/{quality_counts[("HQ", "total")]} clean-pair，{quality_counts[("HQ", "all_copy_clean")]}/{quality_counts[("HQ", "total")]} all-copy-clean。
- MQ：{quality_counts[("MQ", "clean_pair")]}/{quality_counts[("MQ", "total")]} clean-pair，{quality_counts[("MQ", "all_copy_clean")]}/{quality_counts[("MQ", "total")]} all-copy-clean。

## 未通过原因（允许重叠）

- {len(failure_mag_sets["contig_edge_lt5kb"])} 个 MAG 至少有一条拷贝距 contig edge不足5 kb；涉及 {failure_copy_counts["contig_edge_lt5kb"]} 条拷贝。
- {len(failure_mag_sets["partial_gene"])} 个 MAG 至少有一条 partial gene；涉及 {failure_copy_counts["partial_gene"]} 条拷贝。
- {len(failure_mag_sets["local_TNF_lt0.95"])} 个 MAG 至少有一条局部TNF低于0.95；涉及 {failure_copy_counts["local_TNF_lt0.95"]} 条拷贝。

未通过 strict-clean 只表示在现有组装信息下不能完成最严格排除，**不得改写为组装错误或污染阳性**。

## 对 retention 结论的意义

全量审计把此前584树内117个MAG的定向结果扩展到冻结全集342个coexist MAG。至少 {clean_pair_mags} 个MAG在两种profile中均存在非partial、非边缘、组成一致的拷贝，且跨多个order，因此“coexist普遍由简单拼接、截断或单一谱系污染产生”不是可行的总体解释。该证据排除的是简单组装替代解释，不单独证明 duplication方向、HGT次数或功能分化。

## 可视化

- `figures/full_6769_coexist_assembly_audit/fig_full_coexist_MAG_strict_copy_fraction_by_quality.pdf`
- `figures/full_6769_coexist_assembly_audit/fig_full_coexist_MAG_clean_evidence_by_order.pdf`
- 两图均由本任务R脚本独立输出PDF和PNG；未生成SVG或TIFF。
"""
report_path = WORK / "FULL_6769_COEXIST_MAG_ASSEMBLY_AUDIT_CN_20260808.md"
report_path.write_text(report, encoding="utf-8", newline="\n")

figure_dir = BASE / "figures" / "full_6769_coexist_assembly_audit"
formal_assets = [
    BASE / "code" / "audit_full_6769_coexist_MAG_assembly_context_20260808.py",
    BASE / "code" / "plot_full_6769_coexist_MAG_assembly_audit_20260808.R",
    mag_out,
    copy_out,
    summary_out,
    RESULTS / "full_6769_coexist_assembly_summary_20260808.json",
    order_out,
    quality_out,
    manifest_out,
    DATA / "fig_full_coexist_MAG_strict_copy_fraction_source_data.tsv",
    DATA / "fig_full_coexist_MAG_clean_evidence_by_order_source_data.tsv",
    figure_dir / "fig_full_coexist_MAG_strict_copy_fraction_by_quality.pdf",
    figure_dir / "fig_full_coexist_MAG_strict_copy_fraction_by_quality.png",
    figure_dir / "fig_full_coexist_MAG_clean_evidence_by_order.pdf",
    figure_dir / "fig_full_coexist_MAG_clean_evidence_by_order.png",
    report_path,
    WORK / "FULL_6769_COEXIST_MAG_ASSEMBLY_FIGURE_QA_20260808.tsv",
]
missing_assets = [str(path) for path in formal_assets if not path.is_file() or path.stat().st_size == 0]
if missing_assets:
    raise SystemExit(f"Formal assets missing or empty: {missing_assets}")
output_manifest = []
for path in formal_assets:
    row_count = "NA"
    if path.suffix.lower() in {".tsv", ".md", ".r", ".py"}:
        with path.open(encoding="utf-8-sig", errors="replace") as handle:
            row_count = sum(1 for _ in handle)
    output_manifest.append({
        "relative_path": path.relative_to(BASE).as_posix(),
        "bytes": path.stat().st_size,
        "rows_or_lines": row_count,
        "sha256": sha256(path),
    })
write_tsv(RESULTS / "full_6769_coexist_assembly_output_manifest_20260808.tsv", output_manifest)
(RESULTS / "FULL_6769_COEXIST_MAG_ASSEMBLY_AUDIT_COMPLETE.marker").write_text(
    "status=complete\n"
    "frozen_sequences=6769\n"
    f"coexist_MAGs={len(mag_rows)}\n"
    f"profile_copies={total_copies}\n"
    f"clean_pair_MAGs={clean_pair_mags}\n"
    f"all_copy_clean_MAGs={all_clean_mags}\n"
    "figures_pdf=2\nfigures_png=2\n",
    encoding="utf-8",
    newline="\n",
)

print(json.dumps(summary_json, ensure_ascii=False))
