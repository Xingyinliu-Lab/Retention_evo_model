#!/usr/bin/env python3
"""cALP/dALP profile-state retention audit using the frozen 584 gappyout set.

CL1/CL2 topology labels are deliberately not used to define states.
"""

from __future__ import annotations

import copy
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict, deque
from pathlib import Path

import numpy as np
from Bio import Phylo
from Bio.Phylo.BaseTree import Clade, Tree
from scipy.linalg import expm
from scipy.optimize import minimize
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.stats import kruskal, mannwhitneyu, spearmanr, wilcoxon


WORK = Path(r"..")
DATA = WORK / "data"
RESULTS = WORK / "results"
EVID = Path(r"..")
EXEMPLAR = Path(r"..")
ASGARD = Path(r"..")
ARCH1338 = Path(r"..")

META = EVID / "inputs/frozen_authoritative_6769/seq_meta_with_aa_seq.tsv"
RAW584 = EVID / "results/cALP_dALP_584_806_tree_inputs_20260807/cALP_dALP_named_species_plus16euk_584.raw.fasta"
GENE584 = EVID / "results/cALP_dALP_584_806_tree_inputs_20260807/remote_trees/584.gappyout.treefile"

TREE_SPECS = {
    "asgard971_addcore": {
        "path": EXEMPLAR / "inputs/species_trees/asgard971_orthofinder_species_tree_rooted.txt",
        "root_semantics": "method_rooted",
        "directional": True,
    },
    "asgard971_astral89": {
        "path": ASGARD / "astral_pro_third_species_tree_20260730/asgard971_89_formal_astral_pro3.tree",
        "root_semantics": "unrooted",
        "directional": False,
    },
    "archaea1338_addcore": {
        "path": EXEMPLAR / "inputs/species_trees/archaea1338/archaea1338_orthofinder_species_tree_rooted.txt",
        "root_semantics": "method_rooted",
        "directional": True,
    },
    "archaea1338_denovo": {
        "path": EXEMPLAR / "inputs/species_trees/archaea1338/archaea1338_denovo_species_tree_unrooted.txt",
        "root_semantics": "unrooted",
        "directional": False,
    },
    "archaea1338_astral64": {
        "path": ARCH1338 / "astral_pro_third_species_tree_20260805/archaea1338_64_formal_astral_pro3.tree",
        "root_semantics": "unrooted",
        "directional": False,
    },
    "gtdb_r226_expanded": {
        "path": Path(r".."),
        "root_semantics": "operational_gtdb_root_projection",
        "directional": True,
    },
}

PROFILE_MAP = {
    "canonical Actin-like": "cALP",
    "Crenactin-like / archaeal actin": "dALP",
}
STATE_LEVELS = ("dALP-only", "coexist", "cALP-only")
STATE_CODE = {x: i for i, x in enumerate(STATE_LEVELS)}
RNG = np.random.default_rng(20260808)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_tsv(path: Path, rows: list[dict[str, object]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        if not rows:
            raise ValueError(f"No rows for {path}")
        fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def norm_tip(name: str) -> str:
    if name.startswith(("GB_", "RS_")):
        return name.split("_", 1)[1]
    return name


def fasta_ids(path: Path) -> set[str]:
    ids = set()
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.startswith(">"):
                ids.add(line[1:].split()[0])
    return ids


def load_profile_states():
    selected = fasta_ids(RAW584)
    seq_rows: dict[str, dict[str, str]] = {}
    all_profile_counts: dict[str, Counter] = defaultdict(Counter)
    with META.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            profile = PROFILE_MAP.get(row["actin_family_class"])
            if profile:
                all_profile_counts[row["mag_id"]][profile] += 1
            if profile and row["seq"] in selected:
                row = dict(row)
                row["profile"] = profile
                seq_rows[row["seq"]] = row
    if len(seq_rows) != 568:
        raise ValueError(f"Expected 568 selected archaeal cALP/dALP sequences, got {len(seq_rows)}")

    by_mag: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in seq_rows.values():
        by_mag[row["mag_id"]].append(row)
    mag_rows = []
    selected_state_by_mag = {}
    full_state_by_mag = {}
    tax_by_mag = {}
    for mag, rows in sorted(by_mag.items()):
        n_c = sum(x["profile"] == "cALP" for x in rows)
        n_d = sum(x["profile"] == "dALP" for x in rows)
        selected_state = "coexist" if n_c and n_d else "cALP-only" if n_c else "dALP-only"
        full_c = all_profile_counts[mag]["cALP"]
        full_d = all_profile_counts[mag]["dALP"]
        full_state = "coexist" if full_c and full_d else "cALP-only" if full_c else "dALP-only"
        selected_state_by_mag[mag] = selected_state
        full_state_by_mag[mag] = full_state
        tax_by_mag[mag] = rows[0]
        mag_rows.append({
            "mag_id": mag,
            "state": full_state,
            "selected_584_state": selected_state,
            "n_cALP": n_c,
            "n_dALP": n_d,
            "dALP_fraction": n_d / (n_c + n_d),
            "all_frozen_n_cALP": full_c,
            "all_frozen_n_dALP": full_d,
            "dALP_fraction_all_frozen": full_d / sum(all_profile_counts[mag].values()),
            "phylum": rows[0]["p"],
            "class": rows[0]["c"],
            "order": rows[0]["o"],
            "quality_checkm2": rows[0]["quality_checkm2"],
            "sequence_ids": ";".join(sorted(x["seq"] for x in rows)),
        })
    if len(mag_rows) != 461:
        raise ValueError(f"Expected 461 MAGs, got {len(mag_rows)}")
    seq_out = [{
        "seq": seq,
        "mag_id": row["mag_id"],
        "profile": row["profile"],
        "phylum": row["p"],
        "class": row["c"],
        "order": row["o"],
        "quality_checkm2": row["quality_checkm2"],
    } for seq, row in sorted(seq_rows.items())]
    write_tsv(DATA / "frozen_584_sequence_profiles.tsv", seq_out)
    write_tsv(DATA / "frozen_584_MAG_profile_states.tsv", mag_rows)
    return seq_rows, selected_state_by_mag, full_state_by_mag, tax_by_mag, {x["mag_id"]: x for x in mag_rows}


def restrict_tree(source: Tree, state_by_mag: dict[str, str]) -> Tree:
    """Restrict a species tree to mapped MAGs while preserving path lengths."""
    keep = set(state_by_mag)

    def visit(clade: Clade, is_root: bool = False) -> Clade | None:
        if clade.is_terminal():
            mag = norm_tip(clade.name or "")
            if mag not in keep:
                return None
            return Clade(branch_length=clade.branch_length, name=mag)
        children = [x for child in clade.clades if (x := visit(child)) is not None]
        if not children:
            return None
        if len(children) == 1 and not is_root:
            child = children[0]
            child.branch_length = float(child.branch_length or 0) + float(clade.branch_length or 0)
            return child
        return Clade(branch_length=clade.branch_length, name=clade.name, confidence=clade.confidence, clades=children)

    root = visit(source.root, is_root=True)
    if root is None:
        raise ValueError("No mapped tips in tree")
    while len(root.clades) == 1 and not root.is_terminal():
        root = root.clades[0]
        root.branch_length = None
    tree = Tree(root=root, rooted=source.rooted)
    names = [x.name for x in tree.get_terminals()]
    if len(names) != len(set(names)):
        raise ValueError("Duplicate normalized MAG tips after restriction")
    return tree


def nested_topology(tree: Tree):
    def visit(clade: Clade):
        if clade.is_terminal():
            return clade.name
        return [visit(x) for x in clade.clades]
    return visit(tree.root)


def split_set(tree: Tree) -> set[frozenset[str]]:
    universe = {x.name for x in tree.get_terminals()}
    result = set()
    for clade in tree.find_clades(order="postorder"):
        side = {x.name for x in clade.get_terminals()}
        other = universe - side
        if len(side) < 2 or len(other) < 2:
            continue
        canonical = side if (len(side), sorted(side)) <= (len(other), sorted(other)) else other
        result.add(frozenset(canonical))
    return result


def sankoff(topology, states: dict[str, int], cost: list[list[int]], root_state: int | None = None) -> int:
    big = 10**7
    def visit(node):
        if isinstance(node, str):
            observed = states[node]
            return [0 if i == observed else big for i in range(3)]
        children = [visit(x) for x in node]
        return [sum(min(dp[j] + cost[i][j] for j in range(3)) for dp in children) for i in range(3)]
    root = visit(topology)
    return int(root[root_state] if root_state is not None else min(root))


def graph_nearest_sets(topology):
    graph: dict[int, set[int]] = defaultdict(set)
    labels: dict[int, str] = {}
    next_id = 0
    def build(node, parent=None):
        nonlocal next_id
        here = next_id
        next_id += 1
        if isinstance(node, str):
            labels[here] = node
        else:
            for child in node:
                cid = build(child, here)
                graph[here].add(cid)
                graph[cid].add(here)
        return here
    build(topology)
    nearest = {}
    for start, label in labels.items():
        seen = {start}
        queue = deque([(start, 0)])
        found, found_dist = [], None
        while queue:
            node, dist = queue.popleft()
            if found_dist is not None and dist > found_dist:
                break
            if node != start and node in labels:
                found.append(labels[node])
                found_dist = dist
                continue
            for nxt in graph[node] - seen:
                seen.add(nxt)
                queue.append((nxt, dist + 1))
        nearest[label] = found
    return nearest


def nearest_agreement(nearest: dict[str, list[str]], states: dict[str, int]) -> float:
    return sum(any(states[x] == states[t] for x in near) for t, near in nearest.items()) / len(nearest)


def fit_ctmc(tree: Tree, tip_states: dict[str, int], scale: str, name: str, root_mode, transitions):
    nodes = list(tree.find_clades(order="postorder"))
    idx = {id(n): i for i, n in enumerate(nodes)}
    children = []
    for node in nodes:
        row = []
        for child in node.clades:
            bl = 1.0 if scale == "unit_topology" else max(float(child.branch_length or 0), 1e-8)
            row.append((idx[id(child)], bl))
        children.append(row)
    names = [n.name if n.is_terminal() else None for n in nodes]

    def stationary(q):
        vals, vecs = np.linalg.eig(q.T)
        v = np.real(vecs[:, np.argmin(np.abs(vals))])
        v = np.abs(v)
        return v / v.sum() if v.sum() > 0 else np.repeat(1 / 3, 3)

    def objective(log_rates):
        q = np.zeros((3, 3))
        for value, (a, b) in zip(np.exp(log_rates), transitions):
            q[a, b] = value
        np.fill_diagonal(q, -q.sum(axis=1))
        cache = {}
        likelihoods = [np.ones(3) for _ in nodes]
        log_scale = 0.0
        for i, node in enumerate(nodes):
            if node.is_terminal():
                v = np.zeros(3)
                v[tip_states[names[i]]] = 1.0
                likelihoods[i] = v
                continue
            v = np.ones(3)
            for child_i, bl in children[i]:
                key = round(bl, 12)
                if key not in cache:
                    cache[key] = expm(q * bl)
                v *= cache[key] @ likelihoods[child_i]
            total = v.sum()
            if not np.isfinite(total) or total <= 0:
                return 1e100
            likelihoods[i] = v / total
            log_scale += math.log(total)
        if root_mode == "stationary":
            root_prior = stationary(q)
            root_like = float(np.dot(root_prior, likelihoods[-1]))
        else:
            root_like = float(likelihoods[-1][int(root_mode)])
        if root_like <= 0 or not np.isfinite(root_like):
            return 1e100
        return -(math.log(root_like) + log_scale)

    best = None
    for start in (np.zeros(len(transitions)), np.full(len(transitions), -1.0)):
        fit = minimize(objective, start, method="L-BFGS-B", bounds=[(-10, 10)] * len(transitions), options={"maxiter": 300, "ftol": 1e-10})
        if best is None or fit.fun < best.fun:
            best = fit
    return {
        "model": name,
        "root_mode": STATE_LEVELS[root_mode] if isinstance(root_mode, int) else root_mode,
        "branch_scale": scale,
        "k": len(transitions),
        "log_likelihood": -float(best.fun),
        "AIC": 2 * len(transitions) + 2 * float(best.fun),
        "success": str(bool(best.success)).upper(),
        "rates": ";".join(f"{STATE_LEVELS[a]}->{STATE_LEVELS[b]}:{math.exp(x):.8g}" for x, (a, b) in zip(best.x, transitions)),
    }


def retention_models(tree: Tree, states: dict[str, int], tree_name: str):
    adjacent = ((0, 1), (1, 0), (1, 2), (2, 1))
    all_rates = tuple((a, b) for a in range(3) for b in range(3) if a != b)
    rows = []
    for scale in ("unit_topology", "source_branch_lengths"):
        endpoint_d = fit_ctmc(tree, states, scale, "endpoint_d", 0, adjacent)
        endpoint_c = fit_ctmc(tree, states, scale, "endpoint_c", 2, adjacent)
        endpoint = min((endpoint_d, endpoint_c), key=lambda x: x["AIC"])
        endpoint["model"] = "retention_sequential_endpoint_root_best"
        endpoint["root_mode"] = "either_single_state;best=" + endpoint["root_mode"]
        current = [
            endpoint,
            fit_ctmc(tree, states, scale, "retention_adjacent_reversible", "stationary", adjacent),
            fit_ctmc(tree, states, scale, "divergent_from_ancestral_coexist_strict", 1, ((1, 0), (1, 2))),
            fit_ctmc(tree, states, scale, "ARD_unrestricted", "stationary", all_rates),
        ]
        min_aic = min(x["AIC"] for x in current)
        for row in current:
            row["tree"] = tree_name
            row["delta_AIC"] = row["AIC"] - min_aic
            rows.append(row)
    return rows


def species_tree_audit(state_by_mag, tax_by_mag, mag_rows):
    inventory, topo_rows, depth_rows, depth_summary, pairwise_rows = [], [], [], [], []
    model_rows, lineage_rows, loo_rows = [], [], []
    state_counts_by_tree = {}
    restricted_trees = {}
    for tree_name, spec in TREE_SPECS.items():
        path = spec["path"]
        source = Phylo.read(str(path), "newick")
        restricted = restrict_tree(source, state_by_mag)
        restricted_trees[tree_name] = restricted
        tips = [x.name for x in restricted.get_terminals()]
        states_txt = {tip: state_by_mag[tip] for tip in tips}
        states = {tip: STATE_CODE[states_txt[tip]] for tip in tips}
        counts = Counter(states_txt.values())
        state_counts_by_tree[tree_name] = counts
        topology = nested_topology(restricted)
        splits = split_set(restricted)
        nearest = graph_nearest_sets(topology)
        nearest_obs = nearest_agreement(nearest, states)
        unordered = [[0 if i == j else 1 for j in range(3)] for i in range(3)]
        ordered = [[abs(i - j) for j in range(3)] for i in range(3)]
        obs_unordered = sankoff(topology, states, unordered)
        obs_ordered = sankoff(topology, states, ordered)
        labels = list(states)
        values = np.array([states[x] for x in labels])
        perm_unordered, perm_nearest = [], []
        for _ in range(1000):
            shuffled = RNG.permutation(values)
            perm = dict(zip(labels, shuffled.tolist()))
            perm_unordered.append(sankoff(topology, perm, unordered))
            perm_nearest.append(nearest_agreement(nearest, perm))
        mono = {}
        universe = set(tips)
        for state in STATE_LEVELS:
            selected = {x for x in tips if states_txt[x] == state}
            mono[state] = len(selected) <= 1 or frozenset(selected) in splits or frozenset(universe - selected) in splits

        inventory.append({
            "tree": tree_name,
            "source_path": str(path),
            "source_sha256": sha256(path),
            "source_tips": len(source.get_terminals()),
            "mapped_584_MAGs": len(tips),
            "root_children_source": len(source.root.clades),
            "root_children_restricted": len(restricted.root.clades),
            "root_semantics": spec["root_semantics"],
            "directional_models_run": str(spec["directional"]).upper(),
        })
        topo_rows.append({
            "tree": tree_name,
            "mapped_MAGs": len(tips),
            "n_dALP_only": counts["dALP-only"],
            "n_coexist": counts["coexist"],
            "n_cALP_only": counts["cALP-only"],
            "coexist_orders": len({tax_by_mag[x]["o"] for x in tips if states_txt[x] == "coexist"}),
            "coexist_classes": len({tax_by_mag[x]["c"] for x in tips if states_txt[x] == "coexist"}),
            "unordered_min_changes": obs_unordered,
            "ordered_min_step_score": obs_ordered,
            "unordered_permutation_p_low": (1 + sum(x <= obs_unordered for x in perm_unordered)) / 1001,
            "nearest_same_state_fraction": nearest_obs,
            "nearest_permutation_p_high": (1 + sum(x >= nearest_obs for x in perm_nearest)) / 1001,
            "dALP_only_unrooted_monophyletic": str(mono["dALP-only"]).upper(),
            "coexist_unrooted_monophyletic": str(mono["coexist"]).upper(),
            "cALP_only_unrooted_monophyletic": str(mono["cALP-only"]).upper(),
        })

        for order in sorted({tax_by_mag[x]["o"] for x in tips}):
            members = [x for x in tips if tax_by_mag[x]["o"] == order]
            cc = Counter(states_txt[x] for x in members)
            lineage_rows.append({
                "tree": tree_name,
                "order": order,
                "n_MAGs": len(members),
                "n_dALP_only": cc["dALP-only"],
                "n_coexist": cc["coexist"],
                "n_cALP_only": cc["cALP-only"],
            })

        if spec["directional"]:
            source_depths = source.depths(unit_branch_lengths=True)
            max_depth = max(source_depths.values())
            source_tip_by_norm = {norm_tip(x.name): x for x in source.get_terminals()}
            tree_depth_records = []
            for tip in restricted.get_terminals():
                row = mag_rows[tip.name]
                source_tip = source_tip_by_norm[tip.name]
                rec = {
                    "tree": tree_name,
                    "mag_id": tip.name,
                    "state": row["state"],
                    "root_topological_depth": source_depths[source_tip],
                    "root_normalized_depth": source_depths[source_tip] / max_depth,
                    "dALP_fraction": row["dALP_fraction_all_frozen"],
                    "phylum": row["phylum"],
                    "class": row["class"],
                    "order": row["order"],
                }
                depth_rows.append(rec)
                tree_depth_records.append(rec)
            groups = {s: [x["root_normalized_depth"] for x in tree_depth_records if x["state"] == s] for s in STATE_LEVELS}
            kw = kruskal(*(groups[s] for s in STATE_LEVELS))
            for state in STATE_LEVELS:
                vals = groups[state]
                depth_summary.append({
                    "tree": tree_name,
                    "state": state,
                    "n": len(vals),
                    "mean_root_normalized_depth": float(np.mean(vals)),
                    "median_root_normalized_depth": float(np.median(vals)),
                    "kruskal_H_all_states": float(kw.statistic),
                    "kruskal_p_all_states": float(kw.pvalue),
                })
            for a, b in (("dALP-only", "coexist"), ("dALP-only", "cALP-only"), ("coexist", "cALP-only")):
                test = mannwhitneyu(groups[a], groups[b], alternative="two-sided")
                pairwise_rows.append({
                    "tree": tree_name,
                    "group_a": a,
                    "group_b": b,
                    "n_a": len(groups[a]),
                    "n_b": len(groups[b]),
                    "median_a": float(np.median(groups[a])),
                    "median_b": float(np.median(groups[b])),
                    "median_b_minus_a": float(np.median(groups[b]) - np.median(groups[a])),
                    "U": float(test.statistic),
                    "p": float(test.pvalue),
                })
            fractions = [x["dALP_fraction"] for x in tree_depth_records]
            dd = [x["root_normalized_depth"] for x in tree_depth_records]
            rho = spearmanr(fractions, dd)
            pairwise_rows.append({
                "tree": tree_name,
                "group_a": "continuous_dALP_fraction",
                "group_b": "root_normalized_depth",
                "n_a": len(dd), "n_b": len(dd), "median_a": "NA", "median_b": "NA", "median_b_minus_a": "NA",
                "U": float(rho.statistic), "p": float(rho.pvalue),
            })
            centered = []
            for order in sorted({x["order"] for x in tree_depth_records}):
                rr = [x for x in tree_depth_records if x["order"] == order]
                med = float(np.median([x["root_normalized_depth"] for x in rr]))
                centered.extend([(x["state"], x["root_normalized_depth"] - med) for x in rr])
            da = [x for s, x in centered if s == "dALP-only"]
            ca = [x for s, x in centered if s == "cALP-only"]
            if da and ca:
                test = mannwhitneyu(da, ca, alternative="two-sided")
                pairwise_rows.append({
                    "tree": tree_name, "group_a": "order_centered_dALP-only", "group_b": "order_centered_cALP-only",
                    "n_a": len(da), "n_b": len(ca), "median_a": float(np.median(da)), "median_b": float(np.median(ca)),
                    "median_b_minus_a": float(np.median(ca) - np.median(da)), "U": float(test.statistic), "p": float(test.pvalue),
                })
            orders = Counter(x["order"] for x in tree_depth_records)
            for order, n_order in sorted(orders.items()):
                if n_order < 5:
                    continue
                kept = [x for x in tree_depth_records if x["order"] != order]
                da = [x["root_normalized_depth"] for x in kept if x["state"] == "dALP-only"]
                ca = [x["root_normalized_depth"] for x in kept if x["state"] == "cALP-only"]
                if not da or not ca:
                    continue
                test = mannwhitneyu(da, ca, alternative="two-sided")
                loo_rows.append({
                    "tree": tree_name,
                    "left_out_order": order,
                    "left_out_n": n_order,
                    "remaining_n_dALP_only": len(da),
                    "remaining_n_cALP_only": len(ca),
                    "median_cALP_minus_dALP": float(np.median(ca) - np.median(da)),
                    "p": float(test.pvalue),
                    "dALP_still_shallower": str(np.median(da) < np.median(ca)).upper(),
                })
            model_rows.extend(retention_models(restricted, states, tree_name))

    write_tsv(RESULTS / "species_tree_inventory.tsv", inventory)
    write_tsv(RESULTS / "species_tree_profile_state_topology.tsv", topo_rows)
    write_tsv(RESULTS / "root_depth_MAG_states.tsv", depth_rows)
    write_tsv(RESULTS / "root_depth_state_summary.tsv", depth_summary)
    write_tsv(RESULTS / "root_depth_tests.tsv", pairwise_rows)
    write_tsv(RESULTS / "directional_model_comparison.tsv", model_rows)
    write_tsv(RESULTS / "lineage_order_state_counts.tsv", lineage_rows)
    write_tsv(RESULTS / "leave_one_order_out_depth.tsv", loo_rows)
    return restricted_trees, topo_rows, depth_summary, pairwise_rows, model_rows, loo_rows


def gene_tree_audit(seq_rows, state_by_mag, tax_by_mag):
    source = Phylo.read(str(GENE584), "newick")
    selected = set(seq_rows)
    present = {x.name for x in source.get_terminals()} & selected
    if len(present) != 568:
        raise ValueError(f"584 gene tree has {len(present)}/568 archaeal selected tips")
    tree = copy.deepcopy(source)
    for tip in list(tree.get_terminals()):
        if tip.name not in selected:
            tree.prune(tip)
    universe = {x.name for x in tree.get_terminals()}
    all_nodes = list(tree.find_clades(order="preorder"))
    node_index = {id(node): i for i, node in enumerate(all_nodes)}
    edge_i, edge_j, edge_w = [], [], []
    for parent in all_nodes:
        for child in parent.clades:
            a, b = node_index[id(parent)], node_index[id(child)]
            weight = max(float(child.branch_length or 0), 1e-12)
            edge_i.extend((a, b)); edge_j.extend((b, a)); edge_w.extend((weight, weight))
    graph = csr_matrix((edge_w, (edge_i, edge_j)), shape=(len(all_nodes), len(all_nodes)))
    terminals = list(tree.get_terminals())
    tip_names = [x.name for x in terminals]
    tip_row = {name: i for i, name in enumerate(tip_names)}
    tip_node_indices = [node_index[id(x)] for x in terminals]
    distance_matrix = dijkstra(graph, directed=False, indices=tip_node_indices)[:, tip_node_indices]

    def tip_distance(a: str, b: str) -> float:
        return float(distance_matrix[tip_row[a], tip_row[b]])

    splits = split_set(tree)
    profile_sets = {p: {s for s in universe if seq_rows[s]["profile"] == p} for p in ("dALP", "cALP")}
    architecture = []
    for profile, tips in profile_sets.items():
        architecture.append({
            "profile": profile,
            "n_tips": len(tips),
            "unrooted_monophyletic": str(frozenset(tips) in splits or frozenset(universe - tips) in splits).upper(),
        })

    by_mag = defaultdict(list)
    for seq in universe:
        by_mag[seq_rows[seq]["mag_id"]].append(seq)
    coexist = [m for m in by_mag if state_by_mag[m] == "coexist"]
    pair_rows = []
    for mag in sorted(coexist):
        tips = sorted(by_mag[mag])
        c = [x for x in tips if seq_rows[x]["profile"] == "cALP"]
        d = [x for x in tips if seq_rows[x]["profile"] == "dALP"]
        mrca = tree.common_ancestor(tips)
        descendants = {x.name for x in mrca.get_terminals()}
        exclusive = descendants == set(tips)
        exact_cherry = len(tips) == 2 and exclusive and len(mrca.clades) == 2 and all(x.is_terminal() for x in mrca.clades)
        within = min(tip_distance(x, y) for x in c for y in d)
        order = tax_by_mag[mag]["o"]
        other_c = [x for x in universe if seq_rows[x]["profile"] == "cALP" and seq_rows[x]["mag_id"] != mag and seq_rows[x]["o"] == order]
        other_d = [x for x in universe if seq_rows[x]["profile"] == "dALP" and seq_rows[x]["mag_id"] != mag and seq_rows[x]["o"] == order]
        background = [tip_distance(x, y) for x in d for y in other_c] + [tip_distance(x, y) for x in c for y in other_d]
        bg_median = float(np.median(background)) if background else math.nan
        pair_rows.append({
            "mag_id": mag,
            "order": order,
            "n_cALP": len(c),
            "n_dALP": len(d),
            "same_MAG_tips_exclusive_clade": str(exclusive).upper(),
            "exact_terminal_cherry": str(exact_cherry).upper(),
            "within_MAG_min_cALP_dALP_distance": within,
            "same_order_between_MAG_median_distance": bg_median,
            "within_minus_between_median": within - bg_median if np.isfinite(bg_median) else "NA",
            "cALP_sequences": ";".join(c),
            "dALP_sequences": ";".join(d),
        })
    write_tsv(RESULTS / "gene_tree_584_profile_architecture.tsv", architecture)
    write_tsv(RESULTS / "gene_tree_584_coexist_MAG_pairs.tsv", pair_rows)
    valid = [x for x in pair_rows if isinstance(x["within_minus_between_median"], float) and np.isfinite(x["within_minus_between_median"])]
    deltas = [x["within_minus_between_median"] for x in valid]
    if deltas:
        test = wilcoxon(deltas, alternative="two-sided")
        summary = {
            "gene_tree_total_tips": len(source.get_terminals()),
            "archaeal_profile_tips": len(universe),
            "coexist_MAGs": len(coexist),
            "same_MAG_exclusive_clade_MAGs": sum(x["same_MAG_tips_exclusive_clade"] == "TRUE" for x in pair_rows),
            "exact_terminal_cherry_MAGs": sum(x["exact_terminal_cherry"] == "TRUE" for x in pair_rows),
            "distance_comparable_MAGs": len(valid),
            "median_within_minus_between": float(np.median(deltas)),
            "paired_wilcoxon_statistic": float(test.statistic),
            "paired_wilcoxon_p": float(test.pvalue),
        }
    else:
        summary = {"coexist_MAGs": len(coexist), "distance_comparable_MAGs": 0}
    (RESULTS / "gene_tree_584_coexist_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return architecture, pair_rows, summary


def main():
    for directory in (WORK, DATA, RESULTS, WORK / "work_records", WORK / "figures"):
        directory.mkdir(parents=True, exist_ok=True)
    required = [META, RAW584, GENE584] + [x["path"] for x in TREE_SPECS.values()]
    for path in required:
        if not path.is_file() or path.stat().st_size == 0:
            raise FileNotFoundError(path)
    seq_rows, selected_state_by_mag, full_state_by_mag, tax_by_mag, mag_rows = load_profile_states()
    gene_arch, pair_rows, gene_summary = gene_tree_audit(seq_rows, selected_state_by_mag, tax_by_mag)
    restricted, topo, depths, tests, models, loo = species_tree_audit(full_state_by_mag, tax_by_mag, mag_rows)
    audit = {
        "frozen_584_archaeal_sequences": len(seq_rows),
        "frozen_584_MAGs": len(full_state_by_mag),
        "selected_584_state_counts": dict(Counter(selected_state_by_mag.values())),
        "full_frozen_6769_state_counts_for_584_MAGs": dict(Counter(full_state_by_mag.values())),
        "state_discrepancy_MAGs": sum(selected_state_by_mag[m] != full_state_by_mag[m] for m in full_state_by_mag),
        "gene_tree_summary": gene_summary,
        "species_trees": [x["tree"] for x in topo],
        "input_sha256": {str(path): sha256(path) for path in required},
    }
    (RESULTS / "AUDIT_SUMMARY.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (WORK / "PROFILE_RETENTION_FOUR_TREE_AUDIT_COMPLETE.marker").write_text("status=complete\nstate_definition=cALP_dALP_profile\n", encoding="utf-8")
    print(json.dumps({"status": "complete", "states": audit["full_frozen_6769_state_counts_for_584_MAGs"], "trees": len(topo)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
