#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(ggsignif)
})

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) sub("^--file=", "", file_arg[1]) else "plot_dalp_depth_boxplot_20260808.R"
audit_dir <- normalizePath(dirname(script_path), winslash = "/", mustWork = FALSE)
input <- file.path(audit_dir, "tip_depth_state.tsv")
out_dir <- file.path(audit_dir, "figures")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

dat <- read.delim(input, stringsAsFactors = FALSE, check.names = FALSE)
stopifnot(all(c("state", "depth_norm") %in% names(dat)))
dat$state <- factor(dat$state, levels = c("dALP-only", "coexist", "cALP-only"))
dat <- dat[!is.na(dat$state) & is.finite(dat$depth_norm), , drop = FALSE]

pairs <- list(c("dALP-only", "coexist"), c("dALP-only", "cALP-only"), c("coexist", "cALP-only"))
labels <- c("p = 1.17 × 10⁻²⁶", "p = 1.58 × 10⁻⁷", "p = 1.37 × 10⁻⁶")
ypos <- c(1.08, 1.20, 1.34)

p <- ggplot(dat, aes(x = state, y = depth_norm, fill = state)) +
  geom_boxplot(width = 0.62, linewidth = 0.35, outlier.shape = NA, colour = "black") +
  geom_jitter(width = 0.13, height = 0, size = 0.75, alpha = 0.28, colour = "#303030") +
  geom_signif(comparisons = pairs, annotations = labels, y_position = ypos,
              tip_length = 0.012, textsize = 3.0, vjust = 0.15,
              size = 0.32, colour = "black") +
  scale_fill_manual(values = c("dALP-only" = "#4C78A8", "coexist" = "#F2A541", "cALP-only" = "#D95F59")) +
  scale_y_continuous(limits = c(0, 1.48), breaks = seq(0, 1, 0.2), expand = c(0, 0)) +
  labs(x = NULL, y = "GTDB r226 root-normalized depth",
       title = "dALP-enriched MAG states occupy shallower GTDB-projected regions") +
  theme_classic(base_size = 10, base_family = "Arial") +
  theme(legend.position = "none", plot.title = element_text(face = "bold", size = 11),
        axis.title = element_text(size = 9.5), axis.text = element_text(size = 9),
        axis.line = element_line(linewidth = 0.4), axis.ticks = element_line(linewidth = 0.4),
        plot.margin = margin(8, 10, 8, 8, "pt"))

ggsave(file.path(out_dir, "fig_dalp_calp_depth.pdf"), p,
       width = 170, height = 125, units = "mm", device = cairo_pdf)
ggsave(file.path(out_dir, "fig_dalp_calp_depth.png"), p,
       width = 170, height = 125, units = "mm", dpi = 600)
write.table(data.frame(n_MAG = nrow(dat),
                       dALP_only_median = median(dat$depth_norm[dat$state == "dALP-only"]),
                       coexist_median = median(dat$depth_norm[dat$state == "coexist"]),
                       cALP_only_median = median(dat$depth_norm[dat$state == "cALP-only"])),
            file.path(out_dir, "fig_dalp_calp_depth_summary.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
