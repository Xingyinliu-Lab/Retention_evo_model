suppressPackageStartupMessages(library(ggplot2))

base_dir <- ".."
mag_path <- file.path(base_dir, "results", "full_6769_coexist_MAG_assembly_context_20260808.tsv")
order_path <- file.path(base_dir, "data", "full_6769_coexist_assembly_audit", "full_6769_coexist_assembly_by_order_20260808.tsv")
figure_dir <- file.path(base_dir, "figures", "full_6769_coexist_assembly_audit")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

mag <- read.delim(mag_path, check.names = FALSE, stringsAsFactors = FALSE)
ord <- read.delim(order_path, check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(mag) == 342L, sum(mag$n_profile_copies) == 1175L)

mag$quality_checkm2 <- factor(mag$quality_checkm2, levels = c("HQ", "MQ"))
mag$evidence_tier <- factor(
  mag$evidence_tier,
  levels = c(
    "NO_STRICT_COPY",
    "STRICT_COPY_IN_ONE_PROFILE_ONLY",
    "AT_LEAST_ONE_STRICT_COPY_PER_PROFILE",
    "ALL_COPIES_STRICT_CLEAN"
  ),
  labels = c(
    "No strict-clean copy",
    "Strict-clean copy in one profile",
    "At least one strict-clean cALP+dALP pair",
    "All profile copies strict-clean"
  )
)

palette <- c(
  "No strict-clean copy" = "#BDBDBD",
  "Strict-clean copy in one profile" = "#86B6C8",
  "At least one strict-clean cALP+dALP pair" = "#2A9D8F",
  "All profile copies strict-clean" = "#D97706"
)

theme_pub <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.title = element_text(size = base_size),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 0.6),
      plot.title = element_text(size = base_size + 0.5, face = "bold", hjust = 0),
      plot.margin = margin(5, 6, 5, 5)
    )
}

save_pdf_png <- function(plot, stem, width_mm, height_mm) {
  ggsave(paste0(stem, ".pdf"), plot, width = width_mm, height = height_mm,
         units = "mm", device = cairo_pdf, bg = "white")
  ggsave(paste0(stem, ".png"), plot, width = width_mm, height = height_mm,
         units = "mm", dpi = 600, bg = "white")
}

n_labels <- aggregate(mag_id ~ quality_checkm2, mag, length)
n_labels$label <- paste0("n = ", n_labels$mag_id)

p_fraction <- ggplot(mag, aes(quality_checkm2, strict_copy_fraction)) +
  geom_boxplot(width = 0.48, outlier.shape = NA, linewidth = 0.4, fill = "white") +
  geom_jitter(aes(colour = evidence_tier), width = 0.19, height = 0,
              size = 1.15, alpha = 0.72) +
  geom_text(data = n_labels, aes(x = quality_checkm2, y = 1.075, label = label),
            inherit.aes = FALSE, size = 2.25, family = "Arial") +
  scale_colour_manual(values = palette, drop = FALSE) +
  scale_y_continuous(limits = c(0, 1.11), breaks = seq(0, 1, 0.25),
                     labels = c("0", "0.25", "0.50", "0.75", "1.00"), expand = c(0, 0)) +
  labs(
    x = "MAG quality",
    y = "Fraction of cALP/dALP copies passing strict-clean",
    title = "Assembly-context support across all 342 coexist MAGs"
  ) +
  guides(colour = guide_legend(override.aes = list(size = 2.0, alpha = 1), ncol = 2, byrow = TRUE)) +
  theme_pub() +
  theme(legend.position = "bottom", legend.box.margin = margin(-2, 0, 0, 0))

save_pdf_png(
  p_fraction,
  file.path(figure_dir, "fig_full_coexist_MAG_strict_copy_fraction_by_quality"),
  118, 90
)

ord$order_label <- paste0(ord$order, " (n=", ord$coexist_MAGs, ")")
ord$order_label <- factor(ord$order_label, levels = ord$order_label[order(ord$coexist_MAGs, decreasing = FALSE)])
ord_long <- rbind(
  data.frame(order = ord$order, order_label = ord$order_label, evidence = "Clean cALP+dALP pair", fraction = ord$clean_pair_fraction, total = ord$coexist_MAGs),
  data.frame(order = ord$order, order_label = ord$order_label, evidence = "All profile copies clean", fraction = ord$all_copy_clean_fraction, total = ord$coexist_MAGs)
)
ord_long$evidence <- factor(ord_long$evidence, levels = c("Clean cALP+dALP pair", "All profile copies clean"))

p_order <- ggplot(ord_long, aes(fraction, order_label, colour = evidence, shape = evidence)) +
  geom_segment(aes(x = 0, xend = fraction, yend = order_label), colour = "#D9D9D9", linewidth = 0.35) +
  geom_point(size = 2.1, alpha = 0.9, stroke = 0.35) +
  scale_colour_manual(values = c("Clean cALP+dALP pair" = "#2A9D8F", "All profile copies clean" = "#D97706")) +
  scale_shape_manual(values = c("Clean cALP+dALP pair" = 16, "All profile copies clean" = 17)) +
  scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.25),
                     labels = c("0", "25", "50", "75", "100"), expand = c(0, 0)) +
  labs(
    x = "MAGs meeting assembly-context evidence tier (%)",
    y = NULL,
    title = "Clean coexist evidence spans multiple archaeal orders"
  ) +
  guides(colour = guide_legend(order = 1), shape = guide_legend(order = 1)) +
  theme_pub() +
  theme(legend.position = "bottom")

save_pdf_png(
  p_order,
  file.path(figure_dir, "fig_full_coexist_MAG_clean_evidence_by_order"),
  125, 96
)

write.table(
  mag,
  file.path(DATA <- file.path(base_dir, "data", "full_6769_coexist_assembly_audit"),
            "fig_full_coexist_MAG_strict_copy_fraction_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  ord_long,
  file.path(DATA, "fig_full_coexist_MAG_clean_evidence_by_order_source_data.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)
