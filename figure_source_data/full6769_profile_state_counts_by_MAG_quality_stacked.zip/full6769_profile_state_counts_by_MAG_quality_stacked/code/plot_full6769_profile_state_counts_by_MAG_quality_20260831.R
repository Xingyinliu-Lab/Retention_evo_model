suppressPackageStartupMessages({
  library(ggplot2)
})

input_file <- "../data/seq_metat.tsv"
source_dir <- ".."
figure_dir <- ".."
manuscript_dir <- ".."
basename_out <- "fig_1_full6769_profile_state_counts_by_MAG_quality_stacked"

dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(manuscript_dir, recursive = TRUE, showWarnings = FALSE)

seq_meta <- read.delim(
  input_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

profile_map <- c(
  "canonical Actin-like" = "cALP",
  "Crenactin-like / archaeal actin" = "dALP"
)

dat <- seq_meta[seq_meta$actin_family_class %in% names(profile_map), , drop = FALSE]
dat$profile <- unname(profile_map[dat$actin_family_class])

stopifnot(nrow(dat) == 2606L)
stopifnot(sum(dat$profile == "cALP") == 1216L)
stopifnot(sum(dat$profile == "dALP") == 1390L)
stopifnot(all(dat$quality_checkm2 %in% c("HQ", "MQ")))

mag_quality_n <- aggregate(
  quality_checkm2 ~ mag_id,
  dat,
  function(x) length(unique(x))
)
stopifnot(all(mag_quality_n$quality_checkm2 == 1L))

mag_profiles <- aggregate(
  profile ~ mag_id + quality_checkm2,
  dat,
  function(x) paste(sort(unique(x)), collapse = "+")
)

mag_profiles$profile_state <- ifelse(
  mag_profiles$profile == "dALP", "dALP-only",
  ifelse(mag_profiles$profile == "cALP", "cALP-only", "coexist")
)

state_levels <- c("dALP-only", "coexist", "cALP-only")
quality_levels <- c("MQ", "HQ")
mag_profiles$profile_state <- factor(mag_profiles$profile_state, levels = state_levels)
mag_profiles$quality_checkm2 <- factor(mag_profiles$quality_checkm2, levels = quality_levels)

counts <- as.data.frame(
  xtabs(~ profile_state + quality_checkm2, data = mag_profiles),
  stringsAsFactors = FALSE
)
names(counts) <- c("profile_state", "quality_checkm2", "n_MAG")
counts$profile_state <- factor(counts$profile_state, levels = state_levels)
counts$quality_checkm2 <- factor(counts$quality_checkm2, levels = quality_levels)

totals <- aggregate(n_MAG ~ profile_state, counts, sum)
names(totals)[2] <- "total_MAG"
counts <- merge(counts, totals, by = "profile_state", sort = FALSE)
counts <- counts[order(counts$profile_state, counts$quality_checkm2), , drop = FALSE]
counts$fraction_within_state <- counts$n_MAG / counts$total_MAG

expected <- data.frame(
  profile_state = factor(rep(state_levels, each = 2), levels = state_levels),
  quality_checkm2 = factor(rep(quality_levels, times = 3), levels = quality_levels),
  n_MAG = c(478L, 429L, 284L, 58L, 323L, 90L)
)
stopifnot(identical(as.integer(counts$n_MAG), expected$n_MAG))
stopifnot(sum(counts$n_MAG) == 1662L)

write.table(
  counts[, c("profile_state", "quality_checkm2", "n_MAG", "total_MAG", "fraction_within_state")],
  file.path(source_dir, paste0(basename_out, "_source_data.tsv")),
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  mag_profiles[, c("mag_id", "quality_checkm2", "profile_state")],
  file.path(source_dir, paste0(basename_out, "_MAG_states.tsv")),
  sep = "\t", quote = FALSE, row.names = FALSE
)

quality_palette <- c("MQ" = "#C3D0DC", "HQ" = "#637BA8")
label_palette <- c("MQ" = "#203040", "HQ" = "white")

p <- ggplot(counts, aes(x = profile_state, y = n_MAG, fill = quality_checkm2)) +
  geom_col(width = 0.68, colour = "white", linewidth = 0.35) +
  geom_text(
    aes(label = n_MAG, colour = quality_checkm2),
    position = position_stack(vjust = 0.5),
    family = "Arial", size = 2.45, fontface = "bold"
  ) +
  geom_text(
    data = totals,
    aes(x = profile_state, y = total_MAG, label = paste0("n = ", total_MAG)),
    inherit.aes = FALSE,
    family = "Arial", size = 2.4, vjust = -0.55, colour = "#252525"
  ) +
  scale_fill_manual(
    values = quality_palette,
    breaks = c("HQ", "MQ"),
    labels = c("HQ", "MQ"),
    name = "MAG quality"
  ) +
  scale_colour_manual(values = label_palette, guide = "none") +
  scale_y_continuous(
    limits = c(0, 1000),
    breaks = seq(0, 1000, 200),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(x = NULL, y = "Number of MAGs") +
  theme_classic(base_size = 7, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.38, colour = "black"),
    axis.ticks = element_line(linewidth = 0.38, colour = "black"),
    axis.text = element_text(size = 6.6, colour = "black"),
    axis.title.y = element_text(size = 7.2, margin = margin(r = 5)),
    legend.position = "top",
    legend.justification = "left",
    legend.direction = "horizontal",
    legend.title = element_text(size = 6.6),
    legend.text = element_text(size = 6.4),
    legend.key.size = grid::unit(3.2, "mm"),
    legend.spacing.x = grid::unit(1.2, "mm"),
    plot.margin = margin(4, 5, 3, 4)
  )

pdf_file <- file.path(figure_dir, paste0(basename_out, ".pdf"))
png_file <- file.path(figure_dir, paste0(basename_out, ".png"))

grDevices::cairo_pdf(pdf_file, width = 92 / 25.4, height = 76 / 25.4, family = "Arial")
print(p)
dev.off()

if (!requireNamespace("ragg", quietly = TRUE)) {
  stop("The ragg package is required for the PNG export.")
}
ragg::agg_png(
  png_file,
  width = 92 / 25.4,
  height = 76 / 25.4,
  units = "in",
  res = 600,
  background = "white"
)
print(p)
dev.off()

file.copy(pdf_file, file.path(manuscript_dir, basename(pdf_file)), overwrite = TRUE)
file.copy(png_file, file.path(manuscript_dir, basename(png_file)), overwrite = TRUE)
file.copy(
  file.path(source_dir, paste0(basename_out, "_source_data.tsv")),
  file.path(manuscript_dir, paste0(basename_out, "_source_data.tsv")),
  overwrite = TRUE
)

writeLines(
  c(
    "scope=frozen authoritative 6769-sequence inventory",
    "included_profiles=cALP,dALP",
    "statistical_unit=MAG",
    "state_rule=dALP-only: dALP>=1 and cALP=0; coexist: dALP>=1 and cALP>=1; cALP-only: cALP>=1 and dALP=0",
    "quality_rule=CheckM2 HQ/MQ from seq_metat.tsv; one quality label per MAG",
    "included_sequences=2606",
    "included_MAGs=1662",
    "dALP-only=907",
    "coexist=342",
    "cALP-only=413",
    "output_formats=PDF,PNG",
    "SVG_and_TIFF=not_generated"
  ),
  file.path(source_dir, paste0(basename_out, "_plot_config.txt"))
)
