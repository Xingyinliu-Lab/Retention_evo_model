#!/usr/bin/env python3
"""Freeze final actin-retention conclusion and visualization deliverables."""

from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "figures" / "three_model_validation"
DATA = ROOT / "data" / "three_model_figures"
RESULTS = ROOT / "results"
WORK = ROOT / "work_records"

FIGURE_STEMS = [
    "fig_1_observed_profile_state_counts",
    "fig_2_four_pair_AU_likelihood_loss",
    "fig_2b_unbiased_19_pair_AU_likelihood_support",
    "fig_3_M2_vs_M3_delta_AIC",
    "fig_3b_full_state_model_AIC_comparison",
    "fig_4_six_species_tree_state_clustering",
    "fig_5_leave_Sigyn_coexistence",
    "fig_6_all_coexist_MAG_profile_distance",
    "fig_7_coexist_MAG_assembly_context",
    "fig_8_legacy_ALE_DTL_context",
]
SOURCE_FILES = [
    "source_state_counts.tsv",
    "source_four_pair_AU_likelihood_loss.tsv",
    "fig_2b_unbiased_19_pair_AU_source_data.tsv",
    "source_M2_vs_M3_delta_AIC.tsv",
    "fig_3b_full_state_model_AIC_source_data.tsv",
    "source_six_tree_state_clustering.tsv",
    "source_leave_Sigyn_coexistence.tsv",
    "fig_6_all_coexist_MAG_profile_distance_source_data.tsv",
    "fig_7_coexist_MAG_assembly_context_source_data.tsv",
    "fig_8_legacy_ALE_DTL_context_source_data.tsv",
]


def main() -> None:
    paths = [
        RESULTS / "ACTIN_RETENTION_CONCLUSION_TO_FIGURE_MAP_20260808.tsv",
        RESULTS / "ACTIN_RETENTION_CONCLUSION_VISUAL_COMPLETENESS_AUDIT.tsv",
        RESULTS / "THREE_MODEL_FIGURE_DELIVERY_AUDIT.tsv",
        WORK / "ACTIN_RETENTION_CONCLUSION_RECOVERY_CN_20260808.md",
        ROOT / "ACTIN_RETENTION_CONCLUSION_VISUAL_RECOVERY_COMPLETE.marker",
        ROOT / "code" / "plot_retention_conclusion_gap_subfigures_20260808.R",
        ROOT / "code" / "audit_conclusion_visual_mapping_20260808.py",
    ]
    paths.extend(FIG / f"{stem}.{ext}" for stem in FIGURE_STEMS for ext in ("pdf", "png"))
    paths.extend(DATA / name for name in SOURCE_FILES)
    missing = [str(path) for path in paths if not path.is_file() or path.stat().st_size == 0]
    if missing:
        raise RuntimeError(f"missing/nonempty deliverables: {missing}")
    out = RESULTS / "ACTIN_RETENTION_VISUAL_RECOVERY_FREEZE.tsv"
    with out.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("path\tbytes\tlines\tsha256\n")
        for path in paths:
            data = path.read_bytes()
            handle.write(
                f"{path.relative_to(ROOT).as_posix()}\t{len(data)}\t{data.count(b'\n')}\t"
                f"{hashlib.sha256(data).hexdigest()}\n"
            )


if __name__ == "__main__":
    main()
