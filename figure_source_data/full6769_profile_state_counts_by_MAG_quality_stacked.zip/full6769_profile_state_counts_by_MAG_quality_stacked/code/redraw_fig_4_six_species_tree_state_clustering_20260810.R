suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

base_dir <- ".."
source_file <- file.path(base_dir, "data", "three_model_figures",
                         "source_six_tree_state_clustering_boxplot.tsv")
figure_dir <- file.path(base_dir, "figures", "three_model_validation")

dat <- read.delim(source_file, check.names = FALSE, stringsAsFactors = FALSE)

tree_levels <- c(
  "gtdb_r226_expanded",
  "asgard971_addcore", "asgard971_astral89",
  "archaea1338_addcore", "archaea1338_denovo", "archaea1338_astral64"
)
tree_labels <- c(
  "GTDB r226", "A971 add-core", "A971 ASTRAL89",
  "A1338 add-core", "A1338 de novo", "A1338 ASTRAL64"
)
tree_cols <- setNames(
  c("#565656", "#3F7FB3", "#58AABD", "#D48A35", "#CB5B63", "#8D6BB3"),
  tree_levels
)
tree_offsets <- setNames(seq(-0.105, 0.105, length.out = 6), tree_levels)

dat <- dat %>%
  mutate(
    group = factor(group, levels = c("Random", "Observed")),
    x_base = as.integer(group),
    tree = factor(tree, levels = tree_levels),
    x_plot = x_base + unname(tree_offsets[as.character(tree)])
  )

p <- ggplot(dat, aes(x_base, same_state_fraction, group = group)) +
  geom_boxplot(
    width = 0.36, linewidth = 0.30, outlier.shape = NA,
    fill = NA, colour = "#8F8F8F"
  ) +
  geom_point(
    aes(x = x_plot, colour = tree),
    shape = 16, size = 1.95, alpha = 0.96
  ) +
  annotate("segment", x = 1, xend = 2, y = 0.925, yend = 0.925,
           linewidth = 0.30, colour = "black") +
  annotate("segment", x = 1, xend = 1, y = 0.915, yend = 0.925,
           linewidth = 0.30, colour = "black") +
  annotate("segment", x = 2, xend = 2, y = 0.915, yend = 0.925,
           linewidth = 0.30, colour = "black") +
  annotate("text", x = 1.5, y = 0.942,
           label = "Permutation P = 0.000999 in all six trees",
           family = "Arial", size = 2.45) +
  scale_x_continuous(
    breaks = c(1, 2), labels = c("Randomized", "Observed"),
    limits = c(0.72, 2.28)
  ) +
  scale_y_continuous(
    limits = c(0.30, 0.96), breaks = seq(0.3, 0.9, 0.1),
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_colour_manual(
    values = tree_cols, breaks = tree_levels, labels = tree_labels,
    limits = tree_levels, drop = FALSE, name = NULL
  ) +
  labs(
    title = "Profile states cluster beyond random expectation",
    x = NULL,
    y = "Nearest-neighbour same-state fraction"
  ) +
  theme_classic(base_size = 7.2, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.30, colour = "black"),
    axis.ticks = element_line(linewidth = 0.28, colour = "black"),
    axis.text.x = element_text(size = 6.5),
    axis.text.y = element_text(size = 6.3),
    axis.title.y = element_text(size = 7.0),
    plot.title = element_text(size = 8.2, face = "bold", hjust = 0),
    legend.position = "top",
    legend.text = element_text(size = 5.3),
    legend.key.width = grid::unit(3.3, "mm"),
    legend.spacing.x = grid::unit(0.9, "mm"),
    plot.margin = margin(3, 5, 3, 5)
  ) +
  guides(colour = guide_legend(nrow = 1, override.aes = list(size = 1.9)))

ggsave(
  file.path(figure_dir, "fig_4_six_species_tree_state_clustering.pdf"),
  p, width = 125, height = 92, units = "mm", device = cairo_pdf
)
ggsave(
  file.path(figure_dir, "fig_4_six_species_tree_state_clustering.png"),
  p, width = 125, height = 92, units = "mm", dpi = 600, bg = "white"
)
