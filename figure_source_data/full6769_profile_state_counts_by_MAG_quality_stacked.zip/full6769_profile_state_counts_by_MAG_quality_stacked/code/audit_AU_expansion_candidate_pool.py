#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

from Bio import Phylo

BASE = Path(r"..")
RESULTS = BASE / "results"
OLD = Path(r"..")
META = Path(r"..")
ASSEMBLY = Path(r"..")
CANDIDATES = OLD / "reciprocal_paralog_species_pair_candidates.tsv"
DONE = RESULTS / "CORE_PROFILE_RETENTION_AU_CASES.tsv"
TREES = {
    "asgard971_addcore": Path(r".."),
    "asgard971_astral89": Path(r".."),
    "gtdb_r226_expanded": Path(r".."),
}
PROFILE = {
    "canonical Actin-like": "cALP",
    "Crenactin-like / archaeal actin": "dALP",
}


def read_tsv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        yield from csv.DictReader(handle, delimiter="\t")


def norm(name: str) -> str:
    if name.startswith(("GB_", "RS_")):
        return name.split("_", 1)[1]
    return name


meta_by_seq = {}
meta_by_mag = {}
for row in read_tsv(META):
    profile = PROFILE.get(row["actin_family_class"])
    if profile:
        meta_by_seq[row["seq"]] = profile
        meta_by_mag[row["mag_id"]] = row

strict_by_mag = defaultdict(list)
for row in read_tsv(ASSEMBLY):
    if row["actin_family_class"] not in PROFILE:
        continue
    try:
        strict = (
            row["partial"] == "00"
            and float(row["edge_distance_bp"]) >= 5000
            and float(row["local20kb_tnf_cosine_to_genome"]) >= 0.95
        )
    except (TypeError, ValueError):
        strict = False
    strict_by_mag[row["mag_id"]].append(strict)

tree_maps = {}
for tree_id, path in TREES.items():
    tree = Phylo.read(str(path), "newick")
    by_norm = {norm(t.name): t.name for t in tree.get_terminals()}
    tree_maps[tree_id] = (tree, by_norm)


def sister_call(tree_id: str, mag_a: str, mag_b: str) -> str:
    tree, by_norm = tree_maps[tree_id]
    if mag_a not in by_norm or mag_b not in by_norm:
        return "UNMAPPED"
    node = tree.common_ancestor(by_norm[mag_a], by_norm[mag_b])
    return "TRUE" if len(node.get_terminals()) == 2 else "FALSE"


done_pairs = set()
for row in read_tsv(DONE):
    done_pairs.add(tuple(sorted((row["mag_a"], row["mag_b"]))))

rows = []
for row in read_tsv(CANDIDATES):
    pa = [meta_by_seq.get(row["clade1_gene_a"]), meta_by_seq.get(row["clade2_gene_a"])]
    pb = [meta_by_seq.get(row["clade1_gene_b"]), meta_by_seq.get(row["clade2_gene_b"])]
    if sorted(pa) != ["cALP", "dALP"] or sorted(pb) != ["cALP", "dALP"]:
        continue
    mag_a, mag_b = row["mag_a"], row["mag_b"]
    sister = {tree_id: sister_call(tree_id, mag_a, mag_b) for tree_id in TREES}
    mapped_n = sum(v != "UNMAPPED" for v in sister.values())
    sister_n = sum(v == "TRUE" for v in sister.values())
    exact = row["both_exact_cherries"].lower() == "true"
    support95 = row["both_support_ge_95"].lower() == "true"
    assembly_a = strict_by_mag.get(mag_a, [])
    assembly_b = strict_by_mag.get(mag_b, [])
    clean_a = bool(assembly_a) and all(assembly_a)
    clean_b = bool(assembly_b) and all(assembly_b)
    already_done = tuple(sorted((mag_a, mag_b))) in done_pairs
    if exact and support95 and sister_n >= 2:
        tier = "TIER1_PRIMARY"
    elif exact and support95:
        tier = "TIER2_TOPOLOGY_SENSITIVITY"
    else:
        tier = "TIER3_EXPLORATORY"
    rows.append({
        "mag_a": mag_a,
        "mag_b": mag_b,
        "class": row["class"],
        "order": row["order"],
        "quality_a": meta_by_mag[mag_a]["quality_checkm2"],
        "quality_b": meta_by_mag[mag_b]["quality_checkm2"],
        "both_exact_gene_cherries": str(exact).upper(),
        "both_gene_support_ge95": str(support95).upper(),
        "asgard971_addcore_sisters": sister["asgard971_addcore"],
        "asgard971_astral89_sisters": sister["asgard971_astral89"],
        "gtdb_r226_sisters": sister["gtdb_r226_expanded"],
        "species_trees_mapped": mapped_n,
        "species_trees_exact_sisters": sister_n,
        "all_profile_copies_strict_clean_a": str(clean_a).upper(),
        "all_profile_copies_strict_clean_b": str(clean_b).upper(),
        "already_AU_complete": str(already_done).upper(),
        "AU_expansion_tier": tier,
        "clade1_support": row["clade1_support"],
        "clade2_support": row["clade2_support"],
        "clade1_gene_a": row["clade1_gene_a"],
        "clade1_gene_b": row["clade1_gene_b"],
        "clade2_gene_a": row["clade2_gene_a"],
        "clade2_gene_b": row["clade2_gene_b"],
    })

rows.sort(key=lambda x: (
    x["AU_expansion_tier"],
    x["order"] == "Sigynarchaeales",
    x["already_AU_complete"] == "TRUE",
    x["mag_a"], x["mag_b"],
))
out = RESULTS / "AU_EXPANSION_CANDIDATE_AUDIT.tsv"
with out.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)

summary = {
    "strict_cALP_dALP_sister_pair_candidates": len(rows),
    "unique_MAGs": len({x[m] for x in rows for m in ("mag_a", "mag_b")}),
    "tier1_primary": sum(x["AU_expansion_tier"] == "TIER1_PRIMARY" for x in rows),
    "tier1_already_complete": sum(x["AU_expansion_tier"] == "TIER1_PRIMARY" and x["already_AU_complete"] == "TRUE" for x in rows),
    "tier1_remaining": sum(x["AU_expansion_tier"] == "TIER1_PRIMARY" and x["already_AU_complete"] == "FALSE" for x in rows),
    "orders_all": dict(sorted(__import__("collections").Counter(x["order"] for x in rows).items())),
    "orders_tier1": dict(sorted(__import__("collections").Counter(x["order"] for x in rows if x["AU_expansion_tier"] == "TIER1_PRIMARY").items())),
    "non_Sigyn_candidates": sum(x["order"] != "Sigynarchaeales" for x in rows),
    "non_Sigyn_tier1": sum(x["order"] != "Sigynarchaeales" and x["AU_expansion_tier"] == "TIER1_PRIMARY" for x in rows),
}
(RESULTS / "AU_EXPANSION_CANDIDATE_SUMMARY.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(summary, ensure_ascii=False))
