suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

audit_root <- ".."
input_file <- file.path(
  audit_root, "au_expansion_19_unbiased_20260808", "summary",
  "UNBIASED_19_AU_RESULTS.tsv"
)
source_dir <- file.path(audit_root, "data", "three_model_figures")
figure_dir <- file.path(audit_root, "figures", "three_model_validation")
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(raw) == 19L, sum(raw$primary_retention_AU_pass == "TRUE") == 18L)

plot_data <- bind_rows(
  raw %>% transmute(
    pair_id, order, hypothesis = "Shared cALP/dALP branches",
    deltaL = retention_deltaL, pAU = retention_pAU,
    primary_retention_AU_pass
  ),
  raw %>% transmute(
    pair_id, order, hypothesis = "Copies cluster by MAG",
    deltaL = terminal_duplication_deltaL, pAU = terminal_duplication_pAU,
    primary_retention_AU_pass
  ),
  raw %>% transmute(
    pair_id, order, hypothesis = "Crossed profile pairing",
    deltaL = crossed_deltaL, pAU = crossed_pAU,
    primary_retention_AU_pass
  )
) %>%
  mutate(
    AU_compatible = pAU >= 0.05,
    pair_label = gsub("_", " / ", pair_id),
    order = factor(order, levels = c("Heimdallarchaeales", "JABLTI01", "Sigynarchaeales")),
    hypothesis = factor(
      hypothesis,
      levels = c("Shared cALP/dALP branches", "Copies cluster by MAG", "Crossed profile pairing")
    )
  )

pair_order <- raw %>%
  mutate(pair_label = gsub("_", " / ", pair_id)) %>%
  arrange(order, desc(primary_retention_AU_pass), retention_deltaL) %>%
  pull(pair_label)
plot_data$pair_label <- factor(plot_data$pair_label, levels = rev(pair_order))

source_file <- file.path(source_dir, "fig_2b_unbiased_19_pair_AU_source_data.tsv")
write.table(
  plot_data, source_file, sep = "\t", quote = FALSE,
  row.names = FALSE, na = "NA", fileEncoding = "UTF-8"
)

pair_offsets <- raw %>%
  arrange(pair_id) %>%
  transmute(pair_id, pair_offset = seq(-0.075, 0.075, length.out = n()))
plot_data <- plot_data %>%
  left_join(pair_offsets, by = "pair_id") %>%
  mutate(
    model_x = as.integer(hypothesis) + pair_offset,
    display_group = as.character(order)
  )

lineage_cols <- c(
  "Heimdallarchaeales" = "#0072B2",
  "JABLTI01" = "#D55E00",
  "Sigynarchaeales" = "#009E73"
)

p <- ggplot(plot_data, aes(x = model_x, y = deltaL, group = pair_id, colour = display_group)) +
  geom_line(linewidth = 0.55, alpha = 0.62) +
  geom_point(aes(shape = AU_compatible), size = 2.0, stroke = 0.7) +
  scale_x_continuous(
    breaks = 1:3,
    labels = c("Shared cALP/dALP branches\n(retention-compatible)",
               "Copies cluster by MAG\n(terminal duplication)",
               "Crossed profile pairing"),
    limits = c(0.82, 3.18), expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    trans = scales::pseudo_log_trans(base = 10, sigma = 1),
    breaks = c(0, 1, 3, 10, 30, 100, 300, 900),
    labels = c("0", "1", "3", "10", "30", "100", "300", "900"),
    expand = expansion(mult = c(0.015, 0.07))
  ) +
  scale_colour_manual(values = lineage_cols, name = "Sister-MAG lineage") +
  scale_shape_manual(
    values = c(`TRUE` = 16, `FALSE` = 1),
    labels = c(`TRUE` = "AU-compatible", `FALSE` = "Rejected (p-AU < 0.05)"),
    name = "Topology test"
  ) +
  labs(
    x = NULL,
    y = expression("Likelihood loss from the best topology ("*Delta*"lnL)"),
    title = "Raw likelihood losses support a shared cALP/dALP split in 18 of 19 sister-MAG pairs",
    subtitle = "Each line is one preselected sister-MAG pair; 0 = best topology; open points are rejected by the AU test"
  ) +
  theme_classic(base_size = 7, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.35),
    axis.ticks = element_line(linewidth = 0.35),
    axis.text.y = element_text(size = 6.0, colour = "#222222"),
    axis.text.x = element_text(size = 6.5, colour = "#222222", lineheight = 0.95),
    axis.title.y = element_text(size = 6.8, margin = margin(r = 5)),
    legend.position = "top",
    legend.box = "vertical",
    legend.title = element_text(size = 6.0, face = "bold"),
    legend.text = element_text(size = 5.7),
    legend.key.width = unit(5, "mm"),
    legend.key.height = unit(3.5, "mm"),
    plot.title = element_text(size = 8.2, face = "bold", margin = margin(b = 2)),
    plot.subtitle = element_text(size = 6.4, colour = "#4A4A4A", margin = margin(b = 6)),
    plot.margin = margin(6, 8, 4, 5)
  ) +
  guides(
    colour = guide_legend(order = 1, nrow = 1, override.aes = list(alpha = 1, linewidth = 0.8)),
    shape = guide_legend(order = 2, nrow = 1)
  )

prefix <- file.path(figure_dir, "fig_2b_unbiased_19_pair_AU_likelihood_support")
grDevices::cairo_pdf(paste0(prefix, ".pdf"), width = 138 / 25.4, height = 105 / 25.4, family = "Arial")
print(p)
dev.off()
grDevices::png(
  paste0(prefix, ".png"), width = 138 / 25.4, height = 105 / 25.4,
  units = "in", res = 450, type = "cairo-png", family = "Arial"
)
print(p)
dev.off()

qa <- data.frame(
  item = c(
    "core_conclusion", "archetype", "backend", "n_pairs", "n_primary_AU_pass",
    "source_data", "pdf", "png", "export_formats", "directionality_boundary"
  ),
  value = c(
    "A shared cALP/dALP split is AU-compatible while terminal and crossed alternatives are rejected in 18/19 unbiased species-tree sister-MAG pairs",
    "raw three-topology likelihood trajectories with AU status", "R ggplot2 only", "19", "18",
    source_file, paste0(prefix, ".pdf"), paste0(prefix, ".png"), "PDF and PNG only",
    "No cALP/dALP ancestral direction inferred"
  ),
  stringsAsFactors = FALSE
)
write.table(
  qa, file.path(figure_dir, "fig_2b_unbiased_19_pair_AU_QA.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8"
)
