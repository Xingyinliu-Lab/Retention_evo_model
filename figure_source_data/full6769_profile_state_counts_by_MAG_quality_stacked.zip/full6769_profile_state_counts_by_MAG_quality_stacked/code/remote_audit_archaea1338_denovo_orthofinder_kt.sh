#!/usr/bin/env bash
set -euo pipefail

base=..

echo '---LOG KEY---'
grep -E 'OrthoFinder version|Command Line|orthofinder|Started OrthoFinder|Species tree|Results:' "$base/Log.txt" | head -n 50 || true

echo '---TREE FILES---'
for f in \
  "$base/WorkingDirectory/SpeciesTree_unrooted.txt" \
  "$base/Species_Tree/SpeciesTree_rooted.txt" \
  "$base/Species_Tree/SpeciesTree_rooted_node_labels.txt"
do
  if [[ -f "$f" ]]; then
    wc -c "$f"
    sha256sum "$f"
  fi
done

echo '---EXACT TREE INVENTORY---'
find "$base" -maxdepth 2 -type f \
  \( -name 'SpeciesTree_rooted.txt' -o -name 'SpeciesTree_rooted_node_labels.txt' -o -name 'SpeciesTree_unrooted.txt' \) \
  -printf '%p\t%s\t%TY-%Tm-%Td %TH:%TM:%TS\n' | sort

