#!/usr/bin/env Rscript

# Circular genus tree with inner actin-family tip symbols and an outer phylum ring.
# Uses the frozen thorough LG+R9 gappyout ML tree; topology and branch lengths are not modified.

required <- c("ape", "ggplot2", "ggtree")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing R packages: ", paste(missing, collapse = ", "))

suppressPackageStartupMessages({
  library(ape)
  library(ggplot2)
  library(ggtree)
})

root <- ".."
tree_file <- file.path(
  root, "genus_tree_LG_R9_gappyout",
  "trimmed_genus_resample_sequences_euk_bac_LG_R9_gappyout_thorough.treefile"
)
meta_file <- file.path(root, "genus_tree", "meta.txt")
out_dir <- file.path(root, "genus_tree_LG_R9_gappyout", "figures")
source_dir <- file.path(root, "genus_tree_LG_R9_gappyout", "plot_source_data")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

tree <- read.tree(tree_file)
tree_display <- tree
tree_display$edge.length <- sqrt(tree_display$edge.length)
meta <- read.delim(meta_file, check.names = FALSE, stringsAsFactors = FALSE)
meta <- meta[match(tree$tip.label, meta$label), , drop = FALSE]
if (anyNA(meta$label)) stop("Some tree tips are absent from meta.txt.")

family_labels <- c(
  "canonical Actin-like" = "cALPs",
  "Crenactin-like / archaeal actin" = "dALPs",
  "Volactin" = "Volactin",
  "Salactin" = "Salactin",
  "MreB/Mbl-like" = "MreB/Mbl-like",
  "MreB-like_C/ALP_N-related" = "MreB-C/ALP-N",
  "FtsA/PilM-like" = "FtsA/PilM-like",
  "Eukaryota_actin" = "Eukaryotic actin",
  "Bacteria_actin" = "Bacterial actin"
)
family_order <- unname(family_labels)
family_palette <- c(
  "cALPs" = "#4C78A8", "dALPs" = "#4F9B8F",
  "Volactin" = "#E18D4F", "Salactin" = "#D6A64A",
  "MreB/Mbl-like" = "#8B6FA8", "MreB-C/ALP-N" = "#C77DA8",
  "FtsA/PilM-like" = "#777777", "Eukaryotic actin" = "#D73027",
  "Bacterial actin" = "#5B4636"
)
phylum_order <- c(
  "Asgardarchaeota", "Thermoproteota", "Thermoplasmatota",
  "Halobacteriota", "Methanobacteriota", "Methanobacteriota_B",
  "Korarchaeota", "Nanobdellota", "Aenigmatarchaeota",
  "Micrarchaeota", "Altiarchaeota", "EX4484-52", "Bacteria", "Eukaryota"
)
phylum_palette <- c(
  "Asgardarchaeota" = "#3B8C6E", "Thermoproteota" = "#7B61A8",
  "Thermoplasmatota" = "#D9822B", "Halobacteriota" = "#C86B98",
  "Methanobacteriota" = "#B8A72A", "Methanobacteriota_B" = "#4CB7C5",
  "Korarchaeota" = "#8C8C8C", "Nanobdellota" = "#476A8A",
  "Aenigmatarchaeota" = "#D95852", "Micrarchaeota" = "#9E4A4A",
  "Altiarchaeota" = "#4E94C4", "EX4484-52" = "#9B776E",
  "Bacteria" = "#333333", "Eukaryota" = "#D73027"
)
domain_shapes <- c("Archaea" = 16, "Bacteria" = 15, "Eukaryota" = 17)

meta$Actin_family <- factor(unname(family_labels[meta$actin_family_class]), levels = family_order)
meta$Phylum <- factor(meta$Phylum, levels = phylum_order)
meta$Domain <- factor(
  ifelse(meta$Phylum == "Bacteria", "Bacteria", ifelse(meta$Phylum == "Eukaryota", "Eukaryota", "Archaea")),
  levels = names(domain_shapes)
)

support_parts <- strsplit(ifelse(is.na(tree$node.label), "", tree$node.label), "/", fixed = TRUE)
sh_alrt <- vapply(support_parts, function(x) suppressWarnings(as.numeric(x[1])), numeric(1))
ufboot <- vapply(support_parts, function(x) if (length(x) > 1) suppressWarnings(as.numeric(x[2])) else NA_real_, numeric(1))
support <- data.frame(
  node = seq.int(Ntip(tree) + 1L, Ntip(tree) + tree$Nnode),
  high_support = is.finite(sh_alrt) & is.finite(ufboot) & sh_alrt >= 80 & ufboot >= 95
)

p <- ggtree(tree_display, layout = "circular", linewidth = 0.32, colour = "#666666")
tip_match <- match(p$data$label, meta$label)
p$data$Actin_family <- meta$Actin_family[tip_match]
p$data$Domain <- meta$Domain[tip_match]
p$data$Phylum <- meta$Phylum[tip_match]
p$data$high_support <- support$high_support[match(p$data$node, support$node)]
p$data$high_support[is.na(p$data$high_support)] <- FALSE

tip_ring <- p$data[p$data$isTip, c("label", "x", "y", "Phylum"), drop = FALSE]
ring_radius <- max(tip_ring$x) + 0.075 * max(tip_ring$x)
tip_ring$x_ring <- ring_radius
write.table(
  tip_ring,
  file.path(source_dir, "figure_1a_genus_tree_phylum_outer_ring_tip_annotations.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

p_ring <- p +
  geom_point2(
    aes(subset = isTip, colour = Actin_family, shape = Domain),
    size = 1.55, alpha = 0.98
  ) +
  geom_point(
    data = tip_ring,
    aes(x = x_ring, y = y, fill = Phylum),
    inherit.aes = FALSE, shape = 21, size = 3.85, colour = "transparent", stroke = 0
  ) +
  geom_point2(
    aes(subset = !isTip & high_support),
    shape = 21, size = 0.78, stroke = 0.08, colour = "white", fill = "black"
  ) +
  scale_colour_manual(values = family_palette, breaks = family_order, drop = FALSE, name = "Actin family") +
  scale_fill_manual(values = phylum_palette, breaks = phylum_order, drop = FALSE, name = "Outer ring: phylum") +
  scale_shape_manual(values = domain_shapes, name = "Domain") +
  labs(
    title = "Genus-sampled actin phylogeny with phylum outer ring",
    subtitle = "Square-root-transformed branch lengths; coloured outer ring denotes tip phylum",
    caption = "Thorough LG+R9 search on the gappyout alignment; black nodes: SH-aLRT ≥80 and UFBoot ≥95."
  ) +
  theme_void(base_family = "Arial") +
  theme(
    plot.title = element_text(size = 13, face = "bold", family = "Arial"),
    plot.subtitle = element_text(size = 9.5, colour = "#444444", family = "Arial"),
    plot.caption = element_text(size = 8, colour = "#444444", hjust = 0, family = "Arial"),
    legend.title = element_text(size = 9, face = "bold", family = "Arial"),
    legend.text = element_text(size = 8.2, family = "Arial"),
    legend.key.height = grid::unit(3.6, "mm"),
    legend.position = "right",
    plot.margin = margin(8, 12, 8, 8)
  )

stem <- file.path(out_dir, "figure_1a_genus_tree_branch_length_actin_family_phylum_outer_ring")
width_mm <- 390
height_mm <- 310
cairo_pdf(paste0(stem, ".pdf"), width = width_mm / 25.4, height = height_mm / 25.4, family = "Arial")
print(p_ring)
dev.off()
png(paste0(stem, "_preview.png"), width = width_mm / 25.4, height = height_mm / 25.4, units = "in", res = 300, type = "cairo", bg = "white")
print(p_ring)
dev.off()

message("Saved: ", normalizePath(paste0(stem, ".pdf"), winslash = "/"))
message("Saved: ", normalizePath(paste0(stem, "_preview.png"), winslash = "/"))
