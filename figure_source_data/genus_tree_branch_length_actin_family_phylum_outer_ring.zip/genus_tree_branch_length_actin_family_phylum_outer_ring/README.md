# 1a_genus_tree_branch_length_actin_family_phylum_outer_ring

- Manuscript panel: Fig.1F
- Source figure basename: figure_1a_genus_tree_branch_length_actin_family_phylum_outer_ring
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 3 directly referenced or locally packaged source-data file(s)
