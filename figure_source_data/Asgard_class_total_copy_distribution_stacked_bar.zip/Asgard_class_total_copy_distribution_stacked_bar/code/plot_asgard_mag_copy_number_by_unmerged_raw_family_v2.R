#!/usr/bin/env Rscript

# Publication-style visualizations for:
#   asgard_mag_copy_number_by_unmerged_raw_family.tsv
#
# Design:
#   - Keep raw actin-family classes unmerged.
#   - Drop all-zero family columns automatically, especially Other if absent.
#   - Use one global family color dictionary across all figures.
#   - Prefer stacked bars for class-level composition and copy-number distribution.
#   - Use copy_combo already present in the table for Asgard class-level combo analysis.
#   - Avoid hard dependencies on ComplexUpset/ComplexHeatmap/ggraph.
#
# Outputs:
#   Fig. 1  Asgard class-level raw-family copy composition
#   Fig. 2  Asgard class-level total_copy distribution
#   Fig. 3  Asgard class-level raw copy_combo distribution
#   Fig. 4  High-copy Asgard MAG-level raw-family copy counts
#   Fig. 5  Asgard raw-family co-occurrence network
#   Fig. 6  Optional high-copy Asgard MAG clustered heatmap
#   Fig. 7  Recommended overview panel

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(patchwork)
  library(scales)
})

# ============================================================
# 0. Input/output handling
# ============================================================

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
script_dir <- if (length(script_arg) == 1) {
  dirname(normalizePath(sub("^--file=", "", script_arg), winslash = "/"))
} else {
  normalizePath(getwd(), winslash = "/")
}

args <- commandArgs(trailingOnly = TRUE)
input_candidates <- c(
  file.path(script_dir, "asgard_mag_copy_number_by_unmerged_raw_family.tsv"),
  file.path(dirname(script_dir), "asgard_mag_copy_number_by_unmerged_raw_family.tsv"),
  file.path(dirname(script_dir), "data", "asgard_mag_copy_number_by_unmerged_raw_family.tsv"),
  file.path(getwd(), "asgard_mag_copy_number_by_unmerged_raw_family.tsv")
)

input_file <- if (length(args) >= 1) {
  normalizePath(args[1], winslash = "/", mustWork = TRUE)
} else {
  existing <- input_candidates[file.exists(input_candidates)]
  if (length(existing) == 0) {
    stop(
      "Cannot find asgard_mag_copy_number_by_unmerged_raw_family.tsv. ",
      "Run from the table directory or provide the input file path."
    )
  }
  normalizePath(existing[1], winslash = "/")
}

output_root <- if (length(args) >= 2) {
  normalizePath(args[2], winslash = "/", mustWork = FALSE)
} else {
  dirname(input_file)
}

figure_dir <- file.path(output_root, "figures")
data_dir <- file.path(output_root, "plot_source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 1. Parameters
# ============================================================

TOP_N_ASGARD_CLASS <- 25L
MIN_ASGARD_CLASS_N <- 3L
TOP_N_COMBOS <- 10L
TOP_N_HIGHCOPY_MAG <- 60L
TOP_N_HEATMAP_MAG <- 90L
PLOT_CLUSTERED_HEATMAP <- TRUE
PLOT_CHORD_DIAGRAM <- TRUE
MIN_JACCARD_EDGE <- 0

raw_family_cols_full <- c(
  "canonical_Actin_like",
  "Crenactin_like_archaeal_actin",
  "MreB_Mbl_like",
  "MreB_like_C_ALP_N_related",
  "FtsA_PilM_like",
  "Salactin",
  "Volactin",
  "Other"
)

family_labels_full <- c(
  canonical_Actin_like = "canonical Actin-like",
  Crenactin_like_archaeal_actin = "Crenactin-like / archaeal actin",
  MreB_Mbl_like = "MreB/Mbl-like",
  MreB_like_C_ALP_N_related = "MreB-like C/ALP-N-related",
  FtsA_PilM_like = "FtsA/PilM-like",
  Salactin = "Salactin",
  Volactin = "Volactin",
  Other = "Other"
)

family_short_labels_full <- c(
  canonical_Actin_like = "canonical\nActin-like",
  Crenactin_like_archaeal_actin = "Crenactin-like /\narchaeal actin",
  MreB_Mbl_like = "MreB/Mbl-like",
  MreB_like_C_ALP_N_related = "MreB-like C /\nALP-N-related",
  FtsA_PilM_like = "FtsA/\nPilM-like",
  Salactin = "Salactin",
  Volactin = "Volactin",
  Other = "Other"
)

# Global family color dictionary. Keep colors consistent across all raw-family plots.
family_palette_full <- c(
  canonical_Actin_like = "#E64B35",
  Crenactin_like_archaeal_actin = "#4DBBD5",
  MreB_Mbl_like = "#00A087",
  MreB_like_C_ALP_N_related = "#3C5488",
  FtsA_PilM_like = "#F39B7F",
  Salactin = "#8491B4",
  Volactin = "#91D1C2",
  Other = "#B09C85"
)

copy_group_levels <- c("1", "2", "3", ">=4")
copy_group_palette <- c(
  "1" = "#D9D9D9",
  "2" = "#9ECAE1",
  "3" = "#4292C6",
  ">=4" = "#084594"
)

# ============================================================
# 2. Helper functions
# ============================================================

fmt_int <- function(x) {
  format(x, big.mark = ",", scientific = FALSE, trim = TRUE)
}

fmt_pct <- function(x, digits = 1) {
  paste0(round(100 * x, digits), "%")
}

theme_nature <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks.length = grid::unit(1.4, "mm"),
      axis.title = element_text(size = base_size, colour = "black"),
      axis.text = element_text(size = base_size - 0.4, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", colour = "black"),
      plot.title = element_text(size = base_size + 0.7, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.tag = element_text(size = 8, face = "bold"),
      plot.caption = element_text(size = base_size - 1.0, colour = "#4D4D4D", hjust = 0),
      panel.grid = element_blank(),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 300) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      paste0(stem, ".pdf"),
      width = width_in,
      height = height_in,
      family = "sans"
    )
  } else {
    grDevices::pdf(
      paste0(stem, ".pdf"),
      width = width_in,
      height = height_in,
      family = "sans"
    )
  }
  print(plot)
  grDevices::dev.off()

  if (capabilities("cairo")) {
    grDevices::png(
      paste0(stem, "_preview.png"),
      width = width_in,
      height = height_in,
      units = "in",
      res = dpi,
      type = "cairo",
      bg = "white"
    )
  } else {
    grDevices::png(
      paste0(stem, "_preview.png"),
      width = width_in,
      height = height_in,
      units = "in",
      res = dpi,
      bg = "white"
    )
  }
  print(plot)
  grDevices::dev.off()
}

write_tsv_base <- function(x, file) {
  write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

make_presence_combo <- function(row_values, families) {
  fam <- families[as.numeric(row_values) > 0]
  if (length(fam) == 0) {
    return("None")
  }
  if (length(fam) == 1) {
    return(paste0(fam, " only"))
  }
  paste(fam, collapse = " + ")
}

# ============================================================
# 3. Read and check input
# ============================================================

asgard_df <- read.delim(
  input_file,
  sep = "\t",
  quote = "",
  comment.char = "",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

required_columns <- c("mag_id", "c", "total_copy")
missing_required <- setdiff(required_columns, names(asgard_df))
if (length(missing_required) > 0) {
  stop("Missing required columns: ", paste(missing_required, collapse = ", "))
}

raw_family_cols <- intersect(raw_family_cols_full, names(asgard_df))
if (length(raw_family_cols) == 0) {
  stop("No raw-family copy columns found.")
}

asgard_df <- asgard_df %>%
  mutate(
    mag_id = as.character(mag_id),
    c = if_else(is.na(c) | c == "", "Unclassified_Asgard_class", as.character(c)),
    p = if ("p" %in% names(.)) if_else(is.na(p) | p == "", "Asgardarchaeota", as.character(p)) else "Asgardarchaeota",
    quality_checkm2 = if ("quality_checkm2" %in% names(.)) {
      if_else(is.na(quality_checkm2) | quality_checkm2 == "", "Unknown", as.character(quality_checkm2))
    } else {
      "Unknown"
    },
    total_copy = as.integer(total_copy)
  )

for (family_col in raw_family_cols) {
  asgard_df[[family_col]] <- as.integer(asgard_df[[family_col]])
  asgard_df[[family_col]][is.na(asgard_df[[family_col]])] <- 0L
}

if (any(is.na(asgard_df$total_copy) | asgard_df$total_copy < 0)) {
  stop("total_copy contains missing or negative values.")
}

# Drop all-zero raw-family columns, including Other if absent.
raw_family_sums <- colSums(asgard_df[, raw_family_cols, drop = FALSE], na.rm = TRUE)
raw_family_cols_present <- names(raw_family_sums)[raw_family_sums > 0]
dropped_family_cols <- setdiff(raw_family_cols, raw_family_cols_present)
if (length(dropped_family_cols) > 0) {
  message("Dropped all-zero raw-family columns: ", paste(dropped_family_cols, collapse = ", "))
}
if (length(raw_family_cols_present) == 0) {
  stop("All raw-family columns are zero. Nothing to plot.")
}

family_palette <- family_palette_full[raw_family_cols_present]
family_labels <- family_labels_full[raw_family_cols_present]
family_short_labels <- family_short_labels_full[raw_family_cols_present]

# Recompute total_copy if inconsistent with raw-family sums. Keep the original as a check.
asgard_df$total_copy_from_raw_family <- rowSums(asgard_df[, raw_family_cols_present, drop = FALSE], na.rm = TRUE)
asgard_df$total_copy_diff <- asgard_df$total_copy_from_raw_family - asgard_df$total_copy
write_tsv_base(
  asgard_df %>% select(mag_id, c, total_copy, total_copy_from_raw_family, total_copy_diff),
  file.path(data_dir, "asgard_total_copy_consistency_check.tsv")
)
if (any(asgard_df$total_copy_diff != 0, na.rm = TRUE)) {
  warning("Some rows have total_copy != sum(raw family columns). Plots use total_copy_from_raw_family for family-composition figures.")
}

# Use raw-family sum for plotting composition, but keep total_copy for copy-number distribution.
asgard_df <- asgard_df %>%
  mutate(total_family_copies = total_copy_from_raw_family)

if (!"copy_combo" %in% names(asgard_df)) {
  asgard_df$copy_combo <- apply(
    asgard_df[, raw_family_cols_present, drop = FALSE],
    1,
    make_presence_combo,
    families = raw_family_cols_present
  )
}
asgard_df$copy_combo <- ifelse(is.na(asgard_df$copy_combo) | asgard_df$copy_combo == "", "None", asgard_df$copy_combo)

write_tsv_base(
  asgard_df,
  file.path(data_dir, "asgard_mag_copy_number_by_unmerged_raw_family_input_checked.tsv")
)

# ============================================================
# 4. Shared data summaries
# ============================================================

class_n_all <- asgard_df %>%
  group_by(c) %>%
  summarise(
    n_mags = n_distinct(mag_id),
    n_seq = sum(total_copy, na.rm = TRUE),
    n_family_copies = sum(total_family_copies, na.rm = TRUE),
    n_multicopy_mags = sum(total_copy >= 2, na.rm = TRUE),
    frac_multicopy = n_multicopy_mags / n_mags,
    .groups = "drop"
  ) %>%
  arrange(desc(n_seq), desc(n_mags), c)

class_keep <- class_n_all %>%
  filter(n_mags >= MIN_ASGARD_CLASS_N)
if (nrow(class_keep) == 0) {
  class_keep_n <- min(as.integer(TOP_N_ASGARD_CLASS), nrow(class_n_all))
  class_keep <- class_n_all %>% head(class_keep_n)
} else {
  class_keep <- class_keep %>% head(TOP_N_ASGARD_CLASS)
}

class_levels <- rev(class_keep$c)
class_label_df <- class_keep %>%
  mutate(class_label = paste0(c, " (n=", fmt_int(n_mags), "; seq=", fmt_int(n_seq), ")"))
class_label_map <- setNames(class_label_df$class_label, class_label_df$c)
class_label_levels <- class_label_map[class_levels]

long_df <- asgard_df %>%
  filter(c %in% class_keep$c) %>%
  select(mag_id, c, total_copy, total_family_copies, all_of(raw_family_cols_present)) %>%
  pivot_longer(
    cols = all_of(raw_family_cols_present),
    names_to = "raw_family",
    values_to = "copy_count"
  ) %>%
  mutate(
    raw_family = factor(raw_family, levels = raw_family_cols_present),
    raw_family_label = family_labels_full[as.character(raw_family)],
    class_label = class_label_map[c]
  )

# ============================================================
# 5. Figure 1: Asgard class-level raw-family copy composition
# ============================================================

fig1_data <- long_df %>%
  group_by(c, class_label, raw_family) %>%
  summarise(n_copies = sum(copy_count, na.rm = TRUE), .groups = "drop") %>%
  complete(
    c,
    class_label,
    raw_family = factor(raw_family_cols_present, levels = raw_family_cols_present),
    fill = list(n_copies = 0L)
  ) %>%
  group_by(c, class_label) %>%
  mutate(
    total_copies = sum(n_copies),
    fraction = if_else(total_copies > 0, n_copies / total_copies, NA_real_)
  ) %>%
  ungroup() %>%
  mutate(
    class_label = factor(class_label, levels = class_label_levels),
    raw_family = factor(raw_family, levels = raw_family_cols_present)
  )

write_tsv_base(
  fig1_data,
  file.path(data_dir, "figure_1_Asgard_class_raw_family_copy_fraction_source_data.tsv")
)

p_fig1 <- ggplot(fig1_data, aes(x = fraction, y = class_label, fill = raw_family)) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.12) +
  scale_fill_manual(values = family_palette, labels = family_labels, drop = FALSE) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.01))) +
  labs(
    x = "Raw-family copy fraction",
    y = NULL,
    fill = "Raw family",
    title = "Asgard raw actin-family copy composition by class",
    subtitle = "Each bar summarizes raw-family copy counts within one Asgard class",
    caption = "Only Asgardarchaeota actin-positive MAGs are included. Raw families are not merged."
  ) +
  theme_nature() +
  theme(
    legend.position = "top",
    legend.justification = "left",
    axis.text.y = element_text(size = 6.0)
  )

fig_height <- max(85, 36 + 4.8 * length(class_levels))
save_figure(
  p_fig1,
  file.path(figure_dir, "figure_1_Asgard_class_raw_family_copy_fraction_stacked_bar"),
  width_mm = 155,
  height_mm = fig_height
)

# ============================================================
# 6. Figure 2: Asgard class-level total_copy distribution
# ============================================================

fig2_data <- asgard_df %>%
  filter(c %in% class_keep$c) %>%
  mutate(
    copy_group = case_when(
      total_copy <= 1 ~ "1",
      total_copy == 2 ~ "2",
      total_copy == 3 ~ "3",
      total_copy >= 4 ~ ">=4",
      TRUE ~ NA_character_
    ),
    copy_group = factor(copy_group, levels = copy_group_levels),
    class_label = class_label_map[c]
  ) %>%
  group_by(c, class_label, copy_group) %>%
  summarise(n_mags = n_distinct(mag_id), .groups = "drop") %>%
  complete(
    c,
    class_label,
    copy_group = factor(copy_group_levels, levels = copy_group_levels),
    fill = list(n_mags = 0L)
  ) %>%
  group_by(c, class_label) %>%
  mutate(
    total_mags = sum(n_mags),
    fraction = if_else(total_mags > 0, n_mags / total_mags, NA_real_)
  ) %>%
  ungroup() %>%
  mutate(class_label = factor(class_label, levels = class_label_levels))

write_tsv_base(
  fig2_data,
  file.path(data_dir, "figure_2_Asgard_class_total_copy_distribution_source_data.tsv")
)

p_fig2 <- ggplot(fig2_data, aes(x = fraction, y = class_label, fill = copy_group)) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.12) +
  scale_fill_manual(values = copy_group_palette, drop = FALSE) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.01))) +
  labs(
    x = "Asgard MAGs (%)",
    y = NULL,
    fill = "Total copy",
    title = "Asgard class-level total copy-number distribution",
    subtitle = "MAGs are grouped by total actin-superfamily copy number",
    caption = "Fractions were calculated within actin-positive MAGs in each Asgard class."
  ) +
  theme_nature() +
  theme(
    legend.position = "top",
    legend.justification = "left",
    axis.text.y = element_text(size = 6.0)
  )

save_figure(
  p_fig2,
  file.path(figure_dir, "figure_2_Asgard_class_total_copy_distribution_stacked_bar"),
  width_mm = 145,
  height_mm = fig_height
)

# ============================================================
# 7. Figure 3: Asgard class-level copy_combo distribution
# ============================================================

combo_counts <- asgard_df %>%
  filter(c %in% class_keep$c) %>%
  count(copy_combo, name = "n_mags") %>%
  arrange(desc(n_mags), copy_combo)
combo_keep_n <- min(as.integer(TOP_N_COMBOS), nrow(combo_counts))
combo_keep <- combo_counts %>%
  head(combo_keep_n) %>%
  pull(copy_combo)
combo_levels <- c(combo_keep, "Other combos")
combo_palette <- setNames(grDevices::hcl.colors(length(combo_levels), palette = "Dark 3"), combo_levels)
if ("Other combos" %in% names(combo_palette)) {
  combo_palette["Other combos"] <- "#BDBDBD"
}

fig3_data <- asgard_df %>%
  filter(c %in% class_keep$c) %>%
  mutate(
    copy_combo_plot = if_else(copy_combo %in% combo_keep, copy_combo, "Other combos"),
    copy_combo_plot = factor(copy_combo_plot, levels = combo_levels),
    class_label = class_label_map[c]
  ) %>%
  group_by(c, class_label, copy_combo_plot) %>%
  summarise(n_mags = n_distinct(mag_id), .groups = "drop") %>%
  complete(
    c,
    class_label,
    copy_combo_plot = factor(combo_levels, levels = combo_levels),
    fill = list(n_mags = 0L)
  ) %>%
  group_by(c, class_label) %>%
  mutate(
    total_mags = sum(n_mags),
    fraction = if_else(total_mags > 0, n_mags / total_mags, NA_real_)
  ) %>%
  ungroup() %>%
  mutate(class_label = factor(class_label, levels = class_label_levels))

write_tsv_base(
  fig3_data,
  file.path(data_dir, "figure_3_Asgard_class_copy_combo_distribution_source_data.tsv")
)

p_fig3 <- ggplot(fig3_data, aes(x = fraction, y = class_label, fill = copy_combo_plot)) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.12) +
  scale_fill_manual(values = combo_palette, drop = FALSE) +
  scale_x_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.01))) +
  labs(
    x = "Asgard MAGs (%)",
    y = NULL,
    fill = "Presence/absence combo",
    title = "Asgard raw-family presence-combo distribution by class",
    subtitle = paste0("Top ", combo_keep_n, " copy_combo categories are shown; remaining categories are grouped"),
    caption = "copy_combo is based on presence/absence of raw families, not exact copy counts."
  ) +
  theme_nature() +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 5.0),
    axis.text.y = element_text(size = 6.0)
  )

save_figure(
  p_fig3,
  file.path(figure_dir, "figure_3_Asgard_class_raw_copy_combo_distribution_stacked_bar"),
  width_mm = 180,
  height_mm = max(fig_height, 105)
)

# ============================================================
# 8. Figure 4: high-copy Asgard MAG-level copy count stacked bar
#    Improvement: facet by Asgard class, so high-copy MAGs can be read by taxonomy.
# ============================================================

highcopy_df <- asgard_df %>%
  filter(total_copy >= 2) %>%
  arrange(desc(total_copy), c, mag_id) %>%
  head(TOP_N_HIGHCOPY_MAG)

if (nrow(highcopy_df) > 0) {
  highcopy_class_n <- highcopy_df %>%
    group_by(c) %>%
    summarise(n_highcopy = n_distinct(mag_id), .groups = "drop") %>%
    arrange(desc(n_highcopy), c)

  highcopy_labels <- highcopy_df %>%
    mutate(
      mag_label = paste0(mag_id, " | copy=", total_copy),
      c = factor(c, levels = highcopy_class_n$c)
    ) %>%
    arrange(c, desc(total_copy), mag_id) %>%
    select(mag_id, mag_label, c)

  fig4_data <- highcopy_df %>%
    select(mag_id, c, total_copy, all_of(raw_family_cols_present)) %>%
    pivot_longer(
      cols = all_of(raw_family_cols_present),
      names_to = "raw_family",
      values_to = "copy_count"
    ) %>%
    left_join(highcopy_labels, by = c("mag_id", "c")) %>%
    mutate(
      c = factor(c, levels = highcopy_class_n$c),
      mag_label = factor(mag_label, levels = rev(unique(highcopy_labels$mag_label))),
      raw_family = factor(raw_family, levels = raw_family_cols_present)
    )

  write_tsv_base(
    fig4_data,
    file.path(data_dir, "figure_4_highcopy_Asgard_MAG_raw_family_copy_count_by_class_source_data.tsv")
  )

  p_fig4 <- ggplot(fig4_data, aes(x = copy_count, y = mag_label, fill = raw_family)) +
    geom_col(width = 0.70, colour = "white", linewidth = 0.10) +
    facet_grid(c ~ ., scales = "free_y", space = "free_y") +
    scale_fill_manual(values = family_palette, labels = family_labels, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +
    labs(
      x = "Copy count",
      y = NULL,
      fill = "Raw family",
      title = "Raw-family composition of high-copy Asgard MAGs",
      subtitle = paste0("Top ", nrow(highcopy_df), " Asgard MAGs ordered by total_copy and faceted by class"),
      caption = "Bars show absolute copy counts, not fractions. Facets indicate Asgard class."
    ) +
    theme_nature() +
    theme(
      legend.position = "top",
      legend.justification = "left",
      strip.text.y = element_text(angle = 0, size = 5.6, face = "bold"),
      axis.text.y = element_text(size = 4.6)
    )

  save_figure(
    p_fig4,
    file.path(figure_dir, "figure_4_highcopy_Asgard_MAG_raw_family_copy_count_stacked_bar_by_class"),
    width_mm = 180,
    height_mm = max(100, 34 + 3.4 * nrow(highcopy_df) + 5.5 * nrow(highcopy_class_n))
  )
} else {
  message("No Asgard MAG with total_copy >= 2; skipping Figure 4.")
}

# ============================================================
# 9. Figure 5: Asgard raw-family co-occurrence network
#    Improvement: use Jaccard similarity as edge weight instead of absolute co-occurrence.
# ============================================================

presence_df <- asgard_df %>%
  select(mag_id, all_of(raw_family_cols_present)) %>%
  mutate(across(all_of(raw_family_cols_present), ~ .x > 0))

node_data <- data.frame(
  raw_family = raw_family_cols_present,
  stringsAsFactors = FALSE
) %>%
  mutate(
    n_mags = vapply(raw_family, function(f) sum(presence_df[[f]], na.rm = TRUE), numeric(1)),
    label = family_short_labels_full[raw_family]
  )

n_family <- nrow(node_data)
angles <- seq(0, 2 * pi, length.out = n_family + 1)[seq_len(n_family)]
node_data$x <- cos(angles)
node_data$y <- sin(angles)
node_data$label_x <- 1.18 * node_data$x
node_data$label_y <- 1.18 * node_data$y

edge_list <- data.frame()
if (n_family >= 2) {
  pair_mat <- utils::combn(raw_family_cols_present, 2)
  edge_list <- data.frame(
    family1 = pair_mat[1, ],
    family2 = pair_mat[2, ],
    stringsAsFactors = FALSE
  ) %>%
    rowwise() %>%
    mutate(
      n_family1 = sum(presence_df[[family1]], na.rm = TRUE),
      n_family2 = sum(presence_df[[family2]], na.rm = TRUE),
      n_cooccur = sum(presence_df[[family1]] & presence_df[[family2]], na.rm = TRUE),
      n_union = sum(presence_df[[family1]] | presence_df[[family2]], na.rm = TRUE),
      jaccard = if_else(n_union > 0, n_cooccur / n_union, 0)
    ) %>%
    ungroup() %>%
    filter(n_cooccur > 0, jaccard >= MIN_JACCARD_EDGE) %>%
    left_join(node_data %>% select(raw_family, x, y), by = c("family1" = "raw_family")) %>%
    rename(x1 = x, y1 = y) %>%
    left_join(node_data %>% select(raw_family, x, y), by = c("family2" = "raw_family")) %>%
    rename(x2 = x, y2 = y)
}

write_tsv_base(node_data, file.path(data_dir, "figure_5_Asgard_raw_family_cooccurrence_nodes.tsv"))
write_tsv_base(edge_list, file.path(data_dir, "figure_5_Asgard_raw_family_cooccurrence_edges_jaccard.tsv"))

p_fig5 <- ggplot() +
  { if (nrow(edge_list) > 0) geom_segment(
      data = edge_list,
      aes(x = x1, y = y1, xend = x2, yend = y2, linewidth = jaccard),
      colour = "#737373",
      alpha = 0.62,
      lineend = "round"
    ) } +
  geom_point(
    data = node_data,
    aes(x = x, y = y, size = n_mags, fill = raw_family),
    shape = 21,
    colour = "black",
    stroke = 0.25
  ) +
  geom_text(
    data = node_data,
    aes(x = label_x, y = label_y, label = label),
    size = 2.15,
    lineheight = 0.86
  ) +
  scale_fill_manual(values = family_palette, guide = "none") +
  scale_size_continuous(name = "MAGs with family", range = c(2.5, 8.0), labels = comma) +
  scale_linewidth_continuous(name = "Jaccard similarity", range = c(0.25, 2.4), labels = number_format(accuracy = 0.01)) +
  coord_equal(xlim = c(-1.42, 1.42), ylim = c(-1.42, 1.42), clip = "off") +
  labs(
    title = "Jaccard co-occurrence network of raw actin families in Asgard MAGs",
    subtitle = "Node size indicates family occurrence; edge width indicates Jaccard similarity",
    caption = "Jaccard = co-occurring MAGs / MAGs containing either family. Absolute co-occurrence counts are provided in source data."
  ) +
  theme_void(base_size = 7, base_family = "sans") +
  theme(
    plot.title = element_text(size = 7.7, face = "bold"),
    plot.subtitle = element_text(size = 6.8, colour = "#4D4D4D"),
    plot.caption = element_text(size = 6.0, colour = "#4D4D4D", hjust = 0),
    legend.position = "right",
    plot.margin = margin(6, 6, 6, 6)
  )

save_figure(
  p_fig5,
  file.path(figure_dir, "figure_5_Asgard_raw_family_cooccurrence_network_jaccard"),
  width_mm = 135,
  height_mm = 115
)

# ============================================================
# 10. Figure 6: optional clustered heatmap of high-copy Asgard MAGs
# ============================================================

if (PLOT_CLUSTERED_HEATMAP) {
  heatmap_df <- asgard_df %>%
    filter(total_copy >= 2) %>%
    arrange(desc(total_copy), c, mag_id) %>%
    head(TOP_N_HEATMAP_MAG)

  if (nrow(heatmap_df) >= 1) {
    heatmap_matrix <- as.matrix(heatmap_df[, raw_family_cols_present, drop = FALSE])
    rownames(heatmap_matrix) <- heatmap_df$mag_id

    if (nrow(heatmap_matrix) >= 2 && ncol(heatmap_matrix) >= 2) {
      row_order <- rownames(heatmap_matrix)[stats::hclust(stats::dist(heatmap_matrix, method = "manhattan"), method = "average")$order]
    } else {
      row_order <- rownames(heatmap_matrix)
    }

    heatmap_labels <- heatmap_df %>%
      mutate(mag_label = paste0(mag_id, " | ", c, " | copy=", total_copy)) %>%
      select(mag_id, mag_label)
    label_map <- setNames(heatmap_labels$mag_label, heatmap_labels$mag_id)

    fig6_data <- heatmap_df %>%
      select(mag_id, c, total_copy, all_of(raw_family_cols_present)) %>%
      pivot_longer(
        cols = all_of(raw_family_cols_present),
        names_to = "raw_family",
        values_to = "copy_count"
      ) %>%
      mutate(
        mag_label = label_map[mag_id],
        mag_label = factor(mag_label, levels = rev(label_map[row_order])),
        raw_family = factor(raw_family, levels = raw_family_cols_present),
        raw_family_label = family_short_labels_full[as.character(raw_family)]
      )

    write_tsv_base(
      fig6_data,
      file.path(data_dir, "figure_6_highcopy_Asgard_MAG_clustered_heatmap_source_data.tsv")
    )

    p_fig6 <- ggplot(fig6_data, aes(x = raw_family, y = mag_label, fill = copy_count)) +
      geom_tile(colour = "white", linewidth = 0.12) +
      geom_text(
        aes(label = if_else(copy_count > 0, as.character(copy_count), "")),
        size = 1.55,
        colour = "black"
      ) +
      scale_x_discrete(labels = family_short_labels_full[raw_family_cols_present]) +
      scale_fill_gradient(low = "#F7FBFF", high = "#084594", breaks = scales::pretty_breaks(n = 4)) +
      labs(
        x = NULL,
        y = NULL,
        fill = "Copy\ncount",
        title = "Clustered raw-family composition of multicopy Asgard MAGs",
        subtitle = paste0("Top ", nrow(heatmap_df), " multicopy Asgard MAGs; rows clustered by raw-family copy vector"),
        caption = "Distance: Manhattan; clustering method: average linkage."
      ) +
      theme_nature() +
      theme(
        axis.line = element_blank(),
        axis.ticks = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 5.4),
        axis.text.y = element_text(size = 4.5),
        legend.position = "right"
      )

    save_figure(
      p_fig6,
      file.path(figure_dir, "figure_6_highcopy_Asgard_MAG_raw_family_clustered_heatmap_optional"),
      width_mm = 145,
      height_mm = max(95, 28 + 3.0 * nrow(heatmap_df))
    )
  } else {
    message("No Asgard MAG with total_copy >= 2; skipping Figure 6.")
  }
}

# ============================================================
# 11. Figure 7: compact overview
# ============================================================

p_fig1_compact <- p_fig1 +
  theme(
    plot.title = element_text(size = 7.4),
    plot.subtitle = element_blank(),
    plot.caption = element_blank(),
    legend.position = "top",
    axis.text.y = element_text(size = 5.0)
  )

p_fig2_compact <- p_fig2 +
  theme(
    plot.title = element_text(size = 7.4),
    plot.subtitle = element_blank(),
    plot.caption = element_blank(),
    legend.position = "top",
    axis.text.y = element_text(size = 5.0)
  )

p_fig3_compact <- p_fig3 +
  theme(
    plot.title = element_text(size = 7.4),
    plot.subtitle = element_blank(),
    plot.caption = element_blank(),
    legend.position = "right",
    axis.text.y = element_text(size = 5.0)
  )

overview <- (p_fig1_compact | p_fig2_compact) / p_fig3_compact +
  plot_layout(heights = c(1, 1.05), widths = c(1, 1)) +
  plot_annotation(
    tag_levels = "a",
    title = "Asgard raw actin-family copy-number patterns",
    caption = "Only Asgardarchaeota actin-positive MAGs are included. Raw families are not merged."
  ) &
  theme_nature()

save_figure(
  overview,
  file.path(figure_dir, "figure_7_Asgard_raw_family_copy_number_overview"),
  width_mm = 190,
  height_mm = max(150, fig_height * 1.35)
)


# ============================================================
# 12. Figure 8: optional class-to-copy_combo chord diagram
#     This is exploratory and requires the circlize package.
# ============================================================

if (PLOT_CHORD_DIAGRAM) {
  if (!requireNamespace("circlize", quietly = TRUE)) {
    message("Package 'circlize' is not installed; skipping optional Figure 8 chord diagram.")
  } else {
    chord_data <- fig3_data %>%
      filter(n_mags > 0) %>%
      mutate(
        class_node = as.character(c),
        combo_node = as.character(copy_combo_plot)
      ) %>%
      select(class_node, combo_node, n_mags)

    write_tsv_base(
      chord_data,
      file.path(data_dir, "figure_8_Asgard_class_copy_combo_chord_source_data.tsv")
    )

    if (nrow(chord_data) > 0) {
      class_nodes <- unique(chord_data$class_node)
      combo_nodes <- unique(chord_data$combo_node)
      class_cols <- setNames(grDevices::hcl.colors(length(class_nodes), palette = "Dynamic"), class_nodes)
      combo_cols <- combo_palette[combo_nodes]
      combo_cols[is.na(combo_cols)] <- "#BDBDBD"
      grid_cols <- c(class_cols, combo_cols)

      draw_chord <- function() {
        circlize::circos.clear()
        circlize::circos.par(
          start.degree = 90,
          gap.after = c(rep(3, max(length(class_nodes) - 1, 0)), 10, rep(3, max(length(combo_nodes) - 1, 0)), 10),
          track.margin = c(0.01, 0.01),
          points.overflow.warning = FALSE
        )
        circlize::chordDiagram(
          x = chord_data,
          grid.col = grid_cols,
          transparency = 0.35,
          annotationTrack = "grid",
          preAllocateTracks = list(track.height = 0.12)
        )
        circlize::circos.trackPlotRegion(
          track.index = 1,
          panel.fun = function(x, y) {
            sector_name <- circlize::get.cell.meta.data("sector.index")
            xlim <- circlize::get.cell.meta.data("xlim")
            ylim <- circlize::get.cell.meta.data("ylim")
            circlize::circos.text(
              x = mean(xlim),
              y = ylim[1],
              labels = sector_name,
              facing = "clockwise",
              niceFacing = TRUE,
              adj = c(0, 0.5),
              cex = 0.42
            )
          },
          bg.border = NA
        )
        title("Asgard class-to-copy_combo relationships", cex.main = 0.82, font.main = 2)
        circlize::circos.clear()
      }

      chord_stem <- file.path(figure_dir, "figure_8_Asgard_class_copy_combo_chord_diagram_optional")
      width_in <- 165 / 25.4
      height_in <- 165 / 25.4
      if (capabilities("cairo")) {
        grDevices::cairo_pdf(paste0(chord_stem, ".pdf"), width = width_in, height = height_in, family = "sans")
      } else {
        grDevices::pdf(paste0(chord_stem, ".pdf"), width = width_in, height = height_in, family = "sans")
      }
      draw_chord()
      grDevices::dev.off()

      if (capabilities("cairo")) {
        grDevices::png(paste0(chord_stem, "_preview.png"), width = width_in, height = height_in, units = "in", res = 300, type = "cairo", bg = "white")
      } else {
        grDevices::png(paste0(chord_stem, "_preview.png"), width = width_in, height = height_in, units = "in", res = 300, bg = "white")
      }
      draw_chord()
      grDevices::dev.off()
    }
  }
}

message("Completed Asgard raw-family visualization.")
message("Input: ", normalizePath(input_file, winslash = "/"))
message("Figures: ", normalizePath(figure_dir, winslash = "/"))
message("Source data: ", normalizePath(data_dir, winslash = "/"))
