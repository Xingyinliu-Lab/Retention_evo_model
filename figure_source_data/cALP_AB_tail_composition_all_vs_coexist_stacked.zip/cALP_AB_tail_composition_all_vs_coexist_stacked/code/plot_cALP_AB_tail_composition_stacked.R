#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
})

root <- ".."
input_file <- file.path(root, "results/copy_associated_AB_v2_orderCV/AB_tail_HILM_composition.tsv")
figure_dir <- file.path(root, "figures")
source_dir <- file.path(figure_dir, "source_data")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

d <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(d) == 16L)

d$scope_label <- factor(
  d$scope,
  levels = c("all_sequences", "coexist_MAG_sequences"),
  labels = c("All sequences", "Coexist MAGs")
)
d$AB <- factor(d$AB, levels = c("A", "B"))
d$tail_label <- factor(
  d$tail_class,
  levels = c("short_or_missing", "low_divergent", "intermediate", "high_euk_like"),
  labels = c("Missing", "Low", "Intermediate", "High")
)

totals <- aggregate(n ~ AB + scope_label, d, sum)
names(totals)[names(totals) == "n"] <- "total_n"
d <- merge(d, totals, by = c("AB", "scope_label"), all.x = TRUE, sort = FALSE)
d$segment_label <- ifelse(
  d$fraction >= 0.045,
  sprintf("%d · %.1f%%", d$n, 100 * d$fraction),
  ""
)

write.table(
  d[, c("scope", "scope_label", "AB", "tail_class", "tail_label", "n", "total_n", "fraction",
          "chi_square", "df", "p_value", "cramers_V")],
  file.path(source_dir, "cALP_AB_tail_composition_all_vs_coexist.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

palette <- c(
  "High" = "#8C6BB1",
  "Intermediate" = "#D9826B",
  "Low" = "#4C9A91",
  "Missing" = "#B8BEC5"
)

p <- ggplot(d, aes(x = scope_label, y = fraction, fill = tail_label)) +
  geom_col(width = 0.68, colour = NA) +
  geom_text(
    aes(label = segment_label),
    position = position_stack(vjust = 0.5),
    colour = "white", size = 2.45, fontface = "bold"
  ) +
  geom_text(
    data = totals,
    aes(x = scope_label, y = 1.025, label = paste0("n = ", total_n)),
    inherit.aes = FALSE, size = 2.75, colour = "#30343B"
  ) +
  facet_grid(. ~ AB, switch = "x") +
  scale_fill_manual(values = palette, breaks = c("High", "Intermediate", "Low", "Missing")) +
  scale_y_continuous(
    limits = c(0, 1.08),
    breaks = seq(0, 1, 0.25),
    labels = paste0(seq(0, 100, 25), "%"),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = NULL,
    y = "Tail-state composition",
    fill = "Tail state"
  ) +
  theme_classic(base_size = 8.5, base_family = "Arial") +
  theme(
    axis.line.x = element_line(linewidth = 0.4, colour = "#202124"),
    axis.line.y = element_line(linewidth = 0.4, colour = "#202124"),
    axis.ticks = element_line(linewidth = 0.35, colour = "#202124"),
    axis.text.x = element_text(size = 8, colour = "#30343B", margin = margin(t = 4)),
    axis.text.y = element_text(size = 7.5, colour = "#30343B"),
    axis.title.y = element_text(size = 8.5, colour = "#202124", margin = margin(r = 7)),
    strip.background = element_blank(),
    strip.text.x = element_text(size = 10, face = "bold", colour = "#202124", margin = margin(b = 4)),
    panel.spacing.x = grid::unit(9, "mm"),
    legend.position = "right",
    legend.title = element_text(size = 8, face = "bold"),
    legend.text = element_text(size = 7.5),
    legend.key.height = grid::unit(4.2, "mm"),
    plot.margin = margin(7, 8, 6, 6)
  ) +
  guides(fill = guide_legend(reverse = FALSE, override.aes = list(colour = NA)))

pdf_file <- file.path(figure_dir, "fig_cALP_AB_tail_composition_all_vs_coexist_stacked.pdf")
png_file <- file.path(figure_dir, "fig_cALP_AB_tail_composition_all_vs_coexist_stacked.png")
grDevices::cairo_pdf(pdf_file, width = 150 / 25.4, height = 88 / 25.4, family = "Arial")
print(p)
dev.off()
png(png_file, width = 150 / 25.4, height = 88 / 25.4, units = "in", res = 450, type = "cairo")
print(p)
dev.off()

writeLines(
  c(
    "status=complete",
    paste0("input=", input_file),
    paste0("pdf=", pdf_file),
    paste0("png=", png_file),
    paste0("completed_at=", format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"))
  ),
  file.path(figure_dir, "CALP_AB_TAIL_COMPOSITION_STACKED_COMPLETE.marker")
)
