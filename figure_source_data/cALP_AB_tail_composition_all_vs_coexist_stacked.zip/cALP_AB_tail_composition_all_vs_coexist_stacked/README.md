# cALP_AB_tail_composition_all_vs_coexist_stacked

- Source figure: `fig_cALP_AB_tail_composition_all_vs_coexist_stacked`
- Analysis basis: tail-state composition of gappyout584-derived A/B sequences in the full cALP set and A+B coexistence MAG subset.
- Contents: final PDF/PNG, R plotting code and the plotted counts, fractions and association statistics.
- Status: included; the former automated1-derived version is superseded.
- Packaging rule: files were copied; the analysis outputs were not moved.
