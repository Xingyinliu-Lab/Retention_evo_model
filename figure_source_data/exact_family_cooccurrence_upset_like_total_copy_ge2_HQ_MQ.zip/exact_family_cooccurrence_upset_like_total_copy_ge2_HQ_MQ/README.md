# 1_exact_family_cooccurrence_upset_like_total_copy_ge2_HQ_MQ

- Manuscript panel: Supp.Fig.10C
- Source figure basename: figure_1_exact_family_cooccurrence_upset_like_total_copy_ge2_HQ_MQ
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 1 final figure asset(s)
- code/: 1 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 2 directly referenced or locally packaged source-data file(s)
