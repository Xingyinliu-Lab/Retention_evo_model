# Representative actin-tail complexes; one object per primary/optional case.
bg_color white
set ray_opaque_background, off
set cartoon_fancy_helices, 1

# primary_01: 8VKH - Gelsolin
load ..
hide everything, p8vkh
show cartoon, p8vkh and (chain E or chain H)
color gray80, p8vkh and chain E
color marine, p8vkh and chain H
select p8vkh_body, p8vkh and chain E and resi 351-372
select p8vkh_kcf, p8vkh and chain E and resi 373-375
show sticks, p8vkh_body or p8vkh_kcf
color orange, p8vkh_body
color red, p8vkh_kcf
disable p8vkh

# primary_02: 7PLZ - Unconventional myosin-Va
load ..
hide everything, p7plz
show cartoon, p7plz and (chain C or chain A)
color gray80, p7plz and chain C
color marine, p7plz and chain A
select p7plz_body, p7plz and chain C and resi 351-372
select p7plz_kcf, p7plz and chain C and resi 373-375
show sticks, p7plz_body or p7plz_kcf
color orange, p7plz_body
color red, p7plz_kcf
disable p7plz

# primary_03: 2PBD - Profilin-1 and VASP poly-proline/GAB domain
load ..
hide everything, p2pbd
show cartoon, p2pbd and (chain A or chain P+V)
color gray80, p2pbd and chain A
color marine, p2pbd and chain P+V
select p2pbd_body, p2pbd and chain A and resi 351-372
select p2pbd_kcf, p2pbd and chain A and resi 373-375
show sticks, p2pbd_body or p2pbd_kcf
color orange, p2pbd_body
color red, p2pbd_kcf
disable p2pbd

# primary_04: 3TPQ - MAL RPEL domain
load ..
hide everything, p3tpq
show cartoon, p3tpq and (chain A or chain M)
color gray80, p3tpq and chain A
color marine, p3tpq and chain M
select p3tpq_body, p3tpq and chain A and resi 351-372
select p3tpq_kcf, p3tpq and chain A and resi 373-375
show sticks, p3tpq_body or p3tpq_kcf
color orange, p3tpq_body
color red, p3tpq_kcf
disable p3tpq

# primary_05: 4B1V - PHACTR1 RPEL-N domain
load ..
hide everything, p4b1v
show cartoon, p4b1v and (chain A or chain M)
color gray80, p4b1v and chain A
color marine, p4b1v and chain M
select p4b1v_body, p4b1v and chain A and resi 351-372
select p4b1v_kcf, p4b1v and chain A and resi 373-375
show sticks, p4b1v_body or p4b1v_kcf
color orange, p4b1v_body
color red, p4b1v_kcf
disable p4b1v

# primary_06: 7R94 - T-Plastin
load ..
hide everything, p7r94
show cartoon, p7r94 and (chain C or chain F)
color gray80, p7r94 and chain C
color marine, p7r94 and chain F
select p7r94_body, p7r94 and chain C and resi 350-371
select p7r94_kcf, p7r94 and chain C and resi 372-374
show sticks, p7r94_body or p7r94_kcf
color orange, p7r94_body
color red, p7r94_kcf
disable p7r94

# optional_not_primary: 9QFK - Coronin-1B within a cofilin-decorated actin filament
load ..
hide everything, p9qfk
show cartoon, p9qfk and (chain B or chain K)
color gray80, p9qfk and chain B
color marine, p9qfk and chain K
select p9qfk_body, p9qfk and chain B and resi 351-372
select p9qfk_kcf, p9qfk and chain B and resi 373-375
show sticks, p9qfk_body or p9qfk_kcf
color orange, p9qfk_body
color red, p9qfk_kcf
disable p9qfk
# Enable one object, e.g. enable p8vkh
