suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

work <- ".."
source_dir <- file.path(work, "source_data")
figure_dir <- file.path(work, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

wilson_ci <- function(k, n, z = 1.96) {
  if (n == 0) return(c(NA_real_, NA_real_))
  p <- k / n
  den <- 1 + z^2 / n
  cen <- (p + z^2 / (2 * n)) / den
  half <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) / den
  c(max(0, cen - half), min(1, cen + half))
}

save_figure <- function(plot, stem, width_mm = 183, height_mm = 112) {
  ggsave(paste0(stem, ".pdf"), plot, width = width_mm, height = height_mm,
         units = "mm", device = grDevices::cairo_pdf, bg = "white")
  ggsave(paste0(stem, ".png"), plot, width = width_mm, height = height_mm,
         units = "mm", device = ragg::agg_png, res = 600, bg = "white")
}

palette <- c(
  "Tail body (HMM386-407)" = "#2F78B7",
  "Terminal KCF (HMM408-410)" = "#D9822B"
)

contacts <- read_tsv(
  file.path(source_dir, "formal_483_direct_nonactin_tail_contacts_3A_5A.tsv"),
  show_col_types = FALSE
)
contexts <- read_tsv(
  file.path(source_dir, "formal_483_granular_and_broad_context_map.tsv"),
  show_col_types = FALSE
)
region_flags <- read_tsv(
  file.path(source_dir, "formal_483_pdb_region_contact_flags.tsv"),
  show_col_types = FALSE
)

if (n_distinct(contexts$pdb_id) != 483 || any(contacts$status != "ok")) {
  stop("Direct-contact audit must contain 483 PDBs and only ok records")
}

base <- crossing(
  pdb_id = sort(unique(contexts$pdb_id)),
  tail_region = c("tail_body", "terminal_KCF")
)
direct_flags <- contacts %>%
  mutate(
    direct_nonactin_3A = direct_nonactin_3A == "TRUE",
    direct_nonactin_5A = direct_nonactin_5A == "TRUE"
  ) %>%
  group_by(pdb_id, tail_region) %>%
  summarise(
    direct_nonactin_3A = any(direct_nonactin_3A),
    direct_nonactin_5A = any(direct_nonactin_5A),
    .groups = "drop"
  )

if (nrow(direct_flags) != nrow(base) ||
    any(direct_flags$direct_nonactin_3A & !direct_flags$direct_nonactin_5A)) {
  stop("Direct-contact PDB-region flags are incomplete or violate threshold monotonicity")
}

context_n <- contexts %>% count(broad_context, name = "n_context_pdb")
figure_source <- base %>%
  left_join(direct_flags, by = c("pdb_id", "tail_region")) %>%
  left_join(contexts %>% select(pdb_id, broad_context), by = "pdb_id") %>%
  mutate(
    region_label = recode(
      tail_region,
      tail_body = "Tail body (HMM386-407)",
      terminal_KCF = "Terminal KCF (HMM408-410)"
    )
  ) %>%
  pivot_longer(
    cols = c(direct_nonactin_3A, direct_nonactin_5A),
    names_to = "metric", values_to = "positive"
  ) %>%
  mutate(
    metric = recode(
      metric,
      direct_nonactin_3A = "Direct non-actin partner contact at 3 A",
      direct_nonactin_5A = "Direct non-actin partner contact at 5 A"
    )
  ) %>%
  group_by(broad_context, region_label, metric) %>%
  summarise(
    n_pdb = n(), n_positive = sum(positive), prevalence = n_positive / n_pdb,
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(
    ci = list(wilson_ci(n_positive, n_pdb)), ci_low = ci[[1]], ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci) %>%
  left_join(context_n, by = "broad_context") %>%
  mutate(
    context_label = paste0(broad_context, " (n=", n_context_pdb, ")"),
    metric = factor(metric, levels = c(
      "Direct non-actin partner contact at 3 A",
      "Direct non-actin partner contact at 5 A"
    )),
    region_label = factor(region_label, levels = names(palette)),
    main_plot_eligible = n_context_pdb >= 10
  )

context_order <- context_n %>%
  arrange(n_context_pdb) %>%
  transmute(context_label = paste0(broad_context, " (n=", n_context_pdb, ")")) %>%
  pull(context_label)
figure_source$context_label <- factor(figure_source$context_label, levels = context_order)

write_tsv(
  figure_source,
  file.path(source_dir, "fig02_context_specific_direct_nonactin_partner_3A_5A_source.tsv")
)

fig <- ggplot(
  filter(figure_source, main_plot_eligible),
  aes(x = prevalence, y = context_label, colour = region_label)
) +
  geom_errorbar(
    aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = 0.18,
    linewidth = 0.38, position = position_dodge(width = 0.45)
  ) +
  geom_point(size = 2.2, position = position_dodge(width = 0.45)) +
  facet_wrap(~metric, ncol = 2) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    labels = label_percent(accuracy = 1), breaks = seq(0, 1, 0.25), limits = c(0, 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Direct non-actin contacts vary by tail segment and context",
    subtitle = "Coordinate-recalculated for 483 classical eukaryotic actin PDB entries; displayed contexts n >= 10",
    x = "PDB-level prevalence", y = NULL, colour = NULL,
    caption = paste(
      "Points show prevalence; error bars show Wilson 95% confidence intervals.",
      "\nPDB entries are descriptive units, not independent biological replicates."
    )
  ) +
  theme_classic(base_family = "Arial", base_size = 7.6) +
  theme(
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(colour = "#555555"),
    plot.caption = element_text(colour = "#666666", hjust = 0),
    legend.position = "top", legend.justification = "left",
    strip.background = element_rect(fill = "#F2F2F2", colour = NA),
    strip.text = element_text(hjust = 0), panel.spacing.x = grid::unit(8, "mm"),
    plot.margin = margin(8, 14, 8, 8)
  )

save_figure(
  fig,
  file.path(figure_dir, "fig02_context_specific_direct_nonactin_partner_3A_5A"),
  183, 112
)

# Strict 3 A analogue of the original Figure 2: all-chain contact versus the
# coordinate-recalculated direct non-actin partner contact.
any_3a_flags <- region_flags %>%
  select(pdb_id, tail_region, any_contact_3A) %>%
  mutate(any_contact_3A = any_contact_3A == "TRUE")
if (nrow(any_3a_flags) != nrow(base)) {
  stop("Any-contact 3 A PDB-region table is incomplete")
}

figure_3a_dual_source <- base %>%
  left_join(any_3a_flags, by = c("pdb_id", "tail_region")) %>%
  left_join(direct_flags %>% select(pdb_id, tail_region, direct_nonactin_3A),
            by = c("pdb_id", "tail_region")) %>%
  left_join(contexts %>% select(pdb_id, broad_context), by = "pdb_id") %>%
  mutate(
    region_label = recode(
      tail_region,
      tail_body = "Tail body (HMM386-407)",
      terminal_KCF = "Terminal KCF (HMM408-410)"
    )
  ) %>%
  pivot_longer(
    cols = c(any_contact_3A, direct_nonactin_3A),
    names_to = "metric", values_to = "positive"
  ) %>%
  mutate(
    metric = recode(
      metric,
      any_contact_3A = "Any 3 A contact",
      direct_nonactin_3A = "Direct non-actin partner contact at 3 A"
    )
  ) %>%
  group_by(broad_context, region_label, metric) %>%
  summarise(
    n_pdb = n(), n_positive = sum(positive), prevalence = n_positive / n_pdb,
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(
    ci = list(wilson_ci(n_positive, n_pdb)), ci_low = ci[[1]], ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci) %>%
  left_join(context_n, by = "broad_context") %>%
  mutate(
    context_label = paste0(broad_context, " (n=", n_context_pdb, ")"),
    metric = factor(metric, levels = c("Any 3 A contact", "Direct non-actin partner contact at 3 A")),
    region_label = factor(region_label, levels = names(palette)),
    main_plot_eligible = n_context_pdb >= 10
  )
figure_3a_dual_source$context_label <- factor(
  figure_3a_dual_source$context_label, levels = context_order
)

write_tsv(
  figure_3a_dual_source,
  file.path(source_dir, "fig02_context_specific_any_vs_direct_nonactin_3A_source.tsv")
)

fig_3a_dual <- ggplot(
  filter(figure_3a_dual_source, main_plot_eligible),
  aes(x = prevalence, y = context_label, colour = region_label)
) +
  geom_errorbar(
    aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = 0.18,
    linewidth = 0.38, position = position_dodge(width = 0.45)
  ) +
  geom_point(size = 2.2, position = position_dodge(width = 0.45)) +
  facet_wrap(~metric, ncol = 2) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    labels = label_percent(accuracy = 1), breaks = seq(0, 1, 0.25), limits = c(0, 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Strict 3 A: any tail contact versus direct non-actin contact",
    subtitle = "483 classical eukaryotic actin PDB entries; displayed contexts contain at least 10 PDB entries",
    x = "PDB-level prevalence", y = NULL, colour = NULL,
    caption = paste(
      "Points show prevalence; error bars show Wilson 95% confidence intervals.",
      "\nPDB entries are descriptive units, not independent biological replicates."
    )
  ) +
  theme_classic(base_family = "Arial", base_size = 7.6) +
  theme(
    plot.title = element_text(face = "bold", size = 12),
    plot.subtitle = element_text(colour = "#555555"),
    plot.caption = element_text(colour = "#666666", hjust = 0),
    legend.position = "top", legend.justification = "left",
    strip.background = element_rect(fill = "#F2F2F2", colour = NA),
    strip.text = element_text(hjust = 0), panel.spacing.x = grid::unit(8, "mm"),
    plot.margin = margin(8, 14, 8, 8)
  )

save_figure(
  fig_3a_dual,
  file.path(figure_dir, "fig02_context_specific_any_vs_direct_nonactin_3A"),
  183, 112
)

write_lines(
  c(
    "formal_classical_eukaryotic_actin_pdb\t483",
    "coordinate_audit_rows\t3522",
    "direct_partner_definition\tA non-classical-actin protein chain with at least one non-hydrogen atom within the stated threshold of a mapped tail residue",
    "thresholds\t3 A; 5 A",
    "main_context_minimum_pdb\t10",
    "fig02_3a_dual_definition\tleft panel any-chain 3 A contact; right panel coordinate-recalculated direct non-actin protein contact at 3 A"
  ),
  file.path(work, "docs", "FIG02_DIRECT_NONACTIN_3A_5A_CONTRACT_20260731.tsv")
)

message("Direct non-actin figure written for 483 PDBs")
