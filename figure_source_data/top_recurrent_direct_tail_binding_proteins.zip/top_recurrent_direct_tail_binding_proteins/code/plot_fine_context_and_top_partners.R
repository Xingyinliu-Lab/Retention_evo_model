suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

root <- ".."
work <- file.path(root, "visualization_20260731")
source_dir <- file.path(work, "source_data")
figure_dir <- file.path(work, "figures")
search_dir <- file.path(root, "rcsb_actin_complex_search")

palette <- c(
  "Tail body (HMM386-407)" = "#3976A8",
  "Terminal KCF (HMM408-410)" = "#D88435"
)

theme_tail <- function(base_size = 8) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "#222222"),
      axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
      axis.text = element_text(colour = "#222222"),
      axis.title = element_text(colour = "#222222"),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 0.5),
      plot.title = element_text(size = base_size + 1.5, face = "bold"),
      plot.subtitle = element_text(size = base_size, colour = "#4D4D4D"),
      plot.caption = element_text(size = base_size - 1, colour = "#666666", hjust = 0),
      panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E6E6E6"),
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 12, 8, 8)
    )
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 600) {
  ggsave(
    paste0(stem, ".pdf"), plot,
    device = grDevices::cairo_pdf,
    width = width_mm, height = height_mm, units = "mm", family = "Arial"
  )
  ggsave(
    paste0(stem, ".png"), plot,
    device = ragg::agg_png,
    width = width_mm, height = height_mm, units = "mm",
    dpi = dpi, background = "white"
  )
}

wilson_ci <- function(k, n, z = 1.96) {
  if (n == 0) return(c(NA_real_, NA_real_))
  p <- k / n
  denominator <- 1 + z^2 / n
  center <- (p + z^2 / (2 * n)) / denominator
  half_width <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) / denominator
  c(max(0, center - half_width), min(1, center + half_width))
}

context_map <- read_tsv(
  file.path(source_dir, "formal_483_granular_and_broad_context_map.tsv"),
  show_col_types = FALSE
)
residue <- read_tsv(
  file.path(source_dir, "formal_483_classical_actin_tail_residue_contacts.tsv"),
  show_col_types = FALSE
)

if (n_distinct(context_map$pdb_id) != 483 || n_distinct(residue$pdb_id) != 483) {
  stop("Expected 483 classical eukaryotic actin PDBs")
}

context_census <- context_map %>%
  count(context_final, name = "n_pdb") %>%
  arrange(n_pdb, context_final) %>%
  mutate(
    context_label = gsub("_", " ", context_final),
    context_label = factor(context_label, levels = context_label)
  )

if (nrow(context_census) != 28 || sum(context_census$n_pdb) != 483) {
  stop("Expected 28 granular contexts spanning 483 PDBs")
}

write_tsv(
  context_census,
  file.path(source_dir, "fig03_granular_context_census_source.tsv")
)

fig03 <- ggplot(context_census, aes(x = n_pdb, y = context_label)) +
  geom_segment(aes(x = 0, xend = n_pdb, yend = context_label),
               linewidth = 0.45, colour = "#B8C5CF") +
  geom_point(size = 2.7, colour = "#3976A8") +
  geom_text(aes(label = n_pdb), hjust = -0.35, size = 2.4, colour = "#222222") +
  scale_x_continuous(
    breaks = c(0, 25, 50, 75, 100),
    limits = c(0, 106),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "The audited actin structure atlas resolves into 28 functional contexts",
    subtitle = "Fine-grained labels after excluding short peptides, bacterial actin-like proteins and non-actin false calls",
    x = "PDB entries containing classical eukaryotic actin",
    y = NULL,
    caption = "Each PDB contributes once to its primary fine-grained context."
  ) +
  theme_tail(6.6) +
  theme(
    panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E6E6E6"),
    axis.text.y = element_text(size = 5.8)
  )

save_figure(
  fig03,
  file.path(figure_dir, "fig03_granular_actin_structure_context_census"),
  183, 180
)

entities <- read_tsv(
  file.path(search_dir, "rcsb_actin_complex_candidate_entities.tsv"),
  show_col_types = FALSE
)

formal_ids <- unique(context_map$pdb_id)
nonclassical_pattern <- paste(
  "actin-like protein\\s*(?:2|3|6A)\\b",
  "SWI/SNF-related",
  "actin-dependent regulator",
  "F-actin-capping protein",
  "actin nucleation-promoting",
  "PP1-alpha",
  "Actin-like ATPase",
  "Actin/actin family protein",
  sep = "|"
)

chain_entity_map <- entities %>%
  filter(pdb_id %in% formal_ids, entity_polymer_type == "Protein") %>%
  mutate(
    is_classical_actin = is_actin_entity & (
      actin_call_reason == "actin_uniprot" |
        !grepl(nonclassical_pattern, entity_description, ignore.case = TRUE)
    )
  ) %>%
  select(pdb_id, auth_asym_ids, entity_description, is_classical_actin) %>%
  separate_rows(auth_asym_ids, sep = ";") %>%
  transmute(
    pdb_id,
    partner_chain = auth_asym_ids,
    partner_entity_description = entity_description,
    is_classical_actin
  ) %>%
  distinct()

all_partner_contacts_long <- residue %>%
  filter(tail_region %in% c("tail_body", "terminal_KCF")) %>%
  filter(!is.na(partner_chains_5A), partner_chains_5A != "") %>%
  select(pdb_id, tail_region, hmm_pos, actin_chain, partner_chains_5A) %>%
  separate_rows(partner_chains_5A, sep = ";") %>%
  rename(partner_chain = partner_chains_5A) %>%
  inner_join(chain_entity_map, by = c("pdb_id", "partner_chain")) %>%
  mutate(
    partner_entity_key = case_when(
      tolower(trimws(partner_entity_description)) == "gelsolin" ~ "gelsolin",
      TRUE ~ tolower(trimws(partner_entity_description))
    ),
    partner_entity_display = case_when(
      partner_entity_key == "gelsolin" ~ "Gelsolin",
      TRUE ~ partner_entity_description
    )
  )

partner_contacts_long <- all_partner_contacts_long %>%
  filter(!is_classical_actin)

partner_contacts <- partner_contacts_long %>%
  distinct(pdb_id, tail_region, partner_entity_description)

mapping_coverage <- partner_contacts %>%
  summarise(n_partner_contact_records = n())
if (mapping_coverage$n_partner_contact_records == 0) {
  stop("No direct protein partner contacts could be mapped")
}

partner_summary <- partner_contacts %>%
  left_join(
    partner_contacts_long %>%
      distinct(partner_entity_description, partner_entity_key, partner_entity_display),
    by = "partner_entity_description"
  ) %>%
  count(partner_entity_key, partner_entity_display, tail_region, name = "n_pdb") %>%
  complete(
    partner_entity_key, partner_entity_display,
    tail_region = c("tail_body", "terminal_KCF"),
    fill = list(n_pdb = 0)
  ) %>%
  pivot_wider(names_from = tail_region, values_from = n_pdb) %>%
  mutate(
    rank_score = tail_body + terminal_KCF,
    max_pdb_support = pmax(tail_body, terminal_KCF)
  ) %>%
  arrange(desc(rank_score), desc(max_pdb_support), partner_entity_display)

top_partners <- partner_summary %>%
  filter(max_pdb_support >= 3) %>%
  slice_head(n = 15) %>%
  mutate(
    partner_label = partner_entity_display,
    partner_label = factor(partner_label, levels = rev(partner_label))
  )

write_tsv(
  partner_summary,
  file.path(source_dir, "fig04_all_direct_tail_binding_protein_ranking.tsv")
)
write_tsv(
  top_partners,
  file.path(source_dir, "fig04_top15_direct_tail_binding_proteins_source.tsv")
)

partner_long <- top_partners %>%
  select(partner_label, tail_body, terminal_KCF) %>%
  pivot_longer(
    cols = c(tail_body, terminal_KCF),
    names_to = "tail_region", values_to = "n_pdb"
  ) %>%
  mutate(
    region_label = recode(
      tail_region,
      tail_body = "Tail body (HMM386-407)",
      terminal_KCF = "Terminal KCF (HMM408-410)"
    ),
    region_label = factor(region_label, levels = names(palette))
  )

partner_wide <- top_partners %>%
  select(partner_label, tail_body, terminal_KCF)

fig04 <- ggplot(partner_long, aes(x = n_pdb, y = partner_label, colour = region_label)) +
  geom_segment(
    data = partner_wide,
    aes(
      x = pmin(tail_body, terminal_KCF),
      xend = pmax(tail_body, terminal_KCF),
      y = partner_label, yend = partner_label
    ),
    inherit.aes = FALSE,
    linewidth = 0.6, colour = "#C7C7C7"
  ) +
  geom_point(size = 2.55) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    breaks = seq(0, max(partner_long$n_pdb) + 2, by = 5),
    expand = expansion(mult = c(0.02, 0.08))
  ) +
  labs(
    title = "Recurrent tail-binding proteins differ by tail segment",
    subtitle = "Top 15 direct non-actin protein partners at 5 A, ranked by PDB-level support",
    x = "PDB entries with direct 5 Å tail contact",
    y = NULL,
    caption = "A PDB is counted once per partner and tail region. Rank score = tail body support + KCF support."
  ) +
  theme_tail(7.2) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    axis.text.y = element_text(size = 6.5)
  )

save_figure(
  fig04,
  file.path(figure_dir, "fig04_top_recurrent_direct_tail_binding_proteins"),
  183, 140
)

# Replace raw PDB counts in the formal Figure 4 with confidence conditional on
# partner availability. This corrects for partners represented by very different
# numbers of deposited complex structures.
write_tsv(
  partner_summary,
  file.path(source_dir, "fig04_raw_direct_tail_binding_protein_counts.tsv")
)

partner_available <- chain_entity_map %>%
  filter(!is_classical_actin) %>%
  mutate(
    partner_entity_key = case_when(
      tolower(trimws(partner_entity_description)) == "gelsolin" ~ "gelsolin",
      TRUE ~ tolower(trimws(partner_entity_description))
    ),
    partner_entity_display = case_when(
      partner_entity_key == "gelsolin" ~ "Gelsolin",
      TRUE ~ partner_entity_description
    )
  ) %>%
  distinct(pdb_id, partner_entity_key, partner_entity_display) %>%
  count(partner_entity_key, partner_entity_display, name = "n_available_pdb")

partner_direct <- partner_contacts_long %>%
  distinct(pdb_id, tail_region, partner_entity_key, partner_entity_display) %>%
  count(partner_entity_key, partner_entity_display, tail_region, name = "n_direct_pdb")

partner_confidence_long <- partner_available %>%
  crossing(tail_region = c("tail_body", "terminal_KCF")) %>%
  left_join(
    partner_direct,
    by = c("partner_entity_key", "partner_entity_display", "tail_region")
  ) %>%
  mutate(n_direct_pdb = replace_na(n_direct_pdb, 0L)) %>%
  rowwise() %>%
  mutate(
    direct_probability = n_direct_pdb / n_available_pdb,
    ci = list(wilson_ci(n_direct_pdb, n_available_pdb)),
    ci_low = ci[[1]],
    ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci)

partner_confidence_wide <- partner_confidence_long %>%
  select(
    partner_entity_key, partner_entity_display, n_available_pdb, tail_region,
    n_direct_pdb, direct_probability, ci_low, ci_high
  ) %>%
  pivot_wider(
    names_from = tail_region,
    values_from = c(n_direct_pdb, direct_probability, ci_low, ci_high)
  ) %>%
  mutate(
    rank_confidence = pmax(ci_low_tail_body, ci_low_terminal_KCF),
    max_direct_support = pmax(n_direct_pdb_tail_body, n_direct_pdb_terminal_KCF)
  ) %>%
  arrange(desc(rank_confidence), desc(max_direct_support), desc(n_available_pdb))

top_partners_confidence <- partner_confidence_wide %>%
  filter(n_available_pdb >= 5, max_direct_support >= 3) %>%
  slice_head(n = 15) %>%
  mutate(
    partner_label = paste0(partner_entity_display, " (n=", n_available_pdb, ")"),
    partner_label = factor(partner_label, levels = rev(partner_label))
  )

write_tsv(
  partner_confidence_long,
  file.path(source_dir, "fig04_all_direct_tail_binding_protein_confidence.tsv")
)
write_tsv(
  top_partners_confidence,
  file.path(source_dir, "fig04_top15_direct_tail_binding_protein_confidence_source.tsv")
)
write_tsv(
  top_partners_confidence,
  file.path(source_dir, "fig04_top15_direct_tail_binding_proteins_source.tsv")
)

partner_confidence_plot_long <- top_partners_confidence %>%
  select(
    partner_label, n_available_pdb,
    n_direct_pdb_tail_body, n_direct_pdb_terminal_KCF,
    direct_probability_tail_body, direct_probability_terminal_KCF,
    ci_low_tail_body, ci_low_terminal_KCF, ci_high_tail_body, ci_high_terminal_KCF
  ) %>%
  pivot_longer(
    cols = -c(partner_label, n_available_pdb),
    names_to = c(".value", "tail_region"),
    names_pattern = "(n_direct_pdb|direct_probability|ci_low|ci_high)_(tail_body|terminal_KCF)"
  ) %>%
  mutate(
    region_label = recode(
      tail_region,
      tail_body = "Tail body (HMM386-407)",
      terminal_KCF = "Terminal KCF (HMM408-410)"
    ),
    region_label = factor(region_label, levels = names(palette))
  )

partner_confidence_plot_wide <- top_partners_confidence %>%
  select(partner_label, direct_probability_tail_body, direct_probability_terminal_KCF)

fig04_confidence <- ggplot(
  partner_confidence_plot_long,
  aes(x = direct_probability, y = partner_label, colour = region_label)
) +
  geom_segment(
    data = partner_confidence_plot_wide,
    aes(
      x = pmin(direct_probability_tail_body, direct_probability_terminal_KCF),
      xend = pmax(direct_probability_tail_body, direct_probability_terminal_KCF),
      y = partner_label, yend = partner_label
    ),
    inherit.aes = FALSE, linewidth = 0.55, colour = "#C7C7C7"
  ) +
  geom_errorbar(
    aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = 0.17,
    linewidth = 0.35, position = position_dodge(width = 0.42)
  ) +
  geom_point(size = 2.35, position = position_dodge(width = 0.42)) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    labels = label_percent(accuracy = 1), breaks = seq(0, 1, 0.25), limits = c(0, 1),
    expand = expansion(mult = c(0, 0.03))
  ) +
  labs(
    title = "Direct tail-contact confidence conditional on partner availability",
    subtitle = "Top partners ranked by the higher Wilson 95% lower bound across tail body and terminal KCF",
    x = "Direct-contact probability among PDBs containing the partner (Wilson 95% CI)",
    y = NULL, colour = NULL,
    caption = "n in each label = PDBs containing the partner; eligibility requires n >= 5 and at least 3 direct-contact PDBs."
  ) +
  theme_tail(7.0) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    axis.text.y = element_text(size = 6.2)
  )

save_figure(
  fig04_confidence,
  file.path(figure_dir, "fig04_top_recurrent_direct_tail_binding_proteins"),
  183, 140
)

# Fig. 5: residue-level support separately resolves classical actin-chain and
# non-actin protein contacts directly observed within 5 A of a mapped tail residue.
residue_support <- all_partner_contacts_long %>%
  mutate(contact_type = if_else(
    is_classical_actin,
    "Classical actin-chain contact",
    "Non-actin protein contact"
  )) %>%
  distinct(pdb_id, hmm_pos, tail_region, contact_type) %>%
  count(hmm_pos, tail_region, contact_type, name = "n_pdb_direct_partner") %>%
  complete(
    hmm_pos = 386:410,
    tail_region = c("tail_body", "terminal_KCF"),
    contact_type = c("Non-actin protein contact", "Classical actin-chain contact"),
    fill = list(n_pdb_direct_partner = 0)
  ) %>%
  filter(
    (tail_region == "tail_body" & hmm_pos >= 386 & hmm_pos <= 407) |
      (tail_region == "terminal_KCF" & hmm_pos >= 408 & hmm_pos <= 410)
  ) %>%
  mutate(
    contact_fraction = n_pdb_direct_partner / length(formal_ids),
    x_plot = hmm_pos + if_else(
      contact_type == "Classical actin-chain contact", -0.13, 0.13
    )
  )

write_tsv(
  residue_support,
  file.path(source_dir, "fig05_tail_residue_direct_partner_support_source.tsv")
)

fig05 <- ggplot(residue_support, aes(x = x_plot, y = contact_fraction, colour = contact_type)) +
  annotate("rect", xmin = 407.5, xmax = 410.5, ymin = -Inf, ymax = Inf,
           fill = "#FCE5CD", alpha = 0.60) +
  geom_hline(yintercept = 0, linewidth = 0.35, colour = "#7A7A7A") +
  geom_segment(aes(xend = x_plot, yend = 0), linewidth = 0.85) +
  geom_point(size = 2.7) +
  scale_x_continuous(breaks = c(386, 390, 394, 398, 402, 406, 408, 410)) +
  scale_y_continuous(labels = label_percent(accuracy = 1), limits = c(0, NA), expand = expansion(mult = c(0.03, 0.12))) +
  scale_colour_manual(values = c(
    "Classical actin-chain contact" = "#6A3D9A",
    "Non-actin protein contact" = "#178F8F"
  )) +
  labs(
    title = "Actin-chain and non-actin protein contacts across the tail",
    subtitle = "PDB-level 5 A contacts; orange block = terminal KCF (HMM408-410)",
    x = "Mapped tail HMM position",
    y = "Structures with direct contact",
    colour = NULL,
    caption = "A PDB is counted once at each HMM position and contact class. Adjacent points are offset only to avoid overlap."
  ) +
  theme_classic(base_family = "Arial", base_size = 11) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(colour = "#555555"),
    legend.position = "top",
    axis.text.x = element_text(size = 8),
    plot.caption = element_text(colour = "#666666", hjust = 0),
    plot.margin = margin(8, 14, 8, 8)
  )

save_figure(
  fig05,
  file.path(figure_dir, "fig05_tail_residue_direct_partner_support"),
  183, 98
)

write_lines(
  c(
    "fine_grained_contexts\t28",
    "formal_classical_euk_actin_pdb\t483",
    paste0("top_partner_threshold\tn_available_pdb >=5 and maximum direct tail-region support >=3 PDBs"),
    paste0("top_partner_displayed\t", nrow(top_partners)),
    "partner_definition\tprotein entity mapped from a direct 5 A contact chain; classical actin chains and nonprotein ligands excluded",
    "partner_confidence\tdirect-contact probability conditional on PDB-level partner availability with Wilson 95% interval; formal ranking uses the higher lower confidence bound across the two tail regions",
    "residue_support_definition\tPDB-level direct 5 A contacts separately classified as classical actin-chain or non-actin protein contact at each HMM386-410 tail position"
  ),
  file.path(work, "docs", "FINE_CONTEXT_AND_TOP_PARTNER_FIGURE_CONTRACT_20260731.tsv")
)

message("Fine-grained contexts: ", nrow(context_census))
message("Top partners displayed: ", nrow(top_partners))
