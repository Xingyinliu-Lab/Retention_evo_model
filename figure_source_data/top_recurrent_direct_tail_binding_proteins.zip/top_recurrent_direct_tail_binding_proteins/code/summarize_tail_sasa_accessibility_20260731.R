suppressPackageStartupMessages({ library(dplyr); library(readr); library(tidyr) })

root <- ".."
work <- file.path(root, "visualization_20260731")
out <- file.path(work, "analysis_redundancy_sasa_20260731")
source_dir <- file.path(work, "source_data")

sasa_files <- file.path(out, sprintf("formal_483_tail_sasa_accessibility_20260731_final_shard%02d.tsv", 1:3))
sasa <- lapply(sasa_files, read_tsv, show_col_types = FALSE) %>% bind_rows(.id = "source_run")
key <- c("pdb_id", "actin_chain", "hmm_pos")

# Raw shard files are retained; the merged table is keyed to one formal
# PDB-chain-HMM record before any downstream descriptive summary.
sasa_final <- sasa %>%
  group_by(across(all_of(key))) %>% slice_tail(n = 1) %>% ungroup() %>%
  arrange(pdb_id, actin_chain, hmm_pos)

contact <- read_tsv(file.path(source_dir, "formal_483_classical_actin_tail_residue_contacts.tsv"), show_col_types = FALSE) %>%
  select(pdb_id, actin_chain, hmm_pos, tail_region_contact = tail_region,
         n_atom_contacts_3A, n_atom_contacts_5A, has_nonactin_partner_5A) %>% distinct()
expected <- contact %>% select(all_of(key))
missing <- anti_join(expected, sasa_final %>% select(all_of(key)), by = key)
unexpected <- anti_join(sasa_final %>% select(all_of(key)), expected, by = key)
if (nrow(missing) != 0 || nrow(unexpected) != 0 || nrow(sasa_final) != nrow(expected)) {
  stop("SASA key audit failed")
}

joined <- sasa_final %>%
  select(-source_run) %>%
  inner_join(contact, by = key) %>%
  mutate(
    direct_nonactin_5A = tolower(as.character(has_nonactin_partner_5A)) == "true",
    tail_region = factor(tail_region, levels = c("tail_body", "terminal_KCF")),
    buried_nonactin = delta_sasa_nonactin_A2 > 0,
    buried_all_complex = delta_sasa_all_complex_A2 > 0
  )

position_summary <- joined %>%
  group_by(tail_region, hmm_pos) %>%
  summarise(
    n_records = n(),
    median_delta_sasa_nonactin_A2 = median(delta_sasa_nonactin_A2),
    median_delta_sasa_all_complex_A2 = median(delta_sasa_all_complex_A2),
    proportion_nonactin_buried = mean(buried_nonactin),
    proportion_direct_nonactin_5A = mean(direct_nonactin_5A),
    .groups = "drop"
  )

region_contact_summary <- joined %>%
  group_by(tail_region, direct_nonactin_5A) %>%
  summarise(
    n_records = n(),
    median_delta_sasa_nonactin_A2 = median(delta_sasa_nonactin_A2),
    q25_delta_sasa_nonactin_A2 = quantile(delta_sasa_nonactin_A2, .25),
    q75_delta_sasa_nonactin_A2 = quantile(delta_sasa_nonactin_A2, .75),
    proportion_nonactin_buried = mean(buried_nonactin),
    median_delta_sasa_all_complex_A2 = median(delta_sasa_all_complex_A2),
    .groups = "drop"
  )

fit <- glm(direct_nonactin_5A ~ tail_region * scale(delta_sasa_nonactin_A2),
           family = binomial(), data = joined)
coefs <- as.data.frame(summary(fit)$coefficients)
names(coefs) <- c("estimate", "std_error", "z_value", "p_value")
coefs <- coefs %>% tibble::rownames_to_column("term") %>% mutate(odds_ratio = exp(estimate))

write_tsv(sasa_final, file.path(out, "formal_483_tail_sasa_accessibility_merged_20260731.tsv"))
write_tsv(position_summary, file.path(out, "tail_sasa_accessibility_by_hmm_position_20260731.tsv"))
write_tsv(region_contact_summary, file.path(out, "tail_sasa_accessibility_by_region_and_direct_contact_20260731.tsv"))
write_tsv(coefs, file.path(out, "tail_direct_contact_accessibility_logistic_descriptive_20260731.tsv"))
write_tsv(position_summary, file.path(source_dir, "supplementary_table_tail_HMM386_410_accessibility_summary_20260731.tsv"))

readr::write_lines(c(
  "# Tail accessibility / interface-burial completion audit",
  "", sprintf("Formal expected residue records: %d; merged SASA records: %d.", nrow(expected), nrow(sasa_final)),
  "", "## Interpretation boundary",
  "SASA deltas are accessibility/interface-burial proxies. The logistic model is descriptive because repeated observations from the same deposited structures are not independent.",
  "", "## Input correction",
  "The first unsharded pilot was duplicated during the switch from repeated per-residue calls to whole-chain atom-area aggregation. The merged canonical TSV retains the final atom-aggregation record per PDB-chain-HMM key; all raw files are retained unchanged."
), file.path(out, "SASA_COMPLETION_AUDIT_20260731.md"))
