suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

work <- ".."
source_file <- file.path(work, "source_data", "fig01_tail_body_vs_kcf_contact_prevalence_source.tsv")
figure_dir <- file.path(work, "figures")

palette <- c(
  "Tail body (HMM386-407)" = "#3976A8",
  "Terminal KCF (HMM408-410)" = "#D88435"
)

theme_tail <- function(base_size = 8.5) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "#222222"),
      axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
      axis.text = element_text(colour = "#222222"),
      axis.title = element_text(colour = "#222222"),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 1),
      plot.title = element_text(size = base_size + 1.5, face = "bold"),
      plot.subtitle = element_text(size = base_size, colour = "#4D4D4D"),
      plot.caption = element_text(size = base_size - 1, colour = "#666666", hjust = 0),
      panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E6E6E6"),
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 8, 8, 8)
    )
}

figure1_source <- read_tsv(source_file, show_col_types = FALSE) %>%
  mutate(
    threshold_num = parse_number(as.character(threshold)),
    threshold_display = factor(
      paste0(threshold_num, " A"),
      levels = c("3 A", "4 A", "5 A", "8 A")
    ),
    region_label = factor(
      region_label,
      levels = c("Tail body (HMM386-407)", "Terminal KCF (HMM408-410)")
    )
  )

stopifnot(nrow(figure1_source) == 8L)

fig01 <- ggplot(
  figure1_source,
  aes(x = threshold_display, y = prevalence, colour = region_label, group = region_label)
) +
  geom_line(linewidth = 0.75) +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high), width = 0.09, linewidth = 0.4) +
  geom_point(size = 2.5, stroke = 0) +
  geom_text(
    aes(label = label), colour = "#222222", size = 2.4,
    vjust = ifelse(figure1_source$region_label == "Tail body (HMM386-407)", -1.15, 1.5),
    show.legend = FALSE
  ) +
  scale_colour_manual(values = palette) +
  scale_y_continuous(
    labels = label_percent(accuracy = 1), breaks = seq(0, 1, 0.2),
    limits = c(0, 1.06), expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Tail body retains broader contact coverage than terminal KCF",
    subtitle = "PDB-level prevalence after classical eukaryotic actin entity audit (n = 483)",
    x = "Heavy-atom distance threshold",
    y = "Structures with at least 1 contact",
    caption = "Points show prevalence; error bars show Wilson 95% confidence intervals."
  ) +
  theme_tail(8.5) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    legend.box.margin = margin(0, 0, 2, 0),
    legend.spacing.x = grid::unit(2, "mm"),
    legend.key.width = grid::unit(7, "mm")
  ) +
  guides(colour = guide_legend(nrow = 1, byrow = TRUE))

stem <- file.path(figure_dir, "fig01_tail_body_vs_terminal_KCF_contact_prevalence")
ggsave(paste0(stem, ".pdf"), fig01, device = grDevices::cairo_pdf,
       width = 125, height = 105, units = "mm", family = "Arial", bg = "white")
ggsave(paste0(stem, ".png"), fig01, device = ragg::agg_png,
       width = 125, height = 105, units = "mm", dpi = 600, background = "white")

stopifnot(all(file.info(paste0(stem, c(".pdf", ".png")))$size > 10000))
writeLines(c(
  "PASS",
  "analysis_rerun=FALSE",
  "source=fig01_tail_body_vs_kcf_contact_prevalence_source.tsv",
  "width_mm=125",
  "height_mm=105",
  "exports=PDF,PNG_600dpi",
  "svg_tiff=FALSE"
), paste0(stem, ".QA.marker"))
