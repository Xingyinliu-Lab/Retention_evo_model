#!/usr/bin/env python3
import csv
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(r"..")
INPUT = ROOT / "batch_tail_contacts" / "structure_context_classification.tsv"
OUT_DIR = ROOT / "visualization_20260731" / "data"
AUDIT_TSV = OUT_DIR / "unclassified_74_context_reaudit.tsv"
SUMMARY_TSV = OUT_DIR / "unclassified_74_context_reaudit_summary.tsv"
BROAD_SUMMARY_TSV = OUT_DIR / "unclassified_74_broad_context_contact_summary.tsv"
STATUS_TSV = OUT_DIR / "unclassified_74_audit_status_summary.tsv"
FORMAL_RETAINED_TSV = OUT_DIR / "unclassified_74_formal_retained_61.tsv"
FORMAL_EXCLUDED_TSV = OUT_DIR / "unclassified_74_formal_excluded_13.tsv"


GROUPS = [
    {
        "ids": {"1KXP", "1LOT", "1MA9"},
        "context": "monomer_sequestration_transport_vitamin_D_binding",
        "broad": "monomer_handling_and_sensing",
        "status": "retain_full_euk_actin_context",
        "evidence": "Full actin bound by vitamin D-binding protein.",
    },
    {
        "ids": {"1SQK"},
        "context": "monomer_handling_beta_thymosin_Ciboulot",
        "broad": "monomer_handling_and_sensing",
        "status": "retain_full_euk_actin_context",
        "evidence": "Ciboulot beta-thymosin-family actin complex.",
    },
    {
        "ids": {"2OAN", "6AV9", "6AVB"},
        "context": "actin_redox_state_MICAL_oxidation",
        "broad": "polymer_or_actin_state",
        "status": "retain_full_euk_actin_context",
        "evidence": "Oxidized actin structure; contacts primarily report actin state or actin neighbors.",
    },
    {
        "ids": {
            "2Q97", "4CI6", "5CE3", "8J9B", "8JO3", "8JO4",
            "8K6E", "8K6F", "8K6I", "8K6R", "8K6V", "9B2Z",
        },
        "context": "pathogen_toxin_effector_actin_complex",
        "broad": "pathogen_effector",
        "status": "retain_full_euk_actin_context",
        "evidence": "Toxofilin, YopO, or Legionella LnaB effector bound to actin.",
    },
    {
        "ids": {"2V51", "2V52", "2YJE", "2YJF", "3TPQ"},
        "context": "monomer_sensor_MRTF_MAL_RPEL",
        "broad": "monomer_handling_and_sensing",
        "status": "retain_full_euk_actin_context",
        "evidence": "MRTF-A/MAL RPEL motifs bound to G-actin.",
    },
    {
        "ids": {"3D2U"},
        "context": "actin_peptide_only_unrelated_receptor_complex",
        "broad": "peptide_only_or_noncomparable",
        "status": "exclude_peptide_only_no_tail",
        "evidence": "mmCIF contains only a 9-aa entity named Actin; no complete actin tail is analyzable.",
    },
    {
        "ids": {"3DAW"},
        "context": "filament_remodeling_twinfilin_ADF",
        "broad": "filament_remodeling_and_assembly",
        "status": "retain_full_euk_actin_context",
        "evidence": "Twinfilin ADF-homology domain bound to actin.",
    },
    {
        "ids": {"4B1U", "4B1V", "4B1W", "4B1X", "4B1Y", "4B1Z"},
        "context": "monomer_sensor_PHACTR_RPEL",
        "broad": "monomer_handling_and_sensing",
        "status": "retain_full_euk_actin_context",
        "evidence": "Phactr1 RPEL motifs or RPEL assemblies bound to G-actin.",
    },
    {
        "ids": {"4K42", "6U96", "8TRN", "8V30"},
        "context": "small_molecule_or_natural_product_actin_state",
        "broad": "polymer_or_actin_state",
        "status": "retain_full_euk_actin_context",
        "evidence": "Actin with a small-molecule or natural-product ligand; not a protein-partner class.",
    },
    {
        "ids": {"4WYB"},
        "context": "nucleation_elongation_Bud6",
        "broad": "filament_remodeling_and_assembly",
        "status": "retain_full_euk_actin_context",
        "evidence": "Bud6 flank domain bound to actin.",
    },
    {
        "ids": {"5LJV", "8R2N"},
        "context": "non_eukaryotic_actin_like_filament",
        "broad": "peptide_only_or_noncomparable",
        "status": "exclude_bacterial_actin_like",
        "evidence": "Bacterial MamK/BeeR actin-family filament; retain separately from eukaryotic actin contexts.",
    },
    {
        "ids": {"6FM2"},
        "context": "monomer_recycling_CAP",
        "broad": "monomer_handling_and_sensing",
        "status": "retain_full_euk_actin_context",
        "evidence": "CAP1 CARP domain bound to ADP-actin.",
    },
    {
        "ids": {"6GVC"},
        "context": "signaling_scaffold_ArhGAP12",
        "broad": "signaling_and_cross_cytoskeleton",
        "status": "retain_full_euk_actin_context",
        "evidence": "ArhGAP12 bound to G-actin.",
    },
    {
        "ids": {"6OX4", "6OX5", "6V62", "6V63", "6WK1", "6WK2"},
        "context": "actin_peptide_modification_SETD3",
        "broad": "peptide_only_or_noncomparable",
        "status": "exclude_peptide_only_no_tail",
        "evidence": "SETD3 bound to an actin peptide around His73; no complete C-terminal tail.",
    },
    {
        "ids": {
            "6TU4", "8DMX", "8DMY", "8DNF", "8DNH", "8OI8", "8OID",
            "8THX", "8THY", "8TI3", "8TRM", "8V2O", "8V2Z", "8W36",
            "9BPH", "9BPM",
        },
        "context": "filament_polymer_or_actin_isoform_mutant_state",
        "broad": "polymer_or_actin_state",
        "status": "retain_full_euk_actin_context",
        "evidence": "Eukaryotic or protist actin filament/isoform/mutant state without a distinct protein partner.",
    },
    {
        "ids": {"6ZEJ"},
        "context": "false_positive_PP1_PHACTR_no_actin",
        "broad": "peptide_only_or_noncomparable",
        "status": "exclude_false_positive_no_actin",
        "evidence": "mmCIF polymer is a 363-aa PP1-alpha/Phactr1 chimera; no actin entity is present.",
    },
    {
        "ids": {"7C2G", "7C2H"},
        "context": "filament_remodeling_archaeal_2DGel",
        "broad": "filament_remodeling_and_assembly",
        "status": "retain_full_euk_actin_context",
        "evidence": "Thorarchaeota 2DGel protein bound to rabbit actin.",
    },
    {
        "ids": {"7RNS", "7RNU", "7RNV"},
        "context": "actin_phosphopeptide_SH2_signaling",
        "broad": "peptide_only_or_noncomparable",
        "status": "exclude_peptide_only_no_tail",
        "evidence": "SH2 domain bound to a Tyr53-phosphorylated actin peptide; no complete C-terminal tail.",
    },
    {
        "ids": {"8IB2"},
        "context": "membrane_cytoskeleton_spectrin_dematin_junction",
        "broad": "filament_remodeling_and_assembly",
        "status": "retain_full_euk_actin_context",
        "evidence": "Spectrin-actin membrane-skeleton junction with dematin.",
    },
    {
        "ids": {"8RX1"},
        "context": "microtubule_organizing_center_gTuRC_actin",
        "broad": "signaling_and_cross_cytoskeleton",
        "status": "retain_full_euk_actin_context",
        "evidence": "Human actin is an integral component of a gamma-tubulin ring complex structure.",
    },
    {
        "ids": {"9JUS", "9JVT", "9JW0"},
        "context": "filament_remodeling_gelsolin_family_villin",
        "broad": "filament_remodeling_and_assembly",
        "status": "retain_full_euk_actin_context",
        "evidence": "Villin/gelsolin-family domains bound to actin.",
    },
]


def read_tsv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def as_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def as_int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def percent(numerator, denominator):
    return round(100.0 * numerator / denominator, 1) if denominator else ""


def main():
    rows = [
        row for row in read_tsv(INPUT)
        if row["context_primary"] == "unclassified_or_other_actin_context"
    ]
    if len(rows) != 74:
        raise RuntimeError(f"Expected 74 unclassified rows, found {len(rows)}")

    lookup = {}
    for group in GROUPS:
        for pdb_id in group["ids"]:
            if pdb_id in lookup:
                raise RuntimeError(f"Duplicate curated mapping for {pdb_id}")
            lookup[pdb_id] = group

    observed = {row["pdb_id"] for row in rows}
    missing = sorted(observed - set(lookup))
    extra = sorted(set(lookup) - observed)
    if missing or extra:
        raise RuntimeError(f"Mapping mismatch; missing={missing}, extra={extra}")

    audit_rows = []
    for row in sorted(rows, key=lambda x: x["pdb_id"]):
        group = lookup[row["pdb_id"]]
        source_complete_tail = as_int(row["n_actin_chains_analyzed"]) > 0
        tail_contact_eligible = (
            source_complete_tail
            and group["status"] == "retain_full_euk_actin_context"
        )
        main_euk_context_eligible = (
            tail_contact_eligible
            and group["status"] == "retain_full_euk_actin_context"
        )
        confidence = "high"
        if group["status"] == "exclude_bacterial_actin_like":
            confidence = "medium"
        audit_rows.append({
            "pdb_id": row["pdb_id"],
            "original_context_primary": row["context_primary"],
            "suggested_context_primary": group["context"],
            "suggested_broad_context": group["broad"],
            "audit_status": group["status"],
            "audit_confidence": confidence,
            "source_complete_tail_reported": int(source_complete_tail),
            "tail_contact_eligible_after_audit": int(tail_contact_eligible),
            "main_euk_context_eligible_after_audit": int(main_euk_context_eligible),
            "source_set": row["source_set"],
            "n_actin_chains_expected": row["n_actin_chains_expected"],
            "n_actin_chains_analyzed": row["n_actin_chains_analyzed"],
            "representative_partner": row["representative_partner"],
            "title": row["title"],
            "evidence_and_rationale": group["evidence"],
            "tail_body_fraction_residues_with_5A_contact": row["tail_body_fraction_residues_with_5A_contact"],
            "tail_body_partner_types_5A": row["tail_body_partner_types_5A"],
            "terminal_KCF_fraction_residues_with_5A_contact": row["terminal_KCF_fraction_residues_with_5A_contact"],
            "terminal_KCF_partner_types_5A": row["terminal_KCF_partner_types_5A"],
            "K408_fraction_chains_with_5A_contact": row["K408_fraction_chains_with_5A_contact"],
            "C409_fraction_chains_with_5A_contact": row["C409_fraction_chains_with_5A_contact"],
            "F410_fraction_chains_with_5A_contact": row["F410_fraction_chains_with_5A_contact"],
            "tail_contact_note": row["tail_contact_note"],
        })

    audit_fields = list(audit_rows[0])
    write_tsv(AUDIT_TSV, audit_rows, audit_fields)
    retained_rows = [
        row for row in audit_rows
        if row["audit_status"] == "retain_full_euk_actin_context"
    ]
    excluded_rows = [
        row for row in audit_rows
        if row["audit_status"] != "retain_full_euk_actin_context"
    ]
    if len(retained_rows) != 61 or len(excluded_rows) != 13:
        raise RuntimeError(
            f"Formal split mismatch; retained={len(retained_rows)}, excluded={len(excluded_rows)}"
        )
    write_tsv(FORMAL_RETAINED_TSV, retained_rows, audit_fields)
    write_tsv(FORMAL_EXCLUDED_TSV, excluded_rows, audit_fields)

    grouped = defaultdict(list)
    for row in audit_rows:
        grouped[(row["suggested_broad_context"], row["suggested_context_primary"])].append(row)

    summary_rows = []
    for (broad, context), members in sorted(grouped.items()):
        complete = [
            row for row in members
            if row["tail_contact_eligible_after_audit"] == 1
        ]
        tail_positive = sum(
            as_float(row["tail_body_fraction_residues_with_5A_contact"]) > 0
            for row in complete
        )
        kcf_positive = sum(
            as_float(row["terminal_KCF_fraction_residues_with_5A_contact"]) > 0
            for row in complete
        )
        f410_positive = sum(
            as_float(row["F410_fraction_chains_with_5A_contact"]) > 0
            for row in complete
        )
        summary_rows.append({
            "suggested_broad_context": broad,
            "suggested_context_primary": context,
            "n_pdb": len(members),
            "n_tail_contact_eligible_after_audit": len(complete),
            "n_main_euk_context_eligible_after_audit": sum(
                row["main_euk_context_eligible_after_audit"] for row in members
            ),
            "tail_body_5A_positive_pdb": tail_positive,
            "tail_body_5A_positive_pct": percent(tail_positive, len(complete)),
            "terminal_KCF_5A_positive_pdb": kcf_positive,
            "terminal_KCF_5A_positive_pct": percent(kcf_positive, len(complete)),
            "F410_5A_positive_pdb": f410_positive,
            "F410_5A_positive_pct": percent(f410_positive, len(complete)),
            "pdb_ids": ";".join(row["pdb_id"] for row in members),
        })
    write_tsv(SUMMARY_TSV, summary_rows, list(summary_rows[0]))

    broad_grouped = defaultdict(list)
    for row in audit_rows:
        if row["main_euk_context_eligible_after_audit"] == 1:
            broad_grouped[row["suggested_broad_context"]].append(row)
    broad_rows = []
    for broad, members in sorted(broad_grouped.items()):
        tail_positive = sum(
            as_float(row["tail_body_fraction_residues_with_5A_contact"]) > 0
            for row in members
        )
        kcf_positive = sum(
            as_float(row["terminal_KCF_fraction_residues_with_5A_contact"]) > 0
            for row in members
        )
        f410_positive = sum(
            as_float(row["F410_fraction_chains_with_5A_contact"]) > 0
            for row in members
        )
        tail_non_actin = sum(
            "non_actin_partner" in row["tail_body_partner_types_5A"]
            for row in members
        )
        kcf_non_actin = sum(
            "non_actin_partner" in row["terminal_KCF_partner_types_5A"]
            for row in members
        )
        broad_rows.append({
            "suggested_broad_context": broad,
            "n_main_euk_context_pdb": len(members),
            "tail_body_5A_positive_pdb": tail_positive,
            "tail_body_5A_positive_pct": percent(tail_positive, len(members)),
            "terminal_KCF_5A_positive_pdb": kcf_positive,
            "terminal_KCF_5A_positive_pct": percent(kcf_positive, len(members)),
            "F410_5A_positive_pdb": f410_positive,
            "F410_5A_positive_pct": percent(f410_positive, len(members)),
            "tail_body_non_actin_partner_5A_pdb": tail_non_actin,
            "tail_body_non_actin_partner_5A_pct": percent(tail_non_actin, len(members)),
            "terminal_KCF_non_actin_partner_5A_pdb": kcf_non_actin,
            "terminal_KCF_non_actin_partner_5A_pct": percent(kcf_non_actin, len(members)),
        })
    total = [row for row in audit_rows if row["main_euk_context_eligible_after_audit"] == 1]
    broad_rows.append({
        "suggested_broad_context": "ALL_REAUDITED_MAIN_EUK_CONTEXTS",
        "n_main_euk_context_pdb": len(total),
        "tail_body_5A_positive_pdb": sum(
            as_float(row["tail_body_fraction_residues_with_5A_contact"]) > 0
            for row in total
        ),
        "tail_body_5A_positive_pct": percent(
            sum(as_float(row["tail_body_fraction_residues_with_5A_contact"]) > 0 for row in total),
            len(total),
        ),
        "terminal_KCF_5A_positive_pdb": sum(
            as_float(row["terminal_KCF_fraction_residues_with_5A_contact"]) > 0
            for row in total
        ),
        "terminal_KCF_5A_positive_pct": percent(
            sum(as_float(row["terminal_KCF_fraction_residues_with_5A_contact"]) > 0 for row in total),
            len(total),
        ),
        "F410_5A_positive_pdb": sum(
            as_float(row["F410_fraction_chains_with_5A_contact"]) > 0
            for row in total
        ),
        "F410_5A_positive_pct": percent(
            sum(as_float(row["F410_fraction_chains_with_5A_contact"]) > 0 for row in total),
            len(total),
        ),
        "tail_body_non_actin_partner_5A_pdb": sum(
            "non_actin_partner" in row["tail_body_partner_types_5A"] for row in total
        ),
        "tail_body_non_actin_partner_5A_pct": percent(
            sum("non_actin_partner" in row["tail_body_partner_types_5A"] for row in total),
            len(total),
        ),
        "terminal_KCF_non_actin_partner_5A_pdb": sum(
            "non_actin_partner" in row["terminal_KCF_partner_types_5A"] for row in total
        ),
        "terminal_KCF_non_actin_partner_5A_pct": percent(
            sum("non_actin_partner" in row["terminal_KCF_partner_types_5A"] for row in total),
            len(total),
        ),
    })
    write_tsv(BROAD_SUMMARY_TSV, broad_rows, list(broad_rows[0]))

    status_counts = Counter(row["audit_status"] for row in audit_rows)
    status_rows = [
        {"audit_status": status, "n_pdb": count}
        for status, count in sorted(status_counts.items())
    ]
    write_tsv(STATUS_TSV, status_rows, ["audit_status", "n_pdb"])

    print(f"audited={len(audit_rows)}")
    print("status=" + ",".join(f"{k}:{v}" for k, v in sorted(status_counts.items())))
    print(f"contexts={len(summary_rows)}")
    print(AUDIT_TSV)
    print(SUMMARY_TSV)
    print(BROAD_SUMMARY_TSV)
    print(FORMAL_RETAINED_TSV)
    print(FORMAL_EXCLUDED_TSV)


if __name__ == "__main__":
    main()
