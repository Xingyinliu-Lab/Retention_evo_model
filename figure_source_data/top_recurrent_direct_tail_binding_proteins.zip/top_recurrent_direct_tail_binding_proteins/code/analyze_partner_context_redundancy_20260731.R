suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
})

# Conservative sensitivity analysis: repeated depositions are collapsed within
# the same normalized partner entity and primary functional context.
root <- ".."
work <- file.path(root, "visualization_20260731")
source_dir <- file.path(work, "source_data")
out_dir <- file.path(work, "analysis_redundancy_sasa_20260731")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

context_map <- read_tsv(file.path(source_dir, "formal_483_granular_and_broad_context_map.tsv"), show_col_types = FALSE)
residue <- read_tsv(file.path(source_dir, "formal_483_classical_actin_tail_residue_contacts.tsv"), show_col_types = FALSE)
entities <- read_tsv(file.path(root, "rcsb_actin_complex_search", "rcsb_actin_complex_candidate_entities.tsv"), show_col_types = FALSE)

formal_ids <- unique(context_map$pdb_id)
nonclassical_pattern <- paste(
  "actin-like protein\\s*(?:2|3|6A)\\b", "SWI/SNF-related",
  "actin-dependent regulator", "F-actin-capping protein", "actin nucleation-promoting",
  "PP1-alpha", "Actin-like ATPase", "Actin/actin family protein", sep = "|"
)

chain_entity_map <- entities %>%
  filter(pdb_id %in% formal_ids, entity_polymer_type == "Protein") %>%
  mutate(is_classical_actin = is_actin_entity & (actin_call_reason == "actin_uniprot" |
    !grepl(nonclassical_pattern, entity_description, ignore.case = TRUE))) %>%
  select(pdb_id, auth_asym_ids, entity_description, is_classical_actin) %>%
  separate_rows(auth_asym_ids, sep = ";") %>%
  transmute(pdb_id, partner_chain = auth_asym_ids,
            partner_entity_description = entity_description, is_classical_actin) %>% distinct()

partner_long <- residue %>%
  filter(tail_region %in% c("tail_body", "terminal_KCF"), !is.na(partner_chains_5A), partner_chains_5A != "") %>%
  select(pdb_id, tail_region, actin_chain, partner_chains_5A) %>%
  separate_rows(partner_chains_5A, sep = ";") %>% rename(partner_chain = partner_chains_5A) %>%
  inner_join(chain_entity_map, by = c("pdb_id", "partner_chain")) %>%
  filter(!is_classical_actin) %>%
  mutate(
    partner_entity_key = if_else(tolower(trimws(partner_entity_description)) == "gelsolin", "gelsolin", tolower(trimws(partner_entity_description))),
    partner_entity_display = if_else(partner_entity_key == "gelsolin", "Gelsolin", partner_entity_description)
  ) %>% distinct(pdb_id, tail_region, partner_entity_key, partner_entity_display)

partner_available <- chain_entity_map %>%
  filter(!is_classical_actin) %>%
  mutate(
    partner_entity_key = if_else(tolower(trimws(partner_entity_description)) == "gelsolin", "gelsolin", tolower(trimws(partner_entity_description))),
    partner_entity_display = if_else(partner_entity_key == "gelsolin", "Gelsolin", partner_entity_description)
  ) %>% distinct(pdb_id, partner_entity_key, partner_entity_display)

unit_table <- partner_available %>%
  inner_join(context_map %>% select(pdb_id, context_final), by = "pdb_id") %>%
  crossing(tail_region = c("tail_body", "terminal_KCF")) %>%
  left_join(partner_long %>% mutate(direct_contact = TRUE),
            by = c("pdb_id", "partner_entity_key", "partner_entity_display", "tail_region")) %>%
  mutate(direct_contact = replace_na(direct_contact, FALSE))

collapsed <- unit_table %>%
  group_by(partner_entity_key, partner_entity_display, context_final, tail_region) %>%
  summarise(n_pdb_available = n_distinct(pdb_id), direct_any = any(direct_contact), .groups = "drop") %>%
  group_by(partner_entity_key, partner_entity_display, tail_region) %>%
  summarise(
    n_context_units = n(),
    n_direct_context_units = sum(direct_any),
    context_normalized_probability = n_direct_context_units / n_context_units,
    n_available_pdb = sum(n_pdb_available),
    .groups = "drop"
  ) %>% arrange(desc(context_normalized_probability), desc(n_direct_context_units), desc(n_available_pdb))

top <- collapsed %>%
  group_by(tail_region) %>%
  filter(n_context_units >= 2, n_direct_context_units >= 2) %>%
  slice_max(context_normalized_probability, n = 20, with_ties = FALSE) %>% ungroup()

write_tsv(unit_table, file.path(out_dir, "partner_context_pdb_units_20260731.tsv"))
write_tsv(collapsed, file.path(out_dir, "partner_context_redundancy_normalized_support_20260731.tsv"))
write_tsv(top, file.path(out_dir, "partner_context_redundancy_normalized_top_support_20260731.tsv"))
write_tsv(collapsed, file.path(source_dir, "supplementary_table_partner_context_redundancy_sensitivity_20260731.tsv"))

# Resume manifest for PyMOL SASA. The non-actin chains are retained separately
# so partner-caused burial is not conflated with neighbouring actin chains.
sasa_manifest <- residue %>%
  filter(tail_region %in% c("tail_body", "terminal_KCF")) %>%
  select(pdb_id, actin_chain, tail_region, tail_pos_1_25, hmm_pos, tail_resi) %>%
  distinct() %>%
  left_join(
    chain_entity_map %>% filter(!is_classical_actin) %>%
      group_by(pdb_id) %>% summarise(nonactin_chains = paste(sort(unique(partner_chain)), collapse = ";"), .groups = "drop"),
    by = "pdb_id"
  ) %>% mutate(nonactin_chains = replace_na(nonactin_chains, "")) %>%
  arrange(pdb_id, actin_chain, hmm_pos)
write_tsv(sasa_manifest, file.path(out_dir, "tail_sasa_manifest_20260731.tsv"))

readr::write_lines(c(
  "# Partner-context redundancy sensitivity analysis",
  "", "Unit definition: one normalized non-actin partner entity within one primary functional context.",
  "All repeated PDB depositions in that unit are collapsed to one direct-contact-positive unit if any deposition has a 5 A direct tail contact.",
  "This is a conservative deposition-redundancy sensitivity analysis, not protein-sequence clustering and not an affinity estimate.",
  sprintf("Formal PDBs: %d; partner-context-PDB records: %d; collapsed entity-context-region units: %d.",
          length(formal_ids), nrow(unit_table), nrow(collapsed))
), file.path(out_dir, "README_partner_context_redundancy_20260731.md"))
