suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(ragg)
})

root <- ".."
work <- file.path(root, "visualization_20260731")
data_dir <- file.path(root, "batch_tail_contacts")
search_dir <- file.path(root, "rcsb_actin_complex_search")
audit_dir <- file.path(work, "data")
source_dir <- file.path(work, "source_data")
figure_dir <- file.path(work, "figures")
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

figure_contract <- list(
  core_conclusion = paste(
    "HMM386-407 tail body is a broadly used contact surface, whereas",
    "terminal HMM408-410 KCF shows more context-dependent partner engagement."
  ),
  archetype = "quantitative grid",
  backend = "R",
  denominator = "PDB-level classical eukaryotic actin structures",
  exports = "PNG and PDF; no SVG",
  statistics = "Descriptive prevalence with Wilson 95% CI; no independence-based P values"
)

palette <- c(
  "Tail body (HMM386-407)" = "#3976A8",
  "Terminal KCF (HMM408-410)" = "#D88435"
)

theme_tail <- function(base_size = 8) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "#222222"),
      axis.ticks = element_line(linewidth = 0.35, colour = "#222222"),
      axis.text = element_text(colour = "#222222"),
      axis.title = element_text(colour = "#222222"),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 0.5),
      plot.title = element_text(size = base_size + 1.5, face = "bold"),
      plot.subtitle = element_text(size = base_size, colour = "#4D4D4D"),
      plot.caption = element_text(size = base_size - 1, colour = "#666666", hjust = 0),
      strip.text = element_text(face = "bold", size = base_size),
      panel.grid.major.x = element_line(linewidth = 0.25, colour = "#E6E6E6"),
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 12, 8, 8)
    )
}

wilson_ci <- function(x, n, z = 1.96) {
  if (n == 0) return(c(NA_real_, NA_real_))
  p <- x / n
  denom <- 1 + z^2 / n
  center <- (p + z^2 / (2 * n)) / denom
  half <- z * sqrt((p * (1 - p) + z^2 / (4 * n)) / n) / denom
  c(max(0, center - half), min(1, center + half))
}

save_figure <- function(plot, stem, width_mm, height_mm, dpi = 600) {
  ggsave(
    paste0(stem, ".pdf"), plot,
    device = grDevices::cairo_pdf,
    width = width_mm, height = height_mm, units = "mm",
    family = "Arial"
  )
  ggsave(
    paste0(stem, ".png"), plot,
    device = ragg::agg_png,
    width = width_mm, height = height_mm, units = "mm",
    dpi = dpi, background = "white"
  )
}

formal_raw <- read_tsv(
  file.path(data_dir, "actin_tail_contact_pdb_level_summary.tsv"),
  show_col_types = FALSE
)
entities <- read_tsv(
  file.path(search_dir, "rcsb_actin_complex_candidate_entities.tsv"),
  show_col_types = FALSE
) %>%
  filter(pdb_id %in% formal_raw$pdb_id, is_actin_entity)

nonclassical_pattern <- paste(
  "actin-like protein\\s*(?:2|3|6A)\\b",
  "SWI/SNF-related",
  "actin-dependent regulator",
  "F-actin-capping protein",
  "actin nucleation-promoting",
  "PP1-alpha",
  "Actin-like ATPase",
  "Actin/actin family protein",
  sep = "|"
)

entities <- entities %>%
  mutate(
    is_classical_actin = actin_call_reason == "actin_uniprot" |
      !grepl(nonclassical_pattern, entity_description, ignore.case = TRUE)
  )

pdb_entity_audit <- entities %>%
  group_by(pdb_id) %>%
  summarise(
    n_called_actin_entities = n(),
    n_classical_actin_entities = sum(is_classical_actin),
    n_nonclassical_or_false_entities = sum(!is_classical_actin),
    classical_actin_descriptions = paste(
      unique(entity_description[is_classical_actin]), collapse = "; "
    ),
    excluded_entity_descriptions = paste(
      unique(entity_description[!is_classical_actin]), collapse = "; "
    ),
    source_organisms = paste(unique(source_organism), collapse = "; "),
    entity_audit_status = case_when(
      n_classical_actin_entities == 0 ~ "exclude_nonclassical_or_false_only",
      n_nonclassical_or_false_entities > 0 ~ "retain_recompute_true_actin_chains_only",
      TRUE ~ "retain_classical_actin_only"
    ),
    .groups = "drop"
  )

if (nrow(pdb_entity_audit) != 495) {
  stop("Expected 495 raw complete-tail PDBs in entity audit")
}
if (sum(pdb_entity_audit$n_classical_actin_entities > 0) != 483) {
  stop("Expected 483 PDBs with at least one classical eukaryotic actin entity")
}

write_tsv(
  pdb_entity_audit,
  file.path(source_dir, "formal_classical_euk_actin_pdb_entity_audit_495.tsv")
)
write_tsv(
  filter(pdb_entity_audit, entity_audit_status == "exclude_nonclassical_or_false_only"),
  file.path(source_dir, "formal_excluded_nonclassical_or_false_only_12.tsv")
)
write_tsv(
  filter(pdb_entity_audit, entity_audit_status == "retain_recompute_true_actin_chains_only"),
  file.path(source_dir, "formal_mixed_structures_recomputed_true_actin_chains_20.tsv")
)

true_chains <- entities %>%
  filter(is_classical_actin) %>%
  select(pdb_id, auth_asym_ids) %>%
  separate_rows(auth_asym_ids, sep = ";") %>%
  transmute(pdb_id, actin_chain = auth_asym_ids) %>%
  distinct()

residue <- read_tsv(
  file.path(data_dir, "actin_tail_residue_contact_summary.tsv"),
  show_col_types = FALSE
)
residue_true <- residue %>%
  inner_join(true_chains, by = c("pdb_id", "actin_chain"))

if (n_distinct(residue_true$pdb_id) != 483) {
  stop("Residue-level true-actin filter did not retain 483 PDBs")
}

true_chain_map <- split(true_chains$actin_chain, true_chains$pdb_id)
has_nonactin_partner <- mapply(
  function(pdb_id, partner_text) {
    if (is.na(partner_text) || partner_text == "") return(FALSE)
    partner_chains <- strsplit(partner_text, ";", fixed = TRUE)[[1]]
    any(!partner_chains %in% true_chain_map[[pdb_id]])
  },
  residue_true$pdb_id,
  residue_true$partner_chains_5A,
  USE.NAMES = FALSE
)
residue_true$has_nonactin_partner_5A <- has_nonactin_partner

write_tsv(
  residue_true,
  file.path(source_dir, "formal_483_classical_actin_tail_residue_contacts.tsv")
)

pdb_region <- residue_true %>%
  group_by(pdb_id, tail_region) %>%
  summarise(
    n_tail_residues = n(),
    any_contact_3A = any(n_atom_contacts_3A > 0),
    any_contact_4A = any(n_atom_contacts_4A > 0),
    any_contact_5A = any(n_atom_contacts_5A > 0),
    any_contact_8A = any(n_atom_contacts_8A > 0),
    direct_nonactin_partner_5A = any(has_nonactin_partner_5A),
    .groups = "drop"
  )

region_counts <- pdb_region %>%
  count(tail_region, name = "n_pdb")
if (nrow(region_counts) != 2 || any(region_counts$n_pdb != 483)) {
  stop("Each tail region must contain exactly 483 audited PDBs")
}

write_tsv(
  pdb_region,
  file.path(source_dir, "formal_483_pdb_region_contact_flags.tsv")
)

threshold_cols <- c(
  "3 \u00C5" = "any_contact_3A",
  "4 \u00C5" = "any_contact_4A",
  "5 \u00C5" = "any_contact_5A",
  "8 \u00C5" = "any_contact_8A"
)

figure1_source <- bind_rows(lapply(names(threshold_cols), function(threshold) {
  col <- threshold_cols[[threshold]]
  pdb_region %>%
    group_by(tail_region) %>%
    summarise(
      threshold = threshold,
      n_pdb = n(),
      n_positive = sum(.data[[col]]),
      prevalence = n_positive / n_pdb,
      .groups = "drop"
    )
})) %>%
  rowwise() %>%
  mutate(
    ci = list(wilson_ci(n_positive, n_pdb)),
    ci_low = ci[[1]],
    ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci) %>%
  mutate(
    threshold = factor(threshold, levels = names(threshold_cols)),
    region_label = recode(
      tail_region,
      tail_body = "Tail body (HMM386-407)",
      terminal_KCF = "Terminal KCF (HMM408-410)"
    ),
    label = paste0(n_positive, "/", n_pdb)
  )

write_tsv(
  figure1_source,
  file.path(source_dir, "fig01_tail_body_vs_kcf_contact_prevalence_source.tsv")
)

fig01 <- ggplot(
  figure1_source,
  aes(x = threshold, y = prevalence, colour = region_label, group = region_label)
) +
  geom_line(linewidth = 0.75) +
  geom_errorbar(
    aes(ymin = ci_low, ymax = ci_high),
    width = 0.09, linewidth = 0.4
  ) +
  geom_point(size = 2.5, stroke = 0) +
  geom_text(
    aes(label = label),
    colour = "#222222", size = 2.4,
    vjust = ifelse(figure1_source$region_label == "Tail body (HMM386-407)", -1.15, 1.5),
    show.legend = FALSE
  ) +
  scale_colour_manual(values = palette) +
  scale_y_continuous(
    labels = label_percent(accuracy = 1),
    breaks = seq(0, 1, 0.2),
    limits = c(0, 1.06),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Tail body retains broader contact coverage than terminal KCF",
    subtitle = "PDB-level prevalence after classical eukaryotic actin entity audit (n = 483)",
    x = "Heavy-atom distance threshold",
    y = "Structures with \u22651 contact",
    caption = "Points show prevalence; error bars show Wilson 95% confidence intervals."
  ) +
  theme_tail(8.5) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    legend.box.margin = margin(0, 0, 2, 0)
  )

save_figure(
  fig01,
  file.path(figure_dir, "fig01_tail_body_vs_terminal_KCF_contact_prevalence"),
  125, 105
)

contexts <- read_tsv(
  file.path(data_dir, "structure_context_classification.tsv"),
  show_col_types = FALSE
)
reaudit <- read_tsv(
  file.path(audit_dir, "unclassified_74_context_reaudit.tsv"),
  show_col_types = FALSE
) %>%
  select(pdb_id, suggested_context_primary, suggested_broad_context, audit_status)

formal_context <- contexts %>%
  filter(pdb_id %in% unique(pdb_region$pdb_id)) %>%
  left_join(reaudit, by = "pdb_id") %>%
  mutate(
    context_final = if_else(
      context_primary == "unclassified_or_other_actin_context",
      suggested_context_primary,
      context_primary
    ),
    broad_context = case_when(
      !is.na(suggested_broad_context) &
        suggested_broad_context == "filament_remodeling_and_assembly" ~
        "Filament assembly and remodeling",
      !is.na(suggested_broad_context) &
        suggested_broad_context == "monomer_handling_and_sensing" ~
        "Monomer handling and sensing",
      !is.na(suggested_broad_context) &
        suggested_broad_context == "pathogen_effector" ~
        "Pathogen effector",
      !is.na(suggested_broad_context) &
        suggested_broad_context == "polymer_or_actin_state" ~
        "Filament/polymer state",
      !is.na(suggested_broad_context) &
        suggested_broad_context == "signaling_and_cross_cytoskeleton" ~
        "Cross-cytoskeleton organization",
      context_final %in% c(
        "nucleation_branching_Arp2_3",
        "filament_end_capping",
        "filament_remodeling_gelsolin",
        "filament_remodeling_cofilin_ADF",
        "nucleation_elongation_formin_WH2"
      ) ~ "Filament assembly and remodeling",
      context_final %in% c(
        "monomer_handling_profilin",
        "monomer_handling_DNaseI"
      ) ~ "Monomer handling and sensing",
      context_final == "filament_polymer_F_actin" ~ "Filament/polymer state",
      context_final == "filament_motor_contractile_myosin_tropomyosin" ~
        "Motor and contractile",
      context_final == "folding_maturation_TRiC_CCT_chaperonin" ~
        "Folding and maturation",
      context_final == "nuclear_chromatin_actin_complex" ~
        "Nuclear and chromatin",
      context_final == "pathogen_toxin_effector_actin_complex" ~
        "Pathogen effector",
      context_final == "special_microtubule_axoneme_flagellar_repeat" ~
        "Cross-cytoskeleton organization",
      TRUE ~ NA_character_
    )
  ) %>%
  select(pdb_id, context_final, broad_context)

if (nrow(formal_context) != 483 || any(is.na(formal_context$broad_context))) {
  stop("Formal context mapping must cover all 483 audited PDBs")
}

write_tsv(
  formal_context,
  file.path(source_dir, "formal_483_granular_and_broad_context_map.tsv")
)

context_n <- formal_context %>%
  count(broad_context, name = "n_context_pdb")

figure2_flags <- pdb_region %>%
  left_join(formal_context, by = "pdb_id") %>%
  mutate(
    region_label = recode(
      tail_region,
      tail_body = "Tail body (HMM386-407)",
      terminal_KCF = "Terminal KCF (HMM408-410)"
    )
  )

figure2_source <- bind_rows(
  figure2_flags %>%
    transmute(
      pdb_id, broad_context, region_label,
      metric = "Any 5 \u00C5 contact",
      positive = any_contact_5A
    ),
  figure2_flags %>%
    transmute(
      pdb_id, broad_context, region_label,
      metric = "Direct non-actin partner contact at 5 \u00C5",
      positive = direct_nonactin_partner_5A
    )
) %>%
  group_by(broad_context, region_label, metric) %>%
  summarise(
    n_pdb = n(),
    n_positive = sum(positive),
    prevalence = n_positive / n_pdb,
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(
    ci = list(wilson_ci(n_positive, n_pdb)),
    ci_low = ci[[1]],
    ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci) %>%
  left_join(context_n, by = "broad_context") %>%
  mutate(
    context_label = paste0(broad_context, " (n=", n_context_pdb, ")"),
    metric = factor(
      metric,
      levels = c(
        "Any 5 \u00C5 contact",
        "Direct non-actin partner contact at 5 \u00C5"
      )
    ),
    region_label = factor(region_label, levels = names(palette)),
    main_plot_eligible = n_context_pdb >= 10
  )

context_order <- context_n %>%
  arrange(n_context_pdb) %>%
  mutate(context_label = paste0(broad_context, " (n=", n_context_pdb, ")")) %>%
  pull(context_label)
figure2_source$context_label <- factor(
  figure2_source$context_label,
  levels = context_order
)

write_tsv(
  figure2_source,
  file.path(source_dir, "fig02_context_specific_tail_body_kcf_source.tsv")
)

fig02 <- ggplot(
  filter(figure2_source, main_plot_eligible),
  aes(x = prevalence, y = context_label, colour = region_label)
) +
  geom_errorbar(
    aes(xmin = ci_low, xmax = ci_high),
    orientation = "y", width = 0.18, linewidth = 0.38,
    position = position_dodge(width = 0.45)
  ) +
  geom_point(
    size = 2.2,
    position = position_dodge(width = 0.45)
  ) +
  facet_wrap(~metric, ncol = 2) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    labels = label_percent(accuracy = 1),
    breaks = seq(0, 1, 0.25),
    limits = c(0, 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Terminal KCF engagement varies more strongly across actin contexts",
    subtitle = "Classical eukaryotic actin chains only; displayed contexts contain at least 10 PDB entries",
    x = "PDB-level prevalence",
    y = NULL,
    caption = paste(
      "Points show prevalence; error bars show Wilson 95% confidence intervals.",
      "\nPDB entries are descriptive units, not independent biological replicates."
    )
  ) +
  theme_tail(7.6) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    strip.background = element_rect(fill = "#F2F2F2", colour = NA),
    strip.text = element_text(hjust = 0),
    panel.spacing.x = unit(8, "mm")
  )

save_figure(
  fig02,
  file.path(figure_dir, "fig02_context_specific_tail_body_vs_terminal_KCF"),
  183, 112
)

# The raw contact table identifies partner-chain provenance at 5 A only.
# Therefore the 3 A companion plot reports the directly available, threshold-
# specific any-chain contact metric rather than mislabelling it as non-actin.
figure2_3A_source <- figure2_flags %>%
  transmute(
    pdb_id, broad_context, region_label,
    metric = "Any 3 A contact",
    positive = any_contact_3A
  ) %>%
  group_by(broad_context, region_label, metric) %>%
  summarise(
    n_pdb = n(),
    n_positive = sum(positive),
    prevalence = n_positive / n_pdb,
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(
    ci = list(wilson_ci(n_positive, n_pdb)),
    ci_low = ci[[1]],
    ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci) %>%
  left_join(context_n, by = "broad_context") %>%
  mutate(
    context_label = paste0(broad_context, " (n=", n_context_pdb, ")"),
    region_label = factor(region_label, levels = names(palette)),
    main_plot_eligible = n_context_pdb >= 10
  )
figure2_3A_source$context_label <- factor(
  figure2_3A_source$context_label,
  levels = context_order
)

write_tsv(
  figure2_3A_source,
  file.path(source_dir, "fig02_context_specific_tail_body_kcf_3A_source.tsv")
)

fig02_3A <- ggplot(
  filter(figure2_3A_source, main_plot_eligible),
  aes(x = prevalence, y = context_label, colour = region_label)
) +
  geom_errorbar(
    aes(xmin = ci_low, xmax = ci_high),
    orientation = "y", width = 0.18, linewidth = 0.38,
    position = position_dodge(width = 0.45)
  ) +
  geom_point(size = 2.2, position = position_dodge(width = 0.45)) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    labels = label_percent(accuracy = 1),
    breaks = seq(0, 1, 0.25), limits = c(0, 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Tail-body contact remains broader at the strict 3 A threshold",
    subtitle = "Classical eukaryotic actin chains only; displayed contexts contain at least 10 PDB entries",
    x = "PDB-level prevalence of any 3 A contact",
    y = NULL,
    caption = paste(
      "Points show prevalence; error bars show Wilson 95% confidence intervals.",
      "\nPartner-chain identity is available only at 5 A and is therefore not inferred here."
    )
  ) +
  theme_tail(7.6) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    panel.spacing.x = unit(8, "mm")
  )

save_figure(
  fig02_3A,
  file.path(figure_dir, "fig02_context_specific_tail_body_vs_terminal_KCF_3A"),
  183, 112
)

# Matched single-metric companion for direct comparison with the strict 3 A plot.
figure2_5A_source <- figure2_flags %>%
  transmute(
    pdb_id, broad_context, region_label,
    metric = "Any 5 A contact",
    positive = any_contact_5A
  ) %>%
  group_by(broad_context, region_label, metric) %>%
  summarise(
    n_pdb = n(),
    n_positive = sum(positive),
    prevalence = n_positive / n_pdb,
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(
    ci = list(wilson_ci(n_positive, n_pdb)),
    ci_low = ci[[1]],
    ci_high = ci[[2]]
  ) %>%
  ungroup() %>%
  select(-ci) %>%
  left_join(context_n, by = "broad_context") %>%
  mutate(
    context_label = paste0(broad_context, " (n=", n_context_pdb, ")"),
    region_label = factor(region_label, levels = names(palette)),
    main_plot_eligible = n_context_pdb >= 10
  )
figure2_5A_source$context_label <- factor(
  figure2_5A_source$context_label,
  levels = context_order
)

write_tsv(
  figure2_5A_source,
  file.path(source_dir, "fig02_context_specific_tail_body_kcf_5A_source.tsv")
)

fig02_5A <- ggplot(
  filter(figure2_5A_source, main_plot_eligible),
  aes(x = prevalence, y = context_label, colour = region_label)
) +
  geom_errorbar(
    aes(xmin = ci_low, xmax = ci_high),
    orientation = "y", width = 0.18, linewidth = 0.38,
    position = position_dodge(width = 0.45)
  ) +
  geom_point(size = 2.2, position = position_dodge(width = 0.45)) +
  scale_colour_manual(values = palette) +
  scale_x_continuous(
    labels = label_percent(accuracy = 1),
    breaks = seq(0, 1, 0.25), limits = c(0, 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Tail-body contact remains broader at the permissive 5 A threshold",
    subtitle = "Classical eukaryotic actin chains only; displayed contexts contain at least 10 PDB entries",
    x = "PDB-level prevalence of any 5 A contact",
    y = NULL,
    caption = "Points show prevalence; error bars show Wilson 95% confidence intervals."
  ) +
  theme_tail(7.6) +
  theme(
    legend.position = "top",
    legend.justification = "left",
    panel.spacing.x = unit(8, "mm")
  )

save_figure(
  fig02_5A,
  file.path(figure_dir, "fig02_context_specific_tail_body_vs_terminal_KCF_5A"),
  183, 112
)

write_lines(
  c(
    paste0("core_conclusion\t", figure_contract$core_conclusion),
    paste0("archetype\t", figure_contract$archetype),
    paste0("backend\t", figure_contract$backend),
    paste0("denominator\t", figure_contract$denominator),
    paste0("exports\t", figure_contract$exports),
    paste0("statistics\t", figure_contract$statistics),
    paste0("raw_complete_tail_pdb\t", nrow(formal_raw)),
    paste0("formal_classical_euk_actin_pdb\t", n_distinct(residue_true$pdb_id)),
    paste0(
      "excluded_nonclassical_or_false_only_pdb\t",
      sum(pdb_entity_audit$entity_audit_status == "exclude_nonclassical_or_false_only")
    ),
    paste0(
      "mixed_pdb_recomputed_true_actin_chains_only\t",
      sum(pdb_entity_audit$entity_audit_status == "retain_recompute_true_actin_chains_only")
    )
  ),
  file.path(work, "docs", "TAIL_BODY_KCF_FIGURE_CONTRACT_20260731.tsv")
)

message("Formal classical eukaryotic actin PDBs: 483")
message("Figures written: fig01, fig02, fig02_3A, fig02_5A")
