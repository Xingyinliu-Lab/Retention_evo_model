"""Recalculate direct non-actin protein tail contacts from local mmCIF coordinates.

The original batch table stored partner-chain identity only at 5 A. This script
rebuilds the 3 A and 5 A direct non-actin flags from coordinates for the frozen
483-PDB classical-eukaryotic-actin set without modifying upstream data.
"""

from __future__ import annotations

import csv
import os
import re
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
from Bio.PDB import MMCIFParser, is_aa
from scipy.spatial import cKDTree


WORK = Path(__file__).resolve().parents[1]
ROOT = WORK.parent
CIF_DIR = ROOT / "cif"
ENTITY_TSV = ROOT / "rcsb_actin_complex_search" / "rcsb_actin_complex_candidate_entities.tsv"
FORMAL_RESIDUE_TSV = WORK / "source_data" / "formal_483_classical_actin_tail_residue_contacts.tsv"
OUT = WORK / "source_data" / "formal_483_direct_nonactin_tail_contacts_3A_5A.tsv"

NONCLASSICAL_PATTERN = re.compile(
    r"actin-like protein (2|3|6A)|SWI/SNF-related|actin-dependent regulator|"
    r"F-actin-capping protein|actin nucleation-promoting|PP1-alpha|"
    r"Actin-like ATPase|Actin/actin family protein",
    re.IGNORECASE,
)


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def is_true_classical_actin(row: dict[str, str]) -> bool:
    is_actin = row.get("is_actin_entity", "").strip().lower() == "true"
    desc = row.get("entity_description", "")
    return is_actin and (
        row.get("actin_call_reason", "") == "actin_uniprot"
        or not NONCLASSICAL_PATTERN.search(desc)
    )


def chain_classification() -> dict[str, dict[str, bool]]:
    result: dict[str, dict[str, bool]] = defaultdict(dict)
    for row in read_tsv(ENTITY_TSV):
        for chain in filter(None, row.get("auth_asym_ids", "").split(";")):
            result[row["pdb_id"].upper()][chain] = is_true_classical_actin(row)
    return result


def target_tail_residues() -> dict[str, dict[str, dict[str, set[str]]]]:
    result: dict[str, dict[str, dict[str, set[str]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(set))
    )
    for row in read_tsv(FORMAL_RESIDUE_TSV):
        result[row["pdb_id"].upper()][row["actin_chain"]][row["tail_region"]].add(
            str(row["tail_resi"]).strip()
        )
    return result


def residue_labels(residue) -> set[str]:
    seq_id, insertion = residue.id[1], residue.id[2].strip()
    labels = {str(seq_id)}
    if insertion:
        labels.add(f"{seq_id}{insertion}")
    return labels


def protein_atoms(chain):
    atoms = []
    for residue in chain.get_residues():
        if not is_aa(residue, standard=False):
            continue
        for atom in residue.get_atoms():
            if atom.element == "H":
                continue
            atoms.append(atom.coord)
    return atoms


def calculate_one(
    pdb_id: str,
    targets: dict[str, dict[str, set[str]]],
    classifications: dict[str, bool],
    parser: MMCIFParser,
) -> list[dict[str, object]]:
    cif_path = CIF_DIR / f"{pdb_id}.cif"
    if not cif_path.exists():
        raise FileNotFoundError(cif_path)
    structure = parser.get_structure(pdb_id, str(cif_path))
    model = next(structure.get_models())
    chain_lookup = {chain.id: chain for chain in model.get_chains()}

    partner_coords = []
    for chain_id, chain in chain_lookup.items():
        if classifications.get(chain_id) is False:
            partner_coords.extend(protein_atoms(chain))
    tree = cKDTree(np.asarray(partner_coords, dtype=float)) if partner_coords else None

    rows = []
    for actin_chain, regions in targets.items():
        chain = chain_lookup.get(actin_chain)
        if chain is None:
            for region in regions:
                rows.append({
                    "pdb_id": pdb_id, "actin_chain": actin_chain, "tail_region": region,
                    "direct_nonactin_3A": "", "direct_nonactin_5A": "",
                    "status": "missing_actin_chain",
                })
            continue
        residues_by_label = {}
        for residue in chain.get_residues():
            for label in residue_labels(residue):
                residues_by_label[label] = residue
        for region, residue_ids in regions.items():
            tail_atoms = []
            missing = []
            for residue_id in residue_ids:
                residue = residues_by_label.get(residue_id)
                if residue is None:
                    missing.append(residue_id)
                    continue
                tail_atoms.extend(
                    atom.coord for atom in residue.get_atoms() if atom.element != "H"
                )
            if not tail_atoms:
                rows.append({
                    "pdb_id": pdb_id, "actin_chain": actin_chain, "tail_region": region,
                    "direct_nonactin_3A": "", "direct_nonactin_5A": "",
                    "status": "missing_tail_residues",
                })
                continue
            coords = np.asarray(tail_atoms, dtype=float)
            has_3a = bool(tree and any(tree.query_ball_point(coord, 3.0) for coord in coords))
            has_5a = bool(tree and any(tree.query_ball_point(coord, 5.0) for coord in coords))
            rows.append({
                "pdb_id": pdb_id, "actin_chain": actin_chain, "tail_region": region,
                "direct_nonactin_3A": str(has_3a).upper(),
                "direct_nonactin_5A": str(has_5a).upper(),
                "status": "partial_tail_residue_mapping" if missing else "ok",
            })
    return rows


def calculate_one_worker(args):
    pdb_id, targets, classifications = args
    parser = MMCIFParser(QUIET=True, auth_chains=True, auth_residues=True)
    try:
        return calculate_one(pdb_id, targets, classifications, parser)
    except Exception as error:
        return [
            {
                "pdb_id": pdb_id, "actin_chain": actin_chain, "tail_region": region,
                "direct_nonactin_3A": "", "direct_nonactin_5A": "",
                "status": f"error:{type(error).__name__}",
            }
            for actin_chain, regions in targets.items()
            for region in regions
        ]


def main() -> None:
    classifications = chain_classification()
    targets = target_tail_residues()
    rows = []
    jobs = [
        (
            pdb_id,
            {
                chain: {region: set(residue_ids) for region, residue_ids in regions.items()}
                for chain, regions in targets[pdb_id].items()
            },
            dict(classifications[pdb_id]),
        )
        for pdb_id in sorted(targets)
    ]
    max_workers = min(4, os.cpu_count() or 1)
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(calculate_one_worker, job) for job in jobs]
        for index, future in enumerate(as_completed(futures), start=1):
            rows.extend(future.result())
            if index % 50 == 0:
                print(f"processed {index}/{len(jobs)}", flush=True)

    fieldnames = [
        "pdb_id", "actin_chain", "tail_region", "direct_nonactin_3A",
        "direct_nonactin_5A", "status",
    ]
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} rows to {OUT}")


if __name__ == "__main__":
    main()
