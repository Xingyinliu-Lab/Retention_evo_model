# top_recurrent_direct_tail_binding_proteins

- Manuscript panel: Supp.Fig.7C
- Source figure basename: fig04_top_recurrent_direct_tail_binding_proteins
- Package type: data
- Inclusion status: included
- Packaging rule: files were copied; original analysis files were not moved or modified.

## Contents
- figure/: 2 final figure asset(s)
- code/: 9 plotting or rendering script(s) located by exact output reference or local provenance
- data/: 55 directly referenced or locally packaged source-data file(s)
