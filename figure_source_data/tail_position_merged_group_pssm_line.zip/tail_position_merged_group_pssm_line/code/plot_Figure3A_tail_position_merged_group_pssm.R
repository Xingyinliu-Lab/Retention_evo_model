# ============================================================
# Figure 3A (merged groups): position-wise eukaryotic-tail PSSM score
#
# Read-only inputs:
#   tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv
#   euk_tail_hmm386_410_pssm.tsv
#   Figure2C_tail_euk_pssm_distribution_merged_groups/group_mapping.tsv
#
# At each HMM386-410 position, score = log2(P_euk[observed AA]).
# Gap, missing position, and non-standard residue score = -6.0.
# The group score is the mean across all member sequences at that position.
# Output: PDF + PNG preview + audit TSVs only (no SVG/TIFF).
# ============================================================

suppressPackageStartupMessages({ library(ggplot2); library(dplyr); library(scales) })

PROJECT_DIR <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
SEQUENCE_INPUT <- file.path(PROJECT_DIR, "tail_hmm386_410_position_tail_euk_pssm_score_gap_penalty.tsv")
PSSM_INPUT <- file.path(PROJECT_DIR, "euk_tail_hmm386_410_pssm.tsv")
MAPPING_INPUT <- file.path(PROJECT_DIR, "Figure2C_tail_euk_pssm_distribution_merged_groups", "group_mapping.tsv")
OUTPUT_ROOT <- file.path(PROJECT_DIR, "Figure3A_tail_position_merged_group_pssm")
HMM_START <- 386L; HMM_END <- 410L; GAP_PENALTY <- -6.0

GROUP_ORDER <- c("Eukaryota_actin", "Asgard_high_euk_like", "Asgard_intermediate", "Asgard_low_divergent", "Asgard_short_or_missing", "Thermoproteota_canonical")
GROUP_LABELS <- c(
  "Eukaryota_actin" = "Eukaryota actin", "Asgard_high_euk_like" = "Asgard high euk-like",
  "Asgard_intermediate" = "Asgard intermediate", "Asgard_low_divergent" = "Asgard low divergent",
  "Asgard_short_or_missing" = "Asgard short/missing", "Thermoproteota_canonical" = "Thermoproteota canonical"
)
GROUP_COLORS <- c(
  "Eukaryota_actin" = "#C73E32", "Asgard_high_euk_like" = "#009E73",
  "Asgard_intermediate" = "#E69F00", "Asgard_low_divergent" = "#0072B2",
  "Asgard_short_or_missing" = "#6D6D6D", "Thermoproteota_canonical" = "#7B61A8"
)
AA <- strsplit("ACDEFGHIKLMNPQRSTVWY", "")[[1]]

write_tsv <- function(x, file) utils::write.table(x, file, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
theme_nature <- function(base_size = 7) theme_classic(base_size = base_size, base_family = "sans") + theme(
  axis.line = element_line(linewidth = 0.35, colour = "black"), axis.ticks = element_line(linewidth = 0.35, colour = "black"),
  axis.ticks.length = grid::unit(1.4, "mm"), axis.title = element_text(size = base_size), axis.text = element_text(size = base_size - 0.3),
  legend.title = element_text(size = base_size - 0.2), legend.text = element_text(size = base_size - 0.5), panel.grid = element_blank(), plot.margin = margin(4, 5, 4, 5)
)

if (!all(file.exists(c(SEQUENCE_INPUT, PSSM_INPUT, MAPPING_INPUT)))) stop("One or more read-only inputs are missing.")
dir.create(OUTPUT_ROOT, recursive = TRUE, showWarnings = FALSE)

seq_df <- read.delim(SEQUENCE_INPUT, sep = "\t", quote = "", comment.char = "", stringsAsFactors = FALSE)
pssm_df <- read.delim(PSSM_INPUT, sep = "\t", quote = "", comment.char = "", stringsAsFactors = FALSE)
mapping_df <- read.delim(MAPPING_INPUT, sep = "\t", quote = "", comment.char = "", stringsAsFactors = FALSE)
if (!all(c("seq", "compare_group", "tail_aligned", "tail_euk_pssm_score_gap_penalty") %in% names(seq_df))) stop("Sequence score input lacks required columns.")
if (!all(c("pos", paste0("p_", AA)) %in% names(pssm_df))) stop("PSSM input lacks position or amino-acid probability columns.")
if (!all(c("compare_group_original", "compare_group_merged") %in% names(mapping_df))) stop("Group mapping input lacks required columns.")

pssm_df <- pssm_df %>% filter(pos >= 1L, pos <= (HMM_END - HMM_START + 1L)) %>% arrange(pos)
if (nrow(pssm_df) != 25L) stop("PSSM must contain exactly 25 tail positions.")

seq_df <- seq_df %>%
  transmute(seq = as.character(seq), compare_group_original = as.character(compare_group), tail_aligned = as.character(tail_aligned),
            frozen_full_score = suppressWarnings(as.numeric(tail_euk_pssm_score_gap_penalty))) %>%
  inner_join(mapping_df, by = "compare_group_original") %>%
  filter(compare_group_merged %in% GROUP_ORDER)

if (anyDuplicated(seq_df$seq)) stop("Duplicated sequence identifiers occur after mapping; cannot calculate a sequence-level mean unambiguously.")

score_one_position <- function(tail, pos) {
  chars <- strsplit(tail, "", fixed = TRUE)[[1]]
  if (length(chars) < pos) return(GAP_PENALTY)
  aa <- chars[pos]
  if (!aa %in% AA) return(GAP_PENALTY)
  p <- pssm_df[pssm_df$pos == pos, paste0("p_", aa)]
  if (length(p) != 1L || is.na(p)) return(GAP_PENALTY)
  log2(max(p, 1e-6))
}

position_scores <- lapply(seq_len(nrow(seq_df)), function(i) {
  score <- vapply(seq_len(25L), function(pos) score_one_position(seq_df$tail_aligned[i], pos), numeric(1))
  data.frame(seq = seq_df$seq[i], compare_group_original = seq_df$compare_group_original[i], compare_group_merged = seq_df$compare_group_merged[i],
             tail_position = seq_len(25L), hmm_pos = HMM_START + seq_len(25L) - 1L, position_pssm_score_gap_penalty = score, stringsAsFactors = FALSE)
}) %>% bind_rows()

sequence_check <- position_scores %>% group_by(seq) %>% summarise(recalculated_full_score = mean(position_pssm_score_gap_penalty), .groups = "drop") %>%
  left_join(seq_df %>% select(seq, frozen_full_score), by = "seq") %>%
  mutate(abs_difference = abs(recalculated_full_score - frozen_full_score))
if (max(sequence_check$abs_difference, na.rm = TRUE) > 1e-10) stop("Position-wise PSSM reconstruction does not match frozen full-tail scores.")

group_n <- seq_df %>% count(compare_group_merged, name = "n_seq") %>% mutate(compare_group_merged = factor(compare_group_merged, levels = GROUP_ORDER),
  group_label = paste0(GROUP_LABELS[as.character(compare_group_merged)], " (n=", n_seq, ")")) %>% arrange(compare_group_merged)

df_plot <- position_scores %>% group_by(compare_group_merged, tail_position, hmm_pos) %>%
  summarise(position_pssm_score_gap_penalty = mean(position_pssm_score_gap_penalty), .groups = "drop") %>%
  mutate(compare_group_merged = factor(compare_group_merged, levels = GROUP_ORDER)) %>% left_join(group_n, by = "compare_group_merged") %>%
  mutate(group_label = factor(group_label, levels = group_n$group_label)) %>% arrange(compare_group_merged, hmm_pos)

group_summary <- df_plot %>% group_by(compare_group_merged, group_label, n_seq) %>% summarise(
  mean_position_score = mean(position_pssm_score_gap_penalty), min_position_score = min(position_pssm_score_gap_penalty), max_position_score = max(position_pssm_score_gap_penalty), .groups = "drop")
label_colours <- setNames(GROUP_COLORS[as.character(group_n$compare_group_merged)], group_n$group_label)

p <- ggplot(df_plot, aes(hmm_pos, position_pssm_score_gap_penalty, colour = group_label, group = group_label)) +
  geom_line(linewidth = 0.8, alpha = 0.95) + geom_point(size = 1.3, alpha = 0.95) +
  geom_hline(yintercept = GAP_PENALTY, linetype = "dashed", linewidth = 0.3, colour = "#7A7A7A") +
  scale_colour_manual(values = label_colours, drop = FALSE) +
  scale_x_continuous(breaks = seq(HMM_START, HMM_END, 2), minor_breaks = seq(HMM_START, HMM_END), expand = expansion(mult = c(0.01, 0.01))) +
  scale_y_continuous(expand = expansion(mult = c(0.03, 0.06))) +
  labs(x = "PF00022 HMM position (386–410)", y = "Mean position-wise eukaryotic-tail PSSM score", colour = "Merged comparison group",
       title = "Position-wise eukaryotic-tail PSSM scores across merged comparison groups",
       subtitle = "Each point is the mean log2 probability at one aligned position; gap, missing, or non-standard residue = −6",
       caption = "Dashed line, gap/missing penalty (−6).") +
  theme_nature() + theme(legend.position = "right", legend.key.height = grid::unit(3.2, "mm"))

fig_name <- "figure_3A_tail_position_merged_group_pssm_line"; fig_dir <- file.path(OUTPUT_ROOT, fig_name); dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
stem <- file.path(fig_dir, fig_name); width_in <- 180 / 25.4; height_in <- 95 / 25.4
if (capabilities("cairo")) grDevices::cairo_pdf(paste0(stem, ".pdf"), width = width_in, height = height_in, family = "sans") else grDevices::pdf(paste0(stem, ".pdf"), width = width_in, height = height_in, family = "sans")
print(p); grDevices::dev.off()
grDevices::png(paste0(stem, "_preview.png"), width = width_in, height = height_in, units = "in", res = 300, type = "cairo", bg = "white"); print(p); grDevices::dev.off()

config <- data.frame(parameter = c("sequence_input", "pssm_input", "mapping_input", "per_position_formula", "gap_missing_nonstandard_penalty", "group_score", "validation", "hmm_range", "output_formats"),
 value = c(SEQUENCE_INPUT, PSSM_INPUT, MAPPING_INPUT, "standard AA: log2(P_euk[AA])", GAP_PENALTY, "mean of all member sequence scores at each HMM position", "mean of 25 position scores equals frozen full-tail gap-penalty score; max absolute difference <= 1e-10", "386-410", "PDF; PNG preview"), stringsAsFactors = FALSE)
write_tsv(df_plot, file.path(fig_dir, "source_data_position_scores.tsv")); write_tsv(group_summary, file.path(fig_dir, "group_position_score_summary.tsv")); write_tsv(sequence_check, file.path(fig_dir, "frozen_full_score_reconstruction_audit.tsv")); write_tsv(mapping_df, file.path(fig_dir, "original_to_merged_group_mapping.tsv")); write_tsv(config, file.path(fig_dir, "plot_config.tsv")); write_tsv(config, file.path(OUTPUT_ROOT, "run_summary.tsv")); write_tsv(data.frame(figure = fig_name, folder = fig_dir, pdf = paste0(stem, ".pdf"), png_preview = paste0(stem, "_preview.png")), file.path(OUTPUT_ROOT, "figure_output_index.tsv"))
message("Done: ", fig_dir)
